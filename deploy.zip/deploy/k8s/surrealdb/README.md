# SurrealDB on AKS via Nexus — setup guide

SurrealDB is a **standalone database server** (a Rust binary shipped as a
container image), **not** an npm/PyPI library. There are two artifacts to get
through Nexus, and they come from two different ecosystems:

| Artifact | Type | Nexus repo type | Used by |
|---|---|---|---|
| `surrealdb/surrealdb:v2` | Docker image (the **server**) | Docker (proxy or hosted) | runs as the StatefulSet here |
| `surrealdb`, `surreal-commands` | PyPI wheels (the **client driver**) | PyPI (proxy) | `pip/uv install` into the DocEX API image |

There is **no npm package** for SurrealDB. npm in Nexus is only relevant if you
also build the frontend there — unrelated to the database.

---

## 1. Mirror the server image into Nexus

From a host that can reach both Docker Hub and Nexus (or your approved mirror
pipeline). Pin a digest for a regulated environment.

```bash
docker pull surrealdb/surrealdb:v2
# capture the digest you pulled:
docker images --digests | grep surrealdb

docker tag  surrealdb/surrealdb:v2 \
            nexus.ubs.com:8443/docker-hosted/surrealdb/surrealdb:v2
docker push nexus.ubs.com:8443/docker-hosted/surrealdb/surrealdb:v2
```

Create the pull secret AKS uses to authenticate to Nexus:

```bash
kubectl create secret docker-registry nexus-docker-pull \
  --namespace docex \
  --docker-server=nexus.ubs.com:8443 \
  --docker-username='<nexus-user>' \
  --docker-password='<nexus-token>'
```

(Update the `image:` in `02-statefulset.yaml` to your real Nexus host/path, and
prefer `...@sha256:<digest>` over the `:v2` tag.)

## 2. Proxy the Python driver through Nexus

The DocEX **API image** build installs the client driver. Point pip/uv at Nexus:

```ini
# pip.conf  (or set UV_INDEX_URL for uv)
[global]
index-url = https://nexus.ubs.com/repository/pypi-proxy/simple
trusted-host = nexus.ubs.com
```

```bash
uv pip install "surrealdb>=1.0.4" "surreal-commands>=1.3.1,<2"
# (these are already in pyproject.toml — this just resolves them via Nexus)
```

## 3. Deploy the database

```bash
# secrets first — copy the example, fill in real values, do NOT commit the filled file
cp 01-secret.example.yaml 01-secret.yaml
$EDITOR 01-secret.yaml          # set strong SURREAL_PASS + OPEN_NOTEBOOK_ENCRYPTION_KEY

kubectl apply -f 00-namespace.yaml
kubectl apply -f 01-secret.yaml        # or apply via Key Vault CSI / Sealed Secrets
kubectl apply -f 02-statefulset.yaml
kubectl apply -f 03-service.yaml

kubectl -n docex rollout status statefulset/surrealdb
kubectl -n docex get pvc,pod,svc
```

Confirm the storage class name first — `managed-csi-premium` is a sensible AKS
default but UBS may use a custom one:

```bash
kubectl get storageclass
```

## 4. Wire the app to the DB

The DocEX API connects over the in-cluster DNS name. Paste the env block from
`04-app-connection.snippet.yaml` into your API Deployment. **No manual schema
step** — `AsyncMigrationManager` runs migrations automatically on API startup.
Watch the API logs on first boot to confirm migrations applied.

Connection string the app will use:

```
ws://surrealdb.docex.svc.cluster.local:8000/rpc
```

---

## Operational notes / gotchas

- **Single writer.** RocksDB is embedded + single-writer → keep `replicas: 1`.
  For HA you would move to SurrealDB's TiKV backend (a separate, heavier setup) —
  out of scope here and flagged as a maturity risk in our design context (§9F).
- **Backups = back up the PVC.** The data is the `data` volume. Use Velero or
  Azure Disk snapshots; SurrealDB also supports `surreal export` for logical dumps.
- **Never expose 8000 outside the cluster.** Only the DocEX API should reach it.
  No Ingress / LoadBalancer on this service.
- **Encryption key is load-bearing.** `OPEN_NOTEBOOK_ENCRYPTION_KEY` decrypts
  stored provider API keys. Lose/rotate it and stored credentials become unreadable.
- **Auth is still root user/pass.** This stands up the DB; it does NOT add the
  Entra→JWT / per-user scoping the UBS integration needs (that's the net-new
  work tracked in our design docs, not part of standing up the database).
- **Pin versions for a bank.** Replace floating `:v2` with an image digest and a
  pinned driver version once you've validated.
```
