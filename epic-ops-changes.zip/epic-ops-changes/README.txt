Epic Ops — changed files (branch feature/epic-ops, commits a634166..9f80bdf)
Base: d7e1f6a (tip of feature/brp-trustworthy-sizing — apply BRP changes first if not present).

Apply options at remote:
  A) git apply epic-ops.patch          (from repo root)
  B) copy the files under src/, docs/, .taskmaster/ over your tree

Contents: new src/services/epicOps + src/components/epicOps modules; edits to
ViewRouter, WelcomeSidebar, WorkspaceSidebar, uiStore (TabId), brp/auditLog
(new audit kinds); design doc + PRD + devlogs.
33 files. Generated 2026-07-15.
