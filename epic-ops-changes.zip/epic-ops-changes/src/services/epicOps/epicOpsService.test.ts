import { describe, it, expect, beforeEach, vi } from 'vitest';

vi.mock('../gitlab/gitlabClient', () => ({
  createGitLabEpic: vi.fn(),
  createGitLabIssue: vi.fn(),
  fetchEpicIssues: vi.fn(),
  fetchGroupEpics: vi.fn(),
  linkIssueToEpic: vi.fn(),
}));

import {
  createGitLabEpic,
  createGitLabIssue,
  fetchEpicIssues,
  fetchGroupEpics,
  linkIssueToEpic,
} from '../gitlab/gitlabClient';
import {
  cloneEpicAsTemplate,
  cloneIssue,
  fetchOpenEpicIssues,
  findDuplicateEpicTitle,
} from './epicOpsService';
import type { GitLabConfig } from '../../domain/configTypes';
import type { GitLabEpic, GitLabIssue } from '../gitlab/types';

const mockCreateEpic = vi.mocked(createGitLabEpic);
const mockCreateIssue = vi.mocked(createGitLabIssue);
const mockFetchEpicIssues = vi.mocked(fetchEpicIssues);
const mockFetchGroupEpics = vi.mocked(fetchGroupEpics);
const mockLink = vi.mocked(linkIssueToEpic);

const config: GitLabConfig = {
  enabled: true, rootGroupId: '42', streamGroupId: '', accessToken: 't',
  authMode: 'pat' as GitLabConfig['authMode'],
};

const sourceEpic: GitLabEpic = {
  id: 900, iid: 151, title: 'Saved payment methods', description: 'epic body',
  state: 'opened', web_url: 'https://gl/epics/151', labels: ['payments'],
  created_at: '', updated_at: '', group_id: 101,
};

function issue(id: number, state = 'opened', weight: number | null = 5): GitLabIssue {
  return {
    id, iid: id, title: `Issue ${id}`, description: 'AC body', state,
    web_url: `https://gl/issues/${id}`, labels: ['payments'],
    assignee: { id: 9, name: 'Dev', username: 'dev' } as GitLabIssue['assignee'],
    weight,
  };
}

const newEpic: GitLabEpic = { ...sourceEpic, id: 1000, iid: 12, title: '[Template] Saved payment methods', web_url: 'https://gl/epics/12', group_id: 200 };

const input = {
  sourceEpic,
  openIssues: [issue(501), issue(502, 'opened', 8)],
  destinationGroupId: '200',
  destinationProjectId: '555',
  newTitle: '[Template] Saved payment methods',
};

beforeEach(() => {
  vi.clearAllMocks();
  mockCreateEpic.mockResolvedValue({ success: true, data: newEpic });
  mockCreateIssue
    .mockResolvedValueOnce({ success: true, data: issue(601) })
    .mockResolvedValueOnce({ success: true, data: issue(602) });
  mockLink.mockResolvedValue({ success: true });
});

describe('cloneEpicAsTemplate (T2)', () => {
  it('creates the epic then creates + links every open issue', async () => {
    const res = await cloneEpicAsTemplate(config, input);
    expect(res.success).toBe(true);
    if (!res.success) return;
    expect(mockCreateEpic).toHaveBeenCalledWith(config, {
      title: '[Template] Saved payment methods',
      description: 'epic body',
      labels: ['payments'],
      group_id: '200',
    });
    expect(mockCreateIssue).toHaveBeenCalledTimes(2);
    expect(mockLink).toHaveBeenCalledTimes(2);
    expect(res.data.epic).toEqual({ id: 1000, iid: 12, webUrl: 'https://gl/epics/12' });
    expect(res.data.created).toHaveLength(2);
    expect(res.data.failures).toHaveLength(0);
  });

  it('applies the D2 strip mapping to created issues (no assignee/iteration keys)', async () => {
    await cloneEpicAsTemplate(config, input);
    const payload = mockCreateIssue.mock.calls[0]![2];
    expect(payload).toEqual({ title: 'Issue 501', description: 'AC body', labels: ['payments'], weight: 5 });
  });

  it('skips closed issues even if the caller passes them', async () => {
    await cloneEpicAsTemplate(config, { ...input, openIssues: [issue(501), issue(777, 'closed')] });
    expect(mockCreateIssue).toHaveBeenCalledTimes(1);
  });

  it('aborts on epic-creation failure — no issue writes (nothing orphaned)', async () => {
    mockCreateEpic.mockReset().mockResolvedValue({ success: false, error: 'GitLab API error (403): no' });
    const res = await cloneEpicAsTemplate(config, input);
    expect(res.success).toBe(false);
    if (res.success) return;
    expect(res.error.code).toBe('auth');
    expect(mockCreateIssue).not.toHaveBeenCalled();
  });

  it('collects a per-issue create failure and continues (INV2)', async () => {
    mockCreateIssue.mockReset()
      .mockResolvedValueOnce({ success: false, error: 'GitLab API error (500): boom' })
      .mockResolvedValueOnce({ success: true, data: issue(602) });
    const res = await cloneEpicAsTemplate(config, input);
    expect(res.success).toBe(true);
    if (!res.success) return;
    expect(res.data.failures).toHaveLength(1);
    expect(res.data.created).toHaveLength(1);
  });

  it('records a link failure as a failure item', async () => {
    mockLink.mockReset()
      .mockResolvedValueOnce({ success: false, error: 'GitLab API error (404): nope' })
      .mockResolvedValueOnce({ success: true });
    const res = await cloneEpicAsTemplate(config, input);
    if (!res.success) return;
    expect(res.data.failures).toHaveLength(1);
    expect(res.data.failures[0]!.error).toMatch(/404/);
  });
});

describe('cloneIssue (T3)', () => {
  it('creates the clone standalone — never links to an epic (D2)', async () => {
    mockCreateIssue.mockReset().mockResolvedValue({ success: true, data: issue(700) });
    const res = await cloneIssue(config, {
      sourceIssue: issue(501),
      destinationProjectId: '555',
      newTitle: '[Clone] Issue 501',
    });
    expect(res.success).toBe(true);
    if (!res.success) return;
    const payload = mockCreateIssue.mock.calls[0]![2];
    expect(payload.title).toBe('[Clone] Issue 501');
    expect(mockLink).not.toHaveBeenCalled();
    expect(res.data.created[0]!.id).toBe(700);
  });

  it('propagates a create failure', async () => {
    mockCreateIssue.mockReset().mockResolvedValue({ success: false, error: 'GitLab API error (429): slow down' });
    const res = await cloneIssue(config, { sourceIssue: issue(501), destinationProjectId: '555', newTitle: 'x' });
    expect(res.success).toBe(false);
    if (res.success) return;
    expect(res.error.code).toBe('ratelimit');
  });
});

describe('read helpers (preview side, INV1)', () => {
  it('fetchOpenEpicIssues filters to opened', async () => {
    mockFetchEpicIssues.mockResolvedValue({ success: true, data: [issue(1), issue(2, 'closed')] });
    const res = await fetchOpenEpicIssues(config, '101', 151);
    if (!res.success) return;
    expect(res.data.map((i) => i.id)).toEqual([1]);
  });

  it('findDuplicateEpicTitle detects an existing title case-insensitively', async () => {
    mockFetchGroupEpics.mockResolvedValue({ success: true, data: [newEpic] });
    const dup = await findDuplicateEpicTitle(config, '200', '[template] saved PAYMENT methods');
    const fresh = await findDuplicateEpicTitle(config, '200', 'Totally new');
    expect(dup.success && dup.data).toBe(true);
    expect(fresh.success && fresh.data).toBe(false);
  });
});
