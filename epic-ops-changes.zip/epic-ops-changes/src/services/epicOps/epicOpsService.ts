/**
 * Epic Ops — GitLab service layer (Tasks 2–3).
 *
 * Thin orchestration over the EXISTING gitlabClient primitives (INV4 — no
 * new HTTP), mirroring brpGitlabService's Result<T> error-code pattern.
 *
 * Execution is best-effort with a per-item report (INV2): GitLab has no
 * bulk-rollback API, so an epic-creation failure aborts (nothing orphaned)
 * while per-issue failures are collected and surfaced with Retry.
 */

import type { GitLabConfig } from '../../domain/configTypes';
import type { GitLabIssue } from '../gitlab/types';
import {
  createGitLabEpic,
  createGitLabIssue,
  fetchEpicIssues,
  fetchGroupEpics,
  linkIssueToEpic,
} from '../gitlab/gitlabClient';
import { hasDuplicateTitle, mapIssueForClone, onlyOpenIssues } from './cloneMapping';
import type { CloneEpicInput, CloneIssueInput, CloneReport, ReportItem } from './types';

// ─── Result pattern (same shape as brpGitlabService) ────────

export type ResultErrorCode = 'auth' | 'ratelimit' | 'network' | 'unknown';
export interface ResultError {
  code: ResultErrorCode;
  message: string;
}
export type Result<T> = { success: true; data: T } | { success: false; error: ResultError };

function classify(raw: string | undefined): ResultErrorCode {
  if (!raw) return 'unknown';
  const m = raw.match(/\((\d{3})\)/);
  if (m?.[1]) {
    const s = parseInt(m[1], 10);
    if (s === 401 || s === 403) return 'auth';
    if (s === 429) return 'ratelimit';
    if (s >= 500) return 'network';
  }
  if (/network|fetch failed|enotfound|econnrefused|timeout/i.test(raw)) return 'network';
  return 'unknown';
}

function err<T>(raw: string | undefined, fallback: string): Result<T> {
  return { success: false, error: { code: classify(raw), message: raw ?? fallback } };
}

// ─── Read helpers (preview side, INV1 — no writes) ──────────

/** OPEN issues of an epic (closed ones are stripped by rule, D2). */
export async function fetchOpenEpicIssues(
  config: GitLabConfig,
  groupId: string,
  epicIid: number,
): Promise<Result<GitLabIssue[]>> {
  const res = await fetchEpicIssues(config, groupId, epicIid);
  if (!res.success) return err(res.error, 'Failed to fetch epic issues');
  return { success: true, data: onlyOpenIssues(res.data ?? []) };
}

/** D4 guard: does the destination group already hold an epic with this title? */
export async function findDuplicateEpicTitle(
  config: GitLabConfig,
  destinationGroupId: string,
  title: string,
): Promise<Result<boolean>> {
  const res = await fetchGroupEpics(config, destinationGroupId, { per_page: 100 });
  if (!res.success) return err(res.error, 'Failed to check destination for duplicates');
  const titles = (res.data ?? []).map((e) => e.title);
  return { success: true, data: hasDuplicateTitle(titles, title) };
}

// ─── Execution (confirm side) ───────────────────────────────

/**
 * Create + link a set of (already-open) issues into an EXISTING epic.
 * Shared by the initial clone and by the result modal's Retry (which
 * re-runs only the failed subset — never re-creates the epic).
 */
export async function cloneIssuesIntoEpic(
  config: GitLabConfig,
  args: {
    destinationGroupId: string;
    destinationProjectId: string;
    epicIid: number;
    issues: readonly GitLabIssue[];
  },
): Promise<{ created: ReportItem[]; failures: ReportItem[] }> {
  const created: ReportItem[] = [];
  const failures: ReportItem[] = [];

  for (const source of onlyOpenIssues(args.issues)) {
    const mapped = mapIssueForClone(source);
    const issueRes = await createGitLabIssue(config, args.destinationProjectId, mapped);
    if (!issueRes.success || !issueRes.data) {
      failures.push({ title: mapped.title, ok: false, error: issueRes.error ?? 'Failed to create issue' });
      continue;
    }
    const linkRes = await linkIssueToEpic(config, args.destinationGroupId, args.epicIid, issueRes.data.id);
    if (!linkRes.success) {
      failures.push({ title: mapped.title, ok: false, id: issueRes.data.id, error: linkRes.error ?? 'Failed to link issue to epic' });
      continue;
    }
    created.push({ title: mapped.title, ok: true, id: issueRes.data.id, webUrl: issueRes.data.web_url });
  }
  return { created, failures };
}

/**
 * Clone an epic as a template (Task 2, D2 fixed rules): create the epic in
 * the destination group with the (renamed) title + original description,
 * then create + link each OPEN issue via `mapIssueForClone` (assignees,
 * iterations, epic-specific noise stripped by construction).
 */
export async function cloneEpicAsTemplate(
  config: GitLabConfig,
  input: CloneEpicInput,
): Promise<Result<CloneReport>> {
  const epicRes = await createGitLabEpic(config, {
    title: input.newTitle.trim(),
    description: input.sourceEpic.description ?? '',
    labels: input.sourceEpic.labels ?? [],
    group_id: input.destinationGroupId,
  });
  if (!epicRes.success || !epicRes.data) {
    return err(epicRes.error, 'Failed to create the template epic');
  }
  const epic = epicRes.data;

  const { created, failures } = await cloneIssuesIntoEpic(config, {
    destinationGroupId: input.destinationGroupId,
    destinationProjectId: input.destinationProjectId,
    epicIid: epic.iid,
    issues: input.openIssues,
  });

  return {
    success: true,
    data: {
      epic: { id: epic.id, iid: epic.iid, webUrl: epic.web_url },
      created,
      failures,
    },
  };
}

/**
 * Clone a single issue (Task 3): create it standalone in the destination
 * project — deliberately NO `linkIssueToEpic` (D2: epic link stripped).
 */
export async function cloneIssue(
  config: GitLabConfig,
  input: CloneIssueInput,
): Promise<Result<CloneReport>> {
  const mapped = mapIssueForClone(input.sourceIssue, input.newTitle);
  const res = await createGitLabIssue(config, input.destinationProjectId, mapped);
  if (!res.success || !res.data) {
    return err(res.error, 'Failed to create the cloned issue');
  }
  return {
    success: true,
    data: {
      created: [{ title: mapped.title, ok: true, id: res.data.id, webUrl: res.data.web_url }],
      failures: [],
    },
  };
}
