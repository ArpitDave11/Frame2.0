import { describe, it, expect } from 'vitest';
import {
  cloneTitle,
  hasDuplicateTitle,
  mapIssueForClone,
  onlyOpenIssues,
  templateTitle,
} from './cloneMapping';
import type { GitLabIssue } from '../gitlab/types';

function issue(overrides: Partial<GitLabIssue> = {}): GitLabIssue {
  return {
    id: 501,
    iid: 501,
    title: 'Tokenise card details',
    description: '### Acceptance criteria\n- [ ] token stored',
    state: 'opened',
    web_url: 'https://gl/issues/501',
    labels: ['payments', 'backend'],
    assignee: { id: 9, name: 'Dev A', username: 'deva' } as GitLabIssue['assignee'],
    weight: 5,
    iteration: { id: 3, iid: 3, title: 'IT-12' } as GitLabIssue['iteration'],
    ...overrides,
  };
}

describe('title prefixing (D4)', () => {
  it('templateTitle prefixes and trims', () => {
    expect(templateTitle('  Saved payment methods ')).toBe('[Template] Saved payment methods');
  });
  it('cloneTitle prefixes and trims', () => {
    expect(cloneTitle('Tokenise card details')).toBe('[Clone] Tokenise card details');
  });
});

describe('mapIssueForClone (D2 fixed rules)', () => {
  it('keeps title/description/labels/weight — and nothing else', () => {
    const m = mapIssueForClone(issue());
    expect(m).toEqual({
      title: 'Tokenise card details',
      description: '### Acceptance criteria\n- [ ] token stored',
      labels: ['payments', 'backend'],
      weight: 5,
    });
    // Strip-by-construction: no assignee/iteration/state keys exist at all.
    expect(Object.keys(m).sort()).toEqual(['description', 'labels', 'title', 'weight']);
  });

  it('applies a rename when newTitle is provided', () => {
    expect(mapIssueForClone(issue(), '[Clone] My renamed issue ').title).toBe('[Clone] My renamed issue');
  });

  it('omits weight when the source has none and defaults null description', () => {
    const m = mapIssueForClone(issue({ weight: null, description: undefined }));
    expect(m.description).toBe('');
    expect('weight' in m).toBe(false);
  });

  it('copies labels defensively (not the same array reference)', () => {
    const src = issue();
    const m = mapIssueForClone(src);
    expect(m.labels).not.toBe(src.labels);
  });
});

describe('hasDuplicateTitle (D4 guard)', () => {
  const existing = ['[Template] Saved payment methods', 'Guest checkout flow'];
  it('matches case-insensitively and trimmed', () => {
    expect(hasDuplicateTitle(existing, '  [template] SAVED payment methods ')).toBe(true);
  });
  it('returns false for a fresh title', () => {
    expect(hasDuplicateTitle(existing, '[Template] Saved payment methods v2')).toBe(false);
  });
  it('handles an empty destination', () => {
    expect(hasDuplicateTitle([], 'anything')).toBe(false);
  });
});

describe('onlyOpenIssues (D2: closed issues stripped)', () => {
  it('filters to state=opened', () => {
    const list = [issue({ id: 1, state: 'opened' }), issue({ id: 2, state: 'closed' }), issue({ id: 3, state: 'opened' })];
    expect(onlyOpenIssues(list).map((i) => i.id)).toEqual([1, 3]);
  });
});
