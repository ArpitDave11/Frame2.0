/**
 * Epic Ops — actions layer (Task 4).
 *
 * The ONLY seam Epic Ops components may call (INV3 — no direct store reads
 * in components). Splits the flow into a read-only PREVIEW side (INV1: zero
 * GitLab writes) and an EXECUTE side that performs the writes and records
 * an audit entry (INV5).
 */

import { useConfigStore } from '@/stores/configStore';
import { recordAudit } from '../brp/auditLog';
import {
  fetchGitLabSubgroups,
  fetchGroupEpics,
  fetchGroupIssues,
  fetchGroupProjects,
} from '../gitlab/gitlabClient';
import type { GitLabEpic, GitLabIssue, GitLabProject, GitLabSubgroup } from '../gitlab/types';
import {
  cloneEpicAsTemplate,
  cloneIssue,
  cloneIssuesIntoEpic,
  fetchOpenEpicIssues,
  findDuplicateEpicTitle,
} from './epicOpsService';
import type { ReportItem } from './types';
import type { Result, ResultError } from './epicOpsService';
import type { CloneEpicInput, CloneIssueInput, ClonePlan, CloneReport, PlanItem } from './types';

/** Same guard as brpActions: GitLab must be enabled in settings. */
function readGitLabConfig() {
  const cfg = useConfigStore.getState().config.gitlab;
  if (!cfg.enabled) {
    throw new Error('GitLab integration is disabled in settings');
  }
  return cfg;
}

function actionError<T>(message: string): Result<T> {
  const error: ResultError = { code: 'unknown', message };
  return { success: false, error };
}

// ─── Source / destination loading (D3: root-subtree scope) ──

/** Destination groups = subgroups of the configured root group only (D3). */
export async function loadDestinationGroupsAction(): Promise<Result<GitLabSubgroup[]>> {
  let cfg;
  try { cfg = readGitLabConfig(); } catch (e) { return actionError(e instanceof Error ? e.message : String(e)); }
  const res = await fetchGitLabSubgroups(cfg, cfg.rootGroupId);
  if (!res.success) return actionError(res.error ?? 'Failed to load groups');
  return { success: true, data: res.data ?? [] };
}

/** Source epics of a chosen group (candidates to clone). */
export async function loadSourceEpicsAction(groupId: string): Promise<Result<GitLabEpic[]>> {
  let cfg;
  try { cfg = readGitLabConfig(); } catch (e) { return actionError(e instanceof Error ? e.message : String(e)); }
  const res = await fetchGroupEpics(cfg, groupId, { per_page: 100 });
  if (!res.success) return actionError(res.error ?? 'Failed to load epics');
  return { success: true, data: res.data ?? [] };
}

/** Projects under a group (destination for cloned issues). */
export async function loadGroupProjectsAction(groupId: string): Promise<Result<GitLabProject[]>> {
  let cfg;
  try { cfg = readGitLabConfig(); } catch (e) { return actionError(e instanceof Error ? e.message : String(e)); }
  const res = await fetchGroupProjects(cfg, groupId, { includeSubgroups: true });
  if (!res.success) return actionError(res.error ?? 'Failed to load projects');
  return { success: true, data: (res.data ?? []).filter((p) => p.issues_enabled !== false) };
}

/** Source issues (open) of a chosen group — single-issue clone candidates. */
export async function loadSourceIssuesAction(groupId: string): Promise<Result<GitLabIssue[]>> {
  let cfg;
  try { cfg = readGitLabConfig(); } catch (e) { return actionError(e instanceof Error ? e.message : String(e)); }
  const res = await fetchGroupIssues(cfg, groupId, { state: 'opened', per_page: 100 });
  if (!res.success) return actionError(res.error ?? 'Failed to load issues');
  return { success: true, data: res.data ?? [] };
}

/** All issue-holding projects under the ROOT group's subtree (D3 destination pool). */
export async function loadDestinationProjectsAction(): Promise<Result<GitLabProject[]>> {
  let cfg;
  try { cfg = readGitLabConfig(); } catch (e) { return actionError(e instanceof Error ? e.message : String(e)); }
  const res = await fetchGroupProjects(cfg, cfg.rootGroupId, { includeSubgroups: true });
  if (!res.success) return actionError(res.error ?? 'Failed to load projects');
  return { success: true, data: (res.data ?? []).filter((p) => p.issues_enabled !== false) };
}

// ─── Preview builders (INV1 — read-only) ────────────────────

function issueToPlanItem(i: GitLabIssue): PlanItem {
  const stripped: string[] = [];
  if (i.assignee || (i.assignees ?? []).length > 0) stripped.push('assignee removed');
  if (i.iteration) stripped.push('iteration removed');
  return {
    title: i.title,
    weight: i.weight ?? null,
    keptNote: 'AC kept',
    strippedNote: stripped.join(' · ') || 'nothing to strip',
  };
}

/**
 * Build the epic-clone preview: fetch the source's OPEN issues + run the
 * duplicate-title guard against the destination. Returns the plan AND the
 * open issues so execute can reuse them without refetching.
 */
export async function buildEpicClonePreviewAction(
  sourceEpic: GitLabEpic,
  sourceGroupId: string,
  destinationGroupId: string,
  destinationLabel: string,
  newTitle: string,
): Promise<Result<{ plan: ClonePlan; openIssues: GitLabIssue[] }>> {
  let cfg;
  try { cfg = readGitLabConfig(); } catch (e) { return actionError(e instanceof Error ? e.message : String(e)); }

  const issuesRes = await fetchOpenEpicIssues(cfg, sourceGroupId, sourceEpic.iid);
  if (!issuesRes.success) return issuesRes;
  const dupRes = await findDuplicateEpicTitle(cfg, destinationGroupId, newTitle);
  if (!dupRes.success) return dupRes;

  const openIssues = issuesRes.data;
  const plan: ClonePlan = {
    title: newTitle.trim(),
    destinationLabel,
    items: openIssues.map(issueToPlanItem),
    // 1 epic create + per issue (create + link).
    writeCount: 1 + openIssues.length * 2,
    duplicateTitle: dupRes.data,
  };
  return { success: true, data: { plan, openIssues } };
}

/** Single-issue preview. (v1: no dup check for issues — epic guard only, see design D4.) */
export function buildIssueClonePreview(
  sourceIssue: GitLabIssue,
  destinationLabel: string,
  newTitle: string,
): ClonePlan {
  return {
    title: newTitle.trim(),
    destinationLabel,
    items: [issueToPlanItem({ ...sourceIssue, title: newTitle.trim() })],
    writeCount: 1,
    duplicateTitle: false,
  };
}

// ─── Execute (writes + audit, INV5) ─────────────────────────

export async function executeCloneEpicAction(input: CloneEpicInput): Promise<Result<CloneReport>> {
  let cfg;
  try { cfg = readGitLabConfig(); } catch (e) { return actionError(e instanceof Error ? e.message : String(e)); }
  const res = await cloneEpicAsTemplate(cfg, input);
  if (res.success) {
    recordAudit(
      'epic-cloned',
      `Cloned "${input.sourceEpic.title}" as "${input.newTitle}" (${res.data.created.length}/${input.openIssues.length} issues) into group ${input.destinationGroupId}`,
      { sourceEpicId: input.sourceEpic.id, newEpicId: res.data.epic?.id ?? 'unknown', failures: res.data.failures.length },
    );
  }
  return res;
}

/**
 * Retry ONLY the failed issues of a prior epic clone, into the epic that was
 * already created (never re-creates the epic — INV2's recovery path).
 */
export async function executeRetryIssuesAction(args: {
  destinationGroupId: string;
  destinationProjectId: string;
  epicIid: number;
  issues: readonly import('../gitlab/types').GitLabIssue[];
}): Promise<Result<{ created: ReportItem[]; failures: ReportItem[] }>> {
  let cfg;
  try { cfg = readGitLabConfig(); } catch (e) { return actionError(e instanceof Error ? e.message : String(e)); }
  const res = await cloneIssuesIntoEpic(cfg, args);
  recordAudit(
    'epic-cloned',
    `Retried ${args.issues.length} failed issue(s) into epic !${args.epicIid} — ${res.created.length} created, ${res.failures.length} still failing`,
    { epicIid: args.epicIid, retried: args.issues.length, stillFailing: res.failures.length },
  );
  return { success: true, data: res };
}

export async function executeCloneIssueAction(input: CloneIssueInput): Promise<Result<CloneReport>> {
  let cfg;
  try { cfg = readGitLabConfig(); } catch (e) { return actionError(e instanceof Error ? e.message : String(e)); }
  const res = await cloneIssue(cfg, input);
  if (res.success) {
    recordAudit(
      'issue-cloned',
      `Cloned issue "${input.sourceIssue.title}" as "${input.newTitle}" into project ${input.destinationProjectId}`,
      { sourceIssueId: input.sourceIssue.id, newIssueId: res.data.created[0]?.id ?? 'unknown' },
    );
  }
  return res;
}
