/**
 * Epic Ops — pure clone-mapping helpers (Task 1).
 *
 * The D2 fixed rules live HERE, in one pure module, so the service, the
 * preview builder, and the UI's KEPT/STRIPPED panels can never disagree
 * about what a clone keeps: title (renamed), description/AC, labels,
 * weight. Everything else (assignees, iteration, epic link, comments,
 * state) is stripped by construction — `MappedIssue` simply has no field
 * for them.
 */

import type { GitLabIssue } from '../gitlab/types';
import type { MappedIssue } from './types';

/** D4 default title for an epic template clone. */
export function templateTitle(original: string): string {
  return `[Template] ${original.trim()}`;
}

/** D4 default title for a single-issue clone. */
export function cloneTitle(original: string): string {
  return `[Clone] ${original.trim()}`;
}

/**
 * Map a source issue to the payload its clone is created with (D2 KEPT
 * set). `newTitle` overrides for single-issue clones; epic-template clones
 * keep each issue's own title.
 */
export function mapIssueForClone(issue: GitLabIssue, newTitle?: string): MappedIssue {
  const mapped: MappedIssue = {
    title: (newTitle ?? issue.title).trim(),
    description: issue.description ?? '',
    labels: [...(issue.labels ?? [])],
  };
  if (issue.weight != null) mapped.weight = issue.weight;
  return mapped;
}

/**
 * D4 duplicate-title guard: case-insensitive, whitespace-trimmed match
 * against the destination's existing titles. Never silently create a twin.
 */
export function hasDuplicateTitle(existingTitles: readonly string[], candidate: string): boolean {
  const norm = candidate.trim().toLowerCase();
  return existingTitles.some((t) => t.trim().toLowerCase() === norm);
}

/** Only issues in state 'opened' survive an epic-template clone (D2). */
export function onlyOpenIssues(issues: readonly GitLabIssue[]): GitLabIssue[] {
  return issues.filter((i) => i.state === 'opened');
}
