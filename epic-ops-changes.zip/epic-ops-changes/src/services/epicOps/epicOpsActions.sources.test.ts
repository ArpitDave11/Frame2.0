import { describe, it, expect, beforeEach, vi } from 'vitest';

vi.mock('../gitlab/gitlabClient', () => ({
  fetchGitLabSubgroups: vi.fn(),
  fetchGroupEpics: vi.fn(),
  fetchGroupIssues: vi.fn(),
  fetchGroupProjects: vi.fn(),
}));

import { loadDestinationProjectsAction, loadSourceIssuesAction } from './epicOpsActions';
import { fetchGroupIssues, fetchGroupProjects } from '../gitlab/gitlabClient';
import { useConfigStore } from '@/stores/configStore';

const mockIssues = vi.mocked(fetchGroupIssues);
const mockProjects = vi.mocked(fetchGroupProjects);

beforeEach(() => {
  vi.clearAllMocks();
  const cfg = useConfigStore.getState().config;
  useConfigStore.setState({ config: { ...cfg, gitlab: { ...cfg.gitlab, enabled: true, accessToken: 't', rootGroupId: '42' } } });
});

describe('loadSourceIssuesAction (T5)', () => {
  it('fetches OPEN issues of the group', async () => {
    mockIssues.mockResolvedValue({ success: true, data: [] });
    const res = await loadSourceIssuesAction('101');
    expect(res.success).toBe(true);
    expect(mockIssues).toHaveBeenCalledWith(expect.anything(), '101', { state: 'opened', per_page: 100 });
  });
});

describe('loadDestinationProjectsAction (T5, D3 scope)', () => {
  it('fetches the root subtree projects and filters issues-disabled ones', async () => {
    mockProjects.mockResolvedValue({
      success: true,
      data: [
        { id: 1, name: 'web', path_with_namespace: 'p/web', web_url: '#', issues_enabled: true },
        { id: 2, name: 'infra', path_with_namespace: 'p/infra', web_url: '#', issues_enabled: false },
      ],
    });
    const res = await loadDestinationProjectsAction();
    expect(mockProjects).toHaveBeenCalledWith(expect.anything(), '42', { includeSubgroups: true });
    if (!res.success) return;
    expect(res.data.map((p) => p.id)).toEqual([1]);
  });
});
