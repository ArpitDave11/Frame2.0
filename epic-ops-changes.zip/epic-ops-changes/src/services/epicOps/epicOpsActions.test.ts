import { describe, it, expect, beforeEach, vi } from 'vitest';

vi.mock('./epicOpsService', async () => {
  const actual = await vi.importActual<typeof import('./epicOpsService')>('./epicOpsService');
  return {
    ...actual,
    cloneEpicAsTemplate: vi.fn(),
    cloneIssue: vi.fn(),
    fetchOpenEpicIssues: vi.fn(),
    findDuplicateEpicTitle: vi.fn(),
  };
});
vi.mock('../gitlab/gitlabClient', () => ({
  fetchGitLabSubgroups: vi.fn(),
  fetchGroupEpics: vi.fn(),
  fetchGroupProjects: vi.fn(),
}));
vi.mock('../brp/auditLog', () => ({ recordAudit: vi.fn() }));

import {
  buildEpicClonePreviewAction,
  buildIssueClonePreview,
  executeCloneEpicAction,
  executeCloneIssueAction,
} from './epicOpsActions';
import {
  cloneEpicAsTemplate,
  cloneIssue,
  fetchOpenEpicIssues,
  findDuplicateEpicTitle,
} from './epicOpsService';
import { recordAudit } from '../brp/auditLog';
import { useConfigStore } from '@/stores/configStore';
import type { GitLabEpic, GitLabIssue } from '../gitlab/types';

const mockCloneEpic = vi.mocked(cloneEpicAsTemplate);
const mockCloneIssue = vi.mocked(cloneIssue);
const mockOpenIssues = vi.mocked(fetchOpenEpicIssues);
const mockDup = vi.mocked(findDuplicateEpicTitle);
const mockAudit = vi.mocked(recordAudit);

const epic: GitLabEpic = {
  id: 900, iid: 151, title: 'Saved payment methods', description: 'body', state: 'opened',
  web_url: '#', labels: [], created_at: '', updated_at: '', group_id: 101,
};
function issue(id: number): GitLabIssue {
  return {
    id, iid: id, title: `Issue ${id}`, description: 'AC', state: 'opened', web_url: '#',
    labels: [], weight: 5,
    assignee: { id: 9, name: 'Dev', username: 'dev' } as GitLabIssue['assignee'],
  };
}

beforeEach(() => {
  vi.clearAllMocks();
  const cfg = useConfigStore.getState().config;
  useConfigStore.setState({ config: { ...cfg, gitlab: { ...cfg.gitlab, enabled: true, accessToken: 't', rootGroupId: '42' } } });
  mockOpenIssues.mockResolvedValue({ success: true, data: [issue(1), issue(2)] });
  mockDup.mockResolvedValue({ success: true, data: false });
  mockCloneEpic.mockResolvedValue({ success: true, data: { epic: { id: 1000, iid: 12, webUrl: '#' }, created: [{ title: 'Issue 1', ok: true }], failures: [] } });
  mockCloneIssue.mockResolvedValue({ success: true, data: { created: [{ title: 'x', ok: true, id: 700 }], failures: [] } });
});

describe('buildEpicClonePreviewAction (INV1 — read-only)', () => {
  it('builds the plan without any write calls', async () => {
    const res = await buildEpicClonePreviewAction(epic, '101', '200', 'Payments / Templates', '[Template] Saved payment methods');
    expect(res.success).toBe(true);
    if (!res.success) return;
    expect(res.data.plan.writeCount).toBe(5); // 1 epic + 2×(create+link)
    expect(res.data.plan.items).toHaveLength(2);
    expect(res.data.plan.items[0]!.strippedNote).toMatch(/assignee removed/);
    expect(res.data.plan.duplicateTitle).toBe(false);
    expect(mockCloneEpic).not.toHaveBeenCalled(); // zero writes
  });

  it('flags a duplicate title from the guard (D4)', async () => {
    mockDup.mockResolvedValue({ success: true, data: true });
    const res = await buildEpicClonePreviewAction(epic, '101', '200', 'd', 't');
    if (!res.success) return;
    expect(res.data.plan.duplicateTitle).toBe(true);
  });

  it('propagates a fetch failure', async () => {
    mockOpenIssues.mockResolvedValue({ success: false, error: { code: 'network', message: '500' } });
    const res = await buildEpicClonePreviewAction(epic, '101', '200', 'd', 't');
    expect(res.success).toBe(false);
  });
});

describe('buildIssueClonePreview', () => {
  it('is pure and plans exactly one write', () => {
    const plan = buildIssueClonePreview(issue(1), 'payments / web', '[Clone] Issue 1');
    expect(plan.writeCount).toBe(1);
    expect(plan.items[0]!.title).toBe('[Clone] Issue 1');
  });
});

describe('execute actions (INV5 — audit)', () => {
  it('executeCloneEpicAction runs the service once and records epic-cloned audit', async () => {
    const res = await executeCloneEpicAction({
      sourceEpic: epic, openIssues: [issue(1)], destinationGroupId: '200',
      destinationProjectId: '555', newTitle: '[Template] Saved payment methods',
    });
    expect(res.success).toBe(true);
    expect(mockCloneEpic).toHaveBeenCalledTimes(1);
    expect(mockAudit).toHaveBeenCalledWith('epic-cloned', expect.stringContaining('[Template] Saved payment methods'), expect.anything());
  });

  it('executeCloneIssueAction records issue-cloned audit', async () => {
    await executeCloneIssueAction({ sourceIssue: issue(1), destinationProjectId: '555', newTitle: '[Clone] Issue 1' });
    expect(mockAudit).toHaveBeenCalledWith('issue-cloned', expect.stringContaining('[Clone] Issue 1'), expect.anything());
  });

  it('does NOT audit on failure', async () => {
    mockCloneEpic.mockResolvedValue({ success: false, error: { code: 'auth', message: '403' } });
    const res = await executeCloneEpicAction({
      sourceEpic: epic, openIssues: [], destinationGroupId: '200', destinationProjectId: '555', newTitle: 't',
    });
    expect(res.success).toBe(false);
    expect(mockAudit).not.toHaveBeenCalled();
  });

  it('errors cleanly when GitLab is disabled', async () => {
    const cfg = useConfigStore.getState().config;
    useConfigStore.setState({ config: { ...cfg, gitlab: { ...cfg.gitlab, enabled: false } } });
    const res = await executeCloneIssueAction({ sourceIssue: issue(1), destinationProjectId: '555', newTitle: 'x' });
    expect(res.success).toBe(false);
    if (res.success) return;
    expect(res.error.message).toMatch(/disabled/i);
  });
});
