/**
 * Epic Ops — domain types (Task 1).
 *
 * Clone/template operations over GitLab epics & issues. The shapes encode
 * the trust pattern: a `ClonePlan` is built by a read-only preview step
 * (INV1 — no writes), the user confirms, execution returns a `CloneReport`
 * with per-item outcomes (INV2 — best-effort, no bulk rollback).
 *
 * Design doc: docs/plans/2026-07-15-epic-ops-design.md (D1–D4).
 */

import type { GitLabEpic, GitLabIssue } from '../gitlab/types';

// ─── Inputs ─────────────────────────────────────────────────

/** Everything needed to clone an epic as a template (D2 fixed rules). */
export interface CloneEpicInput {
  sourceEpic: GitLabEpic;
  /** OPEN issues only — closed ones are stripped by rule, not by caller choice. */
  openIssues: GitLabIssue[];
  /** Destination group (root-subtree scoped, D3). */
  destinationGroupId: string;
  /** Project (under the destination) that will hold the cloned issues. */
  destinationProjectId: string;
  /** Editable clone title (D4) — pre-filled `[Template] <original>`. */
  newTitle: string;
}

/** Everything needed to clone a single issue (standalone — no epic link). */
export interface CloneIssueInput {
  sourceIssue: GitLabIssue;
  destinationProjectId: string;
  /** Editable clone title (D4) — pre-filled `[Clone] <original>`. */
  newTitle: string;
}

// ─── Preview plan (read-only) ───────────────────────────────

/** One item the clone will create, with the kept/stripped notes the UI shows. */
export interface PlanItem {
  title: string;
  weight: number | null;
  /** e.g. "AC kept" */
  keptNote: string;
  /** e.g. "assignee removed · iteration removed" */
  strippedNote: string;
}

/** What the preview modal renders. Built with ZERO GitLab writes (INV1). */
export interface ClonePlan {
  /** The (possibly renamed) title that will be created. */
  title: string;
  /** Human-readable destination, e.g. "Payments Crew / Templates". */
  destinationLabel: string;
  items: PlanItem[];
  /** Total GitLab writes the confirm will perform (epic + issues + links). */
  writeCount: number;
  /** D4 guard: destination already has an epic/issue with this title. */
  duplicateTitle: boolean;
}

// ─── Execution report ───────────────────────────────────────

export interface ReportItem {
  title: string;
  ok: boolean;
  /** GitLab id when created. */
  id?: number;
  webUrl?: string;
  /** Failure message when ok=false. */
  error?: string;
}

/** Per-item outcome of an executed clone (INV2). */
export interface CloneReport {
  /** The created epic (absent for single-issue clones or on epic failure). */
  epic?: { id: number; iid: number; webUrl: string };
  created: ReportItem[];
  failures: ReportItem[];
}

// ─── Fields a cloned issue carries (D2 KEPT set) ────────────

/** The exact payload a cloned issue is created with — nothing else survives. */
export interface MappedIssue {
  title: string;
  description: string;
  labels: string[];
  weight?: number;
}
