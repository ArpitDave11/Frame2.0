import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';

vi.mock('@/services/epicOps/epicOpsActions', async () => {
  const actual = await vi.importActual<typeof import('@/services/epicOps/epicOpsActions')>('@/services/epicOps/epicOpsActions');
  return {
    ...actual,
    loadDestinationGroupsAction: vi.fn(),
    loadDestinationProjectsAction: vi.fn(),
    loadSourceEpicsAction: vi.fn(),
    loadSourceIssuesAction: vi.fn(),
    buildEpicClonePreviewAction: vi.fn(),
  };
});

import { EpicOpsView } from './EpicOpsView';
import {
  buildEpicClonePreviewAction,
  loadDestinationGroupsAction,
  loadDestinationProjectsAction,
  loadSourceEpicsAction,
  loadSourceIssuesAction,
} from '@/services/epicOps/epicOpsActions';
import type { GitLabEpic, GitLabIssue } from '@/services/gitlab/types';

const mockGroups = vi.mocked(loadDestinationGroupsAction);
const mockProjects = vi.mocked(loadDestinationProjectsAction);
const mockEpics = vi.mocked(loadSourceEpicsAction);
const mockIssues = vi.mocked(loadSourceIssuesAction);
const mockPreview = vi.mocked(buildEpicClonePreviewAction);

const epic: GitLabEpic = {
  id: 900, iid: 151, title: 'Saved payment methods', description: 'd', state: 'opened',
  web_url: '#', labels: [], created_at: '', updated_at: '', group_id: 101,
};
const issue: GitLabIssue = {
  id: 501, iid: 501, title: 'Tokenise card details', description: 'AC', state: 'opened',
  web_url: '#', labels: [], weight: 5,
};

beforeEach(() => {
  vi.clearAllMocks();
  mockGroups.mockResolvedValue({ success: true, data: [
    { id: '101', name: 'Payments Crew' } as never,
    { id: '200', name: 'Templates' } as never,
  ] });
  mockProjects.mockResolvedValue({ success: true, data: [
    { id: 555, name: 'web', path_with_namespace: 'payments/web', web_url: '#', issues_enabled: true },
  ] });
  mockEpics.mockResolvedValue({ success: true, data: [epic] });
  mockIssues.mockResolvedValue({ success: true, data: [issue] });
  mockPreview.mockResolvedValue({ success: true, data: { plan: { title: 't', destinationLabel: 'Templates', items: [], writeCount: 1, duplicateTitle: false }, openIssues: [] } });
});

describe('EpicOpsView (T5)', () => {
  it('loads groups + epics on mount and renders the source rows', async () => {
    render(<EpicOpsView />);
    await waitFor(() => screen.getByTestId('epicops-source-row-900'));
    expect(mockEpics).toHaveBeenCalledWith('101');
    expect(screen.getByTestId('epicops-title').textContent).toBe('Epic Ops');
  });

  it('selecting an epic pre-fills the [Template] title; rename stays editable (D4)', async () => {
    render(<EpicOpsView />);
    await waitFor(() => screen.getByTestId('epicops-source-row-900'));
    fireEvent.click(screen.getByTestId('epicops-source-row-900'));
    const input = screen.getByTestId('epicops-new-title') as HTMLInputElement;
    expect(input.value).toBe('[Template] Saved payment methods');
    fireEvent.change(input, { target: { value: 'My renamed template' } });
    expect(input.value).toBe('My renamed template');
  });

  it('toggling to issue mode loads issues + destination projects and uses the [Clone] prefix', async () => {
    render(<EpicOpsView />);
    await waitFor(() => screen.getByTestId('epicops-source-row-900'));
    fireEvent.click(screen.getByTestId('epicops-mode-issue'));
    await waitFor(() => screen.getByTestId('epicops-source-row-501'));
    expect(mockIssues).toHaveBeenCalledWith('101');
    expect(mockProjects).toHaveBeenCalled();
    fireEvent.click(screen.getByTestId('epicops-source-row-501'));
    expect((screen.getByTestId('epicops-new-title') as HTMLInputElement).value).toBe('[Clone] Tokenise card details');
  });

  it('renders the FIXED kept/stripped panels (D2 — no toggles)', async () => {
    render(<EpicOpsView />);
    await waitFor(() => screen.getByTestId('epicops-kept-panel'));
    expect(screen.getByTestId('epicops-kept-panel').textContent).toMatch(/Acceptance criteria/);
    expect(screen.getByTestId('epicops-stripped-panel').textContent).toMatch(/Assignees/);
    expect(screen.getByTestId('epicops-kept-panel').querySelector('input[type=checkbox]')).toBeNull();
  });

  it('Preview stays disabled until source + destination + title are set', async () => {
    render(<EpicOpsView />);
    await waitFor(() => screen.getByTestId('epicops-source-row-900'));
    const btn = () => screen.getByTestId('epicops-preview') as HTMLButtonElement;
    expect(btn().disabled).toBe(true);
    fireEvent.click(screen.getByTestId('epicops-source-row-900'));
    expect(btn().disabled).toBe(true); // destination still missing
    fireEvent.change(screen.getByTestId('epicops-destination'), { target: { value: '200' } });
    expect(btn().disabled).toBe(false);
  });

  it('clicking Preview builds the read-only plan and opens the preview state', async () => {
    render(<EpicOpsView />);
    await waitFor(() => screen.getByTestId('epicops-source-row-900'));
    fireEvent.click(screen.getByTestId('epicops-source-row-900'));
    fireEvent.change(screen.getByTestId('epicops-destination'), { target: { value: '200' } });
    fireEvent.click(screen.getByTestId('epicops-preview'));
    await waitFor(() => expect(screen.getByTestId('epicops-view').getAttribute('data-preview-open')).toBe('true'));
    expect(mockPreview).toHaveBeenCalledWith(epic, '101', '200', 'Templates', '[Template] Saved payment methods');
  });

  it('surfaces a source-load error state', async () => {
    mockEpics.mockResolvedValue({ success: false, error: { code: 'network', message: '500 boom' } });
    render(<EpicOpsView />);
    await waitFor(() => screen.getByTestId('epicops-source-error'));
    expect(screen.getByTestId('epicops-source-error').textContent).toMatch(/500 boom/);
  });

  it('shows the empty state when the group has nothing to clone', async () => {
    mockEpics.mockResolvedValue({ success: true, data: [] });
    render(<EpicOpsView />);
    await waitFor(() => screen.getByTestId('epicops-source-empty'));
  });
});
