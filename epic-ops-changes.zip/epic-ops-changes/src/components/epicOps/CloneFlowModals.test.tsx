import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';

vi.mock('@/services/epicOps/epicOpsActions', async () => {
  const actual = await vi.importActual<typeof import('@/services/epicOps/epicOpsActions')>('@/services/epicOps/epicOpsActions');
  return {
    ...actual,
    executeCloneEpicAction: vi.fn(),
    executeCloneIssueAction: vi.fn(),
    executeRetryIssuesAction: vi.fn(),
    loadGroupProjectsAction: vi.fn(),
  };
});

import { CloneFlowModals } from './CloneFlowModals';
import type { PendingPreview } from './EpicOpsView';
import {
  executeCloneEpicAction,
  executeRetryIssuesAction,
  loadGroupProjectsAction,
} from '@/services/epicOps/epicOpsActions';
import type { GitLabEpic, GitLabIssue } from '@/services/gitlab/types';

const mockExec = vi.mocked(executeCloneEpicAction);
const mockRetry = vi.mocked(executeRetryIssuesAction);
const mockProjects = vi.mocked(loadGroupProjectsAction);

const sourceEpic: GitLabEpic = {
  id: 900, iid: 151, title: 'Saved payment methods', description: 'd', state: 'opened',
  web_url: '#', labels: [], created_at: '', updated_at: '', group_id: 101,
};
const openIssue: GitLabIssue = {
  id: 501, iid: 501, title: 'Set default payment method', description: 'AC', state: 'opened', web_url: '#', labels: [], weight: 3,
};

const preview: PendingPreview = {
  mode: 'epic',
  plan: { title: '[Template] Saved payment methods', destinationLabel: 'Templates', items: [{ title: 'Set default payment method', weight: 3, keptNote: 'AC kept', strippedNote: '—' }], writeCount: 3, duplicateTitle: false },
  sourceEpic,
  openIssues: [openIssue],
  destinationGroupId: '200',
};

beforeEach(() => {
  vi.clearAllMocks();
  mockProjects.mockResolvedValue({ success: true, data: [{ id: 555, name: 'web', path_with_namespace: 'p/web', web_url: '#', issues_enabled: true }] });
  mockExec.mockResolvedValue({ success: true, data: { epic: { id: 1000, iid: 12, webUrl: '#' }, created: [], failures: [{ title: 'Set default payment method', ok: false, error: '429' }] } });
  mockRetry.mockResolvedValue({ success: true, data: { created: [{ title: 'Set default payment method', ok: true, id: 700 }], failures: [] } });
});

describe('CloneFlowModals (T6)', () => {
  it('confirm resolves the destination project then executes with it', async () => {
    render(<CloneFlowModals preview={preview} onClose={vi.fn()} />);
    fireEvent.click(screen.getByTestId('clone-preview-confirm'));
    await waitFor(() => screen.getByTestId('clone-result-modal'));
    expect(mockProjects).toHaveBeenCalledWith('200');
    expect(mockExec).toHaveBeenCalledWith(expect.objectContaining({ destinationProjectId: '555', newTitle: '[Template] Saved payment methods' }));
  });

  it('Retry re-executes only the failed sources into the existing epic and merges the report', async () => {
    render(<CloneFlowModals preview={preview} onClose={vi.fn()} />);
    fireEvent.click(screen.getByTestId('clone-preview-confirm'));
    await waitFor(() => screen.getByTestId('clone-result-retry'));
    fireEvent.click(screen.getByTestId('clone-result-retry'));
    await waitFor(() => expect(screen.queryByTestId('clone-result-retry')).toBeNull()); // failures cleared
    expect(mockRetry).toHaveBeenCalledWith(expect.objectContaining({ epicIid: 12, issues: [openIssue] }));
    expect(screen.getByTestId('clone-result-heading').textContent).toBe('Clone complete');
  });

  it('surfaces an execution failure back into the preview modal', async () => {
    mockExec.mockResolvedValue({ success: false, error: { code: 'auth', message: '403 forbidden' } });
    render(<CloneFlowModals preview={preview} onClose={vi.fn()} />);
    fireEvent.click(screen.getByTestId('clone-preview-confirm'));
    await waitFor(() => screen.getByTestId('clone-preview-error'));
    expect(screen.getByTestId('clone-preview-error').textContent).toMatch(/403/);
  });

  it('errors when the destination group has no project (nothing executed)', async () => {
    mockProjects.mockResolvedValue({ success: true, data: [] });
    render(<CloneFlowModals preview={preview} onClose={vi.fn()} />);
    fireEvent.click(screen.getByTestId('clone-preview-confirm'));
    await waitFor(() => screen.getByTestId('clone-preview-error'));
    expect(mockExec).not.toHaveBeenCalled();
  });

  it('renders nothing when preview is null', () => {
    const { container } = render(<CloneFlowModals preview={null} onClose={vi.fn()} />);
    expect(container.innerHTML).toBe('');
  });
});
