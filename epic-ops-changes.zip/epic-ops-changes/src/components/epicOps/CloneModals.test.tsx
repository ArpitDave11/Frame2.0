import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { ClonePreviewModal } from './ClonePreviewModal';
import { CloneResultModal } from './CloneResultModal';
import type { ClonePlan, CloneReport } from '@/services/epicOps/types';

const plan: ClonePlan = {
  title: '[Template] Saved payment methods',
  destinationLabel: 'Payments Crew / Templates',
  items: [
    { title: 'Tokenise card details', weight: 5, keptNote: 'AC kept', strippedNote: 'assignee removed' },
    { title: 'Vault CRUD API', weight: 8, keptNote: 'AC kept', strippedNote: 'assignee removed' },
  ],
  writeCount: 5,
  duplicateTitle: false,
};

describe('ClonePreviewModal (T6)', () => {
  function setup(overrides: Partial<React.ComponentProps<typeof ClonePreviewModal>> = {}) {
    const props = { mode: 'epic' as const, plan, onBack: vi.fn(), onConfirm: vi.fn(), onRename: vi.fn(), ...overrides };
    render(<ClonePreviewModal {...props} />);
    return props;
  }

  it('renders the summary, items with kept/stripped notes, and the write-count warning', () => {
    setup();
    expect(screen.getByTestId('clone-preview-summary').textContent).toBe('Will create 1 epic + 2 issues in Payments Crew / Templates');
    expect(screen.getByTestId('clone-preview-item-0').textContent).toMatch(/AC kept · assignee removed/);
    expect(screen.getByTestId('clone-preview-writecount').textContent).toMatch(/5 GitLab writes · no undo/);
  });

  it('shows the duplicate-title warning only when the plan flags it (D4)', () => {
    setup();
    expect(screen.queryByTestId('clone-preview-dup-warning')).toBeNull();
  });

  it('dup warning renders with a Rename affordance that fires onRename', () => {
    const props = setup({ plan: { ...plan, duplicateTitle: true } });
    expect(screen.getByTestId('clone-preview-dup-warning').textContent).toMatch(/already exists/);
    fireEvent.click(screen.getByTestId('clone-preview-rename'));
    expect(props.onRename).toHaveBeenCalledTimes(1);
  });

  it('confirm fires once; busy disables it; Escape calls onBack', () => {
    const props = setup();
    fireEvent.click(screen.getByTestId('clone-preview-confirm'));
    expect(props.onConfirm).toHaveBeenCalledTimes(1);
    fireEvent.keyDown(window, { key: 'Escape' });
    expect(props.onBack).toHaveBeenCalled();
  });

  it('renders an execution error when provided', () => {
    setup({ errorMessage: '403 forbidden' });
    expect(screen.getByTestId('clone-preview-error').textContent).toMatch(/403/);
  });
});

describe('CloneResultModal (T6)', () => {
  const report: CloneReport = {
    epic: { id: 1000, iid: 12, webUrl: 'https://gl/epics/12' },
    created: [
      { title: 'Tokenise card details', ok: true, id: 601 },
      { title: 'Vault CRUD API', ok: true, id: 602 },
    ],
    failures: [{ title: 'Set default payment method', ok: false, error: 'rate limited (429)' }],
  };

  function setup(overrides: Partial<React.ComponentProps<typeof CloneResultModal>> = {}) {
    const props = { mode: 'epic' as const, report, onClose: vi.fn(), onRetryFailures: vi.fn(), ...overrides };
    render(<CloneResultModal {...props} />);
    return props;
  }

  it('partitions created vs failed and counts the heading', () => {
    setup();
    expect(screen.getByTestId('clone-result-heading').textContent).toBe('Clone complete — 3 of 4 created');
    expect(screen.getByTestId('clone-result-epic-link').getAttribute('href')).toBe('https://gl/epics/12');
    expect(screen.getByTestId('clone-result-failure-0').textContent).toMatch(/rate limited/);
  });

  it('Retry re-runs only the failed subset via the callback', () => {
    const props = setup();
    const btn = screen.getByTestId('clone-result-retry');
    expect(btn.textContent).toMatch(/Retry 1 failed/);
    fireEvent.click(btn);
    expect(props.onRetryFailures).toHaveBeenCalledTimes(1);
  });

  it('hides Retry on a clean run and titles the heading plainly', () => {
    setup({ report: { ...report, failures: [] } });
    expect(screen.getByTestId('clone-result-heading').textContent).toBe('Clone complete');
    expect(screen.queryByTestId('clone-result-retry')).toBeNull();
  });

  it('Escape closes', () => {
    const props = setup();
    fireEvent.keyDown(window, { key: 'Escape' });
    expect(props.onClose).toHaveBeenCalled();
  });
});
