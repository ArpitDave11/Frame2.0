/**
 * T7 follow-up — the app has TWO sidebars (WelcomeSidebar on the home screen,
 * WorkspaceSidebar inside tabs). Both must list Epic Ops directly below
 * Issue Refinery and above BRP; the workspace one was missed initially and
 * only caught by the user in the live UI.
 */
import { describe, it, expect } from 'vitest';

describe('Epic Ops in WorkspaceSidebar (T7 fix)', () => {
  it('lists Epic Ops between Issue Refinery and BRP', async () => {
    const src = (await import('@/components/layout/WorkspaceSidebar.tsx?raw' as string)) as { default: string };
    const order = ["id: 'issueRefinery'", "id: 'epicOps'", "id: 'brp'"].map((n) => src.default.indexOf(n));
    expect(order[0]).toBeGreaterThan(-1);
    expect(order[0]).toBeLessThan(order[1]!);
    expect(order[1]).toBeLessThan(order[2]!);
  });
});
