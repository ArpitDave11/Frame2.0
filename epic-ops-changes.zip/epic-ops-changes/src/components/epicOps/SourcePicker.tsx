/**
 * SourcePicker — card ① of Epic Ops (T5, Figma 67:200 / 72:200).
 *
 * Pure presentational: group selector + filter + selectable source rows
 * (epics or issues, depending on mode). The caller owns all state; this
 * renders loading / error / empty / ready like EpicPicker does.
 */

import { useMemo, useState } from 'react';
import { MagnifyingGlass } from '@phosphor-icons/react';
import { color, font, fontSize, fontWeight, radius } from '@/theme/tokens';

export interface SourceOption {
  id: string;
  title: string;
  /** e.g. "!151 · 6 open issues · 3 closed" or "#501 · epic !151 · open" */
  meta: string;
  /** Issue weight chip (single-issue mode). */
  weight?: number | null;
}

export interface SourcePickerProps {
  label: string;
  groups: Array<{ id: string; name: string }>;
  selectedGroupId: string | null;
  onSelectGroup: (id: string) => void;
  options: SourceOption[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  state: 'loading' | 'ready' | 'error';
  errorMessage?: string;
}

const card: React.CSSProperties = {
  display: 'flex', flexDirection: 'column', gap: 14, padding: 22, flex: 1,
  background: color.white, border: `1px solid ${color.neutral200}`, borderRadius: radius.lg,
  fontFamily: font.sans, alignSelf: 'flex-start',
};

export function SourcePicker({
  label, groups, selectedGroupId, onSelectGroup, options, selectedId, onSelect, state, errorMessage,
}: SourcePickerProps) {
  const [query, setQuery] = useState('');
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return options;
    return options.filter((o) => o.title.toLowerCase().includes(q) || o.meta.includes(q));
  }, [options, query]);

  return (
    <section data-testid="epicops-source-card" aria-label={label} style={card}>
      <div style={{ fontSize: '0.6875rem', fontWeight: fontWeight.semibold, color: color.grayIII, letterSpacing: '0.5px', textTransform: 'uppercase' }}>{label}</div>

      <div style={{ display: 'flex', gap: 10 }}>
        <select
          aria-label="Source group"
          data-testid="epicops-source-group"
          value={selectedGroupId ?? ''}
          onChange={(e) => onSelectGroup(e.target.value)}
          style={{ padding: '9px 12px', border: `1px solid ${color.grayI}`, borderRadius: radius.sm, background: color.white, color: color.black, fontFamily: font.sans, fontSize: fontSize.sm }}
        >
          {groups.map((g) => (
            <option key={g.id} value={g.id}>{g.name}</option>
          ))}
        </select>
        <label style={{ flex: 1, display: 'inline-flex', alignItems: 'center', gap: 8, padding: '9px 12px', border: `1px solid ${color.grayI}`, borderRadius: radius.sm }}>
          <MagnifyingGlass size={14} color={color.grayIII} aria-hidden="true" />
          <input
            data-testid="epicops-source-search"
            type="text"
            value={query}
            placeholder="Filter by title or id"
            onChange={(e) => setQuery(e.target.value)}
            style={{ flex: 1, border: 'none', outline: 'none', fontFamily: font.sans, fontSize: fontSize.sm, color: color.black, background: color.white }}
          />
        </label>
      </div>

      {state === 'loading' ? (
        <div role="status" aria-live="polite" data-testid="epicops-source-loading" style={{ padding: '30px 0', textAlign: 'center', color: color.grayV, fontSize: fontSize.sm }}>
          Loading from GitLab…
        </div>
      ) : state === 'error' ? (
        <div role="alert" data-testid="epicops-source-error" style={{ padding: '12px 14px', background: color.pastelI, border: `1px solid ${color.bordeauxI}`, borderRadius: radius.sm, color: color.red, fontSize: fontSize.sm }}>
          {errorMessage ?? 'Failed to load from GitLab.'}
        </div>
      ) : filtered.length === 0 ? (
        <div data-testid="epicops-source-empty" style={{ padding: '30px 0', textAlign: 'center', color: color.grayV, fontSize: fontSize.sm }}>
          {options.length === 0 ? 'Nothing to clone in this group.' : 'No matches for your filter.'}
        </div>
      ) : (
        <ul role="list" data-testid="epicops-source-list" style={{ listStyle: 'none', margin: 0, padding: 0, display: 'flex', flexDirection: 'column', gap: 10 }}>
          {filtered.map((o) => {
            const selected = o.id === selectedId;
            return (
              <li key={o.id}>
                <button
                  type="button"
                  data-testid={`epicops-source-row-${o.id}`}
                  aria-pressed={selected}
                  onClick={() => onSelect(o.id)}
                  style={{
                    width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12,
                    padding: '12px 14px', textAlign: 'left', cursor: 'pointer',
                    background: selected ? color.pastelI : color.white,
                    border: `${selected ? 1.5 : 1}px solid ${selected ? color.red : color.neutral200}`,
                    borderRadius: radius.md, fontFamily: font.sans,
                  }}
                >
                  <span style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
                    <span style={{ fontSize: fontSize.sm, fontWeight: selected ? fontWeight.semibold : fontWeight.medium, color: color.black }}>{o.title}</span>
                    <span style={{ fontSize: '0.6875rem', fontFamily: font.mono, color: color.grayIII }}>{o.meta}</span>
                  </span>
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 10 }}>
                    {o.weight != null && (
                      <span style={{ fontSize: '0.6875rem', fontWeight: fontWeight.medium, color: color.black, background: color.neutral50, border: `1px solid ${color.neutral200}`, borderRadius: 6, padding: '3px 8px' }}>{o.weight} SP</span>
                    )}
                    {selected && (
                      <span data-testid={`epicops-source-selected-${o.id}`} style={{ fontSize: '0.6875rem', fontWeight: fontWeight.medium, color: color.white, background: color.red, borderRadius: 12, padding: '3px 9px' }}>Selected</span>
                    )}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
