/**
 * T7 — Epic Ops tab wiring: TabId routes to EpicOpsView; sidebar places
 * "Epic Ops" directly below Issue Refinery (and above BRP).
 */
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';

vi.mock('@/services/epicOps/epicOpsActions', async () => {
  const actual = await vi.importActual<typeof import('@/services/epicOps/epicOpsActions')>('@/services/epicOps/epicOpsActions');
  return {
    ...actual,
    loadDestinationGroupsAction: vi.fn().mockResolvedValue({ success: true, data: [] }),
    loadDestinationProjectsAction: vi.fn().mockResolvedValue({ success: true, data: [] }),
    loadSourceEpicsAction: vi.fn().mockResolvedValue({ success: true, data: [] }),
    loadSourceIssuesAction: vi.fn().mockResolvedValue({ success: true, data: [] }),
  };
});

import { ViewRouter } from '@/components/layout/ViewRouter';
import { useUiStore } from '@/stores/uiStore';

describe('Epic Ops tab wiring (T7)', () => {
  beforeEach(() => {
    useUiStore.setState({ activeTab: 'epicOps' });
  });

  it("activeTab='epicOps' renders EpicOpsView through the router", async () => {
    render(<ViewRouter />);
    await waitFor(() => screen.getByTestId('epicops-view'));
    expect(screen.getByTestId('epicops-title').textContent).toBe('Epic Ops');
  });

  it('sidebar lists Epic Ops directly below Issue Refinery and above BRP', async () => {
    const src = (await import('@/components/layout/WelcomeSidebar.tsx?raw' as string)) as { default: string };
    const order = ['issueRefinery', 'epicOps', 'brp'].map((id) => src.default.indexOf(`id: '${id}'`));
    expect(order[0]).toBeGreaterThan(-1);
    expect(order[0]).toBeLessThan(order[1]!);
    expect(order[1]).toBeLessThan(order[2]!);
  });
});
