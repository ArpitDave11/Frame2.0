/**
 * ClonePreviewModal — the trust step (T6, Figma 68:200).
 *
 * Pure presentational. Renders the read-only ClonePlan: what will be
 * created, the D4 duplicate-title guard, and the honest write-count
 * warning. Nothing is written until `onConfirm`.
 */

import { useEffect, useId } from 'react';
import { X, Warning } from '@phosphor-icons/react';
import type { ClonePlan } from '@/services/epicOps/types';
import { color, font, fontSize, fontWeight, radius, shadow } from '@/theme/tokens';

export interface ClonePreviewModalProps {
  mode: 'epic' | 'issue';
  plan: ClonePlan;
  busy?: boolean;
  /** Execution error surfaced back into the preview (confirm failed). */
  errorMessage?: string;
  onBack: () => void;
  onConfirm: () => void;
  /** D4: user chose to rename instead of creating a twin. */
  onRename: () => void;
}

const MAX_ROWS = 5;

export function ClonePreviewModal({ mode, plan, busy = false, errorMessage, onBack, onConfirm, onRename }: ClonePreviewModalProps) {
  const titleId = useId();

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onBack(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onBack]);

  const summary = mode === 'epic'
    ? `Will create 1 epic + ${plan.items.length} issue${plan.items.length === 1 ? '' : 's'} in ${plan.destinationLabel}`
    : `Will create 1 issue in ${plan.destinationLabel}`;
  const shown = plan.items.slice(0, MAX_ROWS);
  const hidden = plan.items.length - shown.length;

  return (
    <>
      <div data-testid="clone-preview-backdrop" onClick={onBack} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 999 }} />
      <div
        role="dialog" aria-modal="true" aria-labelledby={titleId} data-testid="clone-preview-modal"
        style={{ position: 'fixed', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', width: 620, maxHeight: '90vh', display: 'flex', flexDirection: 'column', background: color.white, borderRadius: radius.xl, boxShadow: shadow.xl, zIndex: 1000, fontFamily: font.sans }}
      >
        <div style={{ padding: '22px 28px', background: color.neutral50, borderBottom: `1px solid ${color.neutral200}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h2 id={titleId} style={{ margin: 0, fontSize: fontSize.lg, fontWeight: fontWeight.medium, color: color.black, letterSpacing: '-0.2px' }}>
            Preview — clone {mode === 'epic' ? 'as template' : 'issue'}
          </h2>
          <button type="button" aria-label="Close preview" data-testid="clone-preview-close" onClick={onBack} style={{ background: 'transparent', border: 'none', cursor: 'pointer', color: color.grayIII, display: 'flex' }}>
            <X size={20} weight="bold" aria-hidden="true" />
          </button>
        </div>

        <div style={{ padding: '24px 28px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div data-testid="clone-preview-summary" style={{ fontSize: fontSize.sm, fontWeight: fontWeight.semibold, color: color.black }}>{summary}</div>

          {mode === 'epic' && (
            <div style={{ padding: 14, background: color.neutral50, border: `1px solid ${color.neutral200}`, borderRadius: radius.md, display: 'flex', flexDirection: 'column', gap: 8 }}>
              <span style={{ fontSize: fontSize.sm, fontWeight: fontWeight.semibold, color: color.black }}>{plan.title}</span>
              <span style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                {['assignees stripped', 'iterations stripped', 'closed issues skipped'].map((c) => (
                  <span key={c} style={{ fontSize: '0.6875rem', fontWeight: fontWeight.medium, color: color.grayV, background: color.white, border: `1px solid ${color.neutral200}`, borderRadius: 6, padding: '3px 8px' }}>{c}</span>
                ))}
              </span>
            </div>
          )}

          {plan.duplicateTitle && (
            <div role="alert" data-testid="clone-preview-dup-warning" style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '11px 14px', background: color.semanticAmberBg, border: `1px solid ${color.semanticAmberBorder}`, borderRadius: radius.md }}>
              <Warning size={14} weight="fill" color={color.semanticAmberText} aria-hidden="true" />
              <span style={{ flex: 1, fontSize: fontSize.xs, color: color.semanticAmberText }}>
                “{plan.title}” already exists in the destination — rename to avoid a duplicate.
              </span>
              <button type="button" data-testid="clone-preview-rename" onClick={onRename} style={{ padding: '5px 12px', background: color.white, border: `1px solid ${color.semanticAmberBorder}`, borderRadius: 6, color: color.semanticAmberText, fontFamily: font.sans, fontSize: fontSize.xs, fontWeight: fontWeight.medium, cursor: 'pointer' }}>
                Rename
              </button>
            </div>
          )}

          <ul role="list" data-testid="clone-preview-items" style={{ listStyle: 'none', margin: 0, padding: 0, display: 'flex', flexDirection: 'column', gap: 10 }}>
            {shown.map((item, i) => (
              <li key={i} data-testid={`clone-preview-item-${i}`} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, padding: '11px 14px', border: `1px solid ${color.neutral200}`, borderRadius: radius.md }}>
                <span style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                  <span style={{ fontSize: fontSize.sm, fontWeight: fontWeight.medium, color: color.black }}>{item.title}</span>
                  <span style={{ fontSize: '0.6875rem', color: color.grayIII }}>{item.keptNote} · {item.strippedNote}</span>
                </span>
                {item.weight != null && (
                  <span style={{ fontSize: '0.6875rem', fontWeight: fontWeight.medium, color: color.black, background: color.neutral50, border: `1px solid ${color.neutral200}`, borderRadius: 6, padding: '3px 8px' }}>{item.weight} SP</span>
                )}
              </li>
            ))}
          </ul>
          {hidden > 0 && <span style={{ fontSize: fontSize.xs, color: color.grayIII }}>+ {hidden} more issue{hidden === 1 ? '' : 's'}…</span>}

          {errorMessage && (
            <div role="alert" data-testid="clone-preview-error" style={{ padding: '11px 14px', background: color.semanticRedBg, border: `1px solid ${color.semanticRedBorder}`, borderRadius: radius.md, color: color.red, fontSize: fontSize.xs }}>
              {errorMessage}
            </div>
          )}
        </div>

        <div style={{ padding: '16px 28px', background: color.neutral50, borderTop: `1px solid ${color.neutral200}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10 }}>
          <span data-testid="clone-preview-writecount" style={{ fontSize: '0.6875rem', color: color.grayIII }}>
            {plan.writeCount} GitLab write{plan.writeCount === 1 ? '' : 's'} · no undo — review carefully
          </span>
          <span style={{ display: 'flex', gap: 10 }}>
            <button type="button" data-testid="clone-preview-back" onClick={onBack} style={{ padding: '10px 18px', background: color.white, border: `1px solid ${color.grayI}`, borderRadius: radius.md, color: color.grayV, fontFamily: font.sans, fontSize: fontSize.sm, fontWeight: fontWeight.medium, cursor: 'pointer' }}>Back</button>
            <button
              type="button" data-testid="clone-preview-confirm" disabled={busy} onClick={onConfirm}
              style={{ padding: '10px 20px', background: color.red, border: 'none', borderRadius: radius.md, color: color.white, fontFamily: font.sans, fontSize: fontSize.sm, fontWeight: fontWeight.medium, cursor: busy ? 'wait' : 'pointer', opacity: busy ? 0.6 : 1 }}
            >
              {busy ? 'Cloning…' : 'Clone to GitLab'}
            </button>
          </span>
        </div>
      </div>
    </>
  );
}
