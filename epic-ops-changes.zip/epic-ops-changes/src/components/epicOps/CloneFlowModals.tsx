/**
 * CloneFlowModals — stateful glue for the clone flow (T6).
 *
 * Owns the preview → execute → result → retry lifecycle for a
 * `PendingPreview` produced by EpicOpsView. Composes exclusively via
 * epicOpsActions (INV3). Confirm resolves the destination project for
 * epic clones (first issues-enabled project under the chosen group),
 * executes, and hands the per-item report to CloneResultModal; Retry
 * re-runs only the failed subset into the already-created epic (INV2).
 */

import { useEffect, useState } from 'react';
import {
  executeCloneEpicAction,
  executeCloneIssueAction,
  executeRetryIssuesAction,
  loadGroupProjectsAction,
} from '@/services/epicOps/epicOpsActions';
import type { CloneReport } from '@/services/epicOps/types';
import { ClonePreviewModal } from './ClonePreviewModal';
import { CloneResultModal } from './CloneResultModal';
import type { PendingPreview } from './EpicOpsView';

export interface CloneFlowModalsProps {
  preview: PendingPreview | null;
  /** Close the whole flow (also used by the dup-guard Rename affordance). */
  onClose: () => void;
}

export function CloneFlowModals({ preview, onClose }: CloneFlowModalsProps) {
  const [busy, setBusy] = useState(false);
  const [retryBusy, setRetryBusy] = useState(false);
  const [report, setReport] = useState<CloneReport | null>(null);
  const [error, setError] = useState<string | undefined>();
  const [epicProjectId, setEpicProjectId] = useState<string | null>(null);

  // Fresh lifecycle per preview.
  useEffect(() => {
    setBusy(false);
    setRetryBusy(false);
    setReport(null);
    setError(undefined);
    setEpicProjectId(null);
  }, [preview]);

  if (!preview) return null;

  const handleConfirm = async () => {
    setBusy(true);
    setError(undefined);
    try {
      if (preview.mode === 'epic' && preview.sourceEpic && preview.destinationGroupId) {
        const projRes = await loadGroupProjectsAction(preview.destinationGroupId);
        const project = projRes.success ? projRes.data[0] : undefined;
        if (!project) {
          setError('No issue-holding project under the destination group.');
          return;
        }
        setEpicProjectId(String(project.id));
        const res = await executeCloneEpicAction({
          sourceEpic: preview.sourceEpic,
          openIssues: preview.openIssues ?? [],
          destinationGroupId: preview.destinationGroupId,
          destinationProjectId: String(project.id),
          newTitle: preview.plan.title,
        });
        if (res.success) setReport(res.data);
        else setError(res.error.message);
      } else if (preview.mode === 'issue' && preview.sourceIssue && preview.destinationProjectId) {
        const res = await executeCloneIssueAction({
          sourceIssue: preview.sourceIssue,
          destinationProjectId: preview.destinationProjectId,
          newTitle: preview.plan.title,
        });
        if (res.success) setReport(res.data);
        else setError(res.error.message);
      }
    } finally {
      setBusy(false);
    }
  };

  const handleRetry = async () => {
    if (!report?.epic || !preview.destinationGroupId || !epicProjectId) return;
    const failedTitles = new Set(report.failures.map((f) => f.title));
    const failedSources = (preview.openIssues ?? []).filter((i) => failedTitles.has(i.title));
    if (failedSources.length === 0) return;
    setRetryBusy(true);
    const res = await executeRetryIssuesAction({
      destinationGroupId: preview.destinationGroupId,
      destinationProjectId: epicProjectId,
      epicIid: report.epic.iid,
      issues: failedSources,
    });
    setRetryBusy(false);
    if (res.success) {
      setReport({ epic: report.epic, created: [...report.created, ...res.data.created], failures: res.data.failures });
    }
  };

  if (report) {
    return (
      <CloneResultModal
        mode={preview.mode}
        report={report}
        retryBusy={retryBusy}
        onClose={onClose}
        onRetryFailures={preview.mode === 'epic' ? handleRetry : undefined}
      />
    );
  }

  return (
    <ClonePreviewModal
      mode={preview.mode}
      plan={preview.plan}
      busy={busy}
      errorMessage={error}
      onBack={onClose}
      onConfirm={handleConfirm}
      onRename={onClose}
    />
  );
}
