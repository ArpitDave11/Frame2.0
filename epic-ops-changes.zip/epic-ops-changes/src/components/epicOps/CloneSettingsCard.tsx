/**
 * CloneSettingsCard — card ② of Epic Ops (T5, Figma 67:200 / 72:200).
 *
 * Pure presentational. Holds the D4 rename field (pre-filled, editable,
 * with hint), the destination selector, and the D2 FIXED kept/stripped
 * rule panels — fixed by design, no toggles in v1, so the panels are the
 * single visual statement of what a clone does.
 */

import { color, font, fontSize, fontWeight, radius } from '@/theme/tokens';

/** D2 fixed rules, per mode. Defined here so the UI can never drift per-callsite. */
export const CLONE_RULES = {
  epic: {
    kept: [
      { label: 'Structure & description' },
      { label: 'Acceptance criteria' },
      { label: 'Labels' },
      { label: 'Estimates (issue weights)' },
      { label: 'Open issues', noteKey: 'openCount' as const },
    ],
    stripped: [
      { label: 'Assignees' },
      { label: 'Iterations' },
      { label: 'Closed issues', noteKey: 'closedCount' as const },
      { label: 'Comments & activity' },
    ],
  },
  issue: {
    kept: [
      { label: 'Description & acceptance criteria' },
      { label: 'Labels' },
      { label: 'Estimate (weight)', noteKey: 'weight' as const },
    ],
    stripped: [
      { label: 'Assignee' },
      { label: 'Iteration' },
      { label: 'Epic link', note: 'clone is standalone' },
      { label: 'Comments & activity' },
    ],
  },
};

export interface CloneSettingsCardProps {
  mode: 'epic' | 'issue';
  title: string;
  onTitleChange: (value: string) => void;
  destinations: Array<{ id: string; label: string }>;
  destinationId: string | null;
  onDestinationChange: (id: string) => void;
  /** Notes rendered next to fixed rules (counts/weight of the selection). */
  notes?: { openCount?: number; closedCount?: number; weight?: number | null };
  canPreview: boolean;
  previewBusy?: boolean;
  onPreview: () => void;
}

function Rule({ glyph, glyphColor, label, note }: { glyph: string; glyphColor: string; label: string; note?: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <span aria-hidden="true" style={{ fontSize: fontSize.xs, fontWeight: fontWeight.semibold, color: glyphColor }}>{glyph}</span>
      <span style={{ flex: 1, fontSize: fontSize.sm, color: color.black }}>{label}</span>
      {note && <span style={{ fontSize: '0.6875rem', color: color.grayIII }}>{note}</span>}
    </div>
  );
}

export function CloneSettingsCard({
  mode, title, onTitleChange, destinations, destinationId, onDestinationChange, notes, canPreview, previewBusy = false, onPreview,
}: CloneSettingsCardProps) {
  const rules = CLONE_RULES[mode];
  const noteFor = (key?: 'openCount' | 'closedCount' | 'weight', fixed?: string): string | undefined => {
    if (fixed) return fixed;
    if (!key || !notes) return undefined;
    if (key === 'openCount' && notes.openCount != null) return `${notes.openCount} issues`;
    if (key === 'closedCount' && notes.closedCount != null) return `${notes.closedCount} skipped`;
    if (key === 'weight' && notes.weight != null) return `${notes.weight} SP`;
    return undefined;
  };

  return (
    <section
      data-testid="epicops-settings-card"
      aria-label={mode === 'epic' ? 'Template settings' : 'Clone settings'}
      style={{ display: 'flex', flexDirection: 'column', gap: 16, padding: 22, width: 470, boxSizing: 'border-box', background: color.white, border: `1px solid ${color.neutral200}`, borderRadius: radius.lg, fontFamily: font.sans, alignSelf: 'flex-start' }}
    >
      <div style={{ fontSize: '0.6875rem', fontWeight: fontWeight.semibold, color: color.grayIII, letterSpacing: '0.5px', textTransform: 'uppercase' }}>
        {mode === 'epic' ? '2 · Template settings' : '2 · Clone settings'}
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        <label htmlFor="epicops-new-title" style={{ fontSize: fontSize.xs, fontWeight: fontWeight.medium, color: color.grayV }}>
          {mode === 'epic' ? 'New epic title' : 'New issue title'}
        </label>
        <input
          id="epicops-new-title"
          data-testid="epicops-new-title"
          type="text"
          value={title}
          onChange={(e) => onTitleChange(e.target.value)}
          style={{ padding: '10px 12px', border: `1px solid ${color.grayI}`, borderRadius: radius.sm, fontFamily: font.sans, fontSize: fontSize.sm, color: color.black, background: color.white }}
        />
        <span style={{ fontSize: '0.6875rem', color: color.grayIII }}>Pre-filled — rename as you like.</span>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        <label htmlFor="epicops-destination" style={{ fontSize: fontSize.xs, fontWeight: fontWeight.medium, color: color.grayV }}>
          {mode === 'epic' ? 'Destination group' : 'Destination project'}
        </label>
        <select
          id="epicops-destination"
          data-testid="epicops-destination"
          value={destinationId ?? ''}
          onChange={(e) => onDestinationChange(e.target.value)}
          style={{ padding: '10px 12px', border: `1px solid ${color.grayI}`, borderRadius: radius.sm, fontFamily: font.sans, fontSize: fontSize.sm, color: color.black, background: color.white }}
        >
          <option value="" disabled>Select…</option>
          {destinations.map((d) => (
            <option key={d.id} value={d.id}>{d.label}</option>
          ))}
        </select>
      </div>

      <div data-testid="epicops-kept-panel" style={{ display: 'flex', flexDirection: 'column', gap: 8, padding: 14, background: color.semanticGreenBg, border: `1px solid ${color.semanticGreenBorder}`, borderRadius: radius.md }}>
        <span style={{ fontSize: '0.625rem', fontWeight: fontWeight.semibold, color: color.semanticGreenText, letterSpacing: '0.6px', textTransform: 'uppercase' }}>Kept</span>
        {rules.kept.map((r) => (
          <Rule key={r.label} glyph="✓" glyphColor={color.semanticGreenText} label={r.label} note={noteFor('noteKey' in r ? r.noteKey : undefined)} />
        ))}
      </div>

      <div data-testid="epicops-stripped-panel" style={{ display: 'flex', flexDirection: 'column', gap: 8, padding: 14, background: color.neutral50, border: `1px solid ${color.neutral200}`, borderRadius: radius.md }}>
        <span style={{ fontSize: '0.625rem', fontWeight: fontWeight.semibold, color: color.grayIII, letterSpacing: '0.6px', textTransform: 'uppercase' }}>Stripped</span>
        {rules.stripped.map((r) => (
          <Rule key={r.label} glyph="✕" glyphColor={color.grayIII} label={r.label} note={noteFor('noteKey' in r ? r.noteKey : undefined, 'note' in r ? r.note : undefined)} />
        ))}
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10 }}>
        <span style={{ fontSize: '0.6875rem', color: color.grayIII }}>Nothing is written until you confirm.</span>
        <button
          type="button"
          data-testid="epicops-preview"
          disabled={!canPreview || previewBusy}
          onClick={onPreview}
          style={{
            display: 'inline-flex', alignItems: 'center', gap: 8, padding: '11px 20px',
            background: color.red, color: color.white, border: 'none', borderRadius: radius.md,
            fontFamily: font.sans, fontSize: fontSize.sm, fontWeight: fontWeight.medium,
            cursor: !canPreview || previewBusy ? 'not-allowed' : 'pointer',
            opacity: !canPreview || previewBusy ? 0.5 : 1,
          }}
        >
          {previewBusy ? 'Building preview…' : 'Preview clone →'}
        </button>
      </div>
    </section>
  );
}
