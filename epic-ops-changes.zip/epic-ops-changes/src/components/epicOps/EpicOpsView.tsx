/**
 * EpicOpsView — tab root for Epic Ops (T5, Figma 67:200 / 72:200).
 *
 * Orchestrator only: owns mode / source / rename / destination state and
 * composes EVERYTHING through epicOpsActions (INV3 — no store reads here).
 * Card ① = SourcePicker, card ② = CloneSettingsCard. The preview/result
 * modals mount on top in T6, fed by the `preview` state set here.
 */

import { useCallback, useEffect, useState } from 'react';
import type { GitLabEpic, GitLabIssue, GitLabProject, GitLabSubgroup } from '@/services/gitlab/types';
import {
  buildEpicClonePreviewAction,
  buildIssueClonePreview,
  loadDestinationGroupsAction,
  loadDestinationProjectsAction,
  loadSourceEpicsAction,
  loadSourceIssuesAction,
} from '@/services/epicOps/epicOpsActions';
import { cloneTitle, templateTitle } from '@/services/epicOps/cloneMapping';
import type { ClonePlan } from '@/services/epicOps/types';
import { CloneFlowModals } from './CloneFlowModals';
import { CloneSettingsCard } from './CloneSettingsCard';
import { SourcePicker } from './SourcePicker';
import { color, font, fontSize, fontWeight, radius } from '@/theme/tokens';

export type EpicOpsMode = 'epic' | 'issue';

/** Everything T6's modals need to render + execute a confirmed clone. */
export interface PendingPreview {
  mode: EpicOpsMode;
  plan: ClonePlan;
  sourceEpic?: GitLabEpic;
  sourceIssue?: GitLabIssue;
  openIssues?: GitLabIssue[];
  destinationGroupId?: string;
  destinationProjectId?: string;
}

type ListState = 'loading' | 'ready' | 'error';

export function EpicOpsView() {
  const [mode, setMode] = useState<EpicOpsMode>('epic');
  const [groups, setGroups] = useState<GitLabSubgroup[]>([]);
  const [projects, setProjects] = useState<GitLabProject[]>([]);
  const [sourceGroupId, setSourceGroupId] = useState<string | null>(null);
  const [epics, setEpics] = useState<GitLabEpic[]>([]);
  const [issues, setIssues] = useState<GitLabIssue[]>([]);
  const [listState, setListState] = useState<ListState>('loading');
  const [listError, setListError] = useState<string | undefined>();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [newTitle, setNewTitle] = useState('');
  const [destinationId, setDestinationId] = useState<string | null>(null);
  const [previewBusy, setPreviewBusy] = useState(false);
  const [preview, setPreview] = useState<PendingPreview | null>(null);

  // Groups once on mount; projects lazily when issue mode first opens.
  useEffect(() => {
    loadDestinationGroupsAction().then((res) => {
      if (res.success) {
        setGroups(res.data);
        if (res.data[0]) setSourceGroupId((cur) => cur ?? String(res.data[0]!.id));
      } else {
        setListState('error');
        setListError(res.error.message);
      }
    });
  }, []);
  useEffect(() => {
    if (mode === 'issue' && projects.length === 0) {
      loadDestinationProjectsAction().then((res) => {
        if (res.success) setProjects(res.data);
      });
    }
  }, [mode, projects.length]);

  // Source list per group + mode.
  useEffect(() => {
    if (!sourceGroupId) return;
    let cancelled = false;
    setListState('loading');
    setSelectedId(null);
    const load = mode === 'epic' ? loadSourceEpicsAction : loadSourceIssuesAction;
    load(sourceGroupId).then((res) => {
      if (cancelled) return;
      if (res.success) {
        if (mode === 'epic') setEpics(res.data as GitLabEpic[]);
        else setIssues(res.data as GitLabIssue[]);
        setListState('ready');
      } else {
        setListState('error');
        setListError(res.error.message);
      }
    });
    return () => { cancelled = true; };
  }, [sourceGroupId, mode]);

  const selectedEpic = epics.find((e) => String(e.id) === selectedId) ?? null;
  const selectedIssue = issues.find((i) => String(i.id) === selectedId) ?? null;

  // D4: pre-fill the rename field whenever the selection changes.
  const select = useCallback((id: string, sourceTitle: string) => {
    setSelectedId(id);
    setNewTitle(mode === 'epic' ? templateTitle(sourceTitle) : cloneTitle(sourceTitle));
  }, [mode]);

  const options = mode === 'epic'
    ? epics.map((e) => ({ id: String(e.id), title: e.title, meta: `!${e.iid}` }))
    : issues.map((i) => ({ id: String(i.id), title: i.title, meta: `#${i.iid} · ${i.state}`, weight: i.weight ?? null }));

  // String() everywhere: GitLab returns numeric ids at runtime even where the
  // type says string, and <select> round-trips values as strings.
  const destinations = mode === 'epic'
    ? groups.map((g) => ({ id: String(g.id), label: g.name }))
    : projects.map((p) => ({ id: String(p.id), label: p.path_with_namespace }));

  const canPreview = !!selectedId && !!destinationId && newTitle.trim().length > 0 && listState === 'ready';

  const handlePreview = async () => {
    if (!canPreview || previewBusy) return;
    const destLabel = destinations.find((d) => d.id === destinationId)?.label ?? '';
    if (mode === 'epic' && selectedEpic && sourceGroupId && destinationId) {
      setPreviewBusy(true);
      const res = await buildEpicClonePreviewAction(selectedEpic, sourceGroupId, destinationId, destLabel, newTitle);
      setPreviewBusy(false);
      if (res.success) {
        setPreview({ mode, plan: res.data.plan, sourceEpic: selectedEpic, openIssues: res.data.openIssues, destinationGroupId: destinationId });
      } else {
        setListState('error');
        setListError(res.error.message);
      }
    } else if (mode === 'issue' && selectedIssue && destinationId) {
      setPreview({ mode, plan: buildIssueClonePreview(selectedIssue, destLabel, newTitle), sourceIssue: selectedIssue, destinationProjectId: destinationId });
    }
  };

  return (
    <div data-testid="epicops-view" data-preview-open={preview ? 'true' : 'false'} style={{ flex: 1, overflowY: 'auto', background: color.white, fontFamily: font.sans }}>
      {/* White header zone */}
      <div style={{ padding: '32px 40px 24px', borderBottom: `1px solid ${color.neutral200}`, display: 'flex', flexDirection: 'column', gap: 16 }}>
        <h1 data-testid="epicops-title" style={{ margin: 0, fontSize: '1.75rem', fontWeight: fontWeight.semibold, color: color.black, letterSpacing: '-0.4px' }}>Epic Ops</h1>
        <p style={{ margin: 0, fontSize: fontSize.sm, color: color.grayIII }}>
          Clone and template epics & issues. Everything is previewed — nothing is written to GitLab until you confirm.
        </p>
        <div role="tablist" aria-label="Operation" style={{ display: 'inline-flex', gap: 4, padding: 3, background: color.neutral50, border: `1px solid ${color.neutral200}`, borderRadius: radius.md, alignSelf: 'flex-start' }}>
          {(['epic', 'issue'] as const).map((m) => {
            const active = mode === m;
            return (
              <button
                key={m}
                type="button"
                role="tab"
                aria-selected={active}
                data-testid={`epicops-mode-${m}`}
                onClick={() => { setMode(m); setSelectedId(null); setDestinationId(null); setNewTitle(''); }}
                style={{
                  padding: '9px 16px', borderRadius: radius.sm, cursor: 'pointer',
                  background: active ? color.white : 'transparent',
                  border: active ? `1px solid ${color.neutral200}` : '1px solid transparent',
                  fontFamily: font.sans, fontSize: fontSize.sm,
                  fontWeight: active ? fontWeight.semibold : fontWeight.normal,
                  color: active ? color.black : color.grayV,
                }}
              >
                {m === 'epic' ? 'Clone Epic as Template' : 'Clone Single Issue'}
              </button>
            );
          })}
        </div>
      </div>

      {/* Gray content band */}
      <div style={{ display: 'flex', gap: 20, padding: '28px 40px 40px', background: color.neutral50, minHeight: '60vh', alignItems: 'flex-start' }}>
        <SourcePicker
          label={mode === 'epic' ? '1 · Source epic' : '1 · Source issue'}
          groups={groups.map((g) => ({ id: String(g.id), name: g.name }))}
          selectedGroupId={sourceGroupId}
          onSelectGroup={setSourceGroupId}
          options={options}
          selectedId={selectedId}
          onSelect={(id) => {
            const src = options.find((o) => o.id === id);
            if (src) select(id, src.title);
          }}
          state={listState}
          errorMessage={listError}
        />
        <CloneSettingsCard
          mode={mode}
          title={newTitle}
          onTitleChange={setNewTitle}
          destinations={destinations}
          destinationId={destinationId}
          onDestinationChange={setDestinationId}
          notes={mode === 'issue' ? { weight: selectedIssue?.weight ?? null } : undefined}
          canPreview={canPreview}
          previewBusy={previewBusy}
          onPreview={handlePreview}
        />
      </div>
      <CloneFlowModals preview={preview} onClose={() => setPreview(null)} />
    </div>
  );
}
