/**
 * CloneResultModal — per-item outcome report (T6, Figma 68:241).
 *
 * Pure presentational (INV2 surface): ✓ created rows with GitLab links,
 * ⚠ failure rows with the error, and a Retry that re-runs ONLY the failed
 * subset (the caller wires it to executeRetryIssuesAction).
 */

import { useEffect, useId } from 'react';
import { X, CheckCircle, Warning } from '@phosphor-icons/react';
import type { CloneReport } from '@/services/epicOps/types';
import { color, font, fontSize, fontWeight, radius, shadow } from '@/theme/tokens';

export interface CloneResultModalProps {
  mode: 'epic' | 'issue';
  report: CloneReport;
  retryBusy?: boolean;
  onClose: () => void;
  /** Re-run only the failed items. Omitted → no Retry button (e.g. clean run). */
  onRetryFailures?: () => void;
}

const MAX_CREATED_ROWS = 3;

export function CloneResultModal({ mode, report, retryBusy = false, onClose, onRetryFailures }: CloneResultModalProps) {
  const titleId = useId();

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  const total = report.created.length + report.failures.length + (report.epic ? 1 : 0);
  const okCount = report.created.length + (report.epic ? 1 : 0);
  const heading = report.failures.length === 0
    ? 'Clone complete'
    : `Clone complete — ${okCount} of ${total} created`;
  const shownCreated = report.created.slice(0, MAX_CREATED_ROWS);
  const hiddenCreated = report.created.length - shownCreated.length;

  return (
    <>
      <div data-testid="clone-result-backdrop" onClick={onClose} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 999 }} />
      <div
        role="dialog" aria-modal="true" aria-labelledby={titleId} data-testid="clone-result-modal"
        style={{ position: 'fixed', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', width: 620, maxHeight: '90vh', display: 'flex', flexDirection: 'column', background: color.white, borderRadius: radius.xl, boxShadow: shadow.xl, zIndex: 1000, fontFamily: font.sans }}
      >
        <div style={{ padding: '22px 28px', background: color.neutral50, borderBottom: `1px solid ${color.neutral200}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h2 id={titleId} data-testid="clone-result-heading" style={{ margin: 0, fontSize: fontSize.lg, fontWeight: fontWeight.medium, color: color.black, letterSpacing: '-0.2px' }}>{heading}</h2>
          <button type="button" aria-label="Close report" data-testid="clone-result-close" onClick={onClose} style={{ background: 'transparent', border: 'none', cursor: 'pointer', color: color.grayIII, display: 'flex' }}>
            <X size={20} weight="bold" aria-hidden="true" />
          </button>
        </div>

        <div style={{ padding: '24px 28px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 10 }}>
          {report.epic && (
            <div data-testid="clone-result-epic" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, padding: '11px 14px', border: `1px solid ${color.neutral200}`, borderRadius: radius.md }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <CheckCircle size={15} weight="fill" color={color.semanticGreenText} aria-hidden="true" />
                <span style={{ fontSize: fontSize.sm, fontWeight: fontWeight.medium, color: color.black }}>Epic created · !{report.epic.iid}</span>
              </span>
              <a href={report.epic.webUrl} target="_blank" rel="noreferrer" data-testid="clone-result-epic-link" style={{ fontSize: fontSize.xs, fontWeight: fontWeight.medium, color: color.red, textDecoration: 'none' }}>Open ↗</a>
            </div>
          )}

          {shownCreated.map((item, i) => (
            <div key={i} data-testid={`clone-result-created-${i}`} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '11px 14px', border: `1px solid ${color.neutral200}`, borderRadius: radius.md }}>
              <CheckCircle size={15} weight="fill" color={color.semanticGreenText} aria-hidden="true" />
              <span style={{ flex: 1, fontSize: fontSize.sm, color: color.black }}>{item.title}</span>
              <span style={{ fontSize: '0.6875rem', color: color.grayIII }}>{mode === 'epic' ? 'created + linked' : 'created'}{item.id ? ` · #${item.id}` : ''}</span>
            </div>
          ))}
          {hiddenCreated > 0 && (
            <span style={{ fontSize: fontSize.xs, color: color.grayIII }}>✓ {hiddenCreated} more created</span>
          )}

          {report.failures.map((item, i) => (
            <div key={i} role="alert" data-testid={`clone-result-failure-${i}`} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '11px 14px', background: color.semanticRedBg, border: `1px solid ${color.semanticRedBorder}`, borderRadius: radius.md }}>
              <Warning size={15} weight="fill" color={color.semanticAmberText} aria-hidden="true" />
              <span style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 2 }}>
                <span style={{ fontSize: fontSize.sm, fontWeight: fontWeight.medium, color: color.black }}>{item.title}</span>
                <span style={{ fontSize: '0.6875rem', color: color.red }}>Failed: {item.error ?? 'unknown error'}</span>
              </span>
            </div>
          ))}
        </div>

        <div style={{ padding: '16px 28px', borderTop: `1px solid ${color.neutral200}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10 }}>
          <span style={{ fontSize: '0.6875rem', color: color.grayIII }}>Logged to audit trail</span>
          <span style={{ display: 'flex', gap: 10 }}>
            {report.failures.length > 0 && onRetryFailures && (
              <button
                type="button" data-testid="clone-result-retry" disabled={retryBusy} onClick={onRetryFailures}
                style={{ padding: '10px 18px', background: color.white, border: `1px solid ${color.grayI}`, borderRadius: radius.md, color: color.red, fontFamily: font.sans, fontSize: fontSize.sm, fontWeight: fontWeight.medium, cursor: retryBusy ? 'wait' : 'pointer', opacity: retryBusy ? 0.6 : 1 }}
              >
                {retryBusy ? 'Retrying…' : `Retry ${report.failures.length} failed`}
              </button>
            )}
            <button type="button" data-testid="clone-result-done" onClick={onClose} style={{ padding: '10px 20px', background: color.red, border: 'none', borderRadius: radius.md, color: color.white, fontFamily: font.sans, fontSize: fontSize.sm, fontWeight: fontWeight.medium, cursor: 'pointer' }}>
              Close
            </button>
          </span>
        </div>
      </div>
    </>
  );
}
