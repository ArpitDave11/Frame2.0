# Epic Ops — clone & template operations (new workspace tab)

**Date:** 2026-07-15
**Status:** DESIGN — Figma approved direction; no code yet
**Owner:** Arpit
**Figma:** file `pr3p016sqn97AuXtx20MHM`, section "Epic Ops" — sidebar `66:202`, main view `67:200`, Clone Single Issue mode `72:200`, preview-confirm modal `68:200`, result report `68:241`

---

## 1. Problem

Cloning/templating epics and issues in GitLab is manual, click-heavy, and error-prone.
FRAME gets a new workspace tab (sidebar, **below Issue Refinery**) for these bulk GitLab
operations. Working name: **Epic Ops** (rename welcome).

## 2. v1 scope (user-confirmed)

| Op | Semantics |
|---|---|
| **Clone Epic as Template** | Clone an epic + its **open** issues into a destination group. **KEPT:** structure & description, acceptance criteria, labels, estimates (issue weights), open issues. **STRIPPED:** assignees, iterations, closed issues, comments/activity. |
| **Clone Single Issue** | Clone one issue into a destination project. **KEPT:** description/AC, labels, weight. **STRIPPED:** assignee, iteration, **epic link** (clone is standalone), comments. |

**Rename rule (user-confirmed):** the clone's title is always editable —
pre-filled `[Template] <original>` / `[Clone] <original>` with hint "Pre-filled — rename
as you like." A **duplicate-title guard** runs at preview: if the destination already has
an epic/issue with that title, show an amber warning + Rename affordance (never silently
create a twin).

Deferred (discussed, not v1): PI Rollover (clone open issues into next PI + close
original), bulk re-parent/move, bulk edit (labels/assignee/iteration/weight), archive
epic, deep clone (child epics), sync FRAME weights.

## 3. UX flow (trust pattern, same as BRP)

```
pick operation → pick source (epic/issue) → settings (rename, destination,
KEPT/STRIPPED panels) → PREVIEW ("will create 1 epic + 6 issues…", per-item rows,
duplicate-title guard, "N GitLab writes · no undo") → CONFIRM → RESULT report
(per-item ✓/⚠ with Retry for failures) → audit log entry
```

Nothing is written to GitLab until confirm. Result is best-effort with a per-item
failure report (no bulk rollback API) — identical error model to
`brpGitlabService.createEpicWithStories`.

## 4. Build notes

- Every primitive already exists in `gitlabClient.ts`: `fetchGroupEpics`,
  `fetchEpicIssues`, `fetchGroupProjects`, `createGitLabEpic`, `createGitLabIssue`,
  `linkIssueToEpic`, `updateIssue`.
- New thin service (`epicOpsService.ts` or extend `brpGitlabService` pattern):
  `cloneEpicAsTemplate(config, input)` / `cloneIssue(config, input)` with the
  strip/keep mapping + per-item report.
- New tab wiring: `WelcomeSidebar.tsx` nav item (below Issue Refinery) + view component;
  components compose via an actions layer (same purity rules as BRP).
- Duplicate-title check: `fetchGroupEpics(dest)` / project issue search at preview time.
- Audit: reuse ADR-0004 audit log (`epic-published`-style kinds: `epic-cloned`,
  `issue-cloned`).

## 5. Resolved decisions (2026-07-15)

| # | Decision | Choice | Why |
|---|----------|--------|-----|
| D1 | Tab name | **Epic Ops** | Matches house style (Issue Refinery); future-proofs for rollover/bulk ops. |
| D2 | KEPT/STRIPPED | **Fixed rules in v1** (no toggles) | Preview gives transparency; toggles multiply test surface; stripping assignees/iterations is what makes it a template. Toggles = v2 with these defaults. |
| D3 | Destination scope | **Configured root group's subtree only** | Matches app scoping (rootGroupId); small fast picker; prevents accidental cross-org writes. Anywhere = v2 setting. |
| D4 | Rename | Clone title always editable; pre-filled `[Template] `/`[Clone] ` prefix; duplicate-title guard at preview (warn + Rename, never silent twin). |
