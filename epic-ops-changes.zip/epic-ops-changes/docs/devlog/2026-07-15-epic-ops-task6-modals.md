# 2026-07-15 — Epic Ops T6: preview & result modals

**Tag:** epic-ops · **Task:** 6/7 · Figma 68:200 / 68:241

## What
- `ClonePreviewModal` (pure): summary line, epic card + stripped chips, D4
  duplicate-title amber warning with Rename affordance, per-item rows (kept SP +
  kept/stripped notes, capped at 5 + "+N more"), "N GitLab writes · no undo"
  footer, Back / Clone to GitLab, execution-error slot, Escape/aria.
- `CloneResultModal` (pure): "Clone complete — X of Y" heading, ✓ epic row with
  Open link, ✓ created rows (capped), ⚠ failure rows, footer "Retry N failed"
  (hidden on clean runs) + Close, Escape/aria.
- `CloneFlowModals` (stateful glue, INV3): confirm resolves the destination
  project (first issues-enabled under the chosen group) → executeCloneEpicAction /
  executeCloneIssueAction; failures → Retry maps failed titles back to source
  issues → executeRetryIssuesAction into the EXISTING epic (never re-creates it)
  → merged report. Wired into EpicOpsView.
- Service refactor: extracted `cloneIssuesIntoEpic` (shared by initial clone +
  retry); new `executeRetryIssuesAction` with audit.

## Verification
- CloneModals.test.tsx (9) + CloneFlowModals.test.tsx (5): plan render, dup
  warning conditional + Rename, confirm-once/busy/Escape, error slot, report
  partitioning, retry-subset (exact source issues + epicIid), no-project guard,
  failure-into-preview, null render. epicOps suite 52/52. tsc 13 baseline.
