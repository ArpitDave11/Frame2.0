# 2026-07-15 — Epic Ops T1: domain types + pure clone mapping

**Tag:** epic-ops · **Task:** 1/7 · Plan: docs/plans/2026-07-15-epic-ops-design.md

## What
- `src/services/epicOps/types.ts`: CloneEpicInput/CloneIssueInput, ClonePlan/PlanItem
  (read-only preview shape, INV1), CloneReport/ReportItem (per-item outcomes, INV2),
  MappedIssue (the exact D2 KEPT payload — strip-by-construction).
- `cloneMapping.ts` (pure): templateTitle/cloneTitle prefixes (D4), mapIssueForClone
  (keeps title/description/labels/weight; assignee/iteration/epic-link have no field),
  hasDuplicateTitle (case-insensitive trimmed, D4 guard), onlyOpenIssues (D2).

## Verification
- cloneMapping.test.ts: 10 cases (prefixing, strip-by-construction key check, rename,
  no-weight/null-description, defensive label copy, dup-guard, open filter). 10/10 pass.
- tsc at 13-error pre-existing baseline.
