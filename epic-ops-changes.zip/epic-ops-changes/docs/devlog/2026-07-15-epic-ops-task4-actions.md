# 2026-07-15 — Epic Ops T4: actions layer + audit

**Tag:** epic-ops · **Task:** 4/7

## What
`epicOpsActions.ts` — the only seam components may call (INV3):
- Loaders (D3 root-subtree scope): loadDestinationGroupsAction (subgroups of
  rootGroupId), loadSourceEpicsAction(groupId), loadGroupProjectsAction
  (issues-enabled only).
- Preview (INV1, zero writes): buildEpicClonePreviewAction → fetch open issues +
  D4 dup-title guard → ClonePlan {items with kept/stripped notes, writeCount =
  1 + 2×issues, duplicateTitle} + openIssues for reuse; buildIssueClonePreview (pure).
- Execute (INV5): executeCloneEpicAction / executeCloneIssueAction → service +
  recordAudit('epic-cloned' / 'issue-cloned'); no audit on failure.
- auditLog.ts: added 'epic-cloned' | 'issue-cloned' AuditKinds.

## Note
v1 dup-title guard covers epics only (issue-clone preview sets duplicateTitle=false);
issue-level guard listed for v2 in the design doc.

## Verification
- epicOpsActions.test.ts: 9 cases (read-only preview asserts no service writes, dup
  flag, fetch-failure propagation, pure issue preview, audit on success only,
  disabled-GitLab error). epicOps suite 28/28. tsc 13 baseline.
