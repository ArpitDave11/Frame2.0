# 2026-07-15 — Epic Ops T5: main view UI

**Tag:** epic-ops · **Task:** 5/7 · Figma 67:200 / 72:200

## What
- `SourcePicker.tsx` (pure): group select + filter + selectable rows (weight chip
  in issue mode), loading/error/empty/ready states.
- `CloneSettingsCard.tsx` (pure): D4 rename field (pre-filled, hint "Pre-filled —
  rename as you like."), destination select, D2 FIXED kept/stripped panels
  (CLONE_RULES const — single source for both modes, no toggles), preview CTA
  with "Nothing is written until you confirm."
- `EpicOpsView.tsx` (orchestrator, INV3 — composes via epicOpsActions only):
  mode toggle, group→sources loading, selection→title prefill
  ([Template]/[Clone]), destination pool (groups / root-subtree projects),
  Preview → buildEpicClonePreviewAction / buildIssueClonePreview → PendingPreview
  state (T6 mounts the modals from it).
- Actions: added loadSourceIssuesAction (open issues) +
  loadDestinationProjectsAction (root subtree, issues-enabled only, D3).

## Verification
- EpicOpsView.test.tsx: 8 cases (mount load, prefill+rename, mode toggle+
  [Clone] prefix, fixed panels no-checkbox assert, preview gating, preview call
  args + open state, error, empty). + sources loader tests. epicOps suite 38/38.
  tsc 13 baseline. Visual loop deferred to T7 (tab not routed yet).
