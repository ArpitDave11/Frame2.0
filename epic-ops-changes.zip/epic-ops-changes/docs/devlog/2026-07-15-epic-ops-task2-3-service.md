# 2026-07-15 — Epic Ops T2+T3: GitLab service layer

**Tag:** epic-ops · **Tasks:** 2–3/7 (one service file — folded deliberately)

## What
`src/services/epicOps/epicOpsService.ts` (INV4: existing gitlabClient primitives only,
brpGitlabService Result/error-code pattern):
- `cloneEpicAsTemplate` — createGitLabEpic in destination (renamed title + original
  description/labels) → per OPEN issue: createGitLabIssue(mapIssueForClone) +
  linkIssueToEpic. Epic-create failure aborts (nothing orphaned); per-issue failures
  collected (INV2). Closed issues filtered even if passed.
- `cloneIssue` — standalone create in destination project; deliberately NO epic link (D2).
- Read helpers (preview side, INV1): `fetchOpenEpicIssues` (state=opened filter),
  `findDuplicateEpicTitle` (D4 guard via fetchGroupEpics).

## Verification
- epicOpsService.test.ts: 10 cases (happy path, D2 strip payload, closed-skip, abort
  no-orphan, per-issue failure, link failure, standalone clone + no-link assert,
  ratelimit classification, open filter, dup detection). epicOps suite 20/20. tsc 13 baseline.
