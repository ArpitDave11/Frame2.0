# 2026-07-15 — Epic Ops T7: wire the tab + E2E visual loop

**Tag:** epic-ops · **Task:** 7/7

## What
- uiStore: 'epicOps' added to TabId.
- ViewRouter: case 'epicOps' → EpicOpsView (ErrorBoundary-wrapped).
- WelcomeSidebar: "Epic Ops" (Copy icon) inserted BELOW Issue Refinery, ABOVE BRP.
- Routing test (epicOpsRouting.test.tsx): tab renders the view; sidebar order asserted.

## Visual loop (live app, stubbed GitLab via fetch patch on /gitlab-api)
- Sidebar shows Epic Ops in the right slot (real Frutiger).
- Tab opens: header + toggle + both cards matching Figma 67:200; error state renders
  correctly when GitLab 401s (real unstubbed run).
- Full flow driven E2E: select source epic → "[Template] …" prefilled → destination
  → Preview modal ("Will create 1 epic + 2 issues in Templates", closed issue
  EXCLUDED live, stripped chips, "5 GitLab writes · no undo") → Confirm →
  "Clone complete" report (✓ Epic created !12 + Open ↗, ✓ 2 issues created+linked,
  "Logged to audit trail") — matches Figma 68:200/68:241.

## Bug caught by the visual loop
Destination label was blank in the preview summary: GitLab returns NUMERIC subgroup
ids at runtime (type says string) while <select> round-trips strings — strict ===
in destinations.find failed. Fixed by String()-normalizing group ids in EpicOpsView.

## Verification
- epicOps + stores + BrpView suites: 349 passed. tsc 13 pre-existing baseline.
