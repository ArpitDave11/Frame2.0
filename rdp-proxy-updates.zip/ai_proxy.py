"""Azure OpenAI proxy – server-side call so API keys never reach the browser."""

import logging
from typing import Any, Optional

import httpx

log = logging.getLogger(__name__)

# Allowlist matches frontend AZURE_API_VERSIONS in configTypes.ts.
ALLOWED_API_VERSIONS = frozenset({
    "2024-10-21",
    "2024-12-01-preview",
    "2025-01-01-preview",
    "2025-04-01-preview",
    "2026-03-17-preview",
})

DEFAULT_API_VERSION = "2025-01-01-preview"

# Hard ceiling matching the frontend MODEL_LIMITS.reasoning.maxTokens.
MAX_TOKENS_CEILING = 128_000

# Patterns that identify reasoning models (must match frontend detectModelFamily).
_REASONING_MARKERS = ("gpt-5", "o1", "o3", "o4")


def detect_is_reasoning(deployment: str) -> bool:
    """Detect whether a deployment is a reasoning model from its name.

    The backend knows the real deployment (from env); the frontend may
    not, so this is the authoritative source of truth.
    """
    name = deployment.lower()
    return any(marker in name for marker in _REASONING_MARKERS)


def build_azure_request_body(
    system_prompt: str,
    user_prompt: str,
    max_tokens: int,
    temperature: float,
    is_reasoning: bool,
    # DocIntel-only optional params — no-op when None
    response_format: Optional[dict[str, Any]] = None,
    reasoning_effort: Optional[str] = None,
    verbosity: Optional[str] = None,
    seed: Optional[int] = None,
) -> dict[str, Any]:
    """Build the Azure OpenAI chat completions request body.

    Reasoning models (o1, o3, o4, gpt-5) require ``max_completion_tokens``
    and must NOT receive a ``temperature`` parameter (Azure returns 400).
    Standard models use ``max_tokens`` + ``temperature``.

    DocIntel passes optional params (response_format, reasoning_effort,
    verbosity, seed) which are forwarded to Azure when set. All existing
    callers pass None for these — zero behavior change.
    """
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]

    capped_tokens = min(max_tokens, MAX_TOKENS_CEILING)

    if is_reasoning:
        body: dict[str, Any] = {
            "messages": messages,
            "max_completion_tokens": capped_tokens,
        }
    else:
        body = {
            "messages": messages,
            "max_tokens": capped_tokens,
            "temperature": temperature,
        }

    # DocIntel-only — append when set, ignored by Azure if unsupported
    if response_format is not None:
        body["response_format"] = response_format
    if reasoning_effort is not None:
        body["reasoning_effort"] = reasoning_effort
    if verbosity is not None:
        body["verbosity"] = verbosity
    if seed is not None:
        body["seed"] = seed

    return body


async def call_azure_openai(
    client: httpx.AsyncClient,
    endpoint: str,
    api_key: str,
    deployment: str,
    api_version: str,
    body: dict[str, Any],
) -> httpx.Response:
    """Make the Azure OpenAI API call.

    Returns the raw ``httpx.Response`` so the caller can forward the
    upstream status code and headers (especially ``Retry-After``).
    """
    url = (
        f"{endpoint.rstrip('/')}/openai/deployments/{deployment}"
        f"/chat/completions?api-version={api_version}"
    )
    return await client.post(
        url,
        headers={
            "Content-Type": "application/json",
            "api-key": api_key,
        },
        json=body,
    )
