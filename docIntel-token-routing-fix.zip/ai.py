"""AI proxy router – forwards chat completion requests to Azure OpenAI.

The frontend calls ``POST /api/v1/ai/chat/completions`` with a provider-
agnostic payload.  This router builds the Azure-specific request server-side,
attaches the API key from environment, and forwards the response (including
error status codes and ``Retry-After`` headers) back to the browser.
"""

import logging
from typing import Any, Optional

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from app.core.config import get_ai_settings, AISettings
from app.services.ai_proxy import (
    ALLOWED_API_VERSIONS,
    DEFAULT_API_VERSION,
    build_azure_request_body,
    call_azure_openai,
    detect_is_reasoning,
)

log = logging.getLogger(__name__)
router = APIRouter(prefix="/ai", tags=["ai"])


# —— Request Schema ——————————————————————————————————————————————

class ChatCompletionRequest(BaseModel):
    """Mirrors the frontend ``AIRequest`` type with extra proxy fields."""

    system_prompt: str = Field(..., alias="systemPrompt")
    user_prompt: str = Field(..., alias="userPrompt")
    max_tokens: int = Field(default=128_000, alias="maxTokens", ge=1, le=128_000)
    temperature: float = Field(default=0.3, ge=0, le=2)
    is_reasoning: bool = Field(default=False, alias="isReasoning")
    api_version: str = Field(default=DEFAULT_API_VERSION, alias="apiVersion")

    # DocIntel-only optional params — no-op when None (all existing callers)
    is_doc_intel: bool = Field(default=False, alias="isDocIntel")
    response_format: Optional[dict[str, Any]] = Field(default=None, alias="responseFormat")
    reasoning_effort: Optional[str] = Field(default=None, alias="reasoningEffort")
    verbosity: Optional[str] = Field(default=None, alias="verbosity")
    seed: Optional[int] = Field(default=None)

    model_config = {"populate_by_name": True}


# —— Endpoint ————————————————————————————————————————————————————

@router.post("/chat/completions")
async def chat_completions(
    req: ChatCompletionRequest,
    request: Request,
) -> JSONResponse:
    # --- guard: backend must have Azure credentials configured ---
    settings = get_ai_settings()
    if not settings.api_key or not settings.endpoint:
        raise HTTPException(503, "Azure OpenAI not configured on this backend")

    # --- guard: api_version allowlist ---
    if req.api_version not in ALLOWED_API_VERSIONS:
        raise HTTPException(
            400,
            f"Invalid apiVersion. Allowed: {sorted(ALLOWED_API_VERSIONS)}",
        )

    # --- build & send ---
    client = getattr(request.app.state, "ai_http_client", None)
    if client is None:
        raise HTTPException(503, "AI proxy HTTP client not initialized")

    # DocIntel uses a separate Azure deployment (AZURE_DOCEX_DEPLOYMENT env var).
    # If isDocIntel=true and the env var is set, route to that deployment.
    # Otherwise use the default deployment from AZURE_OPENAI_DEPLOYMENT.
    effective_deployment = settings.deployment
    if req.is_doc_intel and settings.docex_deployment:
        effective_deployment = settings.docex_deployment
    is_reasoning = detect_is_reasoning(effective_deployment)

    body = build_azure_request_body(
        system_prompt=req.system_prompt,
        user_prompt=req.user_prompt,
        max_tokens=req.max_tokens,
        temperature=req.temperature,
        is_reasoning=is_reasoning,
        # DocIntel-only — forwarded to Azure when set
        response_format=req.response_format,
        reasoning_effort=req.reasoning_effort,
        verbosity=req.verbosity,
        seed=req.seed,
    )

    log.info("ai_proxy.route deployment=%s override=%s", effective_deployment, req.deployment_override)

    try:
        resp = await call_azure_openai(
            client=client,
            endpoint=settings.endpoint,
            api_key=settings.api_key,
            deployment=effective_deployment,
            api_version=req.api_version,
            body=body,
        )
    except Exception:
        log.exception("ai_proxy.call_failed")
        raise HTTPException(502, "Failed to reach Azure OpenAI")

    # --- forward upstream response (status + body + Retry-After) ---
    response_headers: dict[str, str] = {}
    if "retry-after" in resp.headers:
        response_headers["Retry-After"] = resp.headers["retry-after"]

    try:
        payload = resp.json()
    except Exception:
        payload = {"error": resp.text}

    return JSONResponse(
        content=payload,
        status_code=resp.status_code,
        headers=response_headers,
    )
