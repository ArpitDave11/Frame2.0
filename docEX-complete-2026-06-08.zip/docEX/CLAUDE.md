# docx-platform — Project Memory for Claude Code

> Fresh workspace seeded from **Frame_4's skeleton** (gateway + shared lib + infra + rules), to build the **Docx** collective-company-brain document-intelligence service. **Authoritative design: `docs/FINAL_DESIGN.md`. Full context/history: `docs/CONVERSATION_CONTEXT.md`. Read those first.**

## What this is
An AI-native **document-intelligence** platform service ("Docx"): upload documents → understand → chat/search across the org's documents. It is a **collective company brain** (every upload enriches a shared org knowledge base by default; Private/Focus is the opt-in exception for a narrow answer). Built reusing **Open Notebook**'s chat/ask logic + Notebook/Source/Note model.

## Stack (the locked decisions — do not silently change)
- **Backend:** Python 3.11+, FastAPI, Pydantic v2, pydantic-settings, structlog, httpx (via shared corporate-CA client)
- **Docx store:** **SurrealDB** (vector + records + graph relations). NOT FalkorDB, NOT Neo4j. (FalkorDB only revisited if deep graph reasoning becomes a real need.)
- **Queue:** **Procrastinate (Postgres)**. No Redis. No Celery.
- **LLM:** **Azure OpenAI** only (Entra ID + Workload Identity). Never call openai.com directly.
- **Auth:** **MSAL at the gateway only → HS256 local JWT + S2S JWT** downstream (`shared.auth.LocalJWTBearer`). Never put Azure AD tokens on the inter-service wire.
- **Orchestration:** **LangGraph** inside the service. **MCP:** in-process **FastMCP**, per-tenant scoped.
- **Extraction:** **Docling** (+ Azure AI Document Intelligence for scans).
- **Retrieval:** hybrid (vector + BM25) + reranking + contextual chunking + adaptive/agentic LangGraph + citations. (NOT vector-only.)
- **Multi-tenancy:** ONE shared SurrealDB, **row-level `owner` scoping** (from Entra `sub`), enforced by SurrealDB record permissions. NOT a database-per-user.
- **Frontend:** native **FRAME** React panel (host SPA). Open Notebook's Next.js UI is reference only, not reused as-is.
- **Deploy:** Kustomize + AKS + GitLab CI. **Obs/eval:** Langfuse (self-host) + Ragas in CI.

## Services (uv workspace)
```
services/shared/   — FastAPIFactory, BaseConfig, structlog, JWT utils, events (copied from Frame_4)
services/gateway/  — MSAL→JWT, SSE fan-out (copied from Frame_4)
services/docx/     — (to scaffold) the document-intelligence service, built on Open Notebook + SurrealDB
```
> Frame_4's `core` (Cognee/Neo4j graph) and `delivery` were intentionally NOT copied — Docx uses SurrealDB and the design diverges. Cognee/Graphiti rule files were removed for the same reason.

## Inbuilt engineering standards (enforced — see FINAL_DESIGN.md §11)
Hygiene is gate-enforced, not optional: shared-lib auto-wires (structlog+correlation-id, /health, fail-fast config, **corporate-CA HTTP client**, LocalJWTBearer, result-envelope, external-response validation, fail-open/fail-fast, OTel→Langfuse, audited actions). CI (reusable template) blocks merge on ruff+mypy+pytest+coverage+hadolint+secret/vuln scan+conventional-commit+Ragas; semantic-release on merge. Pre-commit mirrors CI. Every Docx query MUST be `owner`/`scope`-filtered (SurrealDB permissions + a failing test on unscoped queries). Tools are mechanical adapters; reasoning in LangGraph nodes.

## Commands (per service)
```bash
uv sync
ruff check . && ruff format --check .
mypy --strict src
pytest -x
docker compose -f infra/docker-compose.yml up -d   # local infra (adapt for SurrealDB + Postgres)
```

## Ground rule
No implementation beyond what's approved. The design in `docs/FINAL_DESIGN.md` is the source of truth; `docs/CONVERSATION_CONTEXT.md` has the full decision history (🔒 locked items). When resuming, read those two first.

## Path-scoped rules
Load `.claude/rules/*` as you touch files (python-fastapi, rule-backend, rule-pipeline, react-components, rule-frontend). A `surrealdb-usage.md` rule will be added when the Docx data layer is built.
