#!/usr/bin/env bash
# H4: Block overwriting existing test files via Write tool.
# Closes the overwrite path. Combined with H3 (no edit) and H4b (no rm),
# the delete-recreate bypass is structurally impossible.
# Override: KIT_ALLOW_TEST_EDIT=1
#
# Path matcher: files in tests/ directories (*.py only) or named test_*.py.

[[ "$KIT_ALLOW_TEST_EDIT" == "1" ]] && exit 0

# Read hook input, extract file path
INPUT=$(cat)
FILE=$(echo "$INPUT" | jq -r '.tool_input.file_path // empty' 2>/dev/null)
[[ -z "$FILE" ]] && exit 0

# Only Python test files
IS_TEST=0
[[ "$FILE" == */tests/*.py ]] && IS_TEST=1
[[ "$FILE" =~ /test_[a-zA-Z_]+\.py$ ]] && IS_TEST=1
[[ "$IS_TEST" == "0" ]] && exit 0

# Only block if file already exists (creating new test files is allowed)
[[ -f "$FILE" ]] || exit 0

{
  echo "BLOCKED by kit-hardening-v1 (H4 pre-write-protect-tests.sh)"
  echo ""
  echo "  File: $FILE"
  echo ""
  echo "You attempted to overwrite an existing test file via Write."
  echo "This is equivalent to editing. Fix the implementation, not the test."
  echo "Override: KIT_ALLOW_TEST_EDIT=1"
} >&2
exit 2
