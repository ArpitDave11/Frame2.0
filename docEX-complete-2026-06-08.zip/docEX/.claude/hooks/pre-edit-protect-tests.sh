#!/usr/bin/env bash
# H3: Block editing existing test files. Fix the implementation, not the test.
# Override: KIT_ALLOW_TEST_EDIT=1
#
# Path matcher: files in tests/ directories (*.py only) or named test_*.py.
# Does not catch production utilities named test_utils.py outside tests/ dirs.

[[ "$KIT_ALLOW_TEST_EDIT" == "1" ]] && exit 0

# Read hook input, extract file path
INPUT=$(cat)
FILE=$(echo "$INPUT" | jq -r '.tool_input.file_path // empty' 2>/dev/null)
[[ -z "$FILE" ]] && exit 0

# Only Python test files: in tests/ dir or named test_*.py
IS_TEST=0
[[ "$FILE" == */tests/*.py ]] && IS_TEST=1
[[ "$FILE" =~ /test_[a-zA-Z_]+\.py$ ]] && IS_TEST=1
[[ "$IS_TEST" == "0" ]] && exit 0

# Only block if file already exists (new files are OK)
[[ -f "$FILE" ]] || exit 0

{
  echo "BLOCKED by kit-hardening-v1 (H3 pre-edit-protect-tests.sh)"
  echo ""
  echo "  File: $FILE"
  echo ""
  echo "You attempted to edit an EXISTING test file. Editing tests to make them"
  echo "pass is the #1 phantom-progress pattern. If the test is genuinely wrong:"
  echo ""
  echo "  1. Ask the human to confirm the test is wrong, not the implementation."
  echo "  2. Human sets KIT_ALLOW_TEST_EDIT=1 and re-runs."
  echo ""
  echo "If you only need to ADD tests, create a NEW file — that is allowed."
  echo "If the implementation is wrong, fix the implementation, not the test."
} >&2
exit 2
