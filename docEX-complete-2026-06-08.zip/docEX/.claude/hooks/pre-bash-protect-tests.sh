#!/usr/bin/env bash
# H4b: Block deletion of test files via rm or git rm.
# Combined with H3 (no edit) and H4 (no overwrite), test files cannot be
# modified or removed without the explicit escape hatch.
# Override: KIT_ALLOW_TEST_EDIT=1
#
# Matches: rm and git rm with literal test paths in the argument list.
# Does NOT catch: find -delete, xargs rm, unlink, or aliased deletion.
# Acceptable because the bypass we care about is the deliberate
# "rm test_file.py" pattern within a Claude session.

[[ "$KIT_ALLOW_TEST_EDIT" == "1" ]] && exit 0

# Require jq — fail loudly if missing so the hook doesn't silently pass
if ! command -v jq &>/dev/null; then
  {
    echo "ERROR: H4b requires jq but it is not installed. Hook cannot execute."
    echo "Install jq or set KIT_ALLOW_TEST_EDIT=1 to bypass."
  } >&2
  exit 2
fi

# Read hook input, extract bash command
INPUT=$(cat)
CMD=$(echo "$INPUT" | jq -r '.tool_input.command // empty' 2>/dev/null)
[[ -z "$CMD" ]] && exit 0

# Extract only the rm/git rm portion of the command (before pipes or chains)
RM_ARGS=$(echo "$CMD" | grep -oE '\b(rm|git\s+rm)\b[[:space:]]+[^|;&]+' || true)
[[ -z "$RM_ARGS" ]] && exit 0

# Check if rm arguments include a test path
if echo "$RM_ARGS" | grep -qE '(tests/[^ ]*\.py|test_[a-zA-Z_]+\.py)'; then
  {
    echo "BLOCKED by kit-hardening-v1 (H4b pre-bash-protect-tests.sh)"
    echo ""
    echo "You attempted to delete a test file. Combined with H3 (no edit) and"
    echo "H4 (no overwrite), test files cannot be modified or removed."
    echo "Fix the implementation, not the test."
    echo "Override: KIT_ALLOW_TEST_EDIT=1"
  } >&2
  exit 2
fi
exit 0
