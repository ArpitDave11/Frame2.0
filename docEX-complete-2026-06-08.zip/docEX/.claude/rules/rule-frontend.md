---
paths: ["src/components/**", "src/stores/**", "src/hooks/**"]
---
# Frontend Rules
- Use React functional components with hooks.
- State management via Zustand stores — no prop drilling for global state.
- Keep components under 200 lines. Extract sub-components when they grow.
- CSS-in-JS or Tailwind — follow the project's existing pattern.
