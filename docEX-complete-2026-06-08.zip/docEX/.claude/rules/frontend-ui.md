# Rule: Premium UI workflow — MANDATORY before any UI work

**Applies to:** any change under `frontend/**`, any `*.tsx`/`*.css`/styling, or wiring a
panel into FRAME.

**Goal:** premium, FRAME-native UI — not generic "AI slop", and never built blind. This
encodes the best-practice method (Anthropic `frontend-design` skill + design-system
grounding + a visual feedback loop), **adapted** for an enterprise panel embedded in FRAME.
Model stays **Claude Opus 4.8** — these are skills/MCPs/discipline layered on top, not a
model change.

## Hard gates — do them IN ORDER. "It compiles / typechecks" is NOT done.

### 1. GROUND (before writing a single line of UI)
- [ ] Invoke the **`frontend-design`** skill (taste / anti-slop discipline).
- [ ] Read FRAME's design system and build in ITS language:
  - `FRAME_DEPLOYED-brp/src/theme/tokens.ts` (color / spacing / typography tokens)
  - an exemplar view — `src/components/docIntel/DocIntelView.tsx` + nearby components
  - use the **Frutiger** font + **`--col-*`** tokens; NEVER invent a palette/font.
- [ ] If a Figma design exists for the screen → pull it via the **Figma Dev Mode MCP**
  (`get_design_context`, `get_variable_defs`, `get_screenshot`) and match it 1:1.
- [ ] Use **Context7** for any library API (Radix, etc.) — don't guess props.
- [ ] State the committed visual direction in 1–2 lines before coding.

### 2. BUILD
- [ ] **Tokens only** — map every color/space/font to FRAME tokens (or a thin alias layer
  that references them). No hardcoded hex, no `system-ui`, no `#2563eb`-style accents.
- [ ] **Accessible** interactive widgets via Radix unstyled primitives styled with FRAME
  tokens (dialog / combobox / tabs / …): keyboard nav, `focus-visible`, ARIA, labels.
- [ ] **Real states**, not just the happy path: loading skeletons, empty, error.

### 3. VISUAL LOOP (mandatory — never ship UI blind)
- [ ] Run the app; use the **Playwright MCP** to navigate + **screenshot** the rendered UI.
- [ ] Compare the screenshot to FRAME (and/or the Figma target); iterate until it matches
  the design language (target 2–3 iterations, not 10).
- [ ] Capture the key states (default / loading / empty / error).

### 4. LINT (definition of done)
- [ ] a11y + design pass: contrast, focus states, labels, keyboard nav, responsive, no
  layout shift (Vercel `web-design-guidelines` style).

## Anti-slop bans (frontend-design, FRAME-tuned)
- ✗ Inter / Roboto / Arial / `system-ui` defaults → ✓ FRAME's Frutiger stack.
- ✗ Invented accents / purple-gradient-on-white clichés → ✓ FRAME `--col-*` tokens.
- ✗ Flat equal-weight card grids with no hierarchy → ✓ deliberate hierarchy + spacing.

## Definition of DONE for UI
Matches FRAME tokens **+** screenshotted-and-compared **+** a11y-checked **+** real states.
A change that only typechecks/builds is **NOT** done.

## Pre-flight statement (say this before touching UI, so it's auditable)
> "UI pre-flight ✓ — frontend-design loaded; grounded in tokens.ts + DocIntelView;
>  direction = <…>." … and before done: "Visual loop ✓ — screenshotted, matches FRAME."

## Why this rule exists
The first Docx panel was built **blind** — no skill, no token grounding, no screenshot —
and came out generic + visually **alien** to FRAME (`#2563eb` / `system-ui` vs FRAME's
Frutiger / `--col-*`). This gate exists to prevent repeating that.
