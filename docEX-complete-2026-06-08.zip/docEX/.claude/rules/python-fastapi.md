---
paths:
  - "services/*/src/**/*.py"
---
# FastAPI Service Rules

- Route handlers are THIN SHELLS. Business logic lives in services/, never in api/.
- Use `Depends()` for resource injection (db sessions, auth, config). No global state.
- Return Pydantic v2 models from every endpoint. No raw dicts.
- Error handling: HTTPException for client errors. Custom exceptions + app-level
  handlers for RFC 9457 problem-detail responses. No bare `except:`.
- Async discipline: I/O-bound uses `async def` + `httpx.AsyncClient`.
  CPU-bound goes to Procrastinate workers. Never `asyncio.run()` inside a request.
  Never `requests` or `time.sleep()` in async code.
- Health endpoints: `/health/live` (process up), `/health/ready` (deps reachable).
- All services use `shared.factory.FastAPIFactory.create_app()` for consistent setup.
- Config via `shared.config.BaseConfig` subclass. Never `os.environ` directly.
- Logging via structlog only. Bind `correlation_id` and `user_oid` per request.
  Never log secrets, tokens, full request bodies, or embedding vectors.
- Every new endpoint needs: Pydantic input/output models, a test in tests/,
  and a docstring explaining what it does.
