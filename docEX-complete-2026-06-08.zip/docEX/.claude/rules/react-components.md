---
paths:
  - "frontend/src/**/*.tsx"
  - "frontend/src/**/*.ts"
---
# React 19 / TypeScript Frontend Rules

## TypeScript
- Strict mode. Never `any`. Use `unknown` + narrowing.
- Destructure props with defaults (no `defaultProps`).

## Components
- Functional components only. No class components.
- Keep under 200 lines. Extract sub-components when they grow.
- Colocate tests as `<name>.test.tsx`.

## Zustand v5
- Slice pattern with typed `StateCreator`.
- Selectors must be atomic: `useStore(s => s.field)`.
- For object selectors, use `useShallow` from `zustand/react/shallow`.
- Never call store actions inside render. Actions in event handlers or effects.
- Persist middleware uses localStorage (no Redis on frontend).

## SSE consumption
- Gateway streams PipelineEvent objects via SSE.
- Event schema: `{ run_id, project_id, stage, status, iteration, score, timestamp, payload }`
- Handle END_DEGRADED status: show warning banner, not error.
- Reconnect on disconnect with exponential backoff.

## BlockNote
- Create editor ONCE with `useCreateBlockNote()`.
- Render via `<BlockNoteView>`. Never re-create on each render.
- Pin @blocknote/core, @blocknote/mantine, @blocknote/react to same version.

## Mermaid
- Client-side only via `mermaid.render()`. No server-side rendering.
- MermaidPreview: default to preview mode, source behind toggle.
- For export: render to SVG data URIs client-side before sending to backend.

## Testing
- Vitest + React Testing Library.
- Query by accessible role/name, not test-ids.
- `vi.mock` for module mocks. `userEvent.setup()` not `fireEvent`.
- One assertion per `it` where possible.

## API calls
- All calls go to gateway. Never call core/ or delivery/ directly.
- Use project_id in all API paths for tenant scoping.
