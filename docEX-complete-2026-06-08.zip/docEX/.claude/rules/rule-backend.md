---
paths: ["backend/**", "server/**", "api/**"]
---
# Backend Rules
- Follow the project's existing API patterns (REST, GraphQL, etc.).
- Validate all external input at the boundary.
- Never log secrets or PII.
- Use dependency injection where the project already does.
