# SurrealDB usage rule (Docx data layer)

Scope: `services/docx/**` data access.

## Tenancy is mandatory (LOCKED)
- ONE shared SurrealDB. Every Docx record carries `owner` (user) + `scope` (`org-common` | `private`).
- **Every read query MUST be scoped.** Use `docx.tenancy.surreal_scope_predicate(principal, focus)`:
  - default (focus=False): `(scope = 'org-common' OR owner = $owner)`
  - focus/private (focus=True): `owner = $owner`
  - Bind `$owner` from the authenticated `Principal` (never interpolate).
- **NEVER write a bare `SELECT * FROM <table>`** without the scope predicate. A query without it is a bug.
- Enforce the same at the DB layer via **SurrealDB record PERMISSIONS** (so a forgotten app-side filter cannot leak).

## Collective company brain (LOCKED, HR-cleared)
- **Write default = `scope = 'org-common'`** (uploads enrich the shared brain). `default_write_scope()`.
- **Read default = common** (the big picture). Private/Focus is the opt-in exception.
- Promotion private→common and dedup-by-content-hash + provenance are handled in the ingest layer.

## Embeddings
- Pin the embedding model + dimension per index; record it on the vector. Changing it = a re-embed migration.

## Connection
- Config via `DocxConfig` (`surreal_url/user/password/namespace/database`). Namespaces/DB per the multi-tenancy design.
