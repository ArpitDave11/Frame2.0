# Skills & tools to use for quality (Docx build)

Use these deliberately; they raise quality and cut risk.

1. **Context7 MCP (live docs)** — BEFORE writing unfamiliar SDK calls (SurrealDB Python SDK,
   SurrealDB record-permissions syntax, LangGraph, FastAPI, Docling). Avoids hallucinated APIs.
2. **Open Notebook's working code = primary ground truth** for the port
   (`open_notebook/database/repository.py`, `open_notebook/domain/*`, `open_notebook/graphs/*`).
   Reuse proven usage; adapt for `owner`/`scope` + the shared lib.
3. **superpowers:requesting-code-review** (code-reviewer agent) — independent review of each
   port increment vs. our standards/rules before calling it done.
4. **superpowers:test-driven-development** + **verification-before-completion** — tests first per
   module; never claim done without running tests + ruff (+ later mypy) and quoting output.
5. **superpowers:systematic-debugging** — root-cause any bug, don't patch symptoms.
6. **karpathy-guidelines** — surgical changes; surface assumptions; verifiable success criteria.
7. **Premium UI gate — MANDATORY for any UI work** (see `.claude/rules/frontend-ui.md` and the
   global `~/.claude/CLAUDE.md`): `frontend-design` skill + ground in FRAME's `theme/tokens.ts`
   (Frutiger, `--col-*`) / Figma Dev Mode MCP + **Playwright visual loop (screenshot, never build
   blind)** + a11y lint. Lesson: the first panel was built blind → generic + alien to FRAME.

Project skills to CREATE if the pattern repeats: `port-open-notebook-module`, `add-owner-scoped-route`.

Definition of Done remains: ruff + (mypy) + pytest + owner-scoping test + external-response
validation + provenance/audit + conventional commit (see docs/FINAL_DESIGN.md §11).
