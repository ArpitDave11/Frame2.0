# Standing Protocol

## Per-atomic-task loop
1. Read the task spec from the plan at `{{PLAN_PATH}}`.
2. Mark the task `in_progress` via `mcp__task-master__set_task_status`.
3. Implement the task.
4. Invoke `superpowers:verification-before-completion` — paste actual command output.
5. Append a one-paragraph journal entry to `.powerstack4/task_plan.md`.
6. Mark the task `completed` via `mcp__task-master__set_task_status`.
7. Commit per Conventional Commits; include `Co-Authored-By: Claude <noreply@anthropic.com>`.

## Checkpoints
- At milestone boundaries: run deep-review protocol.
- Zero critical findings required before proceeding.

## When stuck
- Prefer `Explore` agent for reconnaissance over reading many files directly.
- If >3 consecutive retries on the same problem, escalate to the human — don't spin.

## Non-negotiables
- DO NOT edit existing test files to make them pass. Fix the implementation instead.
- DO NOT use `git commit --no-verify`. If a hook fails, fix the cause.
- DO NOT hand-edit `.taskmaster/tasks/*.json` — use `mcp__task-master__*` tools.
