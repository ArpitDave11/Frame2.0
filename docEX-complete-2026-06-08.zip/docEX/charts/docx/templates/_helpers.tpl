{{- define "docx.labels" -}}
app.kubernetes.io/part-of: docx
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{- end -}}
