# DocEX deploy chart (Option B — self-deployed)

DocEX builds its own images and rolls **this** chart into the **shared FRAME namespace**,
independent of FRAME's release. FRAME deploys never touch DocEX; DocEX redeploys only on DocEX
changes. Driven by the repo-root `.gitlab-ci.yml` (`deploy-dev` / `deploy-engg` / `deploy-main`).

## What it deploys (one flat chart, 8 objects)

| Object | Name | Purpose |
|---|---|---|
| StatefulSet + Service | `surrealdb` | the collective-brain datastore (persistent PVC) |
| Deployment + Service + SA | `docx-api` | FastAPI backend, port 8002 |
| Deployment + Service | `docx-web` | the SPA (nginx, port 80), served at `/docex` |
| VirtualService (or Ingress) | `docx` | routes `/docex` → SPA, `/api/docx` → backend (prefix stripped) |

Image tag: **both** DocEX images share this pipeline's `CI_PIPELINE_ID` tag, injected at deploy
(`--set imageTag=<id>-unstable`). SurrealDB uses a fixed mirrored image.

## Runtime dependencies on FRAME (must pre-exist)

- The target **namespace** (`frame` / `frame-dev` / `frame-engg`) — created by FRAME's pipeline.
- The **Istio gateway** the VirtualService binds to (`infra/gateway-patch.yaml` in FRAME).
- **`dm-frame-docmining:8000`** — FRAME's DocMining extractor (DocEX calls it server-side).

## FILL checklist (everything that needs a real UBS value)

In **`.gitlab-ci.yml`** (repo root):
- [ ] `PY_BASE`, `NODE_BASE`, `NGINX_BASE` → mirrored bases on `container-registry.ubs.net`.
- [ ] AKV secret names for `AZURE_OPENAI_EMBEDDING_DEPLOYMENT`, `SURREAL_PASSWORD`, `LOCAL_JWT_SECRET`
      (add these secrets to the vault `akveus2devdmeshdh01`, or your env's vault).
- [ ] Confirm the `include:` CI-template project paths/refs exist for the docEX project.
- [ ] Confirm the dev SPN/Vault/cluster vars (reused from FRAME); swap for a prod cluster if `main`
      deploys somewhere different.

In **`values.yaml`** (+ per-env `values-{dev,engg,main}.yaml`):
- [ ] `surreal.image` → mirrored `surrealdb:v2.6.5` on `container-registry.ubs.net`.
- [ ] `surreal.storageClassName` + `surreal.storage` → real UBS RWO storage class + size. Plan PVC backups.
- [ ] `routing.istio.gateway` + `routing.istio.host` per env (the FRAME gateway name + the env host).
- [ ] `registry` → confirm your DocEX image namespace under `snapshot-container-registry.ubs.net`.

Decisions:
- [ ] `env.AUTH_MODE`: stays `dev` (header identity, in-cluster only via Istio mTLS) until the
      gateway MSAL→JWT minter ships; then flip to `gateway` (the backend half is already built).

## Validate locally before pushing

```bash
helm lint charts/docx -f charts/docx/values-engg.yaml
helm template docx charts/docx -f charts/docx/values-engg.yaml \
  --set imageTag=12345-unstable --set registry=snapshot-container-registry.ubs.net/ubs/wma
```

## Local kind smoke (mirrors AKS; uses nginx instead of Istio)

```bash
docker build -f services/docx/Dockerfile -t frame-docx:dev .
docker build -t frame-docx-web:dev --build-arg VITE_BASE=/docex/ frontend
kubectl create secret generic docx-secrets -n frame-engg \
  --from-literal=AZURE_OPENAI_API_KEY=... --from-literal=AZURE_OPENAI_ENDPOINT=... \
  --from-literal=AZURE_OPENAI_DEPLOYMENT=... --from-literal=AZURE_OPENAI_EMBEDDING_DEPLOYMENT=text-embedding-3-small \
  --from-literal=SURREAL_PASSWORD=devpass --from-literal=LOCAL_JWT_SECRET=$(openssl rand -hex 32)
helm upgrade -i docx charts/docx -n frame-engg \
  --set imageTag=dev --set registry=docker.io/library --set surreal.image=surrealdb/surrealdb:v2.6.5 \
  --set surreal.storageClassName=standard \
  --set routing.istio.enabled=false --set routing.ingressNginx.enabled=true
# then: curl http://frame-engg.local:8080/api/docx/health/ready
```
