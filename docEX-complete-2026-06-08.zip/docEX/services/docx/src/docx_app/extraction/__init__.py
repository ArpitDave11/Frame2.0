"""Hybrid document extraction (LOCKED — FINAL_DESIGN §3.5).

One normalized boundary `extract()` over two engines:
  - content-core (in-process, light path)
  - Docling     (HTTP → FRAME_DEPLOYED DocMining, quality path)
Docling-first for real document files; content-core for web/audio/video/text + as
the universal fallback. Bidirectional fallback; never ingest garbage into the KB.
"""

from docx_app.extraction.models import (
    DocType,
    EngineName,
    ExtractedDoc,
    ExtractInput,
    ExtractStatus,
)
from docx_app.extraction.router import ExtractionError, ExtractionRouter, detect_type

__all__ = [
    "DocType",
    "EngineName",
    "ExtractedDoc",
    "ExtractInput",
    "ExtractStatus",
    "ExtractionError",
    "ExtractionRouter",
    "detect_type",
]
