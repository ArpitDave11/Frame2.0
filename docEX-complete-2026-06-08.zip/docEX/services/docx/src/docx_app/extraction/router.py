"""The extraction router — LOCKED routing + bidirectional fallback (FINAL_DESIGN §3.5).

extract(inp):
  detect type → choose primary engine (Docling-first for document files) →
  run with fallback:
    primary=Docling:      availability-fail → degrade to content-core (status=DEGRADED)
                          doc-fail          → try content-core (last resort)
    primary=content-core: doc/quality-fail  → escalate to Docling (if type is Docling-capable)
  both fail → ExtractionError (clean; caller surfaces to user; never ingest garbage).
"""

from __future__ import annotations

import os
from collections.abc import Callable

from docx_app.extraction.engines.base import (
    Engine,
    EngineAvailabilityError,
    EngineExtractionError,
)
from docx_app.extraction.models import (
    DocType,
    EngineName,
    ExtractedDoc,
    ExtractInput,
    ExtractStatus,
)
from docx_app.extraction.probe import PdfProbe, probe_pdf

_EXT_MAP: dict[str, DocType] = {
    ".pdf": DocType.PDF,
    ".docx": DocType.DOCX,
    ".pptx": DocType.PPTX,
    ".xlsx": DocType.XLSX,
    ".html": DocType.HTML,
    ".htm": DocType.HTML,
    ".png": DocType.IMAGE,
    ".jpg": DocType.IMAGE,
    ".jpeg": DocType.IMAGE,
    ".tiff": DocType.IMAGE,
    ".tif": DocType.IMAGE,
    ".txt": DocType.TXT,
    ".md": DocType.MD,
    ".markdown": DocType.MD,
    ".mp3": DocType.AUDIO,
    ".wav": DocType.AUDIO,
    ".m4a": DocType.AUDIO,
    ".flac": DocType.AUDIO,
    ".ogg": DocType.AUDIO,
    ".mp4": DocType.VIDEO,
    ".mov": DocType.VIDEO,
    ".avi": DocType.VIDEO,
    ".mkv": DocType.VIDEO,
    ".webm": DocType.VIDEO,
}

# Types Docling can handle (so a quality/escalation fallback to Docling is meaningful).
_DOCLING_CAPABLE = {
    DocType.PDF,
    DocType.DOCX,
    DocType.PPTX,
    DocType.XLSX,
    DocType.HTML,
    DocType.IMAGE,
}
# Types whose PRIMARY is Docling (document files), per the locked table.
_DOCLING_FIRST = {DocType.DOCX, DocType.PPTX, DocType.XLSX, DocType.HTML, DocType.IMAGE}

_MIN_MARKDOWN_CHARS = 32  # empty/near-empty → quality failure
_MIN_CHARS_PER_PAGE = 50  # very low text density → likely scanned, escalate


class ExtractionError(Exception):
    """Both engines failed; nothing usable was produced."""


def detect_type(inp: ExtractInput) -> DocType:
    name = (inp.filename or inp.file_path or "").lower()
    _, ext = os.path.splitext(name)
    if ext in _EXT_MAP:
        return _EXT_MAP[ext]
    if inp.url and not inp.file_path:
        return DocType.URL
    return DocType.UNKNOWN


def _is_low_quality(doc: ExtractedDoc) -> bool:
    md = (doc.markdown or "").strip()
    if len(md) < _MIN_MARKDOWN_CHARS:
        return True
    if doc.page_count > 0 and (len(md) / doc.page_count) < _MIN_CHARS_PER_PAGE:
        return True
    return False


class ExtractionRouter:
    def __init__(
        self,
        content_core: Engine,
        docling: Engine,
        probe: Callable[[str], PdfProbe] = probe_pdf,
    ):
        self._cc = content_core
        self._docling = docling
        self._probe = probe

    def decide_primary(
        self, inp: ExtractInput
    ) -> tuple[DocType, EngineName, PdfProbe | None]:
        doctype = detect_type(inp)
        if doctype in _DOCLING_FIRST:
            return doctype, EngineName.DOCLING, None
        if doctype == DocType.PDF:
            probe = self._probe(inp.file_path) if inp.file_path else PdfProbe()
            return (
                doctype,
                (
                    EngineName.DOCLING
                    if probe.needs_docling
                    else EngineName.CONTENT_CORE
                ),
                probe,
            )
        # URL / AUDIO / VIDEO / TXT / MD / UNKNOWN → light path
        return doctype, EngineName.CONTENT_CORE, None

    async def extract(self, inp: ExtractInput) -> ExtractedDoc:
        doctype, primary, _ = self.decide_primary(inp)
        if primary == EngineName.DOCLING:
            return await self._docling_first(inp)
        return await self._content_core_first(inp, doctype)

    async def _docling_first(self, inp: ExtractInput) -> ExtractedDoc:
        try:
            doc = await self._docling.extract(inp)
            doc.engine_used = EngineName.DOCLING
            return doc
        except EngineAvailabilityError:
            # service down → degrade to content-core, flagged
            try:
                doc = await self._cc.extract(inp)
                doc.engine_used = EngineName.CONTENT_CORE
                doc.status = ExtractStatus.DEGRADED
                doc.errors.append(
                    "Docling unavailable; extracted via content-core (degraded)"
                )
                return doc
            except (EngineAvailabilityError, EngineExtractionError) as e:
                raise ExtractionError(
                    f"Docling unavailable and content-core failed: {e}"
                ) from e
        except EngineExtractionError as de:
            # doc-level failure → last-resort content-core (flag provenance)
            try:
                doc = await self._cc.extract(inp)
                doc.engine_used = EngineName.CONTENT_CORE
                doc.errors.append(
                    f"Docling rejected the document ({de}); extracted via content-core"
                )
                return doc
            except (EngineAvailabilityError, EngineExtractionError) as e:
                raise ExtractionError(
                    f"both engines failed: docling={de}; content-core={e}"
                ) from e

    async def _content_core_first(
        self, inp: ExtractInput, doctype: DocType
    ) -> ExtractedDoc:
        escalatable = doctype in _DOCLING_CAPABLE
        try:
            doc = await self._cc.extract(inp)
            doc.engine_used = EngineName.CONTENT_CORE
            # quality fallback: clean PDF that turned out scanned/garbled → escalate to Docling
            if escalatable and _is_low_quality(doc):
                try:
                    better = await self._docling.extract(inp)
                    better.engine_used = EngineName.DOCLING
                    return better
                except (EngineAvailabilityError, EngineExtractionError):
                    return (
                        doc  # keep the (weak) content-core result rather than nothing
                    )
            return doc
        except (EngineAvailabilityError, EngineExtractionError) as cc_err:
            if not escalatable:
                raise ExtractionError(
                    f"content-core failed and Docling not applicable: {cc_err}"
                ) from cc_err
            try:
                doc = await self._docling.extract(inp)
                doc.engine_used = EngineName.DOCLING
                return doc
            except (EngineAvailabilityError, EngineExtractionError) as e:
                raise ExtractionError(
                    f"both engines failed: content-core={cc_err}; docling={e}"
                ) from e
