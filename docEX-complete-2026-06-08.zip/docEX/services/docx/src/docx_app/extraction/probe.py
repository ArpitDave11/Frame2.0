"""Cheap PDF probe — decides which engine a PDF should go to (LOCKED routing).

A PDF is sent to Docling when it is scanned (no real text layer) OR table-heavy;
otherwise it takes the fast content-core path (with a quality fallback to Docling).

The real implementation uses PyMuPDF (text-layer length per page + `find_tables()`).
It is intentionally cheap (~ms). Until PyMuPDF is wired during the port, this returns
a conservative default that keeps the fast path for clean PDFs.
"""

from __future__ import annotations

from pydantic import BaseModel


class PdfProbe(BaseModel):
    scanned: bool = False  # no/low extractable text layer → needs OCR
    table_heavy: bool = False  # significant table structures → needs TableFormer
    page_count: int = 0

    @property
    def needs_docling(self) -> bool:
        return self.scanned or self.table_heavy


def probe_pdf(file_path: str) -> PdfProbe:
    """Probe a PDF to decide routing.

    TODO(port): implement with PyMuPDF —
        doc = fitz.open(file_path)
        text_chars = sum(len(p.get_text()) for p in doc)
        scanned = (text_chars / max(1, doc.page_count)) < TEXT_PER_PAGE_MIN
        table_heavy = any(p.find_tables().tables for p in doc)
    For now: conservative default (clean digital PDF → content-core fast path).
    """
    return PdfProbe(scanned=False, table_heavy=False, page_count=0)
