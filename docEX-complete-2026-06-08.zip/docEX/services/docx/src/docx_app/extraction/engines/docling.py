"""Docling engine — the quality path via FRAME_DEPLOYED's DocMining service (HTTP).

Calls DocMining `POST {docmining_url}/api/v1/documents/analyze` (multipart file) and
maps its response into `ExtractedDoc`. We build no Docling ourselves — DocMining
already runs it offline. All outbound calls use the corporate-CA client.

Failure mapping (so the router can fall back correctly):
  - connect error / client timeout / HTTP 5xx  → EngineAvailabilityError (service down → degrade to content-core)
  - HTTP 413/415/422/504 or status=="failure"  → EngineExtractionError (doc-level; router may try content-core)
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import httpx
from pydantic import BaseModel, ConfigDict, ValidationError

from docx_app.config import DocxConfig
from docx_app.extraction.engines.base import (
    EngineAvailabilityError,
    EngineExtractionError,
)
from docx_app.extraction.models import (
    EngineName,
    ExtractedDoc,
    ExtractInput,
    ExtractStatus,
    OutlineItem,
    TableData,
)
from docx_app.http import make_client

_ANALYZE_PATH = "/api/v1/documents/analyze"


class _DocMiningResponse(BaseModel):
    """Validated shape of DocMining's /analyze response (unknown keys ignored)."""

    model_config = ConfigDict(extra="ignore")

    status: str | None = None
    markdown: str | None = None
    outline: list[dict[str, Any]] = []
    tables: list[dict[str, Any]] = []
    metadata: dict[str, Any] = {}
    pages: int | None = None
    errors: list[Any] = []


class DoclingEngine:
    name = EngineName.DOCLING.value

    def __init__(self, config: DocxConfig):
        self._config = config

    async def extract(self, input: ExtractInput) -> ExtractedDoc:  # noqa: A002
        if not input.file_path:
            raise EngineExtractionError(
                "Docling requires a file (no file_path provided)"
            )
        path = Path(input.file_path)
        if not path.exists():
            raise EngineExtractionError(f"file not found: {input.file_path}")

        url = self._config.docmining_url.rstrip("/") + _ANALYZE_PATH
        try:
            async with make_client(
                self._config, timeout=self._config.docmining_timeout_s
            ) as client:
                with path.open("rb") as fh:
                    resp = await client.post(
                        url,
                        files={"file": (input.filename or path.name, fh)},
                    )
        except (httpx.ConnectError, httpx.ConnectTimeout, httpx.ReadTimeout) as e:
            raise EngineAvailabilityError(f"DocMining unreachable: {e}") from e

        if resp.status_code >= 500:
            raise EngineAvailabilityError(f"DocMining {resp.status_code}")
        if resp.status_code in (413, 415, 422, 504):
            raise EngineExtractionError(
                f"DocMining could not extract ({resp.status_code}): {resp.text[:200]}"
            )
        if resp.status_code != 200:
            raise EngineExtractionError(
                f"DocMining unexpected status {resp.status_code}"
            )

        # Validate the external response through a Pydantic model (§11): a non-JSON 200
        # or schema drift fails loudly as a doc-level error → the router falls back,
        # instead of silently ingesting an empty/garbage document.
        try:
            payload = resp.json()
        except ValueError as e:
            raise EngineExtractionError(f"DocMining returned non-JSON: {e}") from e
        try:
            data = _DocMiningResponse.model_validate(payload)
        except ValidationError as e:
            raise EngineExtractionError(
                f"DocMining response failed validation: {e}"
            ) from e

        # DocMining returns 200 with status SUCCESS | PARTIAL_SUCCESS; real conversion
        # failures are 4xx/5xx (mapped above). Treat PARTIAL_SUCCESS as DEGRADED so the
        # router flags a partial extraction instead of passing it off as clean.
        status = (
            ExtractStatus.DEGRADED
            if (data.status or "").upper() == "PARTIAL_SUCCESS"
            else ExtractStatus.SUCCESS
        )
        return ExtractedDoc(
            markdown=data.markdown or "",
            outline=[OutlineItem(**o) for o in data.outline],
            tables=[
                TableData(index=t.get("index", i), html=t.get("html"), csv=t.get("csv"))
                for i, t in enumerate(data.tables)
            ],
            metadata=data.metadata,
            page_count=data.pages or 0,
            engine_used=EngineName.DOCLING,
            status=status,
            errors=list(data.errors),
        )
