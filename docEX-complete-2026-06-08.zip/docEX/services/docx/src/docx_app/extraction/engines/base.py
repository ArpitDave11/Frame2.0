"""Engine protocol + the two failure kinds the router distinguishes."""

from __future__ import annotations

from typing import Protocol

from docx_app.extraction.models import ExtractedDoc, ExtractInput


class EngineAvailabilityError(Exception):
    """The engine/service is unreachable (e.g. DocMining down). Router degrades to the other engine."""


class EngineExtractionError(Exception):
    """The engine reached but could not extract this document (corrupt/unsupported). Router tries the other."""


class Engine(Protocol):
    name: str

    async def extract(self, input: ExtractInput) -> ExtractedDoc:  # noqa: A002
        ...
