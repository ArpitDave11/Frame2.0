"""content-core engine — the in-process light path (web/audio/video/text + fallback).

Ported from Open Notebook's `graphs/source.content_process`: builds a content-core
state (output_format=markdown, auto engines) and calls `extract_content`, then maps
the result into our normalized `ExtractedDoc`.

`content_core` is imported lazily (heavy/optional dep) so this module always imports
and the router's unit tests run with fakes. Install `content-core` for real extraction.
TODO(port): inject the default speech-to-text model (audio_provider/audio_model) once
ModelManager is ported, so audio/video transcription uses the configured STT model.
"""

from __future__ import annotations

import os

from docx_app.extraction.engines.base import EngineExtractionError
from docx_app.extraction.models import (
    EngineName,
    ExtractedDoc,
    ExtractInput,
    ExtractStatus,
)


class ContentCoreEngine:
    name = EngineName.CONTENT_CORE.value

    async def extract(self, input: ExtractInput) -> ExtractedDoc:  # noqa: A002
        try:
            # lazy (heavy dep); content-core ships partial types without an __all__ export
            from content_core import extract_content  # type: ignore[attr-defined]
        except ImportError as e:  # pragma: no cover - exercised only without the dep
            raise EngineExtractionError("content-core is not installed") from e

        content_state: dict[str, str] = {
            "output_format": "markdown",
            "url_engine": "auto",
            "document_engine": "auto",
        }
        if input.file_path:
            content_state["file_path"] = input.file_path
        if input.url:
            content_state["url"] = input.url

        # content-core raises library-specific errors (e.g. UnsupportedTypeException for
        # json/csv/xml) that are neither our EngineAvailabilityError nor
        # EngineExtractionError — left uncaught they surface as a 500. Contain them, then
        # fall back to reading the file as plain UTF-8 text (json/csv/xml/code/logs ARE
        # their own text content), so only truly-binary inputs fail (cleanly, → 422).
        processed = None
        cc_error: Exception | None = None
        try:
            processed = await extract_content(content_state)
        except Exception as e:  # noqa: BLE001 - resilience boundary; contained below
            cc_error = e

        text = (getattr(processed, "content", None) or "").strip() if processed else ""
        if not text:
            fallback = self._read_text_fallback(input.file_path)
            if fallback:
                text, processed = fallback, None  # metadata now comes from the file
            elif cc_error is not None:
                raise EngineExtractionError(
                    f"content-core could not extract: {cc_error}"
                ) from cc_error
            else:
                raise EngineExtractionError("content-core extracted no text content")

        metadata = {
            k: v
            for k, v in {
                "title": getattr(processed, "title", None) if processed else None,
                "url": getattr(processed, "url", None) if processed else input.url,
                "file_path": (
                    getattr(processed, "file_path", None)
                    if processed
                    else input.file_path
                ),
            }.items()
            if v
        }
        return ExtractedDoc(
            markdown=text,
            metadata=metadata,
            engine_used=EngineName.CONTENT_CORE,
            status=ExtractStatus.SUCCESS,
        )

    @staticmethod
    def _read_text_fallback(path: str | None) -> str | None:
        """Read a file verbatim as UTF-8, or None if missing / not valid UTF-8 (binary).

        Lets otherwise-"unsupported" but textual inputs (json, csv, xml, code, logs) still
        ingest as their raw text; binary inputs (e.g. images) return None and fail cleanly.
        """
        if not path or not os.path.isfile(path):
            return None
        try:
            with open(path, "rb") as fh:
                raw = fh.read()
        except OSError:
            return None
        try:
            return raw.decode("utf-8").strip() or None
        except UnicodeDecodeError:
            return None
