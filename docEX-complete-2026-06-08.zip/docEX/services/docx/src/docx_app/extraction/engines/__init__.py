"""Extraction engines: content-core (in-process) and Docling (HTTP to DocMining)."""

from docx_app.extraction.engines.base import (
    Engine,
    EngineAvailabilityError,
    EngineExtractionError,
)

__all__ = ["Engine", "EngineAvailabilityError", "EngineExtractionError"]
