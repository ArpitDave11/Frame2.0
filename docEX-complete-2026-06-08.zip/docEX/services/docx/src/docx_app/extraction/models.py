"""Normalized extraction types — every engine produces an `ExtractedDoc`."""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class DocType(str, Enum):
    PDF = "pdf"
    DOCX = "docx"
    PPTX = "pptx"
    XLSX = "xlsx"
    HTML = "html"  # an .html FILE (not a live URL)
    IMAGE = "image"
    TXT = "txt"
    MD = "md"
    URL = "url"  # a live web page to fetch
    AUDIO = "audio"
    VIDEO = "video"
    UNKNOWN = "unknown"


class EngineName(str, Enum):
    CONTENT_CORE = "content-core"
    DOCLING = "docling"


class ExtractStatus(str, Enum):
    SUCCESS = "success"
    DEGRADED = "degraded"  # produced, but via availability fallback (flag it)
    FAILURE = "failure"


class ExtractInput(BaseModel):
    """What the user gave us to extract."""

    filename: str | None = None  # original name (drives type detection)
    file_path: str | None = None  # local path to the uploaded file
    url: str | None = None  # a web page to fetch
    content_type: str | None = None  # optional MIME hint


class OutlineItem(BaseModel):
    level: int
    text: str
    page: int | None = None


class TableData(BaseModel):
    index: int
    html: str | None = None
    csv: str | None = None


class ExtractedDoc(BaseModel):
    markdown: str = ""
    outline: list[OutlineItem] = Field(default_factory=list)
    tables: list[TableData] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
    page_count: int = 0
    engine_used: EngineName | None = None
    status: ExtractStatus = ExtractStatus.SUCCESS
    errors: list[str] = Field(default_factory=list)
