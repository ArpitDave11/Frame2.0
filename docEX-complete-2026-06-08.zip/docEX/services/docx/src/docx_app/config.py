"""Docx service configuration (extends the shared BaseConfig).

Adds the Docx-specific settings: SurrealDB connection, the DocMining (Docling)
service URL, the corporate-CA path for outbound TLS, and extraction limits.
All overridable via env vars (pydantic-settings).
"""

import os

from pydantic import field_validator

from shared.config.base import BaseConfig


class DocxConfig(BaseConfig):
    # --- Docx data store: SurrealDB (vector + records + graph relations) ---
    surreal_url: str = "ws://localhost:8000/rpc"
    surreal_user: str = "root"
    surreal_password: str = "root"
    surreal_namespace: str = "docx"
    surreal_database: str = "docx"
    run_migrations_on_startup: bool = True  # apply migrations/*.surql in lifespan

    # --- Auth mode ---
    # "gateway" (prod, default): validate the gateway-minted local JWT.
    # "dev": derive owner from a header (no token) — local FRAME integration before the
    # gateway exists (FRAME is mock-auth + sends no token today).
    auth_mode: str = "gateway"
    dev_user_header: str = "x-docx-user"  # header carrying the owner in dev mode
    dev_owner: str = "dev-user"  # fallback owner when the header is absent (dev mode)

    # --- Docling extraction via FRAME_DEPLOYED's DocMining service (HTTP) ---
    # Base URL of the DocMining service; the analyze path is appended in the adapter.
    # (Distinct port from SurrealDB's :8000 to avoid a local-dev collision.)
    docmining_url: str = "http://localhost:8100"
    docmining_timeout_s: float = 180.0

    # --- Outbound TLS: corporate CA bundle (mounted in the container). Empty = system trust ---
    corporate_ca_path: str = ""

    # --- Extraction limits ---
    max_file_mb: int = 50

    # --- Embeddings (Azure OpenAI; locked provider). Chat deployment lives in BaseConfig ---
    azure_openai_api_version: str = "2024-10-21"
    azure_openai_embedding_deployment: str = "text-embedding-3-small"
    embedding_dimensions: int = 0  # 0 = model native; text-embedding-3-* may reduce
    embedding_batch_size: int = 50

    # --- Test/local providers (NON-PRODUCTION) ---
    # Route LLM + embeddings OFF Azure for local end-to-end testing without UBS-remote
    # Azure access. Keep both "azure" in production.
    #   llm_provider:       "azure" | "claude_cli" (Claude Sonnet via the Claude Code CLI)
    #   embedding_provider: "azure" | "local"      (deterministic in-process vectors)
    llm_provider: str = "azure"
    embedding_provider: str = "azure"

    # --- RepoGraph: GitLab fetch (Surface 3; injected from FRAME 2.0 env at startup) ---
    # Empty gitlab_base_url disables the RepoGraph endpoints (the service starts fine;
    # GitLabService raises GitLabConfigError at call time → the API maps that to HTTP 503).
    # FRAME 2.0 injects GITLAB_BASE_URL + GITLAB_TOKEN via the standard env-var mechanism
    # (pydantic-settings: case-insensitive env vars). DocEX never hard-codes credentials.
    # NOTE: keep these names stable — when FRAME 2.0 delivers a gateway-settings API, a later
    # shim can populate them from the gateway response without touching downstream code.
    gitlab_base_url: str = ""  # e.g. "https://gitlab.ubs.com"; empty = service disabled
    gitlab_token: str = (
        ""  # PRIVATE-TOKEN value; empty = unauthenticated (public repos)
    )
    # RepoGraph reads BOTH GitHub and GitLab — the provider is detected from the URL host.
    # GitHub public repos need no config; github_token is an optional PAT (higher rate limit /
    # private repos), github_api_url overrides the API base for GitHub Enterprise.
    github_api_url: str = "https://api.github.com"
    github_token: str = ""
    gitlab_timeout_s: float = 30.0  # per-request timeout for the GitHub/GitLab REST API
    repograph_max_file_tree_chars: int = (
        780_000  # abort if the filtered file tree exceeds this (mirrors gitdiagram)
    )

    # --- Chunking (char-based, markdown-aware; ported from Open Notebook) ---
    chunk_size: int = 1600  # ~400 tokens
    chunk_overlap: int = 240  # ~15%

    # --- Retrieval (hybrid: vector + BM25 → RRF → optional rerank) ---
    hybrid_enabled: bool = (
        True  # add the BM25 lexical arm; degrades to vector-only if absent
    )
    rerank_enabled: bool = (
        False  # opt-in LLM listwise rerank (extra chat call per query)
    )
    retrieval_candidates: int = 50  # candidates fetched per arm before fusion/rerank

    # --- Collective-brain default (LOCKED): uploads enrich the common KB by default ---
    default_scope: str = "org-common"  # vs "private"

    @field_validator("default_scope")
    @classmethod
    def _valid_default_scope(cls, v: str) -> str:
        # Fail-fast (§11): a misconfigured default must not silently flip write scoping.
        if v not in ("org-common", "private"):
            raise ValueError("default_scope must be 'org-common' or 'private'")
        return v

    @field_validator("auth_mode")
    @classmethod
    def _valid_auth_mode(cls, v: str) -> str:
        if v not in ("gateway", "dev"):
            raise ValueError("auth_mode must be 'gateway' or 'dev'")
        return v

    @field_validator("llm_provider")
    @classmethod
    def _valid_llm_provider(cls, v: str) -> str:
        if v not in ("azure", "claude_cli"):
            raise ValueError("llm_provider must be 'azure' or 'claude_cli'")
        return v

    @field_validator("embedding_provider")
    @classmethod
    def _valid_embedding_provider(cls, v: str) -> str:
        if v not in ("azure", "local"):
            raise ValueError("embedding_provider must be 'azure' or 'local'")
        return v

    @field_validator("corporate_ca_path")
    @classmethod
    def _ca_path_exists(cls, v: str) -> str:
        # Fail-fast (§11): a CA bundle that's set-but-missing must refuse to start, not
        # surface as an opaque TLS error mid-request (and get swallowed by _safe_index).
        if v and not os.path.isfile(v):
            raise ValueError(f"corporate_ca_path does not exist: {v}")
        return v
