"""RetrievalService — hybrid scoped retrieval: vector + BM25 → RRF → optional rerank.

Both arms reuse the same tenancy predicate, so fusion can only ever combine chunks the
principal may see. The BM25 arm degrades gracefully (vector-only) if its SEARCH index
isn't present yet, so the system works before migrations/0002 is applied and improves
once it is.
"""

from __future__ import annotations

from typing import Any

import structlog
from surrealdb import SurrealError

from docx_app.db import SurrealRepository
from docx_app.indexing.embedding import Embedder
from docx_app.retrieval.fusion import reciprocal_rank_fusion
from docx_app.retrieval.models import RetrievedChunk
from docx_app.retrieval.rerank import IdentityReranker, Reranker
from docx_app.retrieval.search import Retriever
from docx_app.tenancy import Principal

log = structlog.get_logger(__name__)


class RetrievalService:
    def __init__(
        self,
        repo: SurrealRepository,
        embedder: Embedder,
        *,
        reranker: Reranker | None = None,
        hybrid: bool = True,
        candidate_k: int = 50,
    ):
        self._repo = repo
        self._embedder = embedder
        self._reranker: Reranker = reranker or IdentityReranker()
        self._hybrid = hybrid
        self._candidate_k = candidate_k

    async def search(
        self,
        query: str,
        principal: Principal,
        *,
        focus: bool = False,
        limit: int = 10,
        min_similarity: float = 0.2,
        notebook: str | None = None,
    ) -> list[RetrievedChunk]:
        if not query or not query.strip():
            return []
        vectors = await self._embedder.embed([query])
        if not vectors:
            return []

        retriever = Retriever(self._repo)
        vec_rows = await retriever.vector_search(
            vectors[0],
            principal,
            focus=focus,
            min_similarity=min_similarity,
            limit=self._candidate_k,
            notebook=notebook,
        )

        bm25_rows: list[dict[str, Any]] = []
        if self._hybrid:
            try:
                bm25_rows = await retriever.keyword_search(
                    query,
                    principal,
                    focus=focus,
                    limit=self._candidate_k,
                    notebook=notebook,
                )
            except SurrealError:
                # The SEARCH index may not be applied yet → degrade to vector-only.
                # Narrowed to SurrealError so real bugs (not DB/query errors) still surface.
                log.warning("bm25_arm_failed_degrading_to_vector", exc_info=True)

        rows = self._fuse(vec_rows, bm25_rows)
        chunks = [RetrievedChunk(**row) for row in rows]
        chunks = await self._reranker.rerank(query, chunks)
        return chunks[:limit]

    @staticmethod
    def _fuse(
        vec_rows: list[dict[str, Any]], bm25_rows: list[dict[str, Any]]
    ) -> list[dict[str, Any]]:
        if not bm25_rows:
            return vec_rows
        fused = reciprocal_rank_fusion(
            [[r["id"] for r in vec_rows], [r["id"] for r in bm25_rows]]
        )
        # Both arms SELECT the same source_chunk row by id, so a duplicate id is the
        # SAME record — listing vector rows last is just a tie-break (not a content merge).
        # `if cid in by_id` guards against any future id in `fused` that isn't in either arm.
        by_id = {r["id"]: r for r in (*bm25_rows, *vec_rows)}
        return [{**by_id[cid], "score": score} for cid, score in fused if cid in by_id]
