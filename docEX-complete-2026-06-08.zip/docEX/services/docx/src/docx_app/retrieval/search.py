"""Scoped vector search over `source_chunk` (SurrealDB cosine similarity).

The WHERE clause reuses `surreal_scope_predicate` — the SAME tenancy guard as writes —
so retrieval obeys the collective-brain rule: default = common KB ∪ own; focus = own only.
A private chunk can never surface for another owner, even if it is the closest vector match.
Mirrors Open Notebook's `fn::vector_search`, but scoped and inlined (no per-user DB session).
"""

from __future__ import annotations

from typing import Any

from docx_app.db import SurrealRepository, ensure_record_id
from docx_app.tenancy import Principal, surreal_scope_predicate


def _scoped_vars(principal: Principal, notebook: str | None) -> dict[str, Any]:
    variables: dict[str, Any] = {"owner": principal.owner}
    if notebook is not None:
        variables["notebook"] = ensure_record_id(notebook)
    return variables


def build_vector_search(
    principal: Principal,
    *,
    focus: bool,
    min_similarity: float,
    limit: int,
    notebook: str | None = None,
) -> tuple[str, dict[str, Any]]:
    """Build the scoped cosine-similarity query and its bound vars (the query vector is `$q`)."""
    where = surreal_scope_predicate(principal, focus, notebook)
    # NB: `order` is not projected — bare `order` in a SELECT collides with ORDER BY in
    # SurrealDB's parser (Open Notebook's fn::vector_search avoids it too).
    query = (
        "SELECT id, source, content, "
        "vector::similarity::cosine(embedding, $q) AS score "
        "FROM source_chunk "
        "WHERE embedding != NONE "
        "AND array::len(embedding) = array::len($q) "
        f"AND ({where}) "
        "AND vector::similarity::cosine(embedding, $q) >= $min "
        f"ORDER BY score DESC LIMIT {int(limit)}"
    )
    return query, {**_scoped_vars(principal, notebook), "min": min_similarity}


def build_keyword_search(
    principal: Principal, *, focus: bool, limit: int, notebook: str | None = None
) -> tuple[str, dict[str, Any]]:
    """Build the scoped BM25 full-text query and its bound vars (the term is `$kw`).

    Same tenancy guard as the vector arm — the BM25 arm cannot surface another owner's
    private chunk either. Requires the `source_chunk` SEARCH index (migrations/0002).
    """
    where = surreal_scope_predicate(principal, focus, notebook)
    query = (
        "SELECT id, source, content, search::score(1) AS score "
        "FROM source_chunk "
        f"WHERE (content @1@ $kw) AND ({where}) "
        f"ORDER BY score DESC LIMIT {int(limit)}"
    )
    return query, _scoped_vars(principal, notebook)


class Retriever:
    def __init__(self, repo: SurrealRepository):
        self._repo = repo

    async def vector_search(
        self,
        query_embedding: list[float],
        principal: Principal,
        *,
        focus: bool = False,
        min_similarity: float = 0.2,
        limit: int = 10,
        notebook: str | None = None,
    ) -> list[dict[str, Any]]:
        query, variables = build_vector_search(
            principal,
            focus=focus,
            min_similarity=min_similarity,
            limit=limit,
            notebook=notebook,
        )
        return await self._repo.query(query, {**variables, "q": query_embedding})

    async def keyword_search(
        self,
        query_text: str,
        principal: Principal,
        *,
        focus: bool = False,
        limit: int = 10,
        notebook: str | None = None,
    ) -> list[dict[str, Any]]:
        query, variables = build_keyword_search(
            principal, focus=focus, limit=limit, notebook=notebook
        )
        return await self._repo.query(query, {**variables, "kw": query_text})
