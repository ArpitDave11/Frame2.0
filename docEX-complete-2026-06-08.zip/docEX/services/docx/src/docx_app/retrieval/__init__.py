"""Retrieval: scoped semantic search over source chunks (the read side of the brain)."""
