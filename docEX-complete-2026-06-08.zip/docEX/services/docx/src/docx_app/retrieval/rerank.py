"""Reranking — reorder fused candidates by relevance.

The locked stack is OpenAI/Azure-only (no Cohere/voyage/cross-encoder), so the concrete
reranker is an LLM *listwise* reranker — opt-in via `config.rerank_enabled`, since it
costs an extra chat call per query. The default is a no-op (keep RRF fusion order), and
the `Reranker` protocol lets a real cross-encoder drop in later.
"""

from __future__ import annotations

import re
from typing import Protocol

import structlog

from docx_app.ai.chat import ChatClient
from docx_app.retrieval.models import RetrievedChunk

log = structlog.get_logger(__name__)


class Reranker(Protocol):
    async def rerank(
        self, query: str, chunks: list[RetrievedChunk]
    ) -> list[RetrievedChunk]: ...


class IdentityReranker:
    """No-op: keep the fusion order."""

    async def rerank(
        self, query: str, chunks: list[RetrievedChunk]
    ) -> list[RetrievedChunk]:
        return chunks


def _parse_order(raw: str, n: int) -> list[int]:
    """Parse a model's ranked list of 1-based numbers into 0-based indices.

    Tolerates junk: keeps valid, in-range, first-seen numbers; appends any the model
    omitted in their original order — so the result is always a full permutation of n.
    """
    seen: set[int] = set()
    order: list[int] = []
    for token in re.findall(r"\d+", raw):
        idx = int(token) - 1
        if 0 <= idx < n and idx not in seen:
            seen.add(idx)
            order.append(idx)
    order.extend(i for i in range(n) if i not in seen)
    return order


class LLMReranker:
    """Listwise rerank via the chat model. Best-effort: keeps fusion order on any failure."""

    def __init__(self, chat: ChatClient, *, top_n: int = 20):
        self._chat = chat
        self._top_n = top_n

    async def rerank(
        self, query: str, chunks: list[RetrievedChunk]
    ) -> list[RetrievedChunk]:
        if len(chunks) <= 1:
            return chunks
        # Note: chunk content is untrusted, but it's already tenancy-filtered upstream and
        # _parse_order only PERMUTES head (never drops/adds), so prompt-injection here is
        # bounded to ordering quality — it cannot leak or hide a chunk.
        head, tail = chunks[: self._top_n], chunks[self._top_n :]
        listing = "\n".join(
            f"[{i + 1}] {(c.content or '')[:300]}" for i, c in enumerate(head)
        )
        system = (
            "You rank passages by relevance to the question. Reply with ONLY a "
            "comma-separated list of the passage numbers, most relevant first, each "
            "number exactly once."
        )
        try:
            raw = await self._chat.complete(
                system=system,
                user=f"Question: {query}\n\nPassages:\n{listing}",
                max_tokens=200,
            )
        except Exception:  # noqa: BLE001 - rerank is best-effort; keep fusion order
            log.warning("rerank_failed_keeping_fusion_order", exc_info=True)
            return chunks
        order = _parse_order(raw, len(head))
        return [head[i] for i in order] + tail
