"""Reciprocal Rank Fusion — combine multiple ranked result lists into one.

Pure utility, ready for the hybrid arms (vector + BM25/keyword). v1 retrieval uses the
vector arm alone; when the lexical arm lands (step 2b), fuse both lists through here.

RRF score for an item = sum over lists of 1 / (k + rank), rank being 0-based position.
"""

from __future__ import annotations


def reciprocal_rank_fusion(
    ranked_lists: list[list[str]], *, k: int = 60
) -> list[tuple[str, float]]:
    """Fuse ranked id-lists into a single list of (id, score), best first."""
    scores: dict[str, float] = {}
    for ranked in ranked_lists:
        for rank, item_id in enumerate(ranked):
            scores[item_id] = scores.get(item_id, 0.0) + 1.0 / (k + rank + 1)
    return sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
