"""Retrieval result types."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class RetrievedChunk(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: str | None = None
    source: str | None = None  # record<source> the chunk belongs to
    content: str | None = None
    order: int = 0
    # relevance score: cosine similarity when vector-only, RRF fusion score when hybrid
    # (so don't render it as a raw "% match" — it's a ranking score, not a similarity).
    score: float = 0.0
