"""Chat completion via Azure OpenAI (the locked provider).

Uses the chat deployment from BaseConfig. Outbound TLS goes through the corporate-CA
client (FINAL_DESIGN §11), same as embeddings.

For LOCAL end-to-end testing without Azure access, `ClaudeCliChatClient` routes the same
`complete()` contract to Claude Sonnet via the local `claude` CLI (selected with
`llm_provider="claude_cli"`). It is strictly a test aid — never enable it in production.
"""

from __future__ import annotations

import asyncio
from typing import Any

import structlog
from openai import AsyncAzureOpenAI

from docx_app.config import DocxConfig
from docx_app.http import make_client

log = structlog.get_logger(__name__)

# Defensive upper bound on the user content piped to the `claude` CLI (test path only).
# The CLI has no output-token flag (see ClaudeCliChatClient.complete), so this guards the
# *input* side instead: it stops a pathological prompt (e.g. an enormous source body) from
# spawning a runaway subprocess / oversized stdin write. Sized far above every real caller
# (~150k tokens ≈ 600k chars; the largest production caller asks for 8192 *output* tokens
# and feeds prompts orders of magnitude smaller), so it never truncates legitimate input —
# and if it ever does fire it is logged, never swallowed (no silent caps).
CLAUDE_CLI_MAX_INPUT_CHARS = 600_000


class ChatClient:
    def __init__(self, config: DocxConfig):
        self._c = config

    async def complete(self, *, system: str, user: str, max_tokens: int = 1000) -> str:
        http_client = make_client(self._c, timeout=120.0)  # corporate-CA verified
        client = AsyncAzureOpenAI(
            api_key=self._c.azure_openai_api_key,
            azure_endpoint=self._c.azure_openai_endpoint,
            api_version=self._c.azure_openai_api_version,
            http_client=http_client,
        )
        messages: list[Any] = [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ]
        try:
            resp = await client.chat.completions.create(
                model=self._c.azure_openai_deployment,
                messages=messages,
                max_completion_tokens=max_tokens,
            )
            if not resp.choices:  # e.g. a content-filtered / empty envelope
                return ""
            return resp.choices[0].message.content or ""
        finally:
            await client.close()
            await http_client.aclose()


class ClaudeCliChatClient(ChatClient):
    """TEST-ONLY chat client — routes `complete()` to Claude Sonnet via the local `claude`
    CLI (Claude Code auth) instead of Azure OpenAI, so every LLM-dependent flow
    (transformations, ask, source chat, insights) can be exercised end-to-end with no
    Azure access. Never enable in production.

    `--system-prompt` REPLACES Claude Code's agentic persona with the caller's system
    prompt (so output is a clean completion, not an assistant reply); the user content is
    piped via stdin to avoid argv length limits on large inputs.

    `max_tokens` (an OUTPUT cap on the Azure path) cannot be forwarded: the CLI has no
    output-token-limit flag. It is accepted for contract parity and the *input* is capped
    instead (with a logged warning) — see `complete()` and `CLAUDE_CLI_MAX_INPUT_CHARS`.
    """

    async def complete(self, *, system: str, user: str, max_tokens: int = 1000) -> str:
        # `max_tokens` is honoured by the Azure path (as `max_completion_tokens`) but CANNOT
        # be forwarded here: the `claude` CLI exposes no output-token-limit flag. Its only
        # budget controls are `--max-budget-usd` (a *dollar* cap, not a token count) and
        # `--json-schema` (shapes output, doesn't bound length) — neither maps to a
        # max-output-tokens semantic. So we accept `max_tokens` to satisfy the shared
        # `complete()` contract (and the `_ChatLike`/Protocol callers) but leave Sonnet to
        # its own default output length on this test-only path. Sonnet's default ceiling far
        # exceeds any caller's request (max 8192), so completions are not clipped.
        _ = max_tokens  # accepted for contract parity; intentionally not a CLI flag (see above)

        # Cap the *input* instead — the lever the CLI does give us — so a pathological prompt
        # can't spawn a runaway subprocess. Truncation is logged, never silent (the cap is
        # sized never to hit real inputs; see CLAUDE_CLI_MAX_INPUT_CHARS).
        if len(user) > CLAUDE_CLI_MAX_INPUT_CHARS:
            log.warning(
                "claude_cli_input_truncated",
                original_chars=len(user),
                capped_chars=CLAUDE_CLI_MAX_INPUT_CHARS,
            )
            user = user[:CLAUDE_CLI_MAX_INPUT_CHARS]

        args = [
            "claude",
            "-p",
            "--model",
            "sonnet",
            "--system-prompt",
            system or "You are a helpful assistant.",
            "--exclude-dynamic-system-prompt-sections",
        ]
        proc = await asyncio.create_subprocess_exec(
            *args,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        out, err = await proc.communicate(user.encode("utf-8"))
        if proc.returncode != 0:
            detail = err.decode("utf-8", "replace")[:500]
            raise RuntimeError(f"claude CLI exited {proc.returncode}: {detail}")
        return out.decode("utf-8", "replace").strip()
