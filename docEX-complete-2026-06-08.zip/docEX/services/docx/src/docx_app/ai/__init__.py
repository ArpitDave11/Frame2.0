"""AI clients (Azure OpenAI — the locked provider)."""
