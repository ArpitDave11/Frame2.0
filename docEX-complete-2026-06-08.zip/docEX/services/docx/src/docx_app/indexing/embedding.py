"""Embeddings via Azure OpenAI (the locked provider).

Open Notebook routes embeddings through Esperanto's multi-provider abstraction; Docx is
locked to OpenAI/Azure, so we call Azure OpenAI directly. Outbound TLS goes through the
corporate-CA client (FINAL_DESIGN §11). Inputs are batched like Open Notebook's
`generate_embeddings`.
"""

from __future__ import annotations

import hashlib
import math
from typing import Any

from openai import AsyncAzureOpenAI

from docx_app.config import DocxConfig
from docx_app.http import make_client


class Embedder:
    """Batched Azure OpenAI embeddings. One vector per input text, order preserved."""

    def __init__(self, config: DocxConfig):
        self._c = config

    async def embed(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []

        http_client = make_client(self._c, timeout=60.0)  # corporate-CA verified
        client = AsyncAzureOpenAI(
            api_key=self._c.azure_openai_api_key,
            azure_endpoint=self._c.azure_openai_endpoint,
            api_version=self._c.azure_openai_api_version,
            http_client=http_client,
        )
        try:
            out: list[list[float]] = []
            batch = self._c.embedding_batch_size
            for start in range(0, len(texts), batch):
                kwargs: dict[str, Any] = {
                    "model": self._c.azure_openai_embedding_deployment,
                    "input": texts[start : start + batch],
                }
                if self._c.embedding_dimensions:  # only text-embedding-3-* support this
                    kwargs["dimensions"] = self._c.embedding_dimensions
                resp = await client.embeddings.create(**kwargs)
                out.extend(item.embedding for item in resp.data)
            return out
        finally:
            await client.close()
            await http_client.aclose()


class LocalTestEmbedder(Embedder):
    """TEST-ONLY deterministic embedder (no Azure, no network) — selected with
    `embedding_provider="local"`. Hashes whitespace tokens into a fixed-dimension,
    L2-normalized vector so the chunk→embed→store→vector-search pipeline runs end-to-end
    locally. It is lexical, not semantic, so cosine reflects shared tokens — enough to
    verify the plumbing, not a substitute for a real embedding model.

    Dimension is arbitrary: the schema stores `embedding` as `array<float>` and searches
    via a sequential cosine scan (no fixed-dim index), and queries embed through the same
    class, so stored and query vectors always agree.
    """

    DIM = 256

    async def embed(self, texts: list[str]) -> list[list[float]]:
        return [self._vector(t) for t in texts]

    @classmethod
    def _vector(cls, text: str) -> list[float]:
        vec = [0.0] * cls.DIM
        for token in text.lower().split():
            digest = hashlib.md5(token.encode("utf-8")).digest()
            vec[int.from_bytes(digest[:4], "big") % cls.DIM] += 1.0
        norm = math.sqrt(sum(x * x for x in vec)) or 1.0
        return [x / norm for x in vec]
