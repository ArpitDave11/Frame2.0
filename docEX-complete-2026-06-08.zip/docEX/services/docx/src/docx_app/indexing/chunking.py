"""Markdown-aware text chunking (ported from Open Notebook's `utils/chunking.py`).

Our extraction always emits markdown (Docling / content-core `output_format="markdown"`),
so we split on headers first — keeping each section coherent with its heading — then
size-split any oversized section. Char-based (not tiktoken) so it stays offline-safe and
dependency-light; the defaults (~1600 chars ≈ 400 tokens) sit well under embedding limits.
"""

from __future__ import annotations

from langchain_text_splitters import (
    MarkdownHeaderTextSplitter,
    RecursiveCharacterTextSplitter,
)

_HEADERS = [("#", "h1"), ("##", "h2"), ("###", "h3")]
_SEPARATORS = ["\n\n", "\n", ". ", ", ", " ", ""]


def chunk_text(text: str, *, chunk_size: int = 1600, overlap: int = 240) -> list[str]:
    """Split markdown into header-aware, size-bounded chunks (empty in → empty out)."""
    if not text or not text.strip():
        return []

    header_splitter = MarkdownHeaderTextSplitter(
        headers_to_split_on=_HEADERS, strip_headers=False
    )
    secondary = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size, chunk_overlap=overlap, separators=_SEPARATORS
    )

    chunks: list[str] = []
    for section in header_splitter.split_text(text):
        body = section.page_content
        if len(body) > chunk_size:
            chunks.extend(secondary.split_text(body))
        else:
            chunks.append(body)
    return [c.strip() for c in chunks if c.strip()]
