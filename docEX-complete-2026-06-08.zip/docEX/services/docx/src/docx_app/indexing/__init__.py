"""Indexing: turn a stored Source's text into scoped, embedded chunks for retrieval."""
