"""Indexing service — chunk → embed → store a Source's text for scoped retrieval.

v1 runs inline behind this seam. Open Notebook does this in an async, retryable command
(`embed_source`); moving Docx to a Procrastinate task later is a drop-in change at the
call site, not here.
"""

from __future__ import annotations

import structlog

from docx_app.db import SurrealRepository
from docx_app.domain.chunk import ChunkStore
from docx_app.domain.source import Source, scoped_update
from docx_app.indexing.chunking import chunk_text
from docx_app.indexing.embedding import Embedder
from docx_app.tenancy import Scope

log = structlog.get_logger(__name__)


class IndexingService:
    def __init__(
        self,
        repo: SurrealRepository,
        embedder: Embedder,
        *,
        chunk_size: int,
        overlap: int,
    ):
        self._repo = repo
        self._embedder = embedder
        self._chunk_size = chunk_size
        self._overlap = overlap

    async def index_source(self, source: Source) -> int:
        """Chunk + embed the source's text and store it scoped to its owner. Returns count."""
        if not source.id or not source.full_text or not source.full_text.strip():
            return 0

        chunks = chunk_text(
            source.full_text, chunk_size=self._chunk_size, overlap=self._overlap
        )
        if not chunks:
            return 0

        embeddings = await self._embedder.embed(chunks)
        if source.scope:
            scope = Scope(source.scope)
        else:
            # Stored Sources are always stamped; a missing scope is a bug. Fail CLOSED to
            # the narrowest scope (never silently widen a doc into the shared brain).
            scope = Scope.PRIVATE
            log.warning("source_missing_scope", source_id=source.id)
        count = await ChunkStore(self._repo).replace_for_source(
            source.id,
            chunks,
            embeddings,
            owner=source.owner or "",
            scope=scope,
            notebook=source.notebook,
        )
        # Persist chunk_count on the source row (owner-scoped) so it survives restart and
        # powers the list "embedded" view + rebuild(mode="existing"). Previously it was only
        # set on the in-memory response object, so rebuild-existing found nothing to re-embed.
        await scoped_update(
            self._repo,
            "source",
            {"chunk_count": count},
            owner=source.owner or "",
            record_id=source.id,
        )
        log.info("source_indexed", source_id=source.id, chunks=count, scope=scope.value)
        return count
