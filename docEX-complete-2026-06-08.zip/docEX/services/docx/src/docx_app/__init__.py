"""Docx — collective company-brain document-intelligence service.

v1 integrates with FRAME_DEPLOYED (host SPA + DocMining/Docling). Built reusing
Open Notebook's chat/ask logic + Notebook/Source/Note model on SurrealDB.
See docs/FINAL_DESIGN.md.
"""

__version__ = "0.1.0"
