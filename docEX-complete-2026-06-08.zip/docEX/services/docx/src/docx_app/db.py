"""Docx SurrealDB layer — owner/scope-aware (adapted from Open Notebook's repository).

Reuses Open Notebook's proven pattern (connection-per-op + RecordID parsing) but:
  - reads connection from `DocxConfig` (not os.getenv),
  - stamps every write with `owner` + `scope` (collective-brain defaults),
  - scopes every read with the tenancy predicate (APP-layer enforcement — the service
    connects as one principal, so isolation lives here; see tenancy.py + the leak test).

NEVER build a bare `SELECT ... FROM <table>` — always go through `select_scoped()` /
`build_scoped_select()`. See .claude/rules/surrealdb-usage.md.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Any

from surrealdb import AsyncSurreal, RecordID

from docx_app.config import DocxConfig
from docx_app.tenancy import Principal, Scope, surreal_scope_predicate


def parse_record_ids(obj: Any) -> Any:
    """Recursively normalise SurrealDB types to JSON-friendly primitives.

    RecordID → str, datetime → ISO string. The domain models carry `id`/`created`/
    `updated` as `str`, and SurrealDB returns RecordID + datetime objects respectively.
    """
    if isinstance(obj, dict):
        return {k: parse_record_ids(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [parse_record_ids(item) for item in obj]
    if isinstance(obj, RecordID):
        return str(obj)
    if isinstance(obj, datetime):
        return obj.isoformat()
    return obj


def ensure_record_id(value: str | RecordID) -> RecordID:
    return value if isinstance(value, RecordID) else RecordID.parse(value)


# --- Pure query builders (unit-tested without a live DB) -------------------


def scoped_write_fields(owner: str, scope: Scope) -> dict[str, str]:
    """The owner/scope columns stamped on every Docx write."""
    return {"owner": owner, "scope": scope.value}


def build_scoped_select(
    table: str,
    principal: Principal,
    *,
    focus: bool = False,
    extra_where: str = "",
    order_by: str = "updated DESC",
    limit: int | None = None,
    notebook: str | None = None,
) -> tuple[str, dict[str, Any]]:
    """Build an owner/scope-filtered SELECT and its bound vars.

    default (focus=False): (scope = 'org-common' OR owner = $owner)  → the common brain + own
    focus=True            : owner = $owner                            → only the user's own
    notebook set          : owner = $owner AND notebook = $notebook   → a specific workspace
    """
    where = f"({surreal_scope_predicate(principal, focus, notebook)})"
    if extra_where:
        where += f" AND ({extra_where})"
    query = f"SELECT * FROM {table} WHERE {where}"
    if order_by:
        query += f" ORDER BY {order_by}"
    if limit:
        query += f" LIMIT {int(limit)}"
    variables: dict[str, Any] = {"owner": principal.owner}
    if notebook is not None:
        variables["notebook"] = ensure_record_id(notebook)
    return query, variables


# --- Repository ------------------------------------------------------------


class SurrealRepository:
    def __init__(self, config: DocxConfig):
        self._c = config

    @asynccontextmanager
    async def _connect(
        self,
    ) -> AsyncIterator[Any]:  # AsyncSurreal is an untyped factory
        db = AsyncSurreal(self._c.surreal_url)
        await db.signin(
            {"username": self._c.surreal_user, "password": self._c.surreal_password}
        )
        await db.use(self._c.surreal_namespace, self._c.surreal_database)
        try:
            yield db
        finally:
            await db.close()

    async def query(
        self, query_str: str, vars: dict[str, Any] | None = None
    ) -> list[dict[str, Any]]:
        async with self._connect() as db:
            # surrealdb 2.x raises on a failed statement and returns the first statement's
            # rows; there is no error-as-string sentinel (unlike the old 0.3.x driver).
            # Keep queries single-statement — only the first statement's result comes back.
            return parse_record_ids(await db.query(query_str, vars))

    async def create_scoped(
        self, table: str, data: dict[str, Any], *, owner: str, scope: Scope
    ) -> dict[str, Any]:
        """Insert a record stamped with owner + scope + timestamps."""
        record = {
            **data,
            **scoped_write_fields(owner, scope),
            "created": datetime.now(timezone.utc),
            "updated": datetime.now(timezone.utc),
        }
        record.pop("id", None)
        async with self._connect() as db:
            return parse_record_ids(await db.insert(table, record))

    async def insert_scoped(
        self, table: str, rows: list[dict[str, Any]], *, owner: str, scope: Scope
    ) -> int:
        """Bulk-insert rows, each stamped with owner + scope + a created timestamp."""
        if not rows:
            return 0
        stamped = [
            {
                **r,
                **scoped_write_fields(owner, scope),
                "created": datetime.now(timezone.utc),
            }
            for r in rows
        ]
        async with self._connect() as db:
            result = parse_record_ids(await db.insert(table, stamped))
            return len(result) if isinstance(result, list) else 0

    async def delete_where(
        self, table: str, where: str, vars: dict[str, Any] | None = None
    ) -> None:
        """DELETE rows matching `where` (table + where are code constants; values bound)."""
        await self.query(f"DELETE {table} WHERE {where}", vars)

    async def select_scoped(
        self,
        table: str,
        principal: Principal,
        *,
        focus: bool = False,
        extra_where: str = "",
        order_by: str = "updated DESC",
        limit: int | None = None,
        vars: dict[str, Any] | None = None,
        notebook: str | None = None,
    ) -> list[dict[str, Any]]:
        query, base_vars = build_scoped_select(
            table,
            principal,
            focus=focus,
            extra_where=extra_where,
            order_by=order_by,
            limit=limit,
            notebook=notebook,
        )
        return await self.query(query, {**base_vars, **(vars or {})})
