"""Migration runner — apply `migrations/*.surql` on startup, once, in order.

Lighter than Open Notebook's AsyncMigrationManager but the same idea: applied files are
recorded in a `docx_migration` table and skipped next time. Our `.surql` files are all
`IF NOT EXISTS`, so re-applying is harmless even if the record is lost. A failing
statement raises → startup fails (fail-fast, FINAL_DESIGN §11): never serve on a
half-migrated schema.
"""

from __future__ import annotations

from pathlib import Path

import structlog

from docx_app.db import SurrealRepository

log = structlog.get_logger(__name__)

# migrations/ sits at the service root (sibling of src/). __file__ = .../src/docx/migrate.py
MIGRATIONS_DIR = Path(__file__).resolve().parents[2] / "migrations"
_MIGRATION_TABLE = "docx_migration"


def _split_statements(surql: str) -> list[str]:
    """Split a .surql file into individual statements.

    Strips `--` line/trailing comments and splits on `;`. Adequate for our DDL, which has
    no `;` or `--` inside string literals. Running statements one-by-one (rather than as a
    single multi-statement query) means each error surfaces — the surrealdb 2.x driver only
    reports the first statement's result for a combined query.
    """
    no_comments = "\n".join(line.split("--", 1)[0] for line in surql.splitlines())
    return [stmt.strip() for stmt in no_comments.split(";") if stmt.strip()]


async def _applied(repo: SurrealRepository) -> set[str]:
    await repo.query(f"DEFINE TABLE IF NOT EXISTS {_MIGRATION_TABLE} SCHEMALESS")
    rows = await repo.query(f"SELECT name FROM {_MIGRATION_TABLE}")
    return {str(r["name"]) for r in rows if isinstance(r, dict) and "name" in r}


async def apply_migrations(
    repo: SurrealRepository, migrations_dir: Path | None = None
) -> list[str]:
    """Apply not-yet-applied .surql files in filename order. Returns the names applied."""
    directory = migrations_dir or MIGRATIONS_DIR
    done = await _applied(repo)
    newly: list[str] = []
    for path in sorted(directory.glob("*.surql")):
        if path.name in done:
            continue
        for statement in _split_statements(path.read_text()):
            await repo.query(statement)  # raises on error → startup fails
        await repo.query(
            f"CREATE {_MIGRATION_TABLE} SET name = $name, applied = time::now()",
            {"name": path.name},
        )
        newly.append(path.name)
        log.info("migration_applied", name=path.name)
    return newly
