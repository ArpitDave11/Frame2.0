"""Source chunk — a slice of a Source's text plus its embedding vector.

Mirrors Open Notebook's `source_embedding` table, but each chunk also carries `owner` +
`scope` (denormalised from the parent Source) so semantic retrieval can be tenancy-scoped
at the chunk level — the same collective-brain rule as Sources.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from docx_app.db import SurrealRepository, ensure_record_id
from docx_app.tenancy import Scope


class Chunk(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: str | None = None
    source: str | None = None  # record<source>
    order: int = 0
    content: str | None = None
    embedding: list[float] = Field(default_factory=list)
    owner: str | None = None
    scope: str | None = None
    notebook: str | None = (
        None  # workspace (record<notebook>), denormalised from the Source
    )
    created: str | None = None


class ChunkStore:
    """Per-source chunk storage. Re-indexing is idempotent (replace, not append)."""

    TABLE = "source_chunk"

    def __init__(self, repo: SurrealRepository):
        self._repo = repo

    async def replace_for_source(
        self,
        source_id: str,
        chunks: list[str],
        embeddings: list[list[float]],
        *,
        owner: str,
        scope: Scope,
        notebook: str | None = None,
    ) -> int:
        """Drop this owner's existing chunks for the source, then bulk-insert the new set.

        The delete is owner-scoped (not just by source) so a re-index can never wipe or
        repopulate another owner's chunks — the same tenancy rule as every other query.
        `notebook` is denormalised onto each chunk so retrieval can scope to a workspace.
        """
        await self._repo.delete_where(
            self.TABLE,
            "source = $sid AND owner = $owner",
            {"sid": ensure_record_id(source_id), "owner": owner},
        )
        notebook_ref = ensure_record_id(notebook) if notebook is not None else None
        rows: list[dict[str, Any]] = [
            {
                "source": ensure_record_id(source_id),
                "order": order,
                "content": content,
                "embedding": embedding,
                "notebook": notebook_ref,
            }
            for order, (content, embedding) in enumerate(
                zip(chunks, embeddings, strict=True)
            )
        ]
        return await self._repo.insert_scoped(
            self.TABLE, rows, owner=owner, scope=scope
        )
