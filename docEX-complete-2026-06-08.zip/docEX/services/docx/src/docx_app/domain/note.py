"""Note — a user's standalone or workspace-linked annotation (Open Notebook's Note).

Slim, owner/scope-native port of Open Notebook's Note. Notes are owner-PRIVATE (like
notebooks): they organise the user's own view, so every read is owner-scoped (focus) and
every write is stamped with owner + scope=private. A note may be linked to a single
workspace via the denormalised `notebook` field — ON links notes to a notebook with an
`artifact` graph edge, but Docx models a single workspace by a `notebook` record ref
(same simplification as Source, see domain/source.py & domain/notebook.py).

Aligned to Open Notebook's frontend contract (lib/api/notes.ts): a note carries
`title`/`content`/`note_type` (`human` | `ai`) plus `created`/`updated`; list supports a
`notebook_id` filter.

Open Notebook embeds note content via an async `embed_note` command. Docx has no job
queue, so `NoteStore.embed` chunks + embeds the content inline (best-effort) via the
existing Embedder into a parallel `note_chunk` table (mirrors source_chunk). Source-based
ask/retrieval only reads `source_chunk`, so note embeddings are isolated and never leak
into source answers — see retrieval/search.py.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict

from docx_app.db import SurrealRepository, ensure_record_id
from docx_app.domain.source import scoped_update
from docx_app.indexing.chunking import chunk_text
from docx_app.indexing.embedding import Embedder
from docx_app.tenancy import Principal, Scope

# Mirrors ON: a note is either a human-authored note or an AI-generated one. The router
# validates incoming values against this set (anything else → HTTP 400).
NOTE_TYPES = frozenset({"human", "ai"})


def validate_note_type(value: str | None) -> str | None:
    """Validate ON's `note_type` ('human' | 'ai' | None). Raises ValueError otherwise."""
    if value is None:
        return None
    if value not in NOTE_TYPES:
        raise ValueError("note_type must be 'human' or 'ai'")
    return value


class Note(BaseModel):
    # surreal records carry extra fields (owner/scope/created/updated) — keep, ignore unknowns
    model_config = ConfigDict(extra="ignore")

    id: str | None = None
    title: str | None = None
    content: str | None = None
    note_type: str | None = None
    owner: str | None = None
    scope: str | None = None
    notebook: str | None = (
        None  # the workspace it belongs to (record<notebook>), optional
    )
    created: str | None = None
    updated: str | None = None


class NoteChunkStore:
    """Per-note embedding storage (parallel to source's ChunkStore). Idempotent replace."""

    TABLE = "note_chunk"

    def __init__(self, repo: SurrealRepository):
        self._repo = repo

    async def replace_for_note(
        self,
        note_id: str,
        chunks: list[str],
        embeddings: list[list[float]],
        *,
        owner: str,
        scope: Scope,
        notebook: str | None = None,
    ) -> int:
        """Drop this owner's existing chunks for the note, then bulk-insert the new set.

        The delete is owner-scoped (not just by note) so a re-embed can never wipe or
        repopulate another owner's chunks — the same tenancy rule as every other write.
        """
        await self._repo.delete_where(
            self.TABLE,
            "note = $nid AND owner = $owner",
            {"nid": ensure_record_id(note_id), "owner": owner},
        )
        if not chunks:
            return 0
        notebook_ref = ensure_record_id(notebook) if notebook is not None else None
        rows: list[dict[str, Any]] = [
            {
                "note": ensure_record_id(note_id),
                "order": order,
                "content": content,
                "embedding": embedding,
                "notebook": notebook_ref,
            }
            for order, (content, embedding) in enumerate(
                zip(chunks, embeddings, strict=True)
            )
        ]
        return await self._repo.insert_scoped(
            self.TABLE, rows, owner=owner, scope=scope
        )


class NoteStore:
    """Persistence for Note — owner-PRIVATE (a user only ever sees their own notes)."""

    TABLE = "note"

    def __init__(self, repo: SurrealRepository):
        self._repo = repo

    @staticmethod
    def _to_note(record: dict[str, Any] | list[Any]) -> Note:
        if isinstance(record, list):
            record = record[0] if record else {}
        return Note(**record)

    async def create(
        self,
        *,
        owner: str,
        title: str | None = None,
        content: str | None = None,
        note_type: str | None = None,
        notebook: str | None = None,
    ) -> Note:
        data: dict[str, Any] = {
            "title": title,
            "content": content,
            "note_type": note_type,
        }
        if notebook is not None:
            data["notebook"] = ensure_record_id(notebook)
        # PRIVATE: a note is the user's own annotation, not part of the shared brain.
        record = await self._repo.create_scoped(
            self.TABLE, data, owner=owner, scope=Scope.PRIVATE
        )
        return self._to_note(record)

    async def list(
        self,
        principal: Principal,
        *,
        notebook: str | None = None,
        order_by: str = "updated DESC",
        limit: int = 1000,
    ) -> list[Note]:
        """The caller's notes, optionally restricted to one workspace.

        notebook set → owner = $owner AND notebook = $notebook (the workspace's notes);
        otherwise    → focus=True (all of the caller's own notes). Either way it is
        owner-scoped, so another owner's notes are never returned.
        """
        rows = await self._repo.select_scoped(
            self.TABLE,
            principal,
            focus=True,  # notes are owner-private
            order_by=order_by,
            limit=limit,
            notebook=notebook,
        )
        return [self._to_note(r) for r in rows]

    async def get(self, note_id: str, principal: Principal) -> Note | None:
        rows = await self._repo.select_scoped(
            self.TABLE,
            principal,
            focus=True,  # own notes only
            extra_where="id = $nid",
            vars={"nid": ensure_record_id(note_id)},
            limit=1,
        )
        return self._to_note(rows[0]) if rows else None

    async def update(
        self,
        note_id: str,
        principal: Principal,
        *,
        title: str | None = None,
        content: str | None = None,
        note_type: str | None = None,
    ) -> Note | None:
        """Patch the named fields on a note the caller OWNS (None = leave unchanged).

        The owner-scoped read first proves ownership, so the subsequent owner-scoped
        UPDATE can never touch another owner's row (mirrors the leak guard)."""
        existing = await self.get(note_id, principal)
        if existing is None:
            return None
        updates: dict[str, Any] = {}
        if title is not None:
            updates["title"] = title
        if content is not None:
            updates["content"] = content
        if note_type is not None:
            updates["note_type"] = note_type
        if not updates:
            return existing
        rows = await scoped_update(
            self._repo,
            self.TABLE,
            updates,
            owner=principal.owner,
            record_id=note_id,
        )
        return self._to_note(rows[0]) if rows else existing

    async def delete(self, note_id: str, principal: Principal) -> bool:
        """Delete a note the caller OWNS plus its embeddings. False if it isn't theirs.

        Both deletes carry `owner = $owner` so a delete can never reach another owner's
        note or chunks (same tenancy guard as ChunkStore)."""
        if await self.get(note_id, principal) is None:
            return False
        await self._repo.delete_where(
            NoteChunkStore.TABLE,
            "note = $nid AND owner = $owner",
            {"nid": ensure_record_id(note_id), "owner": principal.owner},
        )
        await self._repo.delete_where(
            self.TABLE,
            "id = $nid AND owner = $owner",
            {"nid": ensure_record_id(note_id), "owner": principal.owner},
        )
        return True

    async def count_chunks(self, note_id: str, principal: Principal) -> int:
        """Number of stored embedding chunks for this note the caller can see."""
        rows = await self._repo.select_scoped(
            NoteChunkStore.TABLE,
            principal,
            focus=True,
            extra_where="note = $nid",
            vars={"nid": ensure_record_id(note_id)},
            order_by="",
        )
        return len(rows)

    async def embed(
        self, note: Note, embedder: Embedder, *, chunk_size: int, overlap: int
    ) -> int:
        """Chunk + embed the note's content, stored scoped to its owner. Returns the count.

        Inline stand-in for Open Notebook's async `embed_note` command (Docx has no job
        queue). Owner/scope are taken from the stored Note; a missing scope fails CLOSED to
        PRIVATE (never silently widen a note into the shared brain — same rule as
        IndexingService.index_source)."""
        if not note.id or not note.content or not note.content.strip():
            return 0
        chunks = chunk_text(note.content, chunk_size=chunk_size, overlap=overlap)
        if not chunks:
            return 0
        embeddings = await embedder.embed(chunks)
        scope = Scope(note.scope) if note.scope else Scope.PRIVATE
        return await NoteChunkStore(self._repo).replace_for_note(
            note.id,
            chunks,
            embeddings,
            owner=note.owner or "",  # stored notes are always owner-stamped
            scope=scope,
            notebook=note.notebook,
        )
