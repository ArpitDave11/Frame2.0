"""Notebook — a user's workspace (Open Notebook's Notebook).

Uploads are organised into notebooks; retrieval can be focused to one ("Focus on a
workspace"). Notebooks are PRIVATE to their owner — they organise the user's own view,
while the collective brain (org-common sources) cuts across all workspaces.

Ported to Open Notebook's frontend contract (lib/api/notebooks.ts): list supports an
`archived` filter + `order_by`; notebooks carry an `archived` flag and report
`source_count` (note_count is always 0 — Docx has no notes table, see source.py).
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict

from docx_app.db import SurrealRepository, ensure_record_id
from docx_app.domain.source import scoped_update
from docx_app.tenancy import Principal, Scope

# Allow-listed ORDER BY fields (mirrors ON get_notebooks) — guards against SurrealQL
# injection since the order clause is interpolated into the query, not bound.
_ORDER_FIELDS = {"name", "created", "updated"}
_ORDER_DIRECTIONS = {"asc", "desc"}


def parse_order_by(order_by: str) -> str:
    """Validate ON's `order_by` ("field" or "field direction") → a safe ORDER BY clause.

    Raises ValueError on anything outside the allow-list (the router maps it to HTTP 400).
    """
    parts = order_by.strip().lower().split()
    if len(parts) == 1 and parts[0] in _ORDER_FIELDS:
        return parts[0]
    if len(parts) == 2 and parts[0] in _ORDER_FIELDS and parts[1] in _ORDER_DIRECTIONS:
        return f"{parts[0]} {parts[1]}"
    raise ValueError(
        f"invalid order_by '{order_by}' (fields: {', '.join(sorted(_ORDER_FIELDS))}; "
        "directions: asc, desc)"
    )


class Notebook(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: str | None = None
    name: str | None = None
    description: str | None = None
    archived: bool = False
    owner: str | None = None
    created: str | None = None
    updated: str | None = None


class NotebookStore:
    """Persistence for Notebook — owner-scoped (a user only sees their own workspaces)."""

    TABLE = "notebook"

    def __init__(self, repo: SurrealRepository):
        self._repo = repo

    @staticmethod
    def _to_notebook(record: dict[str, Any] | list[Any]) -> Notebook:
        if isinstance(record, list):
            record = record[0] if record else {}
        return Notebook(**record)

    async def create(
        self, *, owner: str, name: str, description: str | None = None
    ) -> Notebook:
        data: dict[str, Any] = {
            "name": name,
            "description": description,
            "archived": False,
        }
        # PRIVATE: a workspace belongs to its owner, not the shared brain.
        record = await self._repo.create_scoped(
            self.TABLE, data, owner=owner, scope=Scope.PRIVATE
        )
        return self._to_notebook(record)

    async def list(
        self,
        principal: Principal,
        *,
        archived: bool | None = None,
        order_by: str = "updated desc",
        limit: int = 100,
    ) -> list[Notebook]:
        order_clause = parse_order_by(order_by)
        rows = await self._repo.select_scoped(
            self.TABLE,
            principal,
            focus=True,  # only your own workspaces
            order_by=order_clause,
            limit=limit,
        )
        notebooks = [self._to_notebook(r) for r in rows]
        if archived is not None:
            notebooks = [nb for nb in notebooks if nb.archived == archived]
        return notebooks

    async def get(self, notebook_id: str, principal: Principal) -> Notebook | None:
        rows = await self._repo.select_scoped(
            self.TABLE,
            principal,
            focus=True,  # own workspaces only
            extra_where="id = $nid",
            vars={"nid": ensure_record_id(notebook_id)},
            limit=1,
        )
        return self._to_notebook(rows[0]) if rows else None

    async def update(
        self,
        notebook_id: str,
        principal: Principal,
        *,
        name: str | None = None,
        description: str | None = None,
        archived: bool | None = None,
    ) -> Notebook | None:
        """Patch the named fields on a notebook the caller OWNS (None = leave unchanged).

        The owner-scoped read first proves ownership, so the subsequent owner-scoped
        UPDATE can never touch another owner's row (mirrors the leak guard).
        """
        existing = await self.get(notebook_id, principal)
        if existing is None:
            return None
        updates: dict[str, Any] = {}
        if name is not None:
            updates["name"] = name
        if description is not None:
            updates["description"] = description
        if archived is not None:
            updates["archived"] = archived
        if not updates:
            return existing
        rows = await scoped_update(
            self._repo,
            self.TABLE,
            updates,
            owner=principal.owner,
            record_id=notebook_id,
        )
        return self._to_notebook(rows[0]) if rows else existing

    async def delete(self, notebook_id: str, principal: Principal) -> bool:
        """Delete a notebook the caller OWNS. Returns False if it isn't theirs / missing.

        Only the workspace record is removed; its sources keep their `notebook` ref but the
        workspace no longer resolves (ON cascades via a `reference` edge Docx doesn't model —
        see api/notebooks.py for the delete-preview semantics).
        """
        if await self.get(notebook_id, principal) is None:
            return False
        await self._repo.delete_where(
            self.TABLE,
            "id = $nid AND owner = $owner",
            {"nid": ensure_record_id(notebook_id), "owner": principal.owner},
        )
        return True

    async def count_sources(self, notebook_id: str, principal: Principal) -> int:
        """Number of the caller's sources in this workspace (owner+notebook scoped)."""
        rows = await self._repo.select_scoped(
            "source",
            principal,
            notebook=notebook_id,  # → owner = $owner AND notebook = $notebook
            order_by="",
        )
        return len(rows)

    async def count_notes(self, notebook_id: str, principal: Principal) -> int:
        """Number of the caller's notes in this workspace (owner+notebook scoped).

        Same predicate as count_sources, on the `note` table — so NotebookResponse.note_count
        is accurate now that the notes slice exists (was hardcoded 0 at the slice boundary).
        """
        rows = await self._repo.select_scoped(
            "note", principal, notebook=notebook_id, order_by=""
        )
        return len(rows)
