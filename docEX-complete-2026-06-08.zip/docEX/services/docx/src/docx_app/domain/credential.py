"""AI provider credentials, the model registry, and per-owner model defaults.

Port of Open Notebook's `credential` / `model` / `default_models` (open_notebook/domain/
credential.py + open_notebook/ai/models.py), made tenant-scoped and restricted to the two
providers this internal deployment supports: OpenAI and Azure OpenAI.

Tenancy (ZERO TOLERANCE): all three resources are PRIVATE to their owner — a user's API
keys, configured models, and default-model assignments are personal and never part of the
shared brain. Every read goes through `select_scoped(focus=True)` (owner-only predicate);
every write is stamped via `create_scoped` (owner + Scope.PRIVATE). There is no bare SELECT.

Secret handling: `api_key` is carried as a Pydantic `SecretStr` in-process (masked in logs /
repr) and persisted as a plain column. It is NEVER serialised back to a client — responses
expose only `has_api_key`. Field-level encryption-at-rest (ON uses Fernet) is omitted: it
would require the `cryptography` dependency, which is out of scope for this slice.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field, SecretStr

from docx_app.db import SurrealRepository, ensure_record_id
from docx_app.tenancy import Principal, Scope

# --- Provider catalogue (LOCKED: OpenAI + Azure OpenAI only) ---------------
# Mirrors Open Notebook's restricted PROVIDER_MODALITIES / TEST_MODELS for this internal
# deployment (api/credentials_service.py + open_notebook/ai/connection_tester.py).
SUPPORTED_PROVIDERS: tuple[str, ...] = ("openai", "azure")

PROVIDER_MODALITIES: dict[str, list[str]] = {
    "openai": ["language", "embedding", "speech_to_text", "text_to_speech"],
    "azure": ["language", "embedding", "speech_to_text", "text_to_speech"],
}

VALID_MODEL_TYPES: tuple[str, ...] = (
    "language",
    "embedding",
    "text_to_speech",
    "speech_to_text",
)


def normalize_provider(provider: str) -> str:
    """Lower-case + alias-normalise a provider name (ON treats providers case-insensitively)."""
    return provider.strip().lower()


def is_supported_provider(provider: str) -> bool:
    return normalize_provider(provider) in SUPPORTED_PROVIDERS


def default_modalities(provider: str) -> list[str]:
    """Default modalities for a provider (mirrors ON get_default_modalities)."""
    return list(PROVIDER_MODALITIES.get(normalize_provider(provider), ["language"]))


# --- Credential ------------------------------------------------------------


class Credential(BaseModel):
    """An AI provider credential record (owner-private).

    Field set mirrors Open Notebook's Credential exactly so the frontend contract
    (lib/api/credentials.ts) is satisfied. `api_key` is a SecretStr and is never echoed
    back to clients (see module docstring).
    """

    # Surreal rows carry extra columns (owner/scope/created/updated) — ignore unknowns.
    model_config = ConfigDict(extra="ignore")

    id: str | None = None
    name: str | None = None
    provider: str | None = None
    modalities: list[str] = Field(default_factory=list)
    api_key: SecretStr | None = None
    base_url: str | None = None
    endpoint: str | None = None
    api_version: str | None = None
    endpoint_llm: str | None = None
    endpoint_embedding: str | None = None
    endpoint_stt: str | None = None
    endpoint_tts: str | None = None
    # ON also carries project/location/credentials_path (Vertex). Kept for contract parity
    # so the frontend types line up, but always null for the OpenAI/Azure-only deployment.
    project: str | None = None
    location: str | None = None
    credentials_path: str | None = None
    decryption_error: str | None = None
    owner: str | None = None
    scope: str | None = None
    created: str | None = None
    updated: str | None = None

    def to_provider_config(self) -> dict[str, Any]:
        """Build a provider-config dict (the values ai/chat would use to reach the API).

        Equivalent to ON's `to_esperanto_config()` but only for OpenAI/Azure fields. The
        api_key is unwrapped here for outbound use; this dict is NEVER returned to a client.
        """
        config: dict[str, Any] = {}
        if self.api_key is not None:
            config["api_key"] = self.api_key.get_secret_value()
        if self.base_url:
            config["base_url"] = self.base_url
            # ON quirk: for Azure the UI's base_url doubles as the endpoint.
            if (
                self.provider
                and normalize_provider(self.provider) == "azure"
                and not self.endpoint
            ):
                config["endpoint"] = self.base_url
        if self.endpoint:
            config["endpoint"] = self.endpoint
        if self.api_version:
            config["api_version"] = self.api_version
        if self.endpoint_llm:
            config["endpoint_llm"] = self.endpoint_llm
        if self.endpoint_embedding:
            config["endpoint_embedding"] = self.endpoint_embedding
        if self.endpoint_stt:
            config["endpoint_stt"] = self.endpoint_stt
        if self.endpoint_tts:
            config["endpoint_tts"] = self.endpoint_tts
        return config


# Columns persisted on a credential write (model fields minus framework/secret-handling).
_CREDENTIAL_FIELDS = (
    "name",
    "provider",
    "modalities",
    "base_url",
    "endpoint",
    "api_version",
    "endpoint_llm",
    "endpoint_embedding",
    "endpoint_stt",
    "endpoint_tts",
    "project",
    "location",
    "credentials_path",
)


class CredentialStore:
    """Persistence for Credential — every operation is owner-scoped (PRIVATE)."""

    TABLE = "credential"
    MODEL_TABLE = "model"

    def __init__(self, repo: SurrealRepository):
        self._repo = repo

    @staticmethod
    def _to_credential(record: dict[str, Any] | list[Any]) -> Credential:
        if isinstance(record, list):
            record = record[0] if record else {}
        return Credential(**record)

    @staticmethod
    def _payload(
        *,
        name: str,
        provider: str,
        modalities: list[str],
        api_key: str | None,
        base_url: str | None,
        endpoint: str | None,
        api_version: str | None,
        endpoint_llm: str | None,
        endpoint_embedding: str | None,
        endpoint_stt: str | None,
        endpoint_tts: str | None,
    ) -> dict[str, Any]:
        return {
            "name": name,
            "provider": normalize_provider(provider),
            "modalities": modalities,
            # Stored as a plain string column; never returned to a client.
            "api_key": api_key,
            "base_url": base_url,
            "endpoint": endpoint,
            "api_version": api_version,
            "endpoint_llm": endpoint_llm,
            "endpoint_embedding": endpoint_embedding,
            "endpoint_stt": endpoint_stt,
            "endpoint_tts": endpoint_tts,
        }

    async def create(
        self,
        *,
        owner: str,
        name: str,
        provider: str,
        modalities: list[str],
        api_key: str | None = None,
        base_url: str | None = None,
        endpoint: str | None = None,
        api_version: str | None = None,
        endpoint_llm: str | None = None,
        endpoint_embedding: str | None = None,
        endpoint_stt: str | None = None,
        endpoint_tts: str | None = None,
    ) -> Credential:
        data = self._payload(
            name=name,
            provider=provider,
            modalities=modalities,
            api_key=api_key,
            base_url=base_url,
            endpoint=endpoint,
            api_version=api_version,
            endpoint_llm=endpoint_llm,
            endpoint_embedding=endpoint_embedding,
            endpoint_stt=endpoint_stt,
            endpoint_tts=endpoint_tts,
        )
        record = await self._repo.create_scoped(
            self.TABLE, data, owner=owner, scope=Scope.PRIVATE
        )
        return self._to_credential(record)

    async def list(
        self, principal: Principal, *, provider: str | None = None
    ) -> list[Credential]:
        extra = "provider = $provider" if provider else ""
        vars = {"provider": normalize_provider(provider)} if provider else None
        rows = await self._repo.select_scoped(
            self.TABLE,
            principal,
            focus=True,  # owner-only: a user only ever sees their OWN credentials
            order_by="created ASC",
            extra_where=extra,
            vars=vars,
        )
        return [self._to_credential(r) for r in rows]

    async def get(self, credential_id: str, principal: Principal) -> Credential | None:
        rows = await self._repo.select_scoped(
            self.TABLE,
            principal,
            focus=True,
            extra_where="id = $cid",
            vars={"cid": ensure_record_id(credential_id)},
            limit=1,
        )
        return self._to_credential(rows[0]) if rows else None

    async def update(
        self,
        credential_id: str,
        principal: Principal,
        *,
        fields: dict[str, Any],
    ) -> Credential | None:
        """Patch the named columns on a credential the caller OWNS (owner-scoped UPDATE).

        `fields` keys must be code-constant column names (validated by the caller); values
        are bound. The `owner = $owner` predicate is the tenancy guard on the write itself.
        """
        if await self.get(credential_id, principal) is None:
            return None
        if not fields:
            return await self.get(credential_id, principal)
        assignments = ", ".join(f"{k} = ${k}" for k in fields)
        vars: dict[str, Any] = {
            **fields,
            "cid": ensure_record_id(credential_id),
            "owner": principal.owner,
        }
        query = (
            f"UPDATE {self.TABLE} SET {assignments} "
            "WHERE id = $cid AND owner = $owner RETURN AFTER"
        )
        rows = await self._repo.query(query, vars)
        return self._to_credential(rows[0]) if rows else None

    async def delete(
        self,
        credential_id: str,
        principal: Principal,
        *,
        migrate_to: str | None = None,
    ) -> int | None:
        """Delete a credential the caller OWNS. Returns the count of cascade-deleted models.

        Linked models the caller owns are reassigned to `migrate_to` (if given and owned),
        else cascade-deleted. Both writes carry `owner = $owner` so a delete can never reach
        another owner's credential or models. Returns None if the credential isn't theirs.
        """
        if await self.get(credential_id, principal) is None:
            return None
        deleted_models = 0
        linked = await self.linked_model_count(credential_id, principal)
        if linked and migrate_to and await self.get(migrate_to, principal):
            await self._repo.query(
                f"UPDATE {self.MODEL_TABLE} SET credential = $target "
                "WHERE credential = $cid AND owner = $owner",
                {
                    "target": ensure_record_id(migrate_to),
                    "cid": ensure_record_id(credential_id),
                    "owner": principal.owner,
                },
            )
        elif linked:
            await self._repo.delete_where(
                self.MODEL_TABLE,
                "credential = $cid AND owner = $owner",
                {"cid": ensure_record_id(credential_id), "owner": principal.owner},
            )
            deleted_models = linked
        await self._repo.delete_where(
            self.TABLE,
            "id = $cid AND owner = $owner",
            {"cid": ensure_record_id(credential_id), "owner": principal.owner},
        )
        return deleted_models

    async def linked_model_count(self, credential_id: str, principal: Principal) -> int:
        """Number of the caller's models linked to this credential (owner-scoped)."""
        rows = await self._repo.select_scoped(
            self.MODEL_TABLE,
            principal,
            focus=True,
            extra_where="credential = $cid",
            vars={"cid": ensure_record_id(credential_id)},
            order_by="",
        )
        return len(rows)


# --- Model (registry) ------------------------------------------------------


class Model(BaseModel):
    """A configured model (provider + name + type), optionally linked to a credential."""

    model_config = ConfigDict(extra="ignore")

    id: str | None = None
    name: str | None = None
    provider: str | None = None
    type: str | None = None
    credential: str | None = None  # record<credential>, optional
    owner: str | None = None
    scope: str | None = None
    created: str | None = None
    updated: str | None = None


class ModelStore:
    """Persistence for Model — owner-scoped (a user only sees their own models)."""

    TABLE = "model"

    def __init__(self, repo: SurrealRepository):
        self._repo = repo

    @staticmethod
    def _to_model(record: dict[str, Any] | list[Any]) -> Model:
        if isinstance(record, list):
            record = record[0] if record else {}
        return Model(**record)

    async def create(
        self,
        *,
        owner: str,
        name: str,
        provider: str,
        type: str,
        credential: str | None = None,
    ) -> Model:
        data: dict[str, Any] = {
            "name": name,
            "provider": normalize_provider(provider),
            "type": type,
        }
        if credential is not None:
            data["credential"] = ensure_record_id(credential)
        record = await self._repo.create_scoped(
            self.TABLE, data, owner=owner, scope=Scope.PRIVATE
        )
        return self._to_model(record)

    async def list(
        self,
        principal: Principal,
        *,
        type: str | None = None,
        provider: str | None = None,
    ) -> list[Model]:
        clauses: list[str] = []
        vars: dict[str, Any] = {}
        if type:
            clauses.append("type = $type")
            vars["type"] = type
        if provider:
            clauses.append("provider = $provider")
            vars["provider"] = normalize_provider(provider)
        rows = await self._repo.select_scoped(
            self.TABLE,
            principal,
            focus=True,  # owner-only
            order_by="type, name",
            extra_where=" AND ".join(clauses),
            vars=vars or None,
        )
        return [self._to_model(r) for r in rows]

    async def get(self, model_id: str, principal: Principal) -> Model | None:
        rows = await self._repo.select_scoped(
            self.TABLE,
            principal,
            focus=True,
            extra_where="id = $mid",
            vars={"mid": ensure_record_id(model_id)},
            limit=1,
        )
        return self._to_model(rows[0]) if rows else None

    async def find_duplicate(
        self, principal: Principal, *, name: str, provider: str, type: str
    ) -> Model | None:
        """Owner-scoped case-insensitive lookup of an identical (provider, name, type)."""
        rows = await self._repo.select_scoped(
            self.TABLE,
            principal,
            focus=True,
            extra_where=(
                "string::lowercase(provider) = $provider "
                "AND string::lowercase(name) = $name "
                "AND string::lowercase(type) = $type"
            ),
            vars={
                "provider": normalize_provider(provider),
                "name": name.lower(),
                "type": type.lower(),
            },
            limit=1,
            order_by="",
        )
        return self._to_model(rows[0]) if rows else None

    async def delete(self, model_id: str, principal: Principal) -> bool:
        if await self.get(model_id, principal) is None:
            return False
        await self._repo.delete_where(
            self.TABLE,
            "id = $mid AND owner = $owner",
            {"mid": ensure_record_id(model_id), "owner": principal.owner},
        )
        return True

    async def get_credential(
        self, model: Model, principal: Principal
    ) -> Credential | None:
        """Resolve a model's linked Credential (owner-scoped), or None if unlinked."""
        if not model.credential:
            return None
        return await CredentialStore(self._repo).get(model.credential, principal)


# --- Model defaults (per-owner) --------------------------------------------


class ModelDefaults(BaseModel):
    """Per-owner default-model assignments — fields mirror ON's DefaultModels exactly."""

    model_config = ConfigDict(extra="ignore")

    default_chat_model: str | None = None
    default_transformation_model: str | None = None
    large_context_model: str | None = None
    default_text_to_speech_model: str | None = None
    default_speech_to_text_model: str | None = None
    default_embedding_model: str | None = None
    default_tools_model: str | None = None


class ModelDefaultsUpdate(BaseModel):
    """Partial update — every field optional (frontend sends Partial<ModelDefaults>)."""

    model_config = ConfigDict(extra="ignore")

    default_chat_model: str | None = None
    default_transformation_model: str | None = None
    large_context_model: str | None = None
    default_text_to_speech_model: str | None = None
    default_speech_to_text_model: str | None = None
    default_embedding_model: str | None = None
    default_tools_model: str | None = None


_DEFAULTS_FIELDS = (
    "default_chat_model",
    "default_transformation_model",
    "large_context_model",
    "default_text_to_speech_model",
    "default_speech_to_text_model",
    "default_embedding_model",
    "default_tools_model",
)


class ModelDefaultsStore:
    """Per-owner default-model assignments — one row per owner (upsert), PRIVATE.

    Same shape as SettingsStore: a read is owner-only (focus=True) and an upsert is an
    owner-scoped delete + create, so one owner can never read or overwrite another's row.
    """

    TABLE = "model_defaults"

    def __init__(self, repo: SurrealRepository):
        self._repo = repo

    async def _row(self, principal: Principal) -> dict[str, Any] | None:
        rows = await self._repo.select_scoped(
            self.TABLE, principal, focus=True, limit=1
        )
        return rows[0] if rows else None

    async def get(self, principal: Principal) -> ModelDefaults:
        row = await self._row(principal)
        return ModelDefaults(**row) if row else ModelDefaults()

    async def upsert(
        self, principal: Principal, update: ModelDefaultsUpdate
    ) -> ModelDefaults:
        current = await self.get(principal)
        # exclude_unset so an explicit null can clear a slot, but an omitted field is left
        # untouched — matches ON's "update only provided fields" PUT semantics.
        merged = current.model_copy(update=update.model_dump(exclude_unset=True))
        data = {field: getattr(merged, field) for field in _DEFAULTS_FIELDS}
        await self._repo.delete_where(
            self.TABLE, "owner = $owner", {"owner": principal.owner}
        )
        record = await self._repo.create_scoped(
            self.TABLE, data, owner=principal.owner, scope=Scope.PRIVATE
        )
        # create_scoped returns a single-element list ([{...}]) — unwrap before splatting
        # (ModelDefaults(**list) would raise → PUT /models/defaults 500).
        if isinstance(record, list):
            record = record[0] if record else {}
        return ModelDefaults(**record)
