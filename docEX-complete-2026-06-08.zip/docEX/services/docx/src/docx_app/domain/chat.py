"""Chat sessions + messages — owner-private, for notebook chat and source chat.

Port of Open Notebook's ChatSession. ON keeps the message history in a LangGraph
SqliteSaver checkpoint; we do NOT use LangGraph (per slice constraints), so messages are
first-class owner/scope-scoped rows in `chat_message`, linked to their session. This keeps
the SAME tenancy guarantee as every other Docx resource: sessions and messages are PRIVATE
to their owner and every read goes through `select_scoped(focus=True)` — a session can only
ever be read (and its messages enumerated) by the owner that created it.

A session links to EITHER a notebook (notebook chat) OR a source (source chat); both are
optional, so one store serves both surfaces.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict

from docx_app.db import SurrealRepository, ensure_record_id
from docx_app.tenancy import Principal, Scope

# Sessions/messages are owner-private — they organise the user's own conversations and
# never enter the shared collective brain (same rule as notebooks).
_CHAT_SCOPE = Scope.PRIVATE


def ensure_session_id(value: str) -> str:
    """Normalise a session id to the `chat_session:<id>` form (mirrors ON's prefix handling)."""
    return value if value.startswith("chat_session:") else f"chat_session:{value}"


def ensure_source_id(value: str) -> str:
    """Normalise a source id to the `source:<id>` form (mirrors ON's prefix handling)."""
    return value if value.startswith("source:") else f"source:{value}"


def ensure_notebook_id(value: str) -> str:
    """Normalise a notebook id to the `notebook:<id>` form."""
    return value if value.startswith("notebook:") else f"notebook:{value}"


class ChatSession(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: str | None = None
    title: str | None = None
    model_override: str | None = None
    notebook: str | None = None  # record<notebook> — set for notebook chat
    source: str | None = None  # record<source> — set for source chat
    owner: str | None = None
    scope: str | None = None
    created: str | None = None
    updated: str | None = None


class ChatMessage(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: str | None = None
    session: str | None = None  # record<chat_session>
    type: str = "human"  # 'human' | 'ai'
    content: str = ""
    order: int = 0
    owner: str | None = None
    scope: str | None = None
    created: str | None = None
    updated: str | None = None


class ChatStore:
    """Persistence for chat sessions + messages — every operation is owner-scoped.

    Sessions are owner-private, so reads use ``focus=True`` (owner = $owner) — never the
    collective-brain default. That is the isolation guard the leak test exercises.
    """

    SESSION_TABLE = "chat_session"
    MESSAGE_TABLE = "chat_message"

    def __init__(self, repo: SurrealRepository):
        self._repo = repo

    @staticmethod
    def _to_session(record: dict[str, Any] | list[Any]) -> ChatSession:
        if isinstance(record, list):
            record = record[0] if record else {}
        return ChatSession(**record)

    @staticmethod
    def _to_message(record: dict[str, Any] | list[Any]) -> ChatMessage:
        # create_scoped returns a single-element list ([{...}]); unwrap like _to_session
        # (a bare CREATE result is a list, not a mapping → ChatMessage(**list) would fail).
        if isinstance(record, list):
            record = record[0] if record else {}
        return ChatMessage(**record)

    # --- sessions ----------------------------------------------------------

    async def create_session(
        self,
        *,
        owner: str,
        title: str | None = None,
        model_override: str | None = None,
        notebook: str | None = None,
        source: str | None = None,
    ) -> ChatSession:
        data: dict[str, Any] = {"title": title, "model_override": model_override}
        if notebook is not None:
            data["notebook"] = ensure_record_id(notebook)
        if source is not None:
            data["source"] = ensure_record_id(source)
        record = await self._repo.create_scoped(
            self.SESSION_TABLE, data, owner=owner, scope=_CHAT_SCOPE
        )
        return self._to_session(record)

    async def list_sessions_for_notebook(
        self, notebook_id: str, principal: Principal, *, limit: int = 100
    ) -> list[ChatSession]:
        rows = await self._repo.select_scoped(
            self.SESSION_TABLE,
            principal,
            focus=True,  # sessions are owner-private
            extra_where="notebook = $nb",
            vars={"nb": ensure_record_id(notebook_id)},
            limit=limit,
        )
        return [self._to_session(r) for r in rows]

    async def list_sessions_for_source(
        self, source_id: str, principal: Principal, *, limit: int = 100
    ) -> list[ChatSession]:
        rows = await self._repo.select_scoped(
            self.SESSION_TABLE,
            principal,
            focus=True,
            extra_where="source = $src",
            vars={"src": ensure_record_id(source_id)},
            limit=limit,
        )
        return [self._to_session(r) for r in rows]

    async def get_session(
        self, session_id: str, principal: Principal
    ) -> ChatSession | None:
        rows = await self._repo.select_scoped(
            self.SESSION_TABLE,
            principal,
            focus=True,  # only the owner may read their session
            extra_where="id = $sid",
            vars={"sid": ensure_record_id(session_id)},
            limit=1,
        )
        return self._to_session(rows[0]) if rows else None

    async def update_session(
        self,
        session_id: str,
        principal: Principal,
        *,
        title: str | None = None,
        model_override: str | None = None,
        set_title: bool = False,
        set_model_override: bool = False,
    ) -> ChatSession | None:
        """Patch a session the caller owns. Returns the updated session, or None if not theirs.

        The MERGE is owner-scoped (id = $sid AND owner = $owner) so a user can never patch
        another owner's session even with its exact id.
        """
        existing = await self.get_session(session_id, principal)
        if existing is None:
            return None
        patch: dict[str, Any] = {}
        if set_title:
            patch["title"] = title
        if set_model_override:
            patch["model_override"] = model_override
        if patch:
            from datetime import datetime, timezone

            patch["updated"] = datetime.now(timezone.utc)
            await self._repo.query(
                f"UPDATE {self.SESSION_TABLE} MERGE $patch "
                "WHERE id = $sid AND owner = $owner",
                {
                    "patch": patch,
                    "sid": ensure_record_id(session_id),
                    "owner": principal.owner,
                },
            )
        return await self.get_session(session_id, principal)

    async def touch_session(self, session_id: str, principal: Principal) -> None:
        """Bump a session's `updated` timestamp (owner-scoped)."""
        from datetime import datetime, timezone

        await self._repo.query(
            f"UPDATE {self.SESSION_TABLE} SET updated = $now "
            "WHERE id = $sid AND owner = $owner",
            {
                "now": datetime.now(timezone.utc),
                "sid": ensure_record_id(session_id),
                "owner": principal.owner,
            },
        )

    async def delete_session(self, session_id: str, principal: Principal) -> None:
        """Delete a session and its messages — owner-scoped on both tables."""
        sid = ensure_record_id(session_id)
        await self._repo.delete_where(
            self.MESSAGE_TABLE,
            "session = $sid AND owner = $owner",
            {"sid": sid, "owner": principal.owner},
        )
        await self._repo.delete_where(
            self.SESSION_TABLE,
            "id = $sid AND owner = $owner",
            {"sid": sid, "owner": principal.owner},
        )

    # --- messages ----------------------------------------------------------

    async def list_messages(
        self, session_id: str, principal: Principal, *, limit: int = 1000
    ) -> list[ChatMessage]:
        rows = await self._repo.select_scoped(
            self.MESSAGE_TABLE,
            principal,
            focus=True,  # only the owner may read their messages
            extra_where="session = $sid",
            vars={"sid": ensure_record_id(session_id)},
            order_by="order ASC",
            limit=limit,
        )
        return [self._to_message(r) for r in rows]

    async def append_message(
        self,
        *,
        session_id: str,
        owner: str,
        type: str,
        content: str,
        order: int,
    ) -> ChatMessage:
        data: dict[str, Any] = {
            "session": ensure_record_id(session_id),
            "type": type,
            "content": content,
            "order": order,
        }
        record = await self._repo.create_scoped(
            self.MESSAGE_TABLE, data, owner=owner, scope=_CHAT_SCOPE
        )
        return self._to_message(record)
