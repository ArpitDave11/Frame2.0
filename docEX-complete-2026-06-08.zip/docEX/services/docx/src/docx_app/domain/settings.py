"""Per-owner content settings — Open Notebook's ContentSettings, made tenant-scoped.

ON keeps a single global `content_settings` singleton (`open_notebook:content_settings`).
Docx instead keys settings PER OWNER: every user controls their own processing/embedding
preferences, and a read for one owner can never surface another owner's settings.

Tenancy: settings are PRIVATE (personal, never part of the shared brain). Reads go through
`select_scoped(focus=True)` (owner only); writes are stamped with owner + Scope.PRIVATE.
One row per owner — the store upserts (scoped delete + create) so a PUT replaces in place.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from docx_app.db import SurrealRepository
from docx_app.tenancy import Principal, Scope

# ON's ContentSettings defaults (open_notebook/domain/content_settings.py). Kept verbatim so
# the contract a Docx frontend sees matches Open Notebook's out-of-the-box behaviour.
_DEFAULT_YOUTUBE_LANGUAGES: list[str] = [
    "en",
    "pt",
    "es",
    "de",
    "nl",
    "en-GB",
    "fr",
    "hi",
    "ja",
]


class Settings(BaseModel):
    """A user's content settings — fields mirror ON's SettingsResponse exactly."""

    # Surreal records carry extra columns (id/owner/scope/created/updated) — ignore unknowns.
    model_config = ConfigDict(extra="ignore")

    default_content_processing_engine_doc: str | None = "auto"
    default_content_processing_engine_url: str | None = "auto"
    default_embedding_option: str | None = "ask"
    auto_delete_files: str | None = "yes"
    youtube_preferred_languages: list[str] | None = Field(
        default_factory=lambda: list(_DEFAULT_YOUTUBE_LANGUAGES)
    )

    def to_response(self) -> dict[str, Any]:
        """The exact JSON shape the frontend's SettingsResponse expects."""
        return {
            "default_content_processing_engine_doc": self.default_content_processing_engine_doc,
            "default_content_processing_engine_url": self.default_content_processing_engine_url,
            "default_embedding_option": self.default_embedding_option,
            "auto_delete_files": self.auto_delete_files,
            "youtube_preferred_languages": self.youtube_preferred_languages,
        }


class SettingsUpdate(BaseModel):
    """Partial update — every field optional (frontend sends Partial<SettingsResponse>)."""

    model_config = ConfigDict(extra="ignore")

    default_content_processing_engine_doc: str | None = None
    default_content_processing_engine_url: str | None = None
    default_embedding_option: str | None = None
    auto_delete_files: str | None = None
    youtube_preferred_languages: list[str] | None = None


# The settings fields persisted to the row (the model fields, minus framework columns).
_SETTINGS_FIELDS = (
    "default_content_processing_engine_doc",
    "default_content_processing_engine_url",
    "default_embedding_option",
    "auto_delete_files",
    "youtube_preferred_languages",
)


class SettingsStore:
    """Persistence for per-owner Settings — every operation is owner-scoped (PRIVATE)."""

    TABLE = "owner_settings"

    def __init__(self, repo: SurrealRepository):
        self._repo = repo

    async def _row(self, principal: Principal) -> dict[str, Any] | None:
        # focus=True → owner-only predicate; a user can only ever read their OWN settings row.
        rows = await self._repo.select_scoped(
            self.TABLE, principal, focus=True, limit=1
        )
        return rows[0] if rows else None

    async def get(self, principal: Principal) -> Settings:
        """Return the owner's settings, or the ON defaults if they have none yet."""
        row = await self._row(principal)
        return Settings(**row) if row else Settings()

    async def upsert(self, principal: Principal, update: SettingsUpdate) -> Settings:
        """Merge `update` over the owner's current settings and persist (one row per owner).

        Implemented as an owner-scoped delete + create: the delete is bound to `$owner`, so a
        write can never touch another owner's row — the same tenancy rule as every other query.
        """
        current = await self.get(principal)
        merged = current.model_copy(
            update=update.model_dump(exclude_unset=True, exclude_none=True)
        )
        data = {field: getattr(merged, field) for field in _SETTINGS_FIELDS}

        # Drop this owner's existing row (owner-scoped) before writing the replacement.
        await self._repo.delete_where(
            self.TABLE, "owner = $owner", {"owner": principal.owner}
        )
        record = await self._repo.create_scoped(
            self.TABLE, data, owner=principal.owner, scope=Scope.PRIVATE
        )
        # create_scoped returns a single-element list ([{...}]) — unwrap before splatting
        # (Settings(**list) would raise → PUT /settings 500).
        if isinstance(record, list):
            record = record[0] if record else {}
        return Settings(**record)
