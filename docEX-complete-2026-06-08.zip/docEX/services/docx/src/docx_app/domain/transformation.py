"""Transformation — a reusable LLM prompt a user runs over arbitrary text.

Owner/scope-native port of Open Notebook's Transformation. In Open Notebook these are
GLOBAL config; here they are PRIVATE to the owner (a user's own prompt library), matching
Notebook's owner-private model. Every read is owner-scoped (focus=True → owner-only) and
every write is stamped with owner + scope=PRIVATE.

DefaultPrompt is the per-owner "transformation_instructions" preamble prepended to every
transformation at execute time (Open Notebook's `DefaultPrompts` singleton, made
per-owner so one user's preamble can never leak into another's).

NEVER build a bare SELECT/UPDATE/DELETE — everything goes through the owner/scope-aware
SurrealRepository (select_scoped) or the tenancy predicate (update_/delete via WHERE).
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict

from docx_app.db import SurrealRepository, ensure_record_id
from docx_app.domain.default_transformations import (
    DEFAULT_TRANSFORMATION_INSTRUCTIONS,
    DEFAULT_TRANSFORMATIONS,
)
from docx_app.tenancy import Principal, Scope, surreal_scope_predicate


class Transformation(BaseModel):
    # surreal records carry extra fields (owner/scope) — keep them, ignore unknowns
    model_config = ConfigDict(extra="ignore")

    id: str | None = None
    name: str = ""
    title: str = ""
    description: str = ""
    prompt: str = ""
    apply_default: bool = False
    owner: str | None = None
    scope: str | None = None
    created: str | None = None
    updated: str | None = None


class DefaultPrompt(BaseModel):
    """The per-owner transformation-instructions preamble (one row per owner)."""

    model_config = ConfigDict(extra="ignore")

    transformation_instructions: str = ""


class TransformationStore:
    """Persistence for Transformation — every operation is owner-scoped (PRIVATE)."""

    TABLE = "transformation"

    def __init__(self, repo: SurrealRepository):
        self._repo = repo

    @staticmethod
    def _to_transformation(record: dict[str, Any] | list[Any]) -> Transformation:
        if isinstance(record, list):
            record = record[0] if record else {}
        return Transformation(**record)

    async def create(
        self,
        *,
        owner: str,
        name: str,
        title: str,
        description: str,
        prompt: str,
        apply_default: bool = False,
    ) -> Transformation:
        data: dict[str, Any] = {
            "name": name,
            "title": title,
            "description": description,
            "prompt": prompt,
            "apply_default": apply_default,
        }
        # PRIVATE: a user's prompt library belongs to them, not the shared brain.
        record = await self._repo.create_scoped(
            self.TABLE, data, owner=owner, scope=Scope.PRIVATE
        )
        return self._to_transformation(record)

    async def list(
        self, principal: Principal, *, limit: int = 200
    ) -> list[Transformation]:
        rows = await self._repo.select_scoped(
            self.TABLE,
            principal,
            focus=True,  # own prompt library only
            order_by="name ASC",
            limit=limit,
        )
        return [self._to_transformation(r) for r in rows]

    async def get(
        self, transformation_id: str, principal: Principal
    ) -> Transformation | None:
        rows = await self._repo.select_scoped(
            self.TABLE,
            principal,
            focus=True,  # own prompt library only
            extra_where="id = $tid",
            vars={"tid": ensure_record_id(transformation_id)},
            limit=1,
        )
        return self._to_transformation(rows[0]) if rows else None

    async def update(
        self,
        transformation_id: str,
        principal: Principal,
        *,
        fields: dict[str, Any],
    ) -> Transformation | None:
        """Patch the given fields on a transformation the caller OWNS.

        The WHERE is owner-scoped via the tenancy predicate (focus=True → owner-only), so a
        user can never mutate another owner's row even with the exact id. Returns the
        updated record, or None if it doesn't exist / isn't theirs.
        """
        if not fields:  # nothing to change → just re-read (scoped)
            return await self.get(transformation_id, principal)
        # Bind the patch values as $set_<field>; build the SET clause from constant keys.
        set_vars = {f"set_{k}": v for k, v in fields.items()}
        set_clause = ", ".join(f"{k} = $set_{k}" for k in fields)
        where = surreal_scope_predicate(principal, focus=True)  # owner = $owner
        rows = await self._repo.query(
            f"UPDATE {self.TABLE} SET {set_clause}, updated = time::now() "
            f"WHERE {where} AND id = $tid RETURN AFTER",
            {
                "owner": principal.owner,
                "tid": ensure_record_id(transformation_id),
                **set_vars,
            },
        )
        return self._to_transformation(rows[0]) if rows else None

    async def delete(self, transformation_id: str, principal: Principal) -> bool:
        """Delete a transformation the caller OWNS. Returns True if a row was removed.

        Scoped via the same owner predicate as reads — you can only delete your own.
        """
        if await self.get(transformation_id, principal) is None:
            return False
        where = surreal_scope_predicate(principal, focus=True)  # owner = $owner
        await self._repo.delete_where(
            self.TABLE,
            f"{where} AND id = $tid",
            {"owner": principal.owner, "tid": ensure_record_id(transformation_id)},
        )
        return True

    async def ensure_seeded(self, principal: Principal) -> bool:
        """Seed the built-in transformations for an owner who has none yet (idempotent).

        Open Notebook ships 6 transformations + a default-instructions preamble via a DB
        migration. Those are GLOBAL there; here each owner gets their OWN private copy on
        first use, so the prompt library is never empty out of the box — the durable
        equivalent of ON's `migration 5` seed, made per-owner.

        Seed-once semantics: skip if the owner already has any transformation, OR if their
        default-prompt row already exists. The seed sets that row, so its presence marks
        "already seeded" — which stops a re-seed after the user deletes all their
        transformations (we respect a deliberately-emptied library). Returns True iff it
        actually seeded on this call.
        """
        if await self.list(principal, limit=1):
            return False
        prompts = DefaultPromptStore(self._repo)
        if await prompts.exists(principal):
            return False
        for t in DEFAULT_TRANSFORMATIONS:
            await self.create(
                owner=principal.owner,
                name=str(t["name"]),
                title=str(t["title"]),
                description=str(t["description"]),
                prompt=str(t["prompt"]),
                apply_default=bool(t["apply_default"]),
            )
        await prompts.set(
            principal,
            transformation_instructions=DEFAULT_TRANSFORMATION_INSTRUCTIONS,
        )
        return True


class DefaultPromptStore:
    """The per-owner default transformation-instructions (one PRIVATE row per owner)."""

    TABLE = "transformation_default_prompt"

    def __init__(self, repo: SurrealRepository):
        self._repo = repo

    async def get(self, principal: Principal) -> DefaultPrompt:
        """Read the owner's preamble; an absent row means an empty preamble."""
        rows = await self._repo.select_scoped(
            self.TABLE,
            principal,
            focus=True,  # owner-only
            order_by="created ASC",
            limit=1,
        )
        if not rows:
            return DefaultPrompt(transformation_instructions="")
        return DefaultPrompt(**rows[0])

    async def exists(self, principal: Principal) -> bool:
        """Whether this owner has a default-prompt row yet (the seed-once marker)."""
        rows = await self._repo.select_scoped(
            self.TABLE, principal, focus=True, limit=1
        )
        return bool(rows)

    async def set(
        self, principal: Principal, *, transformation_instructions: str
    ) -> DefaultPrompt:
        """Upsert the owner's preamble (create the row on first write, else patch it)."""
        where = surreal_scope_predicate(principal, focus=True)  # owner = $owner
        updated = await self._repo.query(
            f"UPDATE {self.TABLE} SET transformation_instructions = $ti, "
            f"updated = time::now() WHERE {where} RETURN AFTER",
            {"owner": principal.owner, "ti": transformation_instructions},
        )
        if updated:
            return DefaultPrompt(**updated[0])
        # No existing row for this owner → create one (stamped owner + scope=PRIVATE).
        record = await self._repo.create_scoped(
            self.TABLE,
            {"transformation_instructions": transformation_instructions},
            owner=principal.owner,
            scope=Scope.PRIVATE,
        )
        if isinstance(record, list):
            record = record[0] if record else {}
        return DefaultPrompt(**record)
