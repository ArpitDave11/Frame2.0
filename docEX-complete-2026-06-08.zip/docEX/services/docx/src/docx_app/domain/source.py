"""Source — an uploaded/ingested document in a user's knowledge base.

Slim, owner/scope-native port of Open Notebook's Source. Persisted via the
owner/scope-aware SurrealRepository, so every read is tenancy-scoped and every
write is stamped with owner + scope (collective-brain default = org-common).
Embeddings/insights/chunking are added in the retrieval phase.

Aligned to Open Notebook's frontend contract (lib/api/sources.ts): list supports
`limit`/`offset` pagination + `sort_by`/`sort_order`, and a source reports
`embedded_chunks` (the count of its stored chunks). Docx links a source to a single
workspace via the denormalised `notebook` field (ON uses a `reference` edge), so
`add_to_notebook`/`remove_from_notebook` set/clear that field.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from docx_app.db import SurrealRepository, ensure_record_id
from docx_app.tenancy import Principal, Scope

# Allow-listed sort fields/orders for list pagination (mirrors ON get_sources). The
# clause is interpolated, not bound, so it MUST stay restricted to these constants.
_SORT_FIELDS = {"created", "updated"}
_SORT_ORDERS = {"asc", "desc"}


def build_sort_clause(sort_by: str, sort_order: str) -> str:
    """Validate ON's `sort_by`/`sort_order` → a safe ORDER BY clause (else ValueError)."""
    if sort_by not in _SORT_FIELDS:
        raise ValueError("sort_by must be 'created' or 'updated'")
    if sort_order.lower() not in _SORT_ORDERS:
        raise ValueError("sort_order must be 'asc' or 'desc'")
    return f"{sort_by} {sort_order.upper()}"


async def scoped_update(
    repo: SurrealRepository,
    table: str,
    fields: dict[str, Any],
    *,
    owner: str,
    record_id: str,
) -> list[dict[str, Any]]:
    """Owner-scoped UPDATE of a single record (table + field names are code constants).

    The `owner = $owner` predicate is the tenancy guard — even though callers prove
    ownership first via a scoped read, this ensures the write itself can never reach
    another owner's row (no bare/un-scoped UPDATE; see db.py module docstring). Returns
    the updated rows (RETURN AFTER); empty if nothing matched.
    """
    assignments = ", ".join(f"{k} = ${k}" for k in fields)
    vars: dict[str, Any] = {
        **fields,
        "rid": ensure_record_id(record_id),
        "owner": owner,
    }
    query = (
        f"UPDATE {table} SET {assignments} "
        "WHERE id = $rid AND owner = $owner RETURN AFTER"
    )
    return await repo.query(query, vars)


class Asset(BaseModel):
    url: str | None = None
    file_path: str | None = None


class Source(BaseModel):
    # surreal records carry extra fields (created/updated/owner/scope) — keep them, ignore unknowns
    model_config = ConfigDict(extra="ignore")

    id: str | None = None
    title: str | None = None
    full_text: str | None = None
    asset: Asset | None = None
    topics: list[str] = Field(default_factory=list)
    engine_used: str | None = None
    owner: str | None = None
    scope: str | None = None
    notebook: str | None = (
        None  # the workspace it belongs to (record<notebook>), optional
    )
    created: str | None = None
    updated: str | None = None
    chunk_count: int | None = None  # set after indexing; None = not yet indexed


class SourceStore:
    """Persistence for Source — every operation is owner/scope-scoped."""

    TABLE = "source"
    CHUNK_TABLE = "source_chunk"

    def __init__(self, repo: SurrealRepository):
        self._repo = repo

    @staticmethod
    def _to_source(record: dict[str, Any] | list[Any]) -> Source:
        if isinstance(record, list):
            record = record[0] if record else {}
        return Source(**record)

    async def create(
        self,
        *,
        owner: str,
        scope: Scope,
        title: str | None = None,
        full_text: str | None = None,
        asset: Asset | None = None,
        engine_used: str | None = None,
        topics: list[str] | None = None,
        notebook: str | None = None,
    ) -> Source:
        data: dict[str, Any] = {
            "title": title,
            "full_text": full_text,
            "asset": asset.model_dump() if asset else None,
            "engine_used": engine_used,
            "topics": topics or [],
        }
        if notebook is not None:
            data["notebook"] = ensure_record_id(notebook)
        record = await self._repo.create_scoped(
            self.TABLE, data, owner=owner, scope=scope
        )
        return self._to_source(record)

    async def get(
        self,
        source_id: str,
        principal: Principal,
        *,
        focus: bool = False,
        notebook: str | None = None,
    ) -> Source | None:
        rows = await self._repo.select_scoped(
            self.TABLE,
            principal,
            focus=focus,
            extra_where="id = $sid",
            vars={"sid": ensure_record_id(source_id)},
            limit=1,
            notebook=notebook,
        )
        return self._to_source(rows[0]) if rows else None

    async def list(
        self,
        principal: Principal,
        *,
        focus: bool = False,
        limit: int = 50,
        offset: int = 0,
        sort_by: str = "updated",
        sort_order: str = "desc",
        notebook: str | None = None,
    ) -> list[Source]:
        order_clause = build_sort_clause(sort_by, sort_order)
        rows = await self._repo.select_scoped(
            self.TABLE,
            principal,
            focus=focus,
            order_by=order_clause,
            # Fetch through the requested window, then slice the offset off in-app —
            # build_scoped_select has no START/offset and db.py is owned elsewhere.
            limit=offset + limit,
            notebook=notebook,
        )
        return [self._to_source(r) for r in rows[offset : offset + limit]]

    async def update(
        self,
        source_id: str,
        principal: Principal,
        *,
        title: str | None = None,
        topics: Sequence[str] | None = None,
    ) -> Source | None:
        """Patch the named fields on a source the caller OWNS (None = leave unchanged)."""
        existing = await self.get(source_id, principal, focus=True)
        if existing is None:
            return None
        updates: dict[str, Any] = {}
        if title is not None:
            updates["title"] = title
        if topics is not None:
            updates["topics"] = list(topics)
        if not updates:
            return existing
        rows = await scoped_update(
            self._repo,
            self.TABLE,
            updates,
            owner=principal.owner,
            record_id=source_id,
        )
        return self._to_source(rows[0]) if rows else existing

    async def delete(self, source_id: str, principal: Principal) -> bool:
        """Delete a source the caller OWNS plus its chunks. False if it isn't theirs.

        Both deletes carry `owner = $owner` so a delete can never reach another owner's
        source or chunks (same tenancy guard as ChunkStore.replace_for_source)."""
        if await self.get(source_id, principal, focus=True) is None:
            return False
        await self._repo.delete_where(
            self.CHUNK_TABLE,
            "source = $sid AND owner = $owner",
            {"sid": ensure_record_id(source_id), "owner": principal.owner},
        )
        await self._repo.delete_where(
            self.TABLE,
            "id = $sid AND owner = $owner",
            {"sid": ensure_record_id(source_id), "owner": principal.owner},
        )
        return True

    async def count_chunks(self, source_id: str, principal: Principal) -> int:
        """Number of stored chunks for this source the caller can see (→ ON `embedded`)."""
        rows = await self._repo.select_scoped(
            self.CHUNK_TABLE,
            principal,
            focus=True,
            extra_where="source = $sid",
            vars={"sid": ensure_record_id(source_id)},
            order_by="",
        )
        return len(rows)

    async def add_to_notebook(
        self, source_id: str, notebook_id: str, principal: Principal
    ) -> bool:
        """Link a source the caller OWNS into a workspace (set its `notebook`). Idempotent."""
        if await self.get(source_id, principal, focus=True) is None:
            return False
        await scoped_update(
            self._repo,
            self.TABLE,
            {"notebook": ensure_record_id(notebook_id)},
            owner=principal.owner,
            record_id=source_id,
        )
        return True

    async def remove_from_notebook(self, source_id: str, principal: Principal) -> bool:
        """Unlink a source the caller OWNS from its workspace (clear `notebook`)."""
        if await self.get(source_id, principal, focus=True) is None:
            return False
        await scoped_update(
            self._repo,
            self.TABLE,
            {"notebook": None},
            owner=principal.owner,
            record_id=source_id,
        )
        return True
