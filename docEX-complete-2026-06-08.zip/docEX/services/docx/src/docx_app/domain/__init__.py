"""Docx domain models (owner/scope-native, persisted via docx.db.SurrealRepository)."""

from docx_app.domain.source import Asset, Source, SourceStore

__all__ = ["Asset", "Source", "SourceStore"]
