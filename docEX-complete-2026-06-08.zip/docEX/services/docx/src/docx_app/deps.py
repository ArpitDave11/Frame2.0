"""FastAPI dependencies: config, auth→principal, repository, extraction router.

Overridable in tests via app.dependency_overrides.
"""

from __future__ import annotations

from functools import lru_cache

from fastapi import Depends, HTTPException, Request

from shared.auth.jwt import decode_local_jwt

from docx_app.ai.chat import ChatClient, ClaudeCliChatClient
from docx_app.ask.service import AskService
from docx_app.config import DocxConfig
from docx_app.db import SurrealRepository
from docx_app.diagram.gitlab_service import GitLabService
from docx_app.diagram.repo_fetch import RepoFetcher
from docx_app.extraction.engines.content_core import ContentCoreEngine
from docx_app.extraction.engines.docling import DoclingEngine
from docx_app.extraction.router import ExtractionRouter
from docx_app.indexing.embedding import Embedder, LocalTestEmbedder
from docx_app.indexing.service import IndexingService
from docx_app.retrieval.rerank import IdentityReranker, LLMReranker, Reranker
from docx_app.retrieval.service import RetrievalService
from docx_app.tenancy import Principal, principal_from_claims


@lru_cache
def get_config() -> DocxConfig:
    return DocxConfig(service_name="docx")


async def get_principal(
    request: Request, config: DocxConfig = Depends(get_config)
) -> Principal:
    """Resolve the authenticated principal (the tenancy `owner`).

    - dev mode: derive owner from a header (no token) — local FRAME integration before the
      gateway exists; falls back to `dev_owner` if the header is absent.
    - gateway mode (prod): validate the gateway-minted local JWT (MSAL terminates at the
      gateway, which mints this token).
    """
    if config.auth_mode == "dev":
        owner = request.headers.get(config.dev_user_header) or config.dev_owner
        return Principal(owner=owner, email=owner if "@" in owner else None)

    auth = request.headers.get("authorization", "")
    if not auth.lower().startswith("bearer "):
        raise HTTPException(401, "missing bearer token")
    claims = decode_local_jwt(auth[7:], config.local_jwt_secret, config.jwt_algorithm)
    return principal_from_claims(claims)


def get_repository(config: DocxConfig = Depends(get_config)) -> SurrealRepository:
    return SurrealRepository(config)


def get_extractor(config: DocxConfig = Depends(get_config)) -> ExtractionRouter:
    """Hybrid extractor: content-core (in-process) + Docling (HTTP to DocMining)."""
    return ExtractionRouter(ContentCoreEngine(), DoclingEngine(config))


def get_embedder(config: DocxConfig = Depends(get_config)) -> Embedder:
    if (
        config.embedding_provider == "local"
    ):  # test-only: in-process deterministic vectors
        return LocalTestEmbedder(config)
    return Embedder(config)


def get_indexer(
    repo: SurrealRepository = Depends(get_repository),
    embedder: Embedder = Depends(get_embedder),
    config: DocxConfig = Depends(get_config),
) -> IndexingService:
    """Chunk → embed → store, wired from config (overridable in tests)."""
    return IndexingService(
        repo, embedder, chunk_size=config.chunk_size, overlap=config.chunk_overlap
    )


def get_chat_client(config: DocxConfig = Depends(get_config)) -> ChatClient:
    if (
        config.llm_provider == "claude_cli"
    ):  # test-only: Claude Sonnet via the Claude CLI
        return ClaudeCliChatClient(config)
    return ChatClient(config)


def get_gitlab_service(config: DocxConfig = Depends(get_config)) -> GitLabService:
    """The RepoGraph (Surface 3) GitLab fetch service, wired from config.

    Stateless — constructed per request; reads ``gitlab_base_url`` / ``gitlab_token`` /
    ``gitlab_timeout_s`` / ``repograph_max_file_tree_chars`` (injected by FRAME 2.0). An
    empty ``gitlab_base_url`` does not fail here: the service starts fine and only raises
    :class:`~docx_app.diagram.gitlab_service.GitLabConfigError` at call time (the RepoGraph
    router maps that to HTTP 503). Overridable in tests via ``app.dependency_overrides``.
    """
    return GitLabService(config)


def get_repo_fetcher(config: DocxConfig = Depends(get_config)) -> RepoFetcher:
    """The RepoGraph (Surface 3) provider-agnostic repo fetcher — GitHub OR GitLab.

    Detects the provider from the pasted URL host and delegates to the GitHub or GitLab fetch
    service, returning a unified ``RepoData``. GitHub public repos work with no config; GitLab
    needs ``gitlab_base_url`` (else a config error → HTTP 503 at call time). Stateless;
    overridable in tests via ``app.dependency_overrides``.
    """
    return RepoFetcher(config)


def get_reranker(
    config: DocxConfig = Depends(get_config),
    chat: ChatClient = Depends(get_chat_client),
) -> Reranker:
    """LLM listwise reranker when enabled (opt-in), else a no-op keeping fusion order."""
    if config.rerank_enabled:
        return LLMReranker(chat)
    return IdentityReranker()


def get_retrieval_service(
    repo: SurrealRepository = Depends(get_repository),
    embedder: Embedder = Depends(get_embedder),
    reranker: Reranker = Depends(get_reranker),
    config: DocxConfig = Depends(get_config),
) -> RetrievalService:
    return RetrievalService(
        repo,
        embedder,
        reranker=reranker,
        hybrid=config.hybrid_enabled,
        candidate_k=config.retrieval_candidates,
    )


def get_ask_service(
    retrieval: RetrievalService = Depends(get_retrieval_service),
    chat: ChatClient = Depends(get_chat_client),
) -> AskService:
    return AskService(retrieval, chat)
