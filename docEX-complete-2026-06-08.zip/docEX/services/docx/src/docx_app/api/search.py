"""Search API — Open Notebook's /api/search contract on docx's hybrid retrieval.

Exposes the two endpoints the ON frontend (`lib/api/search.ts`) calls:

- POST /search       → scoped hybrid retrieval, returned in ON's SearchResponse shape.
- POST /search/ask   → a synthesized, grounded answer, streamed as ON-shaped SSE events
                       (`final_answer` then `complete`) so the frontend's ReadableStream
                       parser works unchanged.

Tenancy: both endpoints retrieve through RetrievalService / AskService, whose every read
goes through `surreal_scope_predicate` (owner + scope, + notebook). There is no bare SELECT
here — a private chunk can never surface for another owner, even as the closest match.

Simplifications vs Open Notebook (recorded in the slice manifest):
- ON's `search_type` is `text | vector`; docx retrieval is ALWAYS hybrid (vector + BM25 →
  RRF). The requested `type` is accepted for contract compatibility and echoed back as
  `search_type`, but does NOT change the retrieval path (a per-request vector-only override
  would need a flag threaded through RetrievalService — tracked as a future enhancement).
- ON also searches `notes`; docx has no notes domain, so `search_notes` is accepted for
  contract compatibility but only sources/chunks are searched.
- ON's /search/ask drives an agentic multi-search LangGraph with three model roles
  (strategy/answer/final_answer); docx does ONE scoped retrieval + synthesis pass
  (AskService). The three `*_model` fields are accepted for contract compatibility but
  not used. The answer is still streamed in ON's SSE event shape.
"""

from __future__ import annotations

import json
from collections.abc import AsyncIterator

import structlog
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, ConfigDict, Field

from docx_app.ask.service import AskService
from docx_app.deps import get_ask_service, get_principal, get_retrieval_service
from docx_app.retrieval.models import RetrievedChunk
from docx_app.retrieval.service import RetrievalService
from docx_app.tenancy import Principal

router = APIRouter(prefix="/search", tags=["search"])
log = structlog.get_logger(__name__)


# --- Request / response models (Open Notebook contract, see lib/types/search.ts) -------


class SearchRequest(BaseModel):
    # `extra="ignore"` keeps us forward-compatible with the ON payload (which may carry
    # fields docx doesn't model) instead of 422-ing on them.
    model_config = ConfigDict(extra="ignore")

    query: str
    type: str = "vector"  # ON: 'text' | 'vector'
    limit: int = Field(default=10, ge=1, le=100)
    search_sources: bool = True
    search_notes: bool = True  # no docx notes domain — accepted, not used
    minimum_score: float = Field(default=0.2, ge=0.0, le=1.0)
    # docx tenancy extensions (additive; ON omits them → defaults apply):
    focus: bool = False  # False = common brain ∪ own; True = only the user's own docs
    notebook: str | None = None  # narrow to one of the user's workspaces


class SearchResult(BaseModel):
    # Mirrors ON's SearchResult so the frontend renders docx results unchanged.
    id: str
    title: str
    parent_id: str
    final_score: float
    matches: list[str] | None = None
    relevance: float | None = None
    similarity: float | None = None
    score: float | None = None
    type: str | None = None
    source_type: str | None = None
    created: str = ""
    updated: str = ""


class SearchResponse(BaseModel):
    results: list[SearchResult]
    total_count: int
    search_type: str


class AskRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    question: str
    # ON's three agentic model roles — accepted for contract compatibility, not used by
    # docx's single-pass AskService (see module docstring).
    strategy_model: str | None = None
    answer_model: str | None = None
    final_answer_model: str | None = None
    # docx tenancy extensions (additive):
    focus: bool = False
    notebook: str | None = None
    limit: int = Field(default=10, ge=1, le=50)


# --- Mapping helpers -------------------------------------------------------------------


def _to_result(chunk: RetrievedChunk) -> SearchResult:
    """Map a retrieved chunk onto ON's SearchResult shape.

    docx's unit of retrieval is a chunk, so `id` is the chunk and `parent_id` is its
    source. ON populates `similarity`/`relevance` from its search functions; docx's fused
    score is a single ranking score, so we surface it as `final_score`/`score` and leave
    the search-type-specific fields unset (the chunk row carries no timestamps either —
    the SELECT only projects id/source/content/score — so created/updated default to "").
    """
    source = chunk.source or ""
    content = chunk.content or ""
    # No per-chunk title in the KB; derive a short snippet so the UI has a label.
    title = content[:80].strip() or source or (chunk.id or "")
    return SearchResult(
        id=chunk.id or "",
        title=title,
        parent_id=source,
        final_score=chunk.score,
        score=chunk.score,
        source_type="source",
    )


# --- Endpoints -------------------------------------------------------------------------


@router.post("", response_model=SearchResponse)
async def search_knowledge_base(
    req: SearchRequest,
    principal: Principal = Depends(get_principal),
    service: RetrievalService = Depends(get_retrieval_service),
) -> SearchResponse:
    """Scoped hybrid retrieval, returned in ON's SearchResponse shape."""
    if not req.query.strip():
        raise HTTPException(400, "query is required")
    chunks = await service.search(
        req.query,
        principal,
        focus=req.focus,
        limit=req.limit,
        min_similarity=req.minimum_score,
        notebook=req.notebook,
    )
    results = [_to_result(c) for c in chunks]
    return SearchResponse(
        results=results, total_count=len(results), search_type=req.type
    )


def _sse(event: dict[str, object]) -> str:
    return f"data: {json.dumps(event)}\n\n"


async def _stream_answer(
    service: AskService, req: AskRequest, principal: Principal
) -> AsyncIterator[str]:
    """Yield the answer as ON-shaped SSE events.

    docx does one scoped retrieval + synthesis pass (no agentic strategy step), so we emit
    `final_answer` then `complete` — the subset of ON's event stream the frontend needs to
    render a result. Errors are emitted as an `error` event (never a 500 mid-stream), so the
    frontend shows a message instead of a broken stream. Retrieval is still owner/scoped.
    """
    try:
        result = await service.ask(
            req.question,
            principal,
            focus=req.focus,
            limit=req.limit,
            notebook=req.notebook,
        )
        yield _sse({"type": "final_answer", "content": result.answer})
        yield _sse({"type": "complete", "final_answer": result.answer})
    except Exception:  # noqa: BLE001 - stream boundary: surface as an SSE error event, not a 500
        log.warning("ask_stream_failed", exc_info=True)
        yield _sse(
            {"type": "error", "message": "Ask operation failed. Please try again."}
        )


@router.post("/ask")
async def ask_knowledge_base(
    req: AskRequest,
    principal: Principal = Depends(get_principal),
    service: AskService = Depends(get_ask_service),
) -> StreamingResponse:
    """Synthesized, grounded answer streamed as ON-shaped SSE events."""
    if not req.question.strip():
        raise HTTPException(400, "question is required")
    return StreamingResponse(
        _stream_answer(service, req, principal), media_type="text/event-stream"
    )
