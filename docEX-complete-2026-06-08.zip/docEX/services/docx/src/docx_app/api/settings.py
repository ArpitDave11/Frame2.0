"""Settings API — per-owner content settings (Open Notebook's /settings, tenant-scoped).

GET  /settings → the caller's settings (ON defaults if they have none yet)
PUT  /settings → merge a partial update over the caller's settings, persist, return the full
                 SettingsResponse (matches ON: PUT takes Partial<SettingsResponse>, returns it)

Tenancy: settings are PRIVATE to the owner — reads/writes go through the owner-scoped
SettingsStore, so one user can never read or overwrite another user's settings.
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends

from docx_app.db import SurrealRepository
from docx_app.deps import get_principal, get_repository
from docx_app.domain.settings import SettingsStore, SettingsUpdate
from docx_app.tenancy import Principal

router = APIRouter(prefix="/settings", tags=["settings"])


@router.get("")
async def get_settings(
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> dict[str, Any]:
    settings = await SettingsStore(repo).get(principal)
    return settings.to_response()


@router.put("")
async def update_settings(
    body: SettingsUpdate,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> dict[str, Any]:
    settings = await SettingsStore(repo).upsert(principal, body)
    return settings.to_response()
