"""Transformations API — a user's reusable LLM prompts run over arbitrary text.

Mirrors Open Notebook's transformations contract (the field names + paths the frontend's
lib/api/transformations.ts expects):
    GET    /transformations                  → list
    POST   /transformations                  → create
    POST   /transformations/execute          → run a prompt over input_text
    GET    /transformations/default-prompt   → the per-owner instructions preamble
    PUT    /transformations/default-prompt   → set the preamble
    GET    /transformations/{id}             → get one
    PUT    /transformations/{id}             → patch one
    DELETE /transformations/{id}             → delete one

Tenancy: transformations + the default prompt are PRIVATE to the owner (a user's own
prompt library), so every read is owner-scoped and every write is owner-stamped.

The static `/execute` and `/default-prompt` routes are declared BEFORE the dynamic
`/{transformation_id}` routes so FastAPI matches them literally (not as a path param).
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from docx_app.ai.chat import ChatClient
from docx_app.db import SurrealRepository
from docx_app.deps import get_chat_client, get_principal, get_repository
from docx_app.domain.transformation import (
    DefaultPromptStore,
    Transformation,
    TransformationStore,
)
from docx_app.tenancy import Principal

router = APIRouter(prefix="/transformations", tags=["transformations"])


# --- Request / response schemas (field names match the ON frontend contract) ---


class TransformationResponse(BaseModel):
    id: str
    name: str
    title: str
    description: str
    prompt: str
    apply_default: bool
    created: str
    updated: str


class TransformationCreate(BaseModel):
    name: str
    title: str
    description: str
    prompt: str
    apply_default: bool = False


class TransformationUpdate(BaseModel):
    name: str | None = None
    title: str | None = None
    description: str | None = None
    prompt: str | None = None
    apply_default: bool | None = None


class TransformationExecuteRequest(BaseModel):
    transformation_id: str
    input_text: str
    # Accepted for contract parity with Open Notebook; Docx uses the single locked Azure
    # deployment (no per-request model selection), so this only selects nothing — it is
    # echoed back unchanged in the response.
    model_id: str = ""


class TransformationExecuteResponse(BaseModel):
    output: str
    transformation_id: str
    model_id: str


class DefaultPromptResponse(BaseModel):
    transformation_instructions: str


class DefaultPromptUpdate(BaseModel):
    transformation_instructions: str


def _to_response(t: Transformation) -> TransformationResponse:
    # created/updated come back as ISO strings (or None before persistence). The contract
    # requires plain strings, so coerce None → "".
    return TransformationResponse(
        id=t.id or "",
        name=t.name,
        title=t.title,
        description=t.description,
        prompt=t.prompt,
        apply_default=t.apply_default,
        created=t.created or "",
        updated=t.updated or "",
    )


# --- Collection routes -----------------------------------------------------


@router.get("", response_model=list[TransformationResponse])
async def list_transformations(
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> list[TransformationResponse]:
    store = TransformationStore(repo)
    # First time this owner opens Transformations, seed the built-in library (idempotent),
    # so the page is never empty out of the box — ON ships these via a migration.
    await store.ensure_seeded(principal)
    items = await store.list(principal)
    return [_to_response(t) for t in items]


@router.post("", response_model=TransformationResponse)
async def create_transformation(
    body: TransformationCreate,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> TransformationResponse:
    if not body.name.strip():
        raise HTTPException(400, "name is required")
    if not body.prompt.strip():
        raise HTTPException(400, "prompt is required")
    created = await TransformationStore(repo).create(
        owner=principal.owner,
        name=body.name,
        title=body.title,
        description=body.description,
        prompt=body.prompt,
        apply_default=body.apply_default,
    )
    return _to_response(created)


# --- Static routes (must precede /{transformation_id}) ---------------------


@router.post("/execute", response_model=TransformationExecuteResponse)
async def execute_transformation(
    body: TransformationExecuteRequest,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
    chat: ChatClient = Depends(get_chat_client),
) -> TransformationExecuteResponse:
    """Run a transformation prompt over the provided text.

    Reimplements Open Notebook's transformation graph on the existing ChatClient (no
    LangGraph / esperanto). The system prompt is the owner's default-instructions preamble
    (if any) + the transformation prompt; the user message is the input text.
    """
    if not body.input_text.strip():
        raise HTTPException(400, "input_text is required")
    store = TransformationStore(repo)
    transformation = await store.get(body.transformation_id, principal)
    if transformation is None:
        raise HTTPException(404, "transformation not found")

    preamble = (
        await DefaultPromptStore(repo).get(principal)
    ).transformation_instructions
    system_parts = [p for p in (preamble.strip(), transformation.prompt) if p]
    system = "\n\n".join(system_parts) + "\n\n# INPUT"

    output = await chat.complete(system=system, user=body.input_text, max_tokens=8192)
    return TransformationExecuteResponse(
        output=output,
        transformation_id=body.transformation_id,
        model_id=body.model_id,
    )


@router.get("/default-prompt", response_model=DefaultPromptResponse)
async def get_default_prompt(
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> DefaultPromptResponse:
    dp = await DefaultPromptStore(repo).get(principal)
    return DefaultPromptResponse(
        transformation_instructions=dp.transformation_instructions
    )


@router.put("/default-prompt", response_model=DefaultPromptResponse)
async def update_default_prompt(
    body: DefaultPromptUpdate,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> DefaultPromptResponse:
    dp = await DefaultPromptStore(repo).set(
        principal, transformation_instructions=body.transformation_instructions
    )
    return DefaultPromptResponse(
        transformation_instructions=dp.transformation_instructions
    )


# --- Item routes -----------------------------------------------------------


@router.get("/{transformation_id}", response_model=TransformationResponse)
async def get_transformation(
    transformation_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> TransformationResponse:
    t = await TransformationStore(repo).get(transformation_id, principal)
    if t is None:
        raise HTTPException(404, "transformation not found")
    return _to_response(t)


@router.put("/{transformation_id}", response_model=TransformationResponse)
async def update_transformation(
    transformation_id: str,
    body: TransformationUpdate,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> TransformationResponse:
    fields = body.model_dump(exclude_none=True)
    updated = await TransformationStore(repo).update(
        transformation_id, principal, fields=fields
    )
    if updated is None:
        raise HTTPException(404, "transformation not found")
    return _to_response(updated)


@router.delete("/{transformation_id}")
async def delete_transformation(
    transformation_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> dict[str, str]:
    if not await TransformationStore(repo).delete(transformation_id, principal):
        raise HTTPException(404, "transformation not found")
    return {"message": "Transformation deleted successfully"}
