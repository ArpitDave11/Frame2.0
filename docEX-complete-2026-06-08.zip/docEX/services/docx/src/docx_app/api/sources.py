"""Sources API — upload → extract (hybrid router) → store in the owner/scoped KB.

POST /sources accepts a file (extracted via the hybrid router), a URL, or raw text.
Writes default to the COLLECTIVE-BRAIN scope (`org-common`); `scope=private` opts out.
(Chunking + embedding happen in the retrieval phase.)

Read/list/update/delete are aligned to Open Notebook's frontend contract
(lib/api/sources.ts): list takes `notebook_id`/`limit`/`offset`/`sort_by`/`sort_order`
and returns SourceListResponse; GET /{id} returns SourceDetailResponse (adds `full_text`
+ `notebooks`). Docx has no async job queue/insights, so `command_id`/`status`/
`processing_info`/`insights_count` are inert (sync ingestion) — see `simplifications`.
"""

from __future__ import annotations

import json
import os
import tempfile
from typing import Any

import structlog
from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile
from pydantic import BaseModel

from docx_app.config import DocxConfig
from docx_app.db import SurrealRepository, ensure_record_id
from docx_app.deps import (
    get_config,
    get_extractor,
    get_indexer,
    get_principal,
    get_repository,
)
from docx_app.domain.notebook import NotebookStore
from docx_app.domain.source import Asset, Source, SourceStore
from docx_app.extraction.models import ExtractInput
from docx_app.extraction.router import ExtractionError, ExtractionRouter
from docx_app.indexing.service import IndexingService
from docx_app.tenancy import Principal, Scope, default_write_scope

router = APIRouter(prefix="/sources", tags=["sources"])
log = structlog.get_logger(__name__)


class AssetModel(BaseModel):
    file_path: str | None = None
    url: str | None = None


class SourceListResponse(BaseModel):
    id: str
    title: str | None = None
    topics: list[str] = []
    asset: AssetModel | None = None
    embedded: bool = False
    embedded_chunks: int = 0
    insights_count: int = 0
    created: str = ""
    updated: str = ""
    file_available: bool | None = None
    command_id: str | None = None
    status: str | None = None
    processing_info: dict[str, Any] | None = None


class SourceDetailResponse(SourceListResponse):
    full_text: str | None = None
    notebooks: list[str] = []


class SourceStatusResponse(BaseModel):
    status: str | None = None
    message: str
    processing_info: dict[str, Any] | None = None
    command_id: str | None = None


class SourceUpdate(BaseModel):
    title: str | None = None
    topics: list[str] | None = None


def _asset_model(asset: Asset | None) -> AssetModel | None:
    if not asset:
        return None
    return AssetModel(file_path=asset.file_path, url=asset.url)


def _list_response(
    source: Source, *, embedded: bool, embedded_chunks: int = 0
) -> SourceListResponse:
    return SourceListResponse(
        id=source.id or "",
        title=source.title,
        topics=source.topics or [],
        asset=_asset_model(source.asset),
        embedded=embedded,
        embedded_chunks=embedded_chunks,
        insights_count=0,  # Docx has no insights table
        created=source.created or "",
        updated=source.updated or "",
    )


def _detail_response(source: Source, *, embedded_chunks: int) -> SourceDetailResponse:
    return SourceDetailResponse(
        id=source.id or "",
        title=source.title,
        topics=source.topics or [],
        asset=_asset_model(source.asset),
        embedded=embedded_chunks > 0,
        embedded_chunks=embedded_chunks,
        insights_count=0,
        created=source.created or "",
        updated=source.updated or "",
        full_text=source.full_text,
        notebooks=[source.notebook] if source.notebook else [],
    )


async def _safe_index(indexer: IndexingService, source: Source) -> int | None:
    """Best-effort indexing: the document is already saved, so an embedding failure must
    not fail the upload — it is logged and recoverable via POST /sources/{id}/reindex
    (fail-open, FINAL_DESIGN §11). Returns the chunk count, or None if indexing failed."""
    try:
        return await indexer.index_source(source)
    except Exception:  # noqa: BLE001 - resilience boundary; logged, not silently swallowed
        log.warning("indexing_failed", source_id=source.id, exc_info=True)
        return None


def _scope_from_form(value: str) -> Scope:
    try:
        return Scope(value)
    except ValueError:
        raise HTTPException(
            400, f"invalid scope '{value}' (use 'org-common' or 'private')"
        )


async def _save_upload(file: UploadFile, max_mb: int) -> str:
    """Stream an upload to a temp file, enforcing the size cap. Returns the path."""
    max_bytes = max_mb * 1024 * 1024
    size = 0
    suffix = os.path.splitext(file.filename or "")[1]
    fd, path = tempfile.mkstemp(suffix=suffix)
    try:
        with os.fdopen(fd, "wb") as out:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > max_bytes:
                    raise HTTPException(413, f"file too large (> {max_mb} MB)")
                out.write(chunk)
    except Exception:
        if os.path.exists(path):
            os.unlink(path)
        raise
    return path


def _first_notebook(notebooks: str | None) -> str | None:
    """Open Notebook sends `notebooks` as a JSON array of workspace ids; take the first.

    Docx attaches a source to a single workspace (v1), so we use the first id. Missing,
    malformed, or empty input yields None (treated as "no workspace").
    """
    if not notebooks:
        return None
    try:
        parsed = json.loads(notebooks)
    except (json.JSONDecodeError, TypeError):
        return None
    if isinstance(parsed, list) and parsed and parsed[0]:
        return str(parsed[0])
    return None


@router.post("", response_model=Source)
async def create_source(
    file: UploadFile | None = File(None),
    url: str | None = Form(None),
    text: str | None = Form(None),
    # Open Notebook's frontend names raw text `content`; accept it as an alias for `text`.
    content: str | None = Form(None),
    title: str | None = Form(None),
    scope: str | None = Form(None),
    notebook: str | None = Form(None),
    # ON sends the workspace as `notebook_id` (single) or `notebooks` (JSON array of ids).
    notebook_id: str | None = Form(None),
    notebooks: str | None = Form(None),
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
    extractor: ExtractionRouter = Depends(get_extractor),
    indexer: IndexingService = Depends(get_indexer),
    config: DocxConfig = Depends(get_config),
) -> Source:
    # Reconcile this service's native fields (`text`/`notebook`) with the Open Notebook
    # frontend's (`content`/`notebook_id`/`notebooks`). Without this, a text source created
    # from the ON UI 400'd and the workspace association was silently dropped.
    text = text or content
    target_notebook = notebook or notebook_id or _first_notebook(notebooks)

    # No scope given → the locked collective-brain default (config.default_scope).
    write_scope = _scope_from_form(scope) if scope else default_write_scope(config)
    # A workspace must exist and belong to the caller (notebooks are owner-private).
    if target_notebook and not await NotebookStore(repo).get(
        target_notebook, principal
    ):
        raise HTTPException(400, "unknown notebook (or not yours)")
    store = SourceStore(repo)

    # raw text → no extraction
    if text and file is None and not url:
        source = await store.create(
            owner=principal.owner,
            scope=write_scope,
            title=title,
            full_text=text,
            engine_used="text",
            notebook=target_notebook,
        )
        source.chunk_count = await _safe_index(indexer, source)
        return source

    # file or url → hybrid extraction
    tmp_path: str | None = None
    try:
        if file is not None:
            tmp_path = await _save_upload(file, config.max_file_mb)
            inp = ExtractInput(
                filename=file.filename,
                file_path=tmp_path,
                content_type=file.content_type,
            )
            asset = Asset()  # original file not persisted in v1
        elif url:
            inp = ExtractInput(url=url)
            asset = Asset(url=url)
        else:
            raise HTTPException(400, "provide one of: file, url, or text")

        try:
            extracted = await extractor.extract(inp)
        except ExtractionError as e:
            raise HTTPException(422, f"could not extract document: {e}")

        source = await store.create(
            owner=principal.owner,
            scope=write_scope,
            title=title
            or extracted.metadata.get("title")
            or (file.filename if file else None),
            full_text=extracted.markdown,
            asset=asset,
            engine_used=extracted.engine_used.value if extracted.engine_used else None,
            notebook=target_notebook,
        )
        source.chunk_count = await _safe_index(indexer, source)
        return source
    finally:
        if tmp_path and os.path.exists(tmp_path):
            os.unlink(tmp_path)


@router.get("", response_model=list[SourceListResponse])
async def list_sources(
    notebook_id: str | None = Query(
        None, description="Filter by notebook (workspace) ID"
    ),
    limit: int = Query(50, ge=1, le=100, description="Number of sources to return"),
    offset: int = Query(0, ge=0, description="Number of sources to skip"),
    sort_by: str = Query(
        "updated", description="Field to sort by (created or updated)"
    ),
    sort_order: str = Query("desc", description="Sort order (asc or desc)"),
    focus: bool = Query(False, description="Restrict to the caller's own sources"),
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> list[SourceListResponse]:
    store = SourceStore(repo)
    # If a workspace is named it must exist and be the caller's (owner-private).
    if notebook_id and not await NotebookStore(repo).get(notebook_id, principal):
        raise HTTPException(404, "notebook not found")
    try:
        sources = await store.list(
            principal,
            focus=focus,
            limit=limit,
            offset=offset,
            sort_by=sort_by,
            sort_order=sort_order,
            notebook=notebook_id,
        )
    except ValueError as e:
        raise HTTPException(400, str(e))

    embedded_ids = await _embedded_source_ids(repo, principal, sources)
    return [_list_response(s, embedded=(s.id in embedded_ids)) for s in sources]


async def _embedded_source_ids(
    repo: SurrealRepository, principal: Principal, sources: list[Source]
) -> set[str]:
    """One scoped query → the set of listed source ids that have at least one chunk.

    Stays tenancy-scoped (select_scoped applies the predicate) and avoids an N+1: ON
    reports `embedded` per row in the list view; we resolve the whole page at once.
    `embedded_chunks` stays 0 in the list (ON parity — only the detail view counts them).
    """
    ids = [s.id for s in sources if s.id]
    if not ids:
        return set()
    rows = await repo.select_scoped(
        "source_chunk",
        principal,
        focus=True,
        extra_where="source IN $sids",
        vars={"sids": [ensure_record_id(i) for i in ids]},
        order_by="",
    )
    return {str(r["source"]) for r in rows if r.get("source")}


@router.get("/{source_id}", response_model=SourceDetailResponse)
async def get_source(
    source_id: str,
    focus: bool = False,
    notebook: str | None = None,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> SourceDetailResponse:
    store = SourceStore(repo)
    src = await store.get(source_id, principal, focus=focus, notebook=notebook)
    if not src:
        raise HTTPException(404, "source not found")
    embedded_chunks = await store.count_chunks(src.id or source_id, principal)
    return _detail_response(src, embedded_chunks=embedded_chunks)


@router.get("/{source_id}/status", response_model=SourceStatusResponse)
async def get_source_status(
    source_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> SourceStatusResponse:
    """Processing status. Docx ingests synchronously (no job queue), so a stored source is
    already complete; `embedded` reflects whether its chunks have been indexed yet."""
    store = SourceStore(repo)
    src = await store.get(source_id, principal)
    if not src:
        raise HTTPException(404, "source not found")
    embedded_chunks = await store.count_chunks(src.id or source_id, principal)
    embedded = embedded_chunks > 0
    return SourceStatusResponse(
        status="completed" if embedded else "new",
        message=(
            "Source indexed and ready"
            if embedded
            else "Source stored; not yet indexed (retry via POST /sources/{id}/reindex)"
        ),
        processing_info={"embedded": embedded, "embedded_chunks": embedded_chunks},
        command_id=None,
    )


@router.put("/{source_id}", response_model=SourceListResponse)
async def update_source(
    source_id: str,
    body: SourceUpdate,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> SourceListResponse:
    store = SourceStore(repo)
    src = await store.update(source_id, principal, title=body.title, topics=body.topics)
    if not src:
        raise HTTPException(404, "source not found")
    embedded_chunks = await store.count_chunks(src.id or source_id, principal)
    return _list_response(
        src, embedded=embedded_chunks > 0, embedded_chunks=embedded_chunks
    )


@router.delete("/{source_id}")
async def delete_source(
    source_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> dict[str, str]:
    if not await SourceStore(repo).delete(source_id, principal):
        raise HTTPException(404, "source not found")
    return {"message": "Source deleted successfully"}


@router.post("/{source_id}/retry", response_model=Source)  # ON frontend calls /retry
@router.post("/{source_id}/reindex", response_model=Source)
async def reindex_source(
    source_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
    indexer: IndexingService = Depends(get_indexer),
) -> Source:
    """Re-chunk + re-embed a source the caller OWNS (recovery for failed/initial indexing).

    Scoped via SourceStore.get(focus=True) so you can only re-index your own uploads; the
    owner-scoped chunk delete then guarantees no other owner's chunks are touched.
    """
    source = await SourceStore(repo).get(source_id, principal, focus=True)
    if not source:
        raise HTTPException(404, "source not found")
    source.chunk_count = await indexer.index_source(
        source
    )  # explicit action → surfaces errors
    return source
