"""RepoGraph API — Surface 3 (the GitDiagram-for-GitLab top-level panel).

Design: ``docs/2026-06-06-diagram-platform-design.md`` §7. RepoGraph is the third diagram
surface — paste a GitLab repo URL, get an architecture diagram with drill-down + optional
click-to-open the GitLab file/dir. It runs the **same** 2-step pipeline and persists into the
**same** ``diagram`` table as the other two surfaces, distinguished by ``surface="repograph"``
and ``ref=<repo_url>`` (the pasted URL is the subject handle, mirroring Surface 1's
``ref=source.id`` and Surface 2's ``ref=notebook.id``).

Endpoints (a new top-level ``/repograph`` panel, not nested under another resource):

    POST /repograph                 → fetch the repo via ``gitlab_service`` → run the repo
                                      pipeline (``SYSTEM_*`` prompts, file_tree_lookup from
                                      the tree) → persist a draft ``surface='repograph'``
                                      diagram (or refine / re-version an existing one for the
                                      same repo_url) → return it.
    GET  /repograph                 → list the caller's RepoGraph diagrams (latest first;
                                      one row per repo_url — the current diagram).
    GET  /repograph/{diagram_id}    → load one RepoGraph diagram the caller owns.
    POST /repograph/{id}/accept     → freeze the picture: stamp accepted, freeze graph_json,
                                      store a server-rendered static SVG snapshot.

The ``/{diagram_id}`` routes key off the diagram id (an owner-private handle), not the repo
URL, because a repo URL contains slashes/colons that do not fit a single path segment — the
list response carries each diagram's id + ref so the UI can map a repo to its diagram.

Pipeline reuse: the frozen Surface-1 ``agent.py`` is bound to the source-document prompts, so
RepoGraph uses the repo-surface twin :func:`~docx_app.diagram.repo_pipeline.run_repo_diagram_pipeline`,
which **reuses** ``agent.py``'s provider-agnostic parse/clean/retry machinery verbatim and only
swaps in the ``SYSTEM_*`` (repo) prompts + the repo-shaped user message + a real file-tree
lookup. The frozen ``api/diagrams.py`` private helpers are NOT imported — this module defines
its own analogous helpers (the reuse contract: new surfaces own their helpers).

GitLab config: the target base URL + token come from FRAME 2.0 env (``DocxConfig`` →
``GitLabService``). When ``gitlab_base_url`` is empty the feature is **disabled** —
``GitLabService`` raises :class:`GitLabConfigError`, which this layer maps to HTTP 503 (the
service still starts; only the RepoGraph call fails). The other GitLab errors map per the
service contract: a missing project → 404, any other upstream failure → 502, and a too-large
tree / a malformed repo URL → 422.

Tenancy: RepoGraph diagrams are owner-PRIVATE (``DiagramStore`` stamps ``Scope.PRIVATE`` and
reads ``focus=True``). A repo URL is not itself owner-scoped (two users may diagram the same
public repo); each gets their **own** RepoGraph diagram row keyed on ``(owner, repo_url)``.

LLM path: provider-agnostic — the pipeline runs over the injected ``ChatClient`` (prod Azure)
or ``ClaudeCliChatClient`` (local test). A pipeline failure surfaces as a clean
``DiagramPipelineError`` (mapped to HTTP 502), never a raw stack trace.
"""

from __future__ import annotations

from typing import Any

import structlog
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from docx_app.ai.chat import ChatClient
from docx_app.db import SurrealRepository
from docx_app.deps import (
    get_chat_client,
    get_principal,
    get_repo_fetcher,
    get_repository,
)
from docx_app.diagram.agent import DiagramPipelineError
from docx_app.diagram.domain import Diagram, DiagramStore
from docx_app.diagram.repo_fetch import (
    RepoConfigError,
    RepoFetcher,
    RepoFetchError,
    RepoNotFoundError,
)
from docx_app.diagram.model import DiagramGraph
from docx_app.diagram.render_svg import render_snapshot_svg
from docx_app.diagram.repo_pipeline import run_repo_diagram_pipeline
from docx_app.tenancy import Principal

router = APIRouter(prefix="/repograph", tags=["diagrams"])
log = structlog.get_logger(__name__)

# Surface-3 is always a "repograph" diagram (design: one table, distinguished by
# ``surface`` + ``ref``); ``ref`` is the pasted repo URL.
_SURFACE_REPOGRAPH = "repograph"


# --- Request / response schemas -------------------------------------------- #


class RepographResponse(BaseModel):
    """A RepoGraph diagram. ``graph`` is the canonical :class:`DiagramGraph` as a plain JSON
    object (edges keyed by ``"from"`` — the renderer reads it as-is). ``repo_url`` is the
    diagram's subject (the ``ref``). ``render_snapshot_svg`` is present only once the diagram
    is ``accepted`` (the frozen static picture).

    Field names mirror the diagram row + the frontend ``DiagramRenderer`` graph contract
    (``DiagramRenderer.types.ts``).
    """

    id: str
    repo_url: str
    surface: str
    status: str  # 'draft' | 'accepted'
    version: int
    graph: dict[str, Any] | None = None
    render_snapshot_svg: str | None = None
    repo_name: str | None = None  # project name (FE repo label); set on generate, None on list/get
    default_branch: str | None = None  # e.g. "main" (FE branch badge); set on generate only
    created: str = ""
    updated: str = ""


class RepographGenerateRequest(BaseModel):
    """Generate (or refine) a RepoGraph diagram from a GitLab repo URL.

    The pipeline fetches the repo (``gitlab_service``) and runs over its ``file_tree`` /
    ``readme``. ``instruction`` drives refine-by-prompt: when a diagram for this exact
    ``repo_url`` already exists, the instruction is applied to it (the graph step edits the
    previous graph) instead of regenerating; on the very first generation it is ignored.
    ``include_azure_shapes`` toggles the Azure icon catalog injection (default on — design
    §7).
    """

    repo_url: str
    instruction: str | None = None
    include_azure_shapes: bool = True


class RepographAcceptRequest(BaseModel):
    """Accept (freeze) a RepoGraph diagram.

    Optionally carries the final ``graph`` to freeze atomically with its snapshot (e.g. the
    user accepts straight after a hand-edit). When omitted, the row's current ``graph_json``
    is frozen and snapshotted as-is.
    """

    graph: dict[str, Any] | None = None


# --- Helpers ---------------------------------------------------------------- #


def _validate_graph(graph_dict: dict[str, Any]) -> DiagramGraph:
    """Validate a raw graph dict into a :class:`DiagramGraph` (422 on failure).

    Uses ``model_validate`` (NOT ``**dict``) so an incoming ``"from"`` edge key maps to
    ``DiagramGraphEdge.from_``; a schema violation becomes a clean 422.
    """
    try:
        return DiagramGraph.model_validate(graph_dict)
    except ValueError as exc:  # pydantic.ValidationError is a ValueError subclass
        raise HTTPException(422, f"invalid diagram graph: {exc}")


async def _current_diagram(
    store: DiagramStore, repo_url: str, principal: Principal
) -> Diagram | None:
    """The caller's current (latest-updated) diagram for ``repo_url``, or None.

    ``DiagramStore.list`` is owner-scoped and ordered ``updated DESC``, so the first row is
    the one the panel shows for this repo. One ``(owner, repo_url)`` has one current diagram
    (drafts overwrite; accepting freezes; a regenerate after acceptance adds a new version).
    """
    rows = await store.list(
        principal, surface=_SURFACE_REPOGRAPH, ref=repo_url, limit=1
    )
    return rows[0] if rows else None


async def _persist_graph(
    store: DiagramStore,
    *,
    owner: str,
    principal: Principal,
    repo_url: str,
    existing: Diagram | None,
    graph: DiagramGraph,
) -> Diagram:
    """Persist ``graph`` as the caller's current diagram for ``repo_url``, respecting
    immutability.

    Mirrors the source surface's ``_persist_graph``:

    * no diagram yet → create a new draft (version 1);
    * a **draft** → overwrite its graph in place (a regenerate / refine; version bumps);
    * an **accepted** diagram → start a NEW draft version (the frozen row is never mutated —
      the design's immutability rule).
    """
    if existing is None:
        return await store.create(
            owner=owner,
            surface=_SURFACE_REPOGRAPH,
            ref=repo_url,
            graph=graph,
        )
    if existing.status == "accepted":
        revised = await store.new_version(existing.id or "", principal, graph=graph)
    else:
        revised = await store.update_graph(existing.id or "", principal, graph=graph)
    if revised is None:  # pragma: no cover - existing was just read as owned
        raise HTTPException(404, "diagram not found")
    return revised


def _to_response(
    diagram: Diagram,
    *,
    repo_name: str | None = None,
    default_branch: str | None = None,
) -> RepographResponse:
    """Map a stored :class:`Diagram` to the wire response.

    ``graph_json`` is passed through untouched (it is already stored with the ``"from"`` edge
    alias, which is exactly what the frontend renderer expects). ``ref`` is the repo URL.
    ``repo_name``/``default_branch`` come from the live GitLab fetch on generate (the FE shows
    them as the repo label + branch badge); they are ``None`` on list/get, where the FE falls
    back to the raw ``repo_url`` (the values aren't persisted on the diagram row).
    """
    return RepographResponse(
        id=diagram.id or "",
        repo_url=diagram.ref or "",
        surface=diagram.surface or _SURFACE_REPOGRAPH,
        status=diagram.status or "draft",
        version=diagram.version or 1,
        graph=diagram.graph_json,
        render_snapshot_svg=diagram.render_snapshot_svg,
        repo_name=repo_name,
        default_branch=default_branch,
        created=diagram.created or "",
        updated=diagram.updated or "",
    )


# --- Routes ----------------------------------------------------------------- #


@router.post("", response_model=RepographResponse)
async def generate_repograph(
    body: RepographGenerateRequest,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
    chat: ChatClient = Depends(get_chat_client),
    fetcher: RepoFetcher = Depends(get_repo_fetcher),
) -> RepographResponse:
    """Generate (or refine) a RepoGraph diagram from a GitLab repo URL (design §7).

    Fetches the repository (project lookup + filtered file tree + README) via
    ``gitlab_service``, runs the repo 2-step pipeline
    (:func:`~docx_app.diagram.repo_pipeline.run_repo_diagram_pipeline` — the ``SYSTEM_*``
    prompts with the file tree validated as the link lookup), and persists the resulting
    :class:`DiagramGraph` as the caller's current diagram for this ``repo_url``:

    * no diagram yet → create a new draft (version 1);
    * an existing **draft** → overwrite its graph (a regenerate / refine; version bumps);
    * an **accepted** diagram → start a NEW draft version (the accepted row stays frozen).

    Error mapping (from the ``gitlab_service`` contract + the pipeline):

    * GitLab not configured (empty base URL) → **503** (feature disabled).
    * a bad ``repo_url`` (not under the configured base, no project path) or a file tree over
      the size cap → **422**.
    * the project does not exist / is inaccessible → **404**.
    * any other upstream GitLab failure → **502**.
    * the LLM pipeline cannot produce a valid graph after its retries → **502**.
    """
    repo_url = (body.repo_url or "").strip()
    if not repo_url:
        raise HTTPException(422, "repo_url is required")

    # 1) Fetch the repo. Map the service's typed errors to the documented HTTP codes.
    try:
        data = await fetcher.fetch(repo_url)
    except RepoConfigError as exc:
        # The selected provider (GitLab) is not configured (no base URL from FRAME 2.0).
        log.warning(
            "repograph_provider_not_configured", repo_url=repo_url, error=str(exc)
        )
        raise HTTPException(503, f"RepoGraph is not configured: {exc}")
    except RepoNotFoundError as exc:
        raise HTTPException(404, f"repository not found: {exc}")
    except RepoFetchError as exc:
        log.warning("repograph_fetch_failed", repo_url=repo_url, error=str(exc))
        raise HTTPException(502, f"repository fetch failed: {exc}")
    except ValueError as exc:
        # A bad repo_url (not under the base / no project path) or the file tree exceeding
        # repograph_max_file_tree_chars — both are caller-fixable bad input → 422.
        raise HTTPException(422, f"invalid repository: {exc}")

    # 2) Refine vs first-generation: when a diagram for this repo_url already exists AND the
    #    user typed an instruction, refine that graph (the pipeline edits <previous_graph>
    #    per <refinement_instruction>); otherwise generate fresh from the repo.
    store = DiagramStore(repo)
    existing = await _current_diagram(store, repo_url, principal)
    base_graph = existing.graph() if existing else None
    instruction = (body.instruction or "").strip() or None
    refine = bool(base_graph and instruction)

    # 3) Run the repo pipeline (same machinery as Surface 1, repo prompts + file-tree lookup).
    try:
        graph = await run_repo_diagram_pipeline(
            chat,
            file_tree=data.file_tree,
            readme=data.readme,
            namespace=data.namespace,
            include_azure_shapes=body.include_azure_shapes,
            instruction=instruction if refine else None,
            base_graph=base_graph if refine else None,
        )
    except DiagramPipelineError as exc:
        # The pipeline already retried with validation feedback (incl. the flaky local
        # fenced-JSON path); a failure here is an upstream model problem → 502 with the last
        # feedback, not a 500 stack trace.
        log.warning(
            "repograph_pipeline_error",
            repo_url=repo_url,
            error=str(exc),
            validation_feedback=exc.validation_feedback,
        )
        raise HTTPException(502, f"diagram generation failed: {exc}")

    # 4) Persist as the caller's current diagram for this repo.
    diagram = await _persist_graph(
        store,
        owner=principal.owner,
        principal=principal,
        repo_url=repo_url,
        existing=existing,
        graph=graph,
    )
    log.info(
        "repograph_generated",
        repo_url=repo_url,
        diagram_id=diagram.id,
        version=diagram.version,
        namespace=data.namespace,
        node_count=len(graph.nodes),
        edge_count=len(graph.edges),
    )
    repo_name = data.namespace.rsplit("/", 1)[-1] if data.namespace else None
    return _to_response(
        diagram, repo_name=repo_name, default_branch=data.default_branch or None
    )


@router.get("", response_model=list[RepographResponse])
async def list_repographs(
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> list[RepographResponse]:
    """List the caller's RepoGraph diagrams (owner-scoped, latest first).

    Returns every ``surface='repograph'`` diagram the caller owns, ordered ``updated DESC``.
    Each carries its ``repo_url`` (the ``ref``) and id so the panel can present the user's
    repos and link each to its current diagram. Empty list when the caller has none yet (the
    panel's "paste a GitLab repo URL" empty state).
    """
    store = DiagramStore(repo)
    rows = await store.list(principal, surface=_SURFACE_REPOGRAPH)
    return [_to_response(d) for d in rows]


@router.get("/{diagram_id}", response_model=RepographResponse)
async def get_repograph(
    diagram_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> RepographResponse:
    """Load one RepoGraph diagram the caller owns (draft or accepted). 404 if not theirs.

    Keyed on the diagram id (an owner-private handle from the list/generate response), not
    the repo URL — a repo URL contains slashes/colons that do not fit a single path segment.
    A 404 here means the id is not the caller's RepoGraph diagram.
    """
    store = DiagramStore(repo)
    diagram = await store.get(diagram_id, principal)
    if diagram is None or diagram.surface != _SURFACE_REPOGRAPH:
        raise HTTPException(404, "diagram not found")
    return _to_response(diagram)


@router.post("/{diagram_id}/accept", response_model=RepographResponse)
async def accept_repograph(
    diagram_id: str,
    body: RepographAcceptRequest,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> RepographResponse:
    """Freeze a RepoGraph diagram — DATA + PICTURE (design §2; §7 "immutability identical").

    Stamps ``status="accepted"``, freezes ``graph_json`` (the final graph — the request's
    ``graph`` if supplied, else the stored draft's), and stores a **server-rendered static
    SVG snapshot** (``render_snapshot_svg``) — the guaranteed-stable image the accepted view
    shows, produced server-side so the frozen picture never depends on a browser, ``elkjs``,
    or any draw.io path.

    404 if the id is not the caller's RepoGraph diagram; 422 if neither a request ``graph``
    nor a stored ``graph_json`` is available to freeze, or if the supplied graph is invalid.
    """
    store = DiagramStore(repo)
    existing = await store.get(diagram_id, principal)
    if existing is None or existing.surface != _SURFACE_REPOGRAPH:
        raise HTTPException(404, "diagram not found")

    # Resolve the graph to freeze: the request's (validated) graph wins; otherwise the row's
    # stored graph. There must be one to render a snapshot from.
    if body.graph is not None:
        graph = _validate_graph(body.graph)
    else:
        stored = existing.graph()  # model_validate of graph_json (honours the alias)
        if stored is None:
            raise HTTPException(422, "diagram has no graph to accept")
        graph = stored

    # Render the frozen picture server-side (static, self-contained SVG). The repo URL is the
    # natural title for a RepoGraph snapshot.
    svg = render_snapshot_svg(graph, title=existing.ref)

    diagram = await store.accept(
        existing.id or "",
        principal,
        render_snapshot_svg=svg,
        graph=graph,
    )
    if diagram is None:  # pragma: no cover - existing was just read as owned
        raise HTTPException(404, "diagram not found")
    log.info(
        "repograph_accepted",
        repo_url=diagram.ref,
        diagram_id=diagram.id,
        version=diagram.version,
        svg_bytes=len(svg),
    )
    return _to_response(diagram)
