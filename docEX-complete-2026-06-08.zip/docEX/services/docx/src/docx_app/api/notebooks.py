"""Notebooks API — a user's workspaces, aligned to Open Notebook's frontend contract.

Endpoints mirror ON's lib/api/notebooks.ts (paths + request params + response shapes):
    GET    /notebooks                          ?archived&order_by
    POST   /notebooks                          {name, description?}
    GET    /notebooks/{id}
    PUT    /notebooks/{id}                      {name?, description?, archived?}
    GET    /notebooks/{id}/delete-preview
    DELETE /notebooks/{id}                      ?delete_exclusive_sources
    POST   /notebooks/{id}/sources/{source_id}
    DELETE /notebooks/{id}/sources/{source_id}

Notebooks are owner-PRIVATE; every read/write is tenancy-scoped via the stores. Docx has
no notes table, so `note_count`/`deleted_notes` are always 0; a source belongs to a single
workspace (denormalised `notebook` field), so every source in a notebook is "exclusive" to
it (`shared_source_count` is always 0) — see api/notebooks.py history & domain/source.py.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from docx_app.db import SurrealRepository
from docx_app.deps import get_principal, get_repository
from docx_app.domain.notebook import Notebook, NotebookStore
from docx_app.domain.source import SourceStore
from docx_app.tenancy import Principal

router = APIRouter(prefix="/notebooks", tags=["notebooks"])


class NotebookCreate(BaseModel):
    name: str
    description: str | None = None


class NotebookUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    archived: bool | None = None


class NotebookResponse(BaseModel):
    id: str
    name: str
    description: str
    archived: bool
    created: str
    updated: str
    source_count: int
    note_count: int


class NotebookDeletePreview(BaseModel):
    notebook_id: str
    notebook_name: str
    note_count: int
    exclusive_source_count: int
    shared_source_count: int


class NotebookDeleteResponse(BaseModel):
    message: str
    deleted_notes: int
    deleted_sources: int
    unlinked_sources: int


async def _to_response(
    nb: Notebook, store: NotebookStore, principal: Principal
) -> NotebookResponse:
    """Shape a Notebook into ON's NotebookResponse with scoped source_count + note_count.

    Both counts are owner+notebook scoped; `owner` is never exposed."""
    source_count = await store.count_sources(nb.id or "", principal) if nb.id else 0
    note_count = await store.count_notes(nb.id or "", principal) if nb.id else 0
    return NotebookResponse(
        id=nb.id or "",
        name=nb.name or "",
        description=nb.description or "",
        archived=nb.archived,
        created=nb.created or "",
        updated=nb.updated or "",
        source_count=source_count,
        note_count=note_count,
    )


@router.get("", response_model=list[NotebookResponse])
async def list_notebooks(
    archived: bool | None = Query(None, description="Filter by archived status"),
    order_by: str = Query("updated desc", description="Order by field and direction"),
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> list[NotebookResponse]:
    store = NotebookStore(repo)
    try:
        notebooks = await store.list(principal, archived=archived, order_by=order_by)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return [await _to_response(nb, store, principal) for nb in notebooks]


@router.post("", response_model=NotebookResponse)
async def create_notebook(
    body: NotebookCreate,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> NotebookResponse:
    if not body.name.strip():
        raise HTTPException(400, "name is required")
    store = NotebookStore(repo)
    nb = await store.create(
        owner=principal.owner, name=body.name, description=body.description
    )
    return await _to_response(nb, store, principal)


@router.get("/{notebook_id}/delete-preview", response_model=NotebookDeletePreview)
async def get_notebook_delete_preview(
    notebook_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> NotebookDeletePreview:
    store = NotebookStore(repo)
    nb = await store.get(notebook_id, principal)
    if not nb:
        raise HTTPException(404, "notebook not found")
    # Docx links a source to a single workspace, so all of them are exclusive to it.
    exclusive = await store.count_sources(notebook_id, principal)
    return NotebookDeletePreview(
        notebook_id=nb.id or notebook_id,
        notebook_name=nb.name or "",
        note_count=0,
        exclusive_source_count=exclusive,
        shared_source_count=0,
    )


@router.get("/{notebook_id}", response_model=NotebookResponse)
async def get_notebook(
    notebook_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> NotebookResponse:
    store = NotebookStore(repo)
    nb = await store.get(notebook_id, principal)
    if not nb:
        raise HTTPException(404, "notebook not found")
    return await _to_response(nb, store, principal)


@router.put("/{notebook_id}", response_model=NotebookResponse)
async def update_notebook(
    notebook_id: str,
    body: NotebookUpdate,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> NotebookResponse:
    store = NotebookStore(repo)
    nb = await store.update(
        notebook_id,
        principal,
        name=body.name,
        description=body.description,
        archived=body.archived,
    )
    if not nb:
        raise HTTPException(404, "notebook not found")
    return await _to_response(nb, store, principal)


@router.delete("/{notebook_id}", response_model=NotebookDeleteResponse)
async def delete_notebook(
    notebook_id: str,
    delete_exclusive_sources: bool = Query(
        False, description="Whether to delete sources that belong only to this notebook"
    ),
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> NotebookDeleteResponse:
    nb_store = NotebookStore(repo)
    src_store = SourceStore(repo)
    nb = await nb_store.get(notebook_id, principal)
    if not nb:
        raise HTTPException(404, "notebook not found")

    # Sources in this workspace (owner+notebook scoped) are all exclusive to it in Docx.
    sources = await src_store.list(principal, notebook=notebook_id, limit=10_000)
    deleted_sources = 0
    unlinked_sources = 0
    for src in sources:
        if not src.id:
            continue
        if delete_exclusive_sources:
            if await src_store.delete(src.id, principal):
                deleted_sources += 1
        else:
            if await src_store.remove_from_notebook(src.id, principal):
                unlinked_sources += 1

    await nb_store.delete(notebook_id, principal)
    return NotebookDeleteResponse(
        message="Notebook deleted successfully",
        deleted_notes=0,  # Docx has no notes table
        deleted_sources=deleted_sources,
        unlinked_sources=unlinked_sources,
    )


@router.post("/{notebook_id}/sources/{source_id}")
async def add_source_to_notebook(
    notebook_id: str,
    source_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> dict[str, str]:
    """Link an existing source the caller owns into one of their workspaces (idempotent)."""
    nb_store = NotebookStore(repo)
    src_store = SourceStore(repo)
    if not await nb_store.get(notebook_id, principal):
        raise HTTPException(404, "notebook not found")
    if not await src_store.add_to_notebook(source_id, notebook_id, principal):
        raise HTTPException(404, "source not found")
    return {"message": "Source linked to notebook successfully"}


@router.delete("/{notebook_id}/sources/{source_id}")
async def remove_source_from_notebook(
    notebook_id: str,
    source_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> dict[str, str]:
    """Unlink a source the caller owns from their workspace (clear its `notebook`)."""
    nb_store = NotebookStore(repo)
    src_store = SourceStore(repo)
    if not await nb_store.get(notebook_id, principal):
        raise HTTPException(404, "notebook not found")
    if not await src_store.remove_from_notebook(source_id, principal):
        raise HTTPException(404, "source not found")
    return {"message": "Source removed from notebook successfully"}
