"""Notebook-HLD API — Surface 2 (the notebook "Diagram"/HLD view).

Design: ``docs/2026-06-06-diagram-platform-design.md`` §6 + the entity-resolution
sub-design ``docs/2026-06-07-entity-resolution-subdesign.md``. The HLD is a **derived view**
that deterministically composes the notebook's *accepted source diagrams* into one
entity-bridged parent :class:`DiagramGraph` (each source = a drillable node; entities shared
across ≥2 sources = cross-source bridge nodes). It legitimately changes as sources are
added/re-diagrammed or the registry is edited (sub-design §8). Accepting it freezes a
point-in-time picture like any other surface.

Endpoints (nested under ``/notebooks`` — an HLD always belongs to a notebook; the static
sub-paths precede the bare ``GET /{notebook_id}/diagram`` so FastAPI matches them literally,
the same precedence rule the source-diagram + transformations routers follow):

    POST /notebooks/{id}/diagram/build     → the design's "Build notebook diagram" verb
                                             (§6). Idempotent alias of /diagram/rebuild — the
                                             first build and a later rebuild are the same
                                             compose-and-persist operation.
    POST /notebooks/{id}/diagram/rebuild   → (1) upsert the entity registry from every
                                             accepted source diagram (Path C, idempotent),
                                             (2) compose the HLD, (3) persist it as the
                                             notebook's current diagram. Returns it + the
                                             low-confidence merges for human review.
    GET  /notebooks/{id}/diagram           → load the notebook's current HLD (latest).
    POST /notebooks/{id}/diagram/accept    → freeze the HLD: stamp accepted, freeze
                                             graph_json, store a server-rendered static SVG.
    GET    /notebooks/{id}/entities                → the notebook's entity registry.
    POST   /notebooks/{id}/entities/merge          → human override: merge entities (§6).
    POST   /notebooks/{id}/entities/split          → human override: split an entity (§6).
    PATCH  /notebooks/{id}/entities/{entity_id}     → rename / edit kind / aliases (§6).
    DELETE /notebooks/{id}/entities/{entity_id}     → remove an entity (§6).

The frozen ``api/diagrams.py`` is NOT touched: the Path-C registry upsert is driven from the
*rebuild* flow here (sub-design §5 gotcha 10) rather than from the source-accept endpoint, so
no edit to the frozen source router is needed.

Tenancy: a notebook must be the caller's (``NotebookStore.get`` is owner-scoped); the HLD
diagram + the registry are owner-PRIVATE (``DiagramStore`` / ``EntityRegistryStore`` stamp
``Scope.PRIVATE`` and read ``focus=True``). One notebook has one *current* HLD (latest by
``updated``); rebuild overwrites the draft / opens a new version after acceptance, accept
freezes it (mirrors the source surface's immutability rule).

LLM path: composition is provider-agnostic — the reconciler's ambiguous-tail adjudication
runs over the injected ``ChatClient`` (prod Azure) or ``ClaudeCliChatClient`` (local). The
common (controlled-vocab) path needs no LLM; locally the hash embedder is lexical, so synonym
matching leans on the LLM (sub-design §9). A pipeline/compose failure surfaces cleanly, never
a raw stack trace.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

import structlog
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from docx_app.ai.chat import ChatClient
from docx_app.db import SurrealRepository
from docx_app.deps import (
    get_chat_client,
    get_embedder,
    get_principal,
    get_repository,
)
from docx_app.diagram.compose import (
    accepted_source_diagrams_for_notebook,
    compose_notebook_hld,
)
from docx_app.diagram.domain import Diagram, DiagramStore
from docx_app.diagram.entities import EntityRegistryStore, NotebookEntity
from docx_app.diagram.model import DiagramGraph
from docx_app.diagram.render_svg import render_snapshot_svg
from docx_app.domain.notebook import Notebook, NotebookStore
from docx_app.indexing.embedding import Embedder, LocalTestEmbedder
from docx_app.tenancy import Principal

router = APIRouter(prefix="/notebooks", tags=["diagrams"])
log = structlog.get_logger(__name__)

# Surface-2 is always a "notebook" diagram (design: one table, distinguished by surface+ref).
_SURFACE_NOTEBOOK = "notebook"


# --- Request / response schemas -------------------------------------------- #


class EntityResponse(BaseModel):
    """One registry entity (the human-override editor reads these). Mirrors
    :class:`~docx_app.diagram.entities.NotebookEntity` minus the embedding (large, internal).
    """

    id: str
    notebook_id: str
    entity_key: str
    canonical_label: str
    kind: str | None = None
    aliases: list[str] = []
    description: str | None = None
    source_refs: list[str] = []
    locked: bool = False
    created: str = ""
    updated: str = ""


class AssignmentResponse(BaseModel):
    """A low-confidence merge surfaced for human review (sub-design §6/§10).

    ``method`` is ``embedding`` or ``llm`` (heuristic merges); the UI can offer a one-click
    split/relink. Deterministic and brand-new assignments are not surfaced.
    """

    entity_key: str
    method: str
    confidence: float


class NotebookDiagramResponse(BaseModel):
    """A notebook's HLD diagram. ``graph`` is the entity-bridged parent
    :class:`DiagramGraph` as a plain JSON object (edges keyed by ``"from"`` — the renderer
    reads it as-is). ``render_snapshot_svg`` is present only once ``accepted``.

    ``low_confidence`` (rebuild only) lists heuristic merges for human review;
    ``source_count``/``bridge_count`` summarise the composition.
    """

    id: str
    notebook_id: str
    surface: str
    status: str  # 'draft' | 'accepted'
    version: int
    graph: dict[str, Any] | None = None
    render_snapshot_svg: str | None = None
    source_count: int = 0
    bridge_count: int = 0
    low_confidence: list[AssignmentResponse] = []
    created: str = ""
    updated: str = ""


class MergeEntitiesRequest(BaseModel):
    """Merge ``merged_ids`` into ``survivor_id`` (human override, sub-design §6).

    The survivor absorbs the merged entities' labels (as aliases) + source_refs and is
    locked so a later rebuild does not undo the merge.
    """

    survivor_id: str
    merged_ids: list[str]


class SplitEntityRequest(BaseModel):
    """Split ``source_entity_id`` — move selected aliases/source_refs to a new entity (§6).

    Both the source and the new entity are locked (the split is a sticky human decision).
    """

    source_entity_id: str
    new_entity_key: str
    new_canonical_label: str
    move_aliases: list[str] = []
    move_source_refs: list[str] = []
    kind: str | None = None


class UpdateEntityRequest(BaseModel):
    """Rename / edit an entity (human override, sub-design §6). Unset fields are unchanged.

    Any edit locks the entity (``locked`` defaults to ``True`` on a manual edit) so a later
    rebuild treats the human decision as sticky; pass ``locked=False`` to explicitly unlock.
    """

    canonical_label: str | None = None
    kind: str | None = None
    aliases: list[str] | None = None
    description: str | None = None
    locked: bool | None = None


# --- Helpers ---------------------------------------------------------------- #


async def _require_notebook(
    repo: SurrealRepository, notebook_id: str, principal: Principal
) -> Notebook:
    """Fetch a notebook the caller OWNS, or 404 (owner-scoped — mirrors _require_source)."""
    notebook = await NotebookStore(repo).get(notebook_id, principal)
    if notebook is None:
        raise HTTPException(404, "notebook not found")
    return notebook


async def _current_diagram(
    store: DiagramStore, notebook_full_id: str, principal: Principal
) -> Diagram | None:
    """The notebook's current (latest-updated) HLD diagram, or None if it has none.

    ``DiagramStore.list`` is owner-scoped and ordered ``updated DESC``, so the first row is
    the one the HLD view shows (drafts overwrite; accepting freezes; a rebuild after
    acceptance adds a new version).
    """
    rows = await store.list(
        principal, surface=_SURFACE_NOTEBOOK, ref=notebook_full_id, limit=1
    )
    return rows[0] if rows else None


def _to_response(
    diagram: Diagram,
    notebook_id: str,
    *,
    source_count: int = 0,
    bridge_count: int = 0,
    low_confidence: list[AssignmentResponse] | None = None,
) -> NotebookDiagramResponse:
    """Map a stored HLD :class:`Diagram` to the wire response (graph passed through as-is)."""
    return NotebookDiagramResponse(
        id=diagram.id or "",
        notebook_id=notebook_id,
        surface=diagram.surface or _SURFACE_NOTEBOOK,
        status=diagram.status or "draft",
        version=diagram.version or 1,
        graph=diagram.graph_json,
        render_snapshot_svg=diagram.render_snapshot_svg,
        source_count=source_count,
        bridge_count=bridge_count,
        low_confidence=low_confidence or [],
        created=diagram.created or "",
        updated=diagram.updated or "",
    )


def _entity_response(entity: NotebookEntity) -> EntityResponse:
    return EntityResponse(
        id=entity.id or "",
        notebook_id=entity.notebook_id or "",
        entity_key=entity.entity_key or "",
        canonical_label=entity.canonical_label or "",
        kind=entity.kind,
        aliases=entity.aliases,
        description=entity.description,
        source_refs=entity.source_refs,
        locked=entity.locked,
        created=entity.created or "",
        updated=entity.updated or "",
    )


async def _persist_hld_graph(
    store: DiagramStore,
    *,
    owner: str,
    principal: Principal,
    notebook_full_id: str,
    existing: Diagram | None,
    graph: DiagramGraph,
) -> Diagram:
    """Persist ``graph`` as the notebook's current HLD, respecting immutability.

    Mirrors the source surface's ``_persist_graph``:
      * no HLD yet → create a new draft (version 1);
      * a **draft** → overwrite its graph in place (version bumps);
      * an **accepted** HLD → start a NEW draft version (the frozen row is never mutated —
        the immutability rule; a rebuild after acceptance is a new version, sub-design §8).
    """
    if existing is None:
        return await store.create(
            owner=owner,
            surface=_SURFACE_NOTEBOOK,
            ref=notebook_full_id,
            graph=graph,
        )
    if existing.status == "accepted":
        revised = await store.new_version(existing.id or "", principal, graph=graph)
    else:
        revised = await store.update_graph(existing.id or "", principal, graph=graph)
    if revised is None:  # pragma: no cover - existing was just read as owned
        raise HTTPException(404, "diagram not found")
    return revised


def _real_embedder(embedder: Embedder) -> Embedder | None:
    """Return the embedder only when it is a real (network) embedder, else ``None``.

    The reconciler/compose want a real embedding model for synonym matching; the local
    test embedder is lexical and adds no semantic signal, so locally we pass ``None`` and let
    compose use its own deterministic lexical fallback (sub-design §9). Keeps prod wired to
    the real model without coupling compose to the deps container.
    """
    return None if isinstance(embedder, LocalTestEmbedder) else embedder


# --- Static sub-routes (must precede the bare /{notebook_id}/diagram) -------- #


@router.post("/{notebook_id}/diagram/rebuild", response_model=NotebookDiagramResponse)
async def rebuild_notebook_diagram(
    notebook_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
    chat: ChatClient = Depends(get_chat_client),
    embedder: Embedder = Depends(get_embedder),
) -> NotebookDiagramResponse:
    """Rebuild the notebook's HLD from its accepted source diagrams (sub-design §5 gotcha 10).

    Three idempotent steps:
      1. **Path-C upsert** — for every accepted source diagram in the notebook, upsert the
         entity registry from its ``node.entity`` keys (new keys → new entities; reused keys
         → append alias + source_ref; locked entities untouched). Re-running is a no-op for
         unchanged keys.
      2. **Compose** — deterministically build the entity-bridged parent graph, resolving any
         node lacking an ``entity`` key via the §5 reconciler (LLM only for the ambiguous
         tail, bounded per compose).
      3. **Persist** — store the parent graph as the notebook's current HLD (new draft, or a
         new version if the prior HLD was accepted — immutability).

    404 if the notebook isn't the caller's, or has **no accepted source diagrams** to compose
    (the empty-state the HLD view shows as "accept a source diagram first").
    """
    notebook = await _require_notebook(repo, notebook_id, principal)
    notebook_full_id = notebook.id or notebook_id
    store = DiagramStore(repo)
    registry_store = EntityRegistryStore(repo)
    embed_model = _real_embedder(embedder)

    # Step 1 — Path-C registry upsert from each accepted source diagram (idempotent).
    accepted = await accepted_source_diagrams_for_notebook(
        store, principal, notebook_id=notebook_full_id
    )
    if not accepted:
        raise HTTPException(
            404, "no accepted source diagrams to compose into a notebook diagram"
        )
    for diagram in accepted:
        graph = diagram.graph()
        if graph is None:
            continue
        await registry_store.upsert_from_graph(
            principal,
            notebook_id=notebook_full_id,
            source_id=diagram.ref or "",
            graph=graph,
            embedder=embed_model,
        )

    # Step 2 — compose the entity-bridged HLD (Path-B reconciler for unmatched nodes).
    # Embed unmatched nodes with the SAME (real) embedder the registry rows used, so cosine
    # is meaningful; locally embed_model is None → compose uses its lexical fallback (§9).
    embedding_fn = _embed_closure(embed_model) if embed_model is not None else None
    result = await compose_notebook_hld(
        repo,
        principal,
        notebook_id=notebook_full_id,
        chat=chat,
        embedding_fn=embedding_fn,
    )
    if result.graph is None:  # pragma: no cover - accepted set was non-empty above
        raise HTTPException(
            404, "no accepted source diagrams to compose into a notebook diagram"
        )

    # Step 3 — persist as the notebook's current HLD.
    existing = await _current_diagram(store, notebook_full_id, principal)
    diagram = await _persist_hld_graph(
        store,
        owner=principal.owner,
        principal=principal,
        notebook_full_id=notebook_full_id,
        existing=existing,
        graph=result.graph,
    )
    log.info(
        "notebook_hld_rebuilt",
        notebook_id=notebook_full_id,
        source_count=result.source_count,
        bridge_count=result.bridge_count,
        low_confidence=len(result.low_confidence),
    )
    return _to_response(
        diagram,
        notebook_id,
        source_count=result.source_count,
        bridge_count=result.bridge_count,
        low_confidence=[
            AssignmentResponse(
                entity_key=a.entity_key, method=a.method, confidence=a.confidence
            )
            for a in result.low_confidence
        ],
    )


@router.post("/{notebook_id}/diagram/build", response_model=NotebookDiagramResponse)
async def build_notebook_diagram(
    notebook_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
    chat: ChatClient = Depends(get_chat_client),
    embedder: Embedder = Depends(get_embedder),
) -> NotebookDiagramResponse:
    """Build the notebook's HLD — the named "Build notebook diagram" action (design §6).

    This is the design's ``POST /notebooks/{id}/diagram/build`` verb (parent design §6: "Build
    notebook diagram → statically compose all accepted source graphs … via the shared-entity
    registry"). Building the HLD is **idempotent and re-runnable** — composing again over the
    same accepted sources yields the same graph, and it legitimately changes as sources are
    added/re-diagrammed or the registry is edited (sub-design §8). It is therefore an exact
    alias of :func:`rebuild_notebook_diagram`: the very first build and a later rebuild are the
    same operation (Path-C registry upsert → compose → persist as the notebook's current HLD).
    Defined as a thin delegate (not a copy) so the two verbs can never diverge.

    404 if the notebook isn't the caller's, or has **no accepted source diagrams** to compose.
    """
    return await rebuild_notebook_diagram(
        notebook_id,
        principal=principal,
        repo=repo,
        chat=chat,
        embedder=embedder,
    )


@router.post("/{notebook_id}/diagram/accept", response_model=NotebookDiagramResponse)
async def accept_notebook_diagram(
    notebook_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> NotebookDiagramResponse:
    """Freeze the notebook's HLD — DATA + PICTURE (design §2; sub-design §8).

    Stamps ``status="accepted"``, freezes ``graph_json`` (the composed parent graph), and
    stores a **server-rendered static SVG snapshot** (``render_snapshot_svg``) — the
    guaranteed-stable image the accepted HLD view shows. A frozen HLD is a point-in-time
    picture; a later rebuild produces a new version rather than mutating the accepted one.

    404 if the notebook has no HLD; 422 if it has no graph to freeze.
    """
    notebook = await _require_notebook(repo, notebook_id, principal)
    store = DiagramStore(repo)
    notebook_full_id = notebook.id or notebook_id
    existing = await _current_diagram(store, notebook_full_id, principal)
    if existing is None:
        raise HTTPException(404, "diagram not found")
    graph = existing.graph()  # model_validate of graph_json (honours the "from" alias)
    if graph is None:
        raise HTTPException(422, "diagram has no graph to accept")

    svg = render_snapshot_svg(graph, title=notebook.name)
    diagram = await store.accept(
        existing.id or "", principal, render_snapshot_svg=svg, graph=graph
    )
    if diagram is None:  # pragma: no cover - existing was just read as owned
        raise HTTPException(404, "diagram not found")
    log.info(
        "notebook_hld_accepted",
        notebook_id=notebook_full_id,
        diagram_id=diagram.id,
        version=diagram.version,
        svg_bytes=len(svg),
    )
    return _to_response(diagram, notebook_id)


# --- Registry (human override) routes — also static, before the bare diagram route --- #


@router.get("/{notebook_id}/entities", response_model=list[EntityResponse])
async def list_entities(
    notebook_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> list[EntityResponse]:
    """The notebook's entity registry (owner-scoped) — backs the registry editor (§6)."""
    notebook = await _require_notebook(repo, notebook_id, principal)
    entities = await EntityRegistryStore(repo).list(
        principal, notebook_id=notebook.id or notebook_id
    )
    return [_entity_response(e) for e in entities]


@router.post("/{notebook_id}/entities/merge", response_model=EntityResponse)
async def merge_entities(
    notebook_id: str,
    body: MergeEntitiesRequest,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> EntityResponse:
    """Merge entities (human override, sub-design §6). The survivor is locked (sticky)."""
    await _require_notebook(repo, notebook_id, principal)
    survivor = await EntityRegistryStore(repo).merge(
        principal, survivor_id=body.survivor_id, merged_ids=body.merged_ids
    )
    if survivor is None:
        raise HTTPException(404, "survivor entity not found")
    return _entity_response(survivor)


@router.post("/{notebook_id}/entities/split", response_model=list[EntityResponse])
async def split_entity(
    notebook_id: str,
    body: SplitEntityRequest,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> list[EntityResponse]:
    """Split an entity (human override, §6). Returns ``[source_after, new_entity]``; both locked."""
    await _require_notebook(repo, notebook_id, principal)
    result = await EntityRegistryStore(repo).split(
        principal,
        source_entity_id=body.source_entity_id,
        new_entity_key=body.new_entity_key,
        new_canonical_label=body.new_canonical_label,
        move_aliases=body.move_aliases,
        move_source_refs=body.move_source_refs,
        kind=body.kind,
    )
    if result is None:
        raise HTTPException(404, "source entity not found")
    source_after, new_entity = result
    return [_entity_response(source_after), _entity_response(new_entity)]


@router.patch(
    "/{notebook_id}/entities/{entity_id}", response_model=EntityResponse
)
async def update_entity(
    notebook_id: str,
    entity_id: str,
    body: UpdateEntityRequest,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> EntityResponse:
    """Rename / edit an entity (human override, §6). Any edit locks it unless ``locked=False``."""
    await _require_notebook(repo, notebook_id, principal)
    fields: dict[str, Any] = {}
    if body.canonical_label is not None:
        fields["canonical_label"] = body.canonical_label
    if body.kind is not None:
        fields["kind"] = body.kind
    if body.aliases is not None:
        fields["aliases"] = body.aliases
    if body.description is not None:
        fields["description"] = body.description
    # A manual edit is sticky by default (sub-design §6); explicit locked wins.
    fields["locked"] = body.locked if body.locked is not None else True
    updated = await EntityRegistryStore(repo).update_fields(
        entity_id, principal, fields=fields
    )
    if updated is None:
        raise HTTPException(404, "entity not found")
    return _entity_response(updated)


@router.delete("/{notebook_id}/entities/{entity_id}", status_code=204)
async def delete_entity(
    notebook_id: str,
    entity_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> None:
    """Delete an entity the caller OWNS (human override, §6). 404 if it isn't theirs."""
    await _require_notebook(repo, notebook_id, principal)
    deleted = await EntityRegistryStore(repo).delete(entity_id, principal)
    if not deleted:
        raise HTTPException(404, "entity not found")


# --- Bare /{notebook_id}/diagram route (after the static sub-paths) ---------- #


@router.get("/{notebook_id}/diagram", response_model=NotebookDiagramResponse)
async def get_notebook_diagram(
    notebook_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> NotebookDiagramResponse:
    """Load the notebook's current HLD (draft or accepted). 404 if none built yet.

    A 404 here is the HLD view's "empty" state — the frontend then shows the "Build notebook
    diagram" call-to-action that POSTs to ``/diagram/rebuild``.
    """
    notebook = await _require_notebook(repo, notebook_id, principal)
    store = DiagramStore(repo)
    diagram = await _current_diagram(store, notebook.id or notebook_id, principal)
    if diagram is None:
        raise HTTPException(404, "diagram not found")
    return _to_response(diagram, notebook_id)


def _embed_closure(embedder: Embedder) -> Callable[[str], Awaitable[list[float]]]:
    """An async ``str -> vector`` closure over the (real) batched :class:`Embedder`.

    The reconciler embeds one unmatched node label at a time; this adapts the project's
    batched async embedder to that single-text contract so node vectors live in the same
    space as the registry embeddings (computed by the same embedder at Path-C upsert). Only
    built for the real embedder (the local lexical one is bypassed — see ``_real_embedder``).
    """

    async def _embed_one(text: str) -> list[float]:
        vectors = await embedder.embed([text])
        return vectors[0] if vectors else []

    return _embed_one
