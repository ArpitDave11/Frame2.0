"""Credentials API — per-owner AI provider credentials (OpenAI + Azure OpenAI only).

Port of Open Notebook's /credentials router + service (api/routers/credentials.py +
api/credentials_service.py), tenant-scoped and restricted to two providers. Aligned to the
frontend contract (lib/api/credentials.ts):

  GET    /credentials                 → Credential[]   (optional ?provider= filter)
  GET    /credentials/status          → CredentialStatus
  GET    /credentials/env-status      → Record<provider, bool>
  GET    /credentials/by-provider/{p} → Credential[]
  POST   /credentials                 → Credential     (201)
  GET    /credentials/{id}            → Credential
  PUT    /credentials/{id}            → Credential
  DELETE /credentials/{id}            → CredentialDeleteResponse
  POST   /credentials/{id}/test       → TestConnectionResult
  POST   /credentials/{id}/discover   → DiscoverModelsResponse

Tenancy (ZERO TOLERANCE): credentials are PRIVATE to their owner. Every read/write goes
through the owner-scoped CredentialStore. SECURITY: the actual api_key is NEVER returned —
responses expose only `has_api_key`. (`status`/`env-status` reflect what the DEPLOYMENT has
configured via env vars; they carry no per-owner secret material.)

The 'test' endpoint does a light outbound HTTP ping (Azure: list /openai/models; OpenAI:
GET /v1/models) via the corporate-CA client — it does NOT route through ai/chat (which uses
the deployment's static Azure creds, not the per-credential config). See `simplifications`.
"""

from __future__ import annotations

import ipaddress
import os
import socket
from typing import Any
from urllib.parse import urlparse

import httpx
import structlog
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from docx_app.config import DocxConfig
from docx_app.db import SurrealRepository
from docx_app.deps import get_config, get_principal, get_repository
from docx_app.domain.credential import (
    SUPPORTED_PROVIDERS,
    Credential,
    CredentialStore,
    default_modalities,
    is_supported_provider,
    normalize_provider,
)
from docx_app.http import make_client
from docx_app.tenancy import Principal

router = APIRouter(prefix="/credentials", tags=["credentials"])
log = structlog.get_logger(__name__)

# Env vars that mark a provider as DEPLOYMENT-configured (mirrors ON PROVIDER_ENV_CONFIG,
# restricted to OpenAI + Azure). "all of these must be set" semantics per provider.
_PROVIDER_ENV_REQUIRED: dict[str, list[str]] = {
    "openai": ["OPENAI_API_KEY"],
    "azure": [
        "AZURE_OPENAI_API_KEY",
        "AZURE_OPENAI_ENDPOINT",
        "AZURE_OPENAI_API_VERSION",
    ],
}


# --- Wire schemas (match ON CredentialResponse / requests exactly) ---------


class CredentialResponse(BaseModel):
    """Response for a credential. NEVER includes api_key — only `has_api_key`."""

    id: str
    name: str
    provider: str
    modalities: list[str]
    base_url: str | None = None
    endpoint: str | None = None
    api_version: str | None = None
    endpoint_llm: str | None = None
    endpoint_embedding: str | None = None
    endpoint_stt: str | None = None
    endpoint_tts: str | None = None
    project: str | None = None
    location: str | None = None
    credentials_path: str | None = None
    has_api_key: bool = False
    created: str
    updated: str
    model_count: int = 0
    decryption_error: str | None = None


class CreateCredentialRequest(BaseModel):
    name: str = Field(..., description="Credential name")
    provider: str = Field(..., description="Provider name (openai or azure)")
    modalities: list[str] = Field(default_factory=list)
    api_key: str | None = None
    base_url: str | None = None
    endpoint: str | None = None
    api_version: str | None = None
    endpoint_llm: str | None = None
    endpoint_embedding: str | None = None
    endpoint_stt: str | None = None
    endpoint_tts: str | None = None
    # Vertex-only fields; accepted for ON contract parity but unused (OpenAI/Azure only).
    project: str | None = None
    location: str | None = None
    credentials_path: str | None = None


class UpdateCredentialRequest(BaseModel):
    name: str | None = None
    modalities: list[str] | None = None
    api_key: str | None = None
    base_url: str | None = None
    endpoint: str | None = None
    api_version: str | None = None
    endpoint_llm: str | None = None
    endpoint_embedding: str | None = None
    endpoint_stt: str | None = None
    endpoint_tts: str | None = None
    project: str | None = None
    location: str | None = None
    credentials_path: str | None = None


class CredentialDeleteResponse(BaseModel):
    message: str
    deleted_models: int = 0


class TestConnectionResult(BaseModel):
    provider: str
    success: bool
    message: str


class DiscoveredModelResponse(BaseModel):
    name: str
    provider: str
    model_type: str | None = None
    description: str | None = None


class DiscoverModelsResponse(BaseModel):
    credential_id: str
    provider: str
    discovered: list[DiscoveredModelResponse]


# --- URL validation (SSRF protection; ported from ON credentials_service) --


def validate_url(url: str | None) -> None:
    """Validate an API endpoint URL. Blocks non-http(s) schemes and link-local addresses
    (169.254.x.x cloud-metadata endpoints). Private IPs / localhost are allowed (self-hosted).
    Raises ValueError on a bad URL. Mirrors ON's _validate_url, trimmed for this slice.
    """
    if not url or not url.strip():
        return
    try:
        parsed = urlparse(url.strip())
    except Exception as exc:  # noqa: BLE001 - any parse failure → uniform error
        raise ValueError("Invalid URL format.") from exc

    if parsed.scheme not in ("http", "https"):
        raise ValueError(
            f"Invalid URL scheme: '{parsed.scheme}'. Only http and https are allowed."
        )
    hostname = parsed.hostname
    if not hostname:
        raise ValueError("Invalid URL: hostname could not be determined.")

    def _is_link_local(addr: str) -> bool:
        try:
            ip = ipaddress.ip_address(addr)
        except ValueError:
            return False
        if ip.is_link_local:
            return True
        mapped = getattr(ip, "ipv4_mapped", None)
        return bool(mapped and mapped.is_link_local)

    if _is_link_local(hostname):
        raise ValueError(
            "Link-local addresses (169.254.x.x) are not allowed for security reasons."
        )
    # If it's a hostname, resolve and reject if it maps to a link-local address.
    try:
        ipaddress.ip_address(hostname)
    except ValueError:
        try:
            for _, _, _, _, sockaddr in socket.getaddrinfo(hostname, None):
                if _is_link_local(str(sockaddr[0])):
                    raise ValueError(
                        f"Hostname '{hostname}' resolves to a link-local address, "
                        "which is not allowed for security reasons."
                    )
        except socket.gaierror:
            # Unresolvable here may still be valid in the deployment env (internal DNS,
            # Azure endpoints). ON only hard-blocks link-local, so we allow it.
            pass


# --- Helpers ---------------------------------------------------------------


def _credential_response(cred: Credential, model_count: int) -> CredentialResponse:
    return CredentialResponse(
        id=cred.id or "",
        name=cred.name or "",
        provider=cred.provider or "",
        modalities=cred.modalities,
        base_url=cred.base_url,
        endpoint=cred.endpoint,
        api_version=cred.api_version,
        endpoint_llm=cred.endpoint_llm,
        endpoint_embedding=cred.endpoint_embedding,
        endpoint_stt=cred.endpoint_stt,
        endpoint_tts=cred.endpoint_tts,
        project=cred.project,
        location=cred.location,
        credentials_path=cred.credentials_path,
        has_api_key=cred.api_key is not None,
        created=cred.created or "",
        updated=cred.updated or "",
        model_count=model_count,
        decryption_error=cred.decryption_error,
    )


def _validate_urls(*urls: str | None) -> None:
    for u in urls:
        if u:
            try:
                validate_url(u)
            except ValueError as exc:
                raise HTTPException(400, str(exc)) from exc


def _require_supported(provider: str) -> None:
    if not is_supported_provider(provider):
        raise HTTPException(
            400,
            f"unsupported provider '{provider}' (supported: {list(SUPPORTED_PROVIDERS)})",
        )


def _check_env_configured(provider: str) -> bool:
    required = _PROVIDER_ENV_REQUIRED.get(normalize_provider(provider), [])
    return bool(required) and all(bool(os.environ.get(v, "").strip()) for v in required)


# --- Status endpoints (declared before /{credential_id}) -------------------


class CredentialStatusResponse(BaseModel):
    configured: dict[str, bool]
    source: dict[str, str]
    encryption_configured: bool


@router.get("/status", response_model=CredentialStatusResponse)
async def get_status(
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> CredentialStatusResponse:
    """Per-provider configuration status for the caller: a DB credential (owner-scoped) or
    a deployment env var. `encryption_configured` is False — at-rest encryption is omitted
    (see module docstring); the field stays for ON contract parity.
    """
    store = CredentialStore(repo)
    configured: dict[str, bool] = {}
    source: dict[str, str] = {}
    for provider in SUPPORTED_PROVIDERS:
        env_ok = _check_env_configured(provider)
        db_ok = len(await store.list(principal, provider=provider)) > 0
        configured[provider] = db_ok or env_ok
        source[provider] = (
            "database" if db_ok else ("environment" if env_ok else "none")
        )
    return CredentialStatusResponse(
        configured=configured, source=source, encryption_configured=False
    )


@router.get("/env-status")
async def get_env_status() -> dict[str, bool]:
    """Which providers are configured via deployment environment variables."""
    return {p: _check_env_configured(p) for p in SUPPORTED_PROVIDERS}


# --- By-provider (declared before /{credential_id}) ------------------------


@router.get("/by-provider/{provider}", response_model=list[CredentialResponse])
async def list_credentials_by_provider(
    provider: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> list[CredentialResponse]:
    store = CredentialStore(repo)
    creds = await store.list(principal, provider=provider)
    out: list[CredentialResponse] = []
    for cred in creds:
        count = await store.linked_model_count(cred.id or "", principal)
        out.append(_credential_response(cred, count))
    return out


# --- CRUD ------------------------------------------------------------------


@router.get("", response_model=list[CredentialResponse])
async def list_credentials(
    provider: str | None = Query(None, description="Filter by provider"),
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> list[CredentialResponse]:
    store = CredentialStore(repo)
    creds = await store.list(principal, provider=provider)
    out: list[CredentialResponse] = []
    for cred in creds:
        count = await store.linked_model_count(cred.id or "", principal)
        out.append(_credential_response(cred, count))
    return out


@router.post("", response_model=CredentialResponse, status_code=201)
async def create_credential(
    body: CreateCredentialRequest,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> CredentialResponse:
    _require_supported(body.provider)
    _validate_urls(
        body.base_url,
        body.endpoint,
        body.endpoint_llm,
        body.endpoint_embedding,
        body.endpoint_stt,
        body.endpoint_tts,
    )
    modalities = body.modalities or default_modalities(body.provider)
    cred = await CredentialStore(repo).create(
        owner=principal.owner,
        name=body.name,
        provider=body.provider,
        modalities=modalities,
        api_key=body.api_key,
        base_url=body.base_url,
        endpoint=body.endpoint,
        api_version=body.api_version,
        endpoint_llm=body.endpoint_llm,
        endpoint_embedding=body.endpoint_embedding,
        endpoint_stt=body.endpoint_stt,
        endpoint_tts=body.endpoint_tts,
    )
    return _credential_response(cred, 0)


@router.get("/{credential_id}", response_model=CredentialResponse)
async def get_credential(
    credential_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> CredentialResponse:
    store = CredentialStore(repo)
    cred = await store.get(credential_id, principal)
    if not cred:
        raise HTTPException(404, "credential not found")
    count = await store.linked_model_count(credential_id, principal)
    return _credential_response(cred, count)


# Map request column → stored column (all 1:1 here; explicit for safety since the names
# are interpolated into the UPDATE statement — they must be code constants, never user data).
_UPDATABLE_COLUMNS = (
    "name",
    "modalities",
    "api_key",
    "base_url",
    "endpoint",
    "api_version",
    "endpoint_llm",
    "endpoint_embedding",
    "endpoint_stt",
    "endpoint_tts",
)


@router.put("/{credential_id}", response_model=CredentialResponse)
async def update_credential(
    credential_id: str,
    body: UpdateCredentialRequest,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> CredentialResponse:
    _validate_urls(
        body.base_url,
        body.endpoint,
        body.endpoint_llm,
        body.endpoint_embedding,
        body.endpoint_stt,
        body.endpoint_tts,
    )
    # Only fields the client actually sent (exclude_unset) and only the allow-listed columns.
    sent = body.model_dump(exclude_unset=True)
    fields: dict[str, Any] = {k: v for k, v in sent.items() if k in _UPDATABLE_COLUMNS}
    store = CredentialStore(repo)
    cred = await store.update(credential_id, principal, fields=fields)
    if not cred:
        raise HTTPException(404, "credential not found")
    count = await store.linked_model_count(credential_id, principal)
    return _credential_response(cred, count)


@router.delete("/{credential_id}", response_model=CredentialDeleteResponse)
async def delete_credential(
    credential_id: str,
    migrate_to: str | None = Query(
        None, description="Reassign linked models to this credential ID before deletion"
    ),
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> CredentialDeleteResponse:
    deleted = await CredentialStore(repo).delete(
        credential_id, principal, migrate_to=migrate_to
    )
    if deleted is None:
        raise HTTPException(404, "credential not found")
    return CredentialDeleteResponse(
        message="Credential deleted successfully", deleted_models=deleted
    )


# --- Test / discover -------------------------------------------------------


async def _ping_openai(
    client: httpx.AsyncClient, api_key: str | None
) -> tuple[bool, str]:
    if not api_key:
        return False, "No API key configured"
    try:
        resp = await client.get(
            "https://api.openai.com/v1/models",
            headers={"Authorization": f"Bearer {api_key}"},
        )
    except httpx.ConnectError:
        return False, "Cannot connect to OpenAI. Check network/endpoint."
    except httpx.TimeoutException:
        return False, "Connection timed out."
    if resp.status_code == 200:
        return True, "Connection successful"
    if resp.status_code == 401:
        return False, "Invalid API key"
    if resp.status_code == 403:
        return False, "API key lacks required permissions"
    return False, f"OpenAI returned status {resp.status_code}"


async def _ping_azure(
    client: httpx.AsyncClient, config: dict[str, Any]
) -> tuple[bool, str]:
    endpoint = config.get("endpoint")
    api_key = config.get("api_key")
    api_version = config.get("api_version") or "2024-10-21"
    if not endpoint:
        return False, "No Azure endpoint configured"
    if not api_key:
        return False, "No Azure API key configured"
    url = f"{str(endpoint).rstrip('/')}/openai/models?api-version={api_version}"
    try:
        resp = await client.get(url, headers={"api-key": str(api_key)})
    except httpx.ConnectError:
        return False, "Cannot connect to Azure endpoint. Check the URL."
    except httpx.TimeoutException:
        return False, "Connection timed out. Check the endpoint URL."
    if resp.status_code == 200:
        count = len(resp.json().get("data", []))
        return True, f"Connected. {count} models available"
    if resp.status_code == 401:
        return False, "Invalid API key"
    if resp.status_code == 403:
        return False, "API key lacks required permissions"
    return False, f"Azure returned status {resp.status_code}"


@router.post("/{credential_id}/test", response_model=TestConnectionResult)
async def test_credential(
    credential_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
    config: DocxConfig = Depends(get_config),
) -> TestConnectionResult:
    """Light outbound ping to validate the credential's API config (OpenAI/Azure /models)."""
    cred = await CredentialStore(repo).get(credential_id, principal)
    if not cred:
        raise HTTPException(404, "credential not found")
    provider = normalize_provider(cred.provider or "")
    provider_config = cred.to_provider_config()
    client = make_client(config, timeout=10.0)
    try:
        if provider == "openai":
            success, message = await _ping_openai(
                client, provider_config.get("api_key")
            )
        elif provider == "azure":
            success, message = await _ping_azure(client, provider_config)
        else:
            success, message = False, f"Unknown provider: {provider}"
    except Exception as exc:  # noqa: BLE001 - surface a clean message, never the raw secret
        log.warning(
            "credential_test_failed", credential_id=credential_id, exc_info=True
        )
        msg = str(exc)
        message = (msg[:100] + "...") if len(msg) > 100 else msg
        success = False
    finally:
        await client.aclose()
    return TestConnectionResult(provider=provider, success=success, message=message)


# Curated static model lists for discovery (OpenAI/Azure expose /models, but a stable
# curated list keeps the contract deterministic and avoids a network round-trip on discover).
_DISCOVER_MODELS: dict[str, list[str]] = {
    "openai": [
        "gpt-4o",
        "gpt-4o-mini",
        "gpt-4-turbo",
        "text-embedding-3-small",
        "text-embedding-3-large",
    ],
    "azure": [
        "gpt-4o",
        "gpt-4o-mini",
        "gpt-35-turbo",
        "text-embedding-3-small",
        "text-embedding-3-large",
    ],
}


@router.post("/{credential_id}/discover", response_model=DiscoverModelsResponse)
async def discover_models_for_credential(
    credential_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> DiscoverModelsResponse:
    """Return a curated list of well-known models for the credential's provider.

    ON queries the provider's /models API; here we return a deterministic curated list
    (OpenAI/Azure only) so the frontend's register-models flow has options without a
    network call. The model type is chosen by the user at registration time (see ON).
    """
    cred = await CredentialStore(repo).get(credential_id, principal)
    if not cred:
        raise HTTPException(404, "credential not found")
    provider = normalize_provider(cred.provider or "")
    names = _DISCOVER_MODELS.get(provider, [])
    return DiscoverModelsResponse(
        credential_id=cred.id or "",
        provider=provider,
        discovered=[DiscoveredModelResponse(name=n, provider=provider) for n in names],
    )
