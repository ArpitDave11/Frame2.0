"""Docx HTTP API routers."""
