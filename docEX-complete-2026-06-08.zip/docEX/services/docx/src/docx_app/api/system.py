"""System API — Open Notebook's settings-adjacent system endpoints (auth status, config,
embedding rebuild), ported to Docx's owner/scope model.

Endpoints (paths match what the Open Notebook frontend calls; the ingress strips /api/docx):
  GET  /auth/status        → whether an app password is required (Docx: never — auth lives at
                             the gateway, so always `auth_enabled: false`)
  GET  /config             → runtime config blob the frontend reads (apiUrl + db/version info)
  POST /embeddings/rebuild → re-chunk+re-embed the CALLER'S OWN sources via IndexingService

Tenancy: the rebuild only ever touches the caller's own sources (SourceStore.list(focus=True))
and the chunk replace is itself owner-scoped — a rebuild can never re-embed another owner's docs.
"""

from __future__ import annotations

import uuid
from typing import Any, Literal

import structlog
from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from docx_app.db import SurrealRepository
from docx_app.deps import get_indexer, get_principal, get_repository
from docx_app.domain.source import SourceStore
from docx_app.indexing.service import IndexingService
from docx_app.tenancy import Principal

router = APIRouter(tags=["system"])
log = structlog.get_logger(__name__)

# Upper bound on sources processed in one inline rebuild (v1 runs synchronously in-request;
# a real job queue would lift this — see the endpoint docstring / `simplifications`).
_REBUILD_MAX_SOURCES = 1000


# --- /auth/status ----------------------------------------------------------


@router.get("/auth/status")
async def auth_status() -> dict[str, Any]:
    """Docx terminates auth at the gateway, so the app itself never requires a password.

    Field names match Open Notebook's contract: the frontend reads `auth_enabled` (and falls
    back to false). `auth_required` is included for parity with the slice spec.
    """
    return {
        "auth_enabled": False,
        "auth_required": False,
        "message": "Authentication is handled by the gateway",
    }


# --- /config ---------------------------------------------------------------


@router.get("/config")
async def get_config_blob() -> dict[str, Any]:
    """Runtime config the frontend reads on startup.

    `apiUrl` is intentionally empty: the frontend resolves the API base URL itself (same as
    Open Notebook's runtime-config endpoint), so the backend returns "" and lets it decide.
    """
    return {
        "apiUrl": "",
        "version": "docx",
        "latestVersion": None,
        "hasUpdate": False,
        "dbStatus": "online",
    }


# --- /embeddings/rebuild ---------------------------------------------------


class RebuildRequest(BaseModel):
    mode: Literal["existing", "all"] = Field(
        "all",
        description="'existing' re-embeds only already-indexed sources; 'all' embeds every source",
    )
    include_sources: bool = Field(True, description="Include sources in the rebuild")
    # Notes/insights are not part of Docx v1; accepted for contract parity, but ignored.
    include_notes: bool = Field(True, description="(ignored in Docx) include notes")
    include_insights: bool = Field(
        True, description="(ignored in Docx) include insights"
    )


class RebuildResponse(BaseModel):
    command_id: str = Field(..., description="Identifier for this rebuild run")
    message: str = Field(..., description="Human-readable status")
    estimated_items: int = Field(..., description="Number of sources processed")


def _needs_rebuild(mode: str, chunk_count: int | None) -> bool:
    """'existing' → only sources that already have chunks; 'all' → every source with text."""
    if mode == "existing":
        return bool(chunk_count)
    return True


@router.post("/embeddings/rebuild", response_model=RebuildResponse)
async def rebuild_embeddings(
    body: RebuildRequest,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
    indexer: IndexingService = Depends(get_indexer),
) -> RebuildResponse:
    """Re-chunk + re-embed the caller's OWN sources.

    Open Notebook runs this as an async `rebuild_embeddings` command (surreal-commands) that
    fans out per-item jobs and is polled via `/embeddings/rebuild/{id}/status`. Docx has no
    command queue, so v1 rebuilds INLINE here (the same seam as upload-time indexing) and
    returns a synthetic command_id with the final count — recorded in `simplifications`.
    """
    command_id = uuid.uuid4().hex

    if not body.include_sources:
        # Nothing to do in Docx if sources are excluded (notes/insights don't exist here).
        return RebuildResponse(
            command_id=command_id,
            message="No sources selected for rebuild.",
            estimated_items=0,
        )

    # Own sources only (focus=True): a rebuild is a per-owner maintenance action, and the
    # chunk replace is owner-scoped anyway — never another owner's docs.
    sources = await SourceStore(repo).list(
        principal, focus=True, limit=_REBUILD_MAX_SOURCES
    )

    processed = 0
    failed = 0
    for source in sources:
        if not _needs_rebuild(body.mode, source.chunk_count):
            continue
        try:
            await indexer.index_source(source)
            processed += 1
        except Exception:  # noqa: BLE001 - resilience: one bad source must not abort the run
            failed += 1
            log.warning("rebuild_source_failed", source_id=source.id, exc_info=True)

    log.info(
        "embeddings_rebuilt",
        owner=principal.owner,
        mode=body.mode,
        processed=processed,
        failed=failed,
    )
    message = f"Rebuilt embeddings for {processed} source(s)."
    if failed:
        message += f" {failed} failed (see logs; recoverable via per-source reindex)."
    return RebuildResponse(
        command_id=command_id, message=message, estimated_items=processed
    )
