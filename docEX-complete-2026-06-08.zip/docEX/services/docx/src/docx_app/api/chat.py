"""Chat API — notebook chat (/chat) and source chat (/sources/{id}/chat).

Port of Open Notebook's chat + source_chat routers. ON drives both through LangGraph
state machines with a SqliteSaver; we do NOT use LangGraph (slice constraint). Instead each
turn is an explicit, owner-scoped pipeline:

    persist the user message → build grounded context (RAG for notebook chat; the source's
    own text for source chat) → ChatClient.complete → persist the AI message → return the
    full message list.

Message history lives in `chat_message` rows (owner-private), not a checkpoint file. The
response shapes match the frontend contract (lib/api/chat.ts + source-chat.ts) exactly:
sessions carry {id,title,notebook_id|source_id,created,updated,message_count,model_override};
messages carry {id,type,content,timestamp}; execute returns {session_id, messages}.

TWO routers are exported (mirroring ON's two root-level routers): `router` at /chat and
`source_chat_router` at /sources. Both are returned to the orchestrator for registration.

Tenancy: sessions + messages are owner-private; the parent notebook/source is verified via
its own owner-scoped store before any session op, so you can only chat over what you can see.
"""

from __future__ import annotations

import structlog
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from docx_app.ai.chat import ChatClient
from docx_app.db import SurrealRepository
from docx_app.deps import (
    get_chat_client,
    get_principal,
    get_repository,
    get_retrieval_service,
)
from docx_app.domain.chat import (
    ChatMessage,
    ChatSession,
    ChatStore,
    ensure_session_id,
    ensure_source_id,
)
from docx_app.domain.notebook import NotebookStore
from docx_app.domain.source import Source, SourceStore
from docx_app.retrieval.service import RetrievalService
from docx_app.tenancy import Principal

router = APIRouter(prefix="/chat", tags=["chat"])
source_chat_router = APIRouter(prefix="/sources", tags=["source-chat"])
log = structlog.get_logger(__name__)


# --- request/response schemas (field names match the frontend contract) -----


class CreateSessionRequest(BaseModel):
    notebook_id: str = Field(..., description="Notebook ID to create session for")
    title: str | None = None
    model_override: str | None = None


class UpdateSessionRequest(BaseModel):
    title: str | None = None
    model_override: str | None = None


class MessageResponse(BaseModel):
    id: str
    type: str  # 'human' | 'ai'
    content: str
    timestamp: str | None = None


class SessionResponse(BaseModel):
    id: str
    title: str
    notebook_id: str | None = None
    created: str
    updated: str
    message_count: int | None = None
    model_override: str | None = None


class SessionWithMessagesResponse(SessionResponse):
    messages: list[MessageResponse] = Field(default_factory=list)


class ExecuteChatRequest(BaseModel):
    session_id: str = Field(..., description="Chat session ID")
    message: str = Field(..., description="User message content")
    context: dict[str, object] = Field(
        default_factory=dict, description="Chat context with sources and notes"
    )
    model_override: str | None = None


class ExecuteChatResponse(BaseModel):
    session_id: str
    messages: list[MessageResponse]


class BuildContextRequest(BaseModel):
    notebook_id: str
    context_config: dict[str, object] = Field(default_factory=dict)


class BuildContextResponse(BaseModel):
    context: dict[str, object]
    token_count: int
    char_count: int


class SuccessResponse(BaseModel):
    success: bool = True
    message: str


# source chat schemas


class CreateSourceSessionRequest(BaseModel):
    source_id: str = Field(..., description="Source ID to create chat session for")
    title: str | None = None
    model_override: str | None = None


class SourceSessionResponse(BaseModel):
    id: str
    title: str
    source_id: str
    model_override: str | None = None
    created: str
    updated: str
    message_count: int | None = None


class ContextIndicator(BaseModel):
    sources: list[str] = Field(default_factory=list)
    insights: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)


class SourceSessionWithMessagesResponse(SourceSessionResponse):
    messages: list[MessageResponse] = Field(default_factory=list)
    context_indicators: ContextIndicator | None = None


class SendSourceMessageRequest(BaseModel):
    message: str = Field(..., description="User message content")
    model_override: str | None = None


# --- mappers -----------------------------------------------------------------


def _to_message_response(m: ChatMessage) -> MessageResponse:
    return MessageResponse(
        id=m.id or "",
        type=m.type,
        content=m.content,
        timestamp=m.created,
    )


def _session_response(session: ChatSession, *, message_count: int) -> SessionResponse:
    return SessionResponse(
        id=session.id or "",
        title=session.title or "Untitled Session",
        notebook_id=session.notebook,
        created=str(session.created),
        updated=str(session.updated),
        message_count=message_count,
        model_override=session.model_override,
    )


def _source_session_response(
    session: ChatSession, source_id: str, *, message_count: int
) -> SourceSessionResponse:
    return SourceSessionResponse(
        id=session.id or "",
        title=session.title or "Untitled Session",
        source_id=source_id,
        model_override=session.model_override,
        created=str(session.created),
        updated=str(session.updated),
        message_count=message_count,
    )


# --- prompt assembly ---------------------------------------------------------

_NOTEBOOK_SYSTEM = (
    "You are Docx, the company's document-intelligence assistant, chatting with a user "
    "about their notebook. Use the provided context (sources and notes the user attached, "
    "plus any retrieved passages) to answer. Cite retrieved passages inline as [n] when you "
    "use them. If the context does not contain the answer, say so — never invent facts."
)

_SOURCE_SYSTEM = (
    "You are Docx, the company's document-intelligence assistant, chatting with a user "
    "about a single document. Answer using ONLY the document content provided below. If the "
    "document does not contain the answer, say so — never invent facts."
)


def _render_history(messages: list[ChatMessage]) -> str:
    """Flatten prior turns into a transcript. ChatClient.complete takes system+user only
    (no message array), so history is folded into the user turn — the available seam."""
    lines: list[str] = []
    for m in messages:
        speaker = "User" if m.type == "human" else "Assistant"
        lines.append(f"{speaker}: {m.content}")
    return "\n".join(lines)


def _context_to_text(context: dict[str, object]) -> str:
    """Serialise the client-supplied context dict (sources + notes arrays) into prompt text.

    Matches the frontend contract: context = {sources: [...], notes: [...]}. Each item is an
    opaque dict (built by /chat/context or the client); we render its string form so the model
    sees the attached material regardless of the exact per-item shape.
    """
    parts: list[str] = []
    for key in ("sources", "notes"):
        items = context.get(key)
        if isinstance(items, list) and items:
            parts.append(f"## {key.capitalize()}")
            for item in items:
                parts.append(str(item))
    return "\n\n".join(parts)


# === notebook chat: sessions =================================================


@router.get("/sessions", response_model=list[SessionResponse])
async def list_sessions(
    notebook_id: str = Query(..., description="Notebook ID"),
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> list[SessionResponse]:
    # Verify the notebook is the caller's (notebooks are owner-private).
    if not await NotebookStore(repo).get(notebook_id, principal):
        raise HTTPException(404, "notebook not found")
    store = ChatStore(repo)
    sessions = await store.list_sessions_for_notebook(notebook_id, principal)
    out: list[SessionResponse] = []
    for session in sessions:
        msgs = await store.list_messages(session.id or "", principal)
        out.append(_session_response(session, message_count=len(msgs)))
    return out


@router.post("/sessions", response_model=SessionResponse)
async def create_session(
    body: CreateSessionRequest,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> SessionResponse:
    if not await NotebookStore(repo).get(body.notebook_id, principal):
        raise HTTPException(404, "notebook not found")
    session = await ChatStore(repo).create_session(
        owner=principal.owner,
        title=body.title,
        model_override=body.model_override,
        notebook=body.notebook_id,
    )
    return _session_response(session, message_count=0)


@router.get("/sessions/{session_id}", response_model=SessionWithMessagesResponse)
async def get_session(
    session_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> SessionWithMessagesResponse:
    store = ChatStore(repo)
    full_id = ensure_session_id(session_id)
    session = await store.get_session(full_id, principal)
    if not session:
        raise HTTPException(404, "session not found")
    messages = await store.list_messages(full_id, principal)
    base = _session_response(session, message_count=len(messages))
    return SessionWithMessagesResponse(
        **base.model_dump(),
        messages=[_to_message_response(m) for m in messages],
    )


@router.put("/sessions/{session_id}", response_model=SessionResponse)
async def update_session(
    session_id: str,
    body: UpdateSessionRequest,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> SessionResponse:
    store = ChatStore(repo)
    full_id = ensure_session_id(session_id)
    fields = body.model_dump(exclude_unset=True)
    session = await store.update_session(
        full_id,
        principal,
        title=body.title,
        model_override=body.model_override,
        set_title="title" in fields,
        set_model_override="model_override" in fields,
    )
    if not session:
        raise HTTPException(404, "session not found")
    messages = await store.list_messages(full_id, principal)
    return _session_response(session, message_count=len(messages))


@router.delete("/sessions/{session_id}", response_model=SuccessResponse)
async def delete_session(
    session_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> SuccessResponse:
    store = ChatStore(repo)
    full_id = ensure_session_id(session_id)
    if not await store.get_session(full_id, principal):
        raise HTTPException(404, "session not found")
    await store.delete_session(full_id, principal)
    return SuccessResponse(message="Session deleted successfully")


# === notebook chat: execute + context =======================================


@router.post("/execute", response_model=ExecuteChatResponse)
async def execute_chat(
    body: ExecuteChatRequest,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
    retrieval: RetrievalService = Depends(get_retrieval_service),
    chat: ChatClient = Depends(get_chat_client),
) -> ExecuteChatResponse:
    if not body.message.strip():
        raise HTTPException(400, "message content is required")
    store = ChatStore(repo)
    full_id = ensure_session_id(body.session_id)
    session = await store.get_session(full_id, principal)
    if not session:
        raise HTTPException(404, "session not found")

    history = await store.list_messages(full_id, principal)
    next_order = len(history)

    # Persist the user's message first (so it survives even if synthesis fails).
    user_msg = await store.append_message(
        session_id=full_id,
        owner=principal.owner,
        type="human",
        content=body.message,
        order=next_order,
    )

    # Grounding: the client-supplied attached context PLUS RAG over the notebook's own
    # sources (scoped to the notebook → owner-private workspace).
    attached = _context_to_text(body.context)
    retrieved_block = ""
    if session.notebook:
        chunks = await retrieval.search(
            body.message, principal, notebook=session.notebook, limit=10
        )
        if chunks:
            retrieved_block = "\n\n".join(
                f"[{n}] {c.content or ''}" for n, c in enumerate(chunks, start=1)
            )

    context_sections = [s for s in (attached, retrieved_block) if s]
    context_text = "\n\n".join(context_sections) if context_sections else "(none)"
    history_text = _render_history(history)
    user_turn = (
        (f"Conversation so far:\n{history_text}\n\n" if history_text else "")
        + f"Context:\n{context_text}\n\n"
        + f"User: {body.message}"
    )

    answer = await chat.complete(system=_NOTEBOOK_SYSTEM, user=user_turn)
    ai_msg = await store.append_message(
        session_id=full_id,
        owner=principal.owner,
        type="ai",
        content=answer,
        order=next_order + 1,
    )
    await store.touch_session(full_id, principal)

    messages = history + [user_msg, ai_msg]
    return ExecuteChatResponse(
        session_id=body.session_id,
        messages=[_to_message_response(m) for m in messages],
    )


@router.post("/context", response_model=BuildContextResponse)
async def build_context(
    body: BuildContextRequest,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> BuildContextResponse:
    """Build chat context for a notebook from its (owner-scoped) sources.

    Mirrors ON's /chat/context shape {context:{sources,notes}, token_count, char_count}.
    `context_config` selects which sources to include and how much of each ("insights" →
    title only; "full content" → full text); absent config → all sources, titles only.
    Notes are not a Docx resource yet, so `notes` is always [] (noted in simplifications).
    """
    if not await NotebookStore(repo).get(body.notebook_id, principal):
        raise HTTPException(404, "notebook not found")

    sources = await SourceStore(repo).list(
        principal, notebook=body.notebook_id, limit=200
    )
    cfg = body.context_config or {}
    source_cfg = cfg.get("sources") if isinstance(cfg.get("sources"), dict) else None

    built_sources: list[dict[str, object]] = []
    total = ""
    for src in sources:
        status = None
        if isinstance(source_cfg, dict) and src.id is not None:
            status = source_cfg.get(src.id)
        if status is not None and "not in" in str(status):
            continue
        include_full = status is None or "full content" in str(status)
        body_text = (src.full_text or "") if include_full else ""
        item: dict[str, object] = {
            "id": src.id,
            "title": src.title,
            "content": body_text,
        }
        built_sources.append(item)
        total += f"{src.title or ''}\n{body_text}\n"

    char_count = len(total)
    return BuildContextResponse(
        context={"sources": built_sources, "notes": []},
        token_count=char_count // 4,  # cheap estimate (no tokenizer dep in Docx)
        char_count=char_count,
    )


# === source chat =============================================================


async def _require_source(
    repo: SurrealRepository, source_id: str, principal: Principal
) -> Source:
    src = await SourceStore(repo).get(ensure_source_id(source_id), principal)
    if not src:
        raise HTTPException(404, "source not found")
    return src


async def _require_source_session(
    store: ChatStore, session_id: str, source_full_id: str, principal: Principal
) -> ChatSession:
    session = await store.get_session(ensure_session_id(session_id), principal)
    if not session or session.source != source_full_id:
        raise HTTPException(404, "session not found for this source")
    return session


@source_chat_router.post(
    "/{source_id}/chat/sessions", response_model=SourceSessionResponse
)
async def create_source_session(
    source_id: str,
    body: CreateSourceSessionRequest,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> SourceSessionResponse:
    src = await _require_source(repo, source_id, principal)
    session = await ChatStore(repo).create_session(
        owner=principal.owner,
        title=body.title,
        model_override=body.model_override,
        source=src.id,
    )
    return _source_session_response(session, source_id, message_count=0)


@source_chat_router.get(
    "/{source_id}/chat/sessions", response_model=list[SourceSessionResponse]
)
async def list_source_sessions(
    source_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> list[SourceSessionResponse]:
    src = await _require_source(repo, source_id, principal)
    store = ChatStore(repo)
    sessions = await store.list_sessions_for_source(src.id or "", principal)
    out: list[SourceSessionResponse] = []
    for session in sessions:
        msgs = await store.list_messages(session.id or "", principal)
        out.append(
            _source_session_response(session, source_id, message_count=len(msgs))
        )
    return out


@source_chat_router.get(
    "/{source_id}/chat/sessions/{session_id}",
    response_model=SourceSessionWithMessagesResponse,
)
async def get_source_session(
    source_id: str,
    session_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> SourceSessionWithMessagesResponse:
    src = await _require_source(repo, source_id, principal)
    store = ChatStore(repo)
    session = await _require_source_session(store, session_id, src.id or "", principal)
    messages = await store.list_messages(session.id or "", principal)
    base = _source_session_response(session, source_id, message_count=len(messages))
    indicators = ContextIndicator(sources=[src.id] if src.id else [])
    return SourceSessionWithMessagesResponse(
        **base.model_dump(),
        messages=[_to_message_response(m) for m in messages],
        context_indicators=indicators,
    )


@source_chat_router.put(
    "/{source_id}/chat/sessions/{session_id}", response_model=SourceSessionResponse
)
async def update_source_session(
    source_id: str,
    session_id: str,
    body: UpdateSessionRequest,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> SourceSessionResponse:
    src = await _require_source(repo, source_id, principal)
    store = ChatStore(repo)
    await _require_source_session(store, session_id, src.id or "", principal)
    fields = body.model_dump(exclude_unset=True)
    session = await store.update_session(
        ensure_session_id(session_id),
        principal,
        title=body.title,
        model_override=body.model_override,
        set_title="title" in fields,
        set_model_override="model_override" in fields,
    )
    assert session is not None  # guaranteed by _require_source_session above
    messages = await store.list_messages(session.id or "", principal)
    return _source_session_response(session, source_id, message_count=len(messages))


@source_chat_router.delete(
    "/{source_id}/chat/sessions/{session_id}", response_model=SuccessResponse
)
async def delete_source_session(
    source_id: str,
    session_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> SuccessResponse:
    src = await _require_source(repo, source_id, principal)
    store = ChatStore(repo)
    await _require_source_session(store, session_id, src.id or "", principal)
    await store.delete_session(ensure_session_id(session_id), principal)
    return SuccessResponse(message="Source chat session deleted successfully")


@source_chat_router.post(
    "/{source_id}/chat/sessions/{session_id}/messages",
    response_model=SourceSessionWithMessagesResponse,
)
async def send_source_message(
    source_id: str,
    session_id: str,
    body: SendSourceMessageRequest,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
    chat: ChatClient = Depends(get_chat_client),
) -> SourceSessionWithMessagesResponse:
    """Send a message to a source chat session (non-streaming).

    ON streams this over SSE; we return the updated session with messages in one JSON
    response (same data, no streaming — noted in simplifications). Grounding is the source's
    own extracted text (ON's source chat focuses on the single source's content + insights).
    """
    if not body.message.strip():
        raise HTTPException(400, "message content is required")
    src = await _require_source(repo, source_id, principal)
    store = ChatStore(repo)
    session = await _require_source_session(store, session_id, src.id or "", principal)
    full_id = session.id or ""

    history = await store.list_messages(full_id, principal)
    next_order = len(history)
    user_msg = await store.append_message(
        session_id=full_id,
        owner=principal.owner,
        type="human",
        content=body.message,
        order=next_order,
    )

    document = (src.full_text or "").strip() or "(this document has no extracted text)"
    history_text = _render_history(history)
    user_turn = (
        (f"Conversation so far:\n{history_text}\n\n" if history_text else "")
        + f"Document: {src.title or src.id}\n\n{document}\n\n"
        + f"User: {body.message}"
    )
    answer = await chat.complete(system=_SOURCE_SYSTEM, user=user_turn)
    ai_msg = await store.append_message(
        session_id=full_id,
        owner=principal.owner,
        type="ai",
        content=answer,
        order=next_order + 1,
    )
    await store.touch_session(full_id, principal)

    messages = history + [user_msg, ai_msg]
    base = _source_session_response(session, source_id, message_count=len(messages))
    return SourceSessionWithMessagesResponse(
        **base.model_dump(),
        messages=[_to_message_response(m) for m in messages],
        context_indicators=ContextIndicator(sources=[src.id] if src.id else []),
    )
