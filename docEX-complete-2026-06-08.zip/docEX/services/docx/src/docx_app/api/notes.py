"""Notes API — a user's annotations, aligned to Open Notebook's frontend contract.

Endpoints mirror ON's lib/api/notes.ts (paths + request params + response shapes):
    GET    /notes              ?notebook_id        → NoteResponse[]
    POST   /notes              {title?, content, note_type?, notebook_id?}
    GET    /notes/{id}
    PUT    /notes/{id}         {title?, content?, note_type?}
    DELETE /notes/{id}

Notes are owner-PRIVATE; every read/write is tenancy-scoped via NoteStore (focus=True).
A note may be linked to a single workspace (`notebook_id`), which must exist and belong to
the caller. Open Notebook embeds note content asynchronously (`embed_note` command); Docx
embeds inline, best-effort (an embedding failure never fails the write — fail-open, like
sources). ON also auto-generates a title for AI notes via a LangGraph prompt; Docx has no
LangGraph, so the title is taken as given — see `simplifications`.
"""

from __future__ import annotations

import structlog
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from docx_app.config import DocxConfig
from docx_app.db import SurrealRepository
from docx_app.deps import get_config, get_embedder, get_principal, get_repository
from docx_app.domain.note import Note, NoteStore, validate_note_type
from docx_app.domain.notebook import NotebookStore
from docx_app.indexing.embedding import Embedder
from docx_app.tenancy import Principal

router = APIRouter(prefix="/notes", tags=["notes"])
log = structlog.get_logger(__name__)


class NoteCreate(BaseModel):
    title: str | None = None
    content: str
    note_type: str | None = "human"
    notebook_id: str | None = None


class NoteUpdate(BaseModel):
    title: str | None = None
    content: str | None = None
    note_type: str | None = None


class NoteResponse(BaseModel):
    id: str
    title: str | None = None
    content: str | None = None
    note_type: str | None = None
    created: str
    updated: str


def _to_response(note: Note) -> NoteResponse:
    """Shape a Note into ON's NoteResponse. `owner`/`scope`/`notebook` are never exposed."""
    return NoteResponse(
        id=note.id or "",
        title=note.title,
        content=note.content,
        note_type=note.note_type,
        created=note.created or "",
        updated=note.updated or "",
    )


async def _safe_embed(
    store: NoteStore, note: Note, embedder: Embedder, config: DocxConfig
) -> None:
    """Best-effort note embedding: the note is already saved, so an embedding failure must
    not fail the request — it is logged and recoverable on the next update (fail-open,
    FINAL_DESIGN §11)."""
    try:
        await store.embed(
            note, embedder, chunk_size=config.chunk_size, overlap=config.chunk_overlap
        )
    except Exception:  # noqa: BLE001 - resilience boundary; logged, not silently swallowed
        log.warning("note_embedding_failed", note_id=note.id, exc_info=True)


@router.get("", response_model=list[NoteResponse])
async def list_notes(
    notebook_id: str | None = Query(None, description="Filter by notebook ID"),
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> list[NoteResponse]:
    store = NoteStore(repo)
    # If a workspace is named it must exist and be the caller's (notebooks are owner-private).
    if notebook_id and not await NotebookStore(repo).get(notebook_id, principal):
        raise HTTPException(404, "notebook not found")
    notes = await store.list(principal, notebook=notebook_id)
    return [_to_response(n) for n in notes]


@router.post("", response_model=NoteResponse)
async def create_note(
    body: NoteCreate,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
    embedder: Embedder = Depends(get_embedder),
    config: DocxConfig = Depends(get_config),
) -> NoteResponse:
    if not body.content or not body.content.strip():
        raise HTTPException(400, "content is required")
    try:
        note_type = validate_note_type(body.note_type)
    except ValueError as e:
        raise HTTPException(400, str(e))
    # A linked workspace must exist and belong to the caller (mirrors ON: 404 if missing).
    if body.notebook_id and not await NotebookStore(repo).get(
        body.notebook_id, principal
    ):
        raise HTTPException(404, "notebook not found")

    store = NoteStore(repo)
    note = await store.create(
        owner=principal.owner,
        title=body.title,
        content=body.content,
        note_type=note_type,
        notebook=body.notebook_id,
    )
    await _safe_embed(store, note, embedder, config)
    return _to_response(note)


@router.get("/{note_id}", response_model=NoteResponse)
async def get_note(
    note_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> NoteResponse:
    note = await NoteStore(repo).get(note_id, principal)
    if not note:
        raise HTTPException(404, "note not found")
    return _to_response(note)


@router.put("/{note_id}", response_model=NoteResponse)
async def update_note(
    note_id: str,
    body: NoteUpdate,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
    embedder: Embedder = Depends(get_embedder),
    config: DocxConfig = Depends(get_config),
) -> NoteResponse:
    try:
        note_type = validate_note_type(body.note_type)
    except ValueError as e:
        raise HTTPException(400, str(e))
    store = NoteStore(repo)
    note = await store.update(
        note_id,
        principal,
        title=body.title,
        content=body.content,
        note_type=note_type,
    )
    if not note:
        raise HTTPException(404, "note not found")
    # Content may have changed → re-embed (best-effort; replace is idempotent).
    if body.content is not None:
        await _safe_embed(store, note, embedder, config)
    return _to_response(note)


@router.delete("/{note_id}")
async def delete_note(
    note_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> dict[str, str]:
    if not await NoteStore(repo).delete(note_id, principal):
        raise HTTPException(404, "note not found")
    return {"message": "Note deleted successfully"}
