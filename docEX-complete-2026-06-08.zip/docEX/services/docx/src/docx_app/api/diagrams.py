"""Source-diagram API — the Surface-1 "Diagram" tab on a source.

Design: ``docs/2026-06-06-diagram-platform-design.md`` (the canonical
``DiagramGraph`` platform design) — this is the **only** surface in scope. The
endpoints back the source-detail Diagram tab:

    POST /sources/{id}/diagram/chat    → run the 2-step pipeline over the source's
                                         full_text → draft DiagramGraph (or refine /
                                         re-version an existing one).
    GET  /sources/{id}/diagram         → load the source's current diagram (latest).
    PUT  /sources/{id}/diagram         → save a hand-edited DiagramGraph onto the
                                         draft (a refine; bumps version).
    POST /sources/{id}/diagram/accept  → freeze the picture: stamp accepted, freeze
                                         graph_json, and store a server-rendered
                                         static SVG snapshot (render_snapshot_svg).

These are nested under ``/sources`` (so the router uses ``prefix="/sources"``,
exactly like ``source_chat_router`` in ``api/chat.py``) — a diagram always belongs
to a source. The static ``/chat`` and ``/accept`` sub-paths are declared before
the bare ``GET/PUT /{source_id}/diagram`` so FastAPI matches them literally
(the same precedence rule the transformations router follows for ``/execute``).

Tenancy: a source must be the caller's to diagram (``SourceStore.get`` is
owner-scoped), and the diagram itself is owner-PRIVATE (``DiagramStore`` stamps
``Scope.PRIVATE`` and reads with ``focus=True``). One source has one *current*
diagram (the latest by ``updated``); refining overwrites the draft, accepting
freezes it, and a fresh chat after acceptance starts a new version (per design
§"One accepted diagram per source").

Immutability (design §2 — DATA + PICTURE): on accept we freeze ``graph_json`` AND
snapshot the rendered SVG (server-side, via ``diagram/render_svg.py``), so the
accepted view shows a guaranteed-stable image with no browser/elkjs/draw.io
dependency.

LLM path: the pipeline is provider-agnostic — it runs over the injected
``ChatClient`` (prod Azure OpenAI) or ``ClaudeCliChatClient`` (local test). The
local path returns fenced JSON with prose; the agent's defensive parser handles
that and retries with validation feedback, so a parse wobble surfaces as a clean
``DiagramPipelineError`` (mapped to HTTP 502), never a raw stack trace.
"""

from __future__ import annotations

from typing import Any

import structlog
from fastapi import APIRouter, Depends, HTTPException, Query, Response
from pydantic import BaseModel

from docx_app.ai.chat import ChatClient
from docx_app.db import SurrealRepository
from docx_app.deps import get_chat_client, get_principal, get_repository
from docx_app.diagram.agent import DiagramPipelineError, run_diagram_pipeline
from docx_app.diagram.domain import Diagram, DiagramStore
from docx_app.diagram.export_drawio import export_drawio
from docx_app.diagram.model import DiagramGraph
from docx_app.diagram.render_svg import render_snapshot_svg
from docx_app.diagram.to_mermaid import to_mermaid
from docx_app.domain.source import Source, SourceStore
from docx_app.tenancy import Principal

router = APIRouter(prefix="/sources", tags=["diagrams"])
log = structlog.get_logger(__name__)

# Surface-1 is always a "source" diagram (design: one table, distinguished by
# ``surface`` + ``ref``). The notebook/repograph surfaces are later phases.
_SURFACE_SOURCE = "source"

# Emit-only exports of the canonical ``DiagramGraph`` (design §4) — the optional
# "open elsewhere" formats over the *same* accepted/draft graph. Each entry maps a
# ``?format=`` value to: the pure-string exporter, the response ``media_type``, and
# the suggested download file extension. There is **no** runtime draw.io / Mermaid
# dependency on any path — both exporters emit plain text the user renders in their
# own tool (draw.io XML / a Mermaid renderer). draw.io is mxGraph XML
# (``application/xml``); Mermaid is diff-friendly source text (``text/plain``).
_EXPORTERS: dict[str, tuple[Any, str, str]] = {
    "drawio": (export_drawio, "application/xml", "drawio"),
    "mermaid": (to_mermaid, "text/plain; charset=utf-8", "mmd"),
}


# --- Request / response schemas -------------------------------------------- #


class DiagramResponse(BaseModel):
    """A source's diagram. ``graph`` is the canonical :class:`DiagramGraph` as a
    plain JSON object (edges keyed by ``"from"`` — the renderer reads it as-is).

    ``render_snapshot_svg`` is present only once the diagram is ``accepted`` (it is
    the frozen static picture). Field names mirror the diagram row + the frontend
    ``DiagramRenderer`` graph contract (``DiagramRenderer.types.ts``).
    """

    id: str
    source_id: str
    surface: str
    status: str  # 'draft' | 'accepted'
    version: int
    graph: dict[str, Any] | None = None
    render_snapshot_svg: str | None = None
    created: str = ""
    updated: str = ""


class DiagramChatRequest(BaseModel):
    """Generate/refine a source diagram from its document text.

    The pipeline runs over the **source's own** ``full_text`` (the user diagrams
    *this* document). ``instruction`` drives refine-by-prompt: when the source
    already has a diagram, the instruction is applied to it (the graph step edits
    the previous graph) instead of regenerating from scratch; on the very first
    generation (no existing diagram) it is ignored. ``include_azure_shapes``
    toggles the Azure icon catalog injection (default on — design §3).
    """

    instruction: str | None = None
    include_azure_shapes: bool = True


class DiagramSaveRequest(BaseModel):
    """Save a (hand-edited) :class:`DiagramGraph` onto the source's draft.

    ``graph`` is the full canonical graph object; it is validated through
    :class:`DiagramGraph` (honouring the ``from`` edge alias) before persistence,
    so a malformed body is a 422 rather than a corrupt stored row.
    """

    graph: dict[str, Any]


class DiagramAcceptRequest(BaseModel):
    """Accept (freeze) the source's diagram.

    Optionally carries the final ``graph`` to freeze atomically with its snapshot
    (e.g. the user accepts straight after a hand-edit without a separate PUT). When
    omitted, the row's current ``graph_json`` is frozen and snapshotted as-is.
    """

    graph: dict[str, Any] | None = None


# --- Helpers ---------------------------------------------------------------- #


async def _require_source(
    repo: SurrealRepository, source_id: str, principal: Principal
) -> Source:
    """Fetch a source the caller OWNS, or 404 (owner-scoped — mirrors chat.py)."""
    src = await SourceStore(repo).get(source_id, principal, focus=True)
    if not src:
        raise HTTPException(404, "source not found")
    return src


def _validate_graph(graph_dict: dict[str, Any]) -> DiagramGraph:
    """Validate a raw graph dict into a :class:`DiagramGraph` (422 on failure).

    Uses ``model_validate`` (NOT ``**dict``) so an incoming ``"from"`` edge key
    maps to ``DiagramGraphEdge.from_``; a schema violation becomes a clean 422.
    """
    try:
        return DiagramGraph.model_validate(graph_dict)
    except ValueError as exc:  # pydantic.ValidationError is a ValueError subclass
        raise HTTPException(422, f"invalid diagram graph: {exc}")


async def _current_diagram(
    store: DiagramStore, source_full_id: str, principal: Principal
) -> Diagram | None:
    """The source's current (latest-updated) diagram, or None if it has none.

    ``DiagramStore.list`` is owner-scoped and ordered ``updated DESC``, so the
    first row is the one the tab shows. One source has one current diagram (drafts
    overwrite; accepting freezes; a new chat after acceptance adds a new version).
    """
    rows = await store.list(
        principal, surface=_SURFACE_SOURCE, ref=source_full_id, limit=1
    )
    return rows[0] if rows else None


async def _persist_graph(
    store: DiagramStore,
    *,
    owner: str,
    principal: Principal,
    source_full_id: str,
    existing: Diagram | None,
    graph: DiagramGraph,
) -> Diagram:
    """Persist ``graph`` as the source's current diagram, respecting immutability.

    Shared by ``/chat`` and ``PUT /diagram`` (both "make this the current graph"):

    * no diagram yet → create a new draft (version 1);
    * a **draft** → overwrite its graph in place (a refine; version bumps);
    * an **accepted** diagram → start a NEW draft version (the frozen row is never
      mutated — design's immutability rule).

    Raises 404 only on the should-not-happen race where ``existing`` was read as
    the caller's but the follow-up scoped write finds nothing.
    """
    if existing is None:
        return await store.create(
            owner=owner,
            surface=_SURFACE_SOURCE,
            ref=source_full_id,
            graph=graph,
        )
    if existing.status == "accepted":
        revised = await store.new_version(existing.id or "", principal, graph=graph)
    else:
        revised = await store.update_graph(existing.id or "", principal, graph=graph)
    if revised is None:  # pragma: no cover - existing was just read as owned
        raise HTTPException(404, "diagram not found")
    return revised


def _to_response(diagram: Diagram, source_id: str) -> DiagramResponse:
    """Map a stored :class:`Diagram` to the wire response.

    ``graph_json`` is passed through untouched (it is already stored with the
    ``"from"`` edge alias, which is exactly what the frontend renderer expects).
    """
    return DiagramResponse(
        id=diagram.id or "",
        source_id=source_id,
        surface=diagram.surface or _SURFACE_SOURCE,
        status=diagram.status or "draft",
        version=diagram.version or 1,
        graph=diagram.graph_json,
        render_snapshot_svg=diagram.render_snapshot_svg,
        created=diagram.created or "",
        updated=diagram.updated or "",
    )


# --- Static sub-routes (must precede the bare /{source_id}/diagram) --------- #


@router.post("/{source_id}/diagram/chat", response_model=DiagramResponse)
async def diagram_chat(
    source_id: str,
    body: DiagramChatRequest,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
    chat: ChatClient = Depends(get_chat_client),
) -> DiagramResponse:
    """Generate (or refine) the source's diagram from its ``full_text``.

    Runs the 2-step pipeline (``diagram/agent.run_diagram_pipeline``) over the
    source's extracted text and persists the resulting :class:`DiagramGraph`:

    * no diagram yet → create a new draft (version 1);
    * an existing **draft** → overwrite its graph (a refine; version bumps);
    * an **accepted** diagram → start a NEW draft version (the accepted row stays
      frozen — design's immutability rule).

    422 if the source has no extracted text yet; 502 if the LLM pipeline cannot
    produce a valid graph after its retries (``DiagramPipelineError``).
    """
    src = await _require_source(repo, source_id, principal)
    if not src.full_text or not src.full_text.strip():
        raise HTTPException(422, "source has no extracted text yet")

    store = DiagramStore(repo)
    source_full_id = src.id or source_id
    existing = await _current_diagram(store, source_full_id, principal)

    # Refine vs first-generation: when there is an existing diagram AND the user
    # typed an instruction, refine that graph (the pipeline edits <previous_graph>
    # per <refinement_instruction>); otherwise generate fresh from the document.
    base_graph = existing.graph() if existing else None
    instruction = (body.instruction or "").strip() or None
    refine = bool(base_graph and instruction)

    try:
        graph = await run_diagram_pipeline(
            chat,
            source_title=src.title,
            source_text=src.full_text,
            include_azure_shapes=body.include_azure_shapes,
            instruction=instruction if refine else None,
            base_graph=base_graph if refine else None,
        )
    except DiagramPipelineError as exc:
        # The pipeline already retried with validation feedback (incl. the flaky
        # local fenced-JSON path); a failure here is an upstream model problem, so
        # surface 502 (bad gateway) with the last feedback, not a 500 stack trace.
        log.warning(
            "diagram_pipeline_error",
            source_id=src.id,
            error=str(exc),
            validation_feedback=exc.validation_feedback,
        )
        raise HTTPException(502, f"diagram generation failed: {exc}")

    diagram = await _persist_graph(
        store,
        owner=principal.owner,
        principal=principal,
        source_full_id=source_full_id,
        existing=existing,
        graph=graph,
    )
    return _to_response(diagram, source_id)


@router.post("/{source_id}/diagram/accept", response_model=DiagramResponse)
async def accept_diagram(
    source_id: str,
    body: DiagramAcceptRequest,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> DiagramResponse:
    """Freeze the source's diagram — DATA + PICTURE (design §2).

    Stamps ``status="accepted"``, freezes ``graph_json`` (the final graph — the
    request's ``graph`` if supplied, else the stored draft's), and stores a
    **server-rendered static SVG snapshot** (``diagram/render_svg.render_snapshot_svg``)
    as ``render_snapshot_svg`` — the guaranteed-stable image the accepted view
    shows. The snapshot is produced here, on the server, so the frozen picture
    never depends on a browser, ``elkjs``, or any draw.io path.

    404 if the source has no diagram; 422 if neither a request ``graph`` nor a
    stored ``graph_json`` is available to freeze, or if the supplied graph is
    invalid.
    """
    src = await _require_source(repo, source_id, principal)
    store = DiagramStore(repo)
    source_full_id = src.id or source_id
    existing = await _current_diagram(store, source_full_id, principal)
    if existing is None:
        raise HTTPException(404, "diagram not found")

    # Resolve the graph to freeze: the request's (validated) graph wins; otherwise
    # the row's stored graph. There must be one to render a snapshot from.
    if body.graph is not None:
        graph = _validate_graph(body.graph)
    else:
        stored = existing.graph()  # model_validate of graph_json (honours alias)
        if stored is None:
            raise HTTPException(422, "diagram has no graph to accept")
        graph = stored

    # Render the frozen picture server-side (static, self-contained SVG).
    svg = render_snapshot_svg(graph, title=src.title)

    diagram = await store.accept(
        existing.id or "",
        principal,
        render_snapshot_svg=svg,
        graph=graph,
    )
    if diagram is None:  # pragma: no cover - existing was just read as owned
        raise HTTPException(404, "diagram not found")
    log.info(
        "diagram_accepted",
        source_id=src.id,
        diagram_id=diagram.id,
        version=diagram.version,
        svg_bytes=len(svg),
    )
    return _to_response(diagram, source_id)


@router.get(
    "/{source_id}/diagram/export",
    # The body is a raw exported string (draw.io XML / Mermaid text), not the JSON
    # ``DiagramResponse`` — declare no ``response_model`` and return a ``Response``
    # with the format's own media type. FastAPI does not document the body schema
    # here; that is intentional (the payload is plain text by design).
    response_class=Response,
    responses={
        200: {
            "content": {"application/xml": {}, "text/plain": {}},
            "description": "The exported diagram as a draw.io XML or Mermaid string.",
        }
    },
)
async def export_diagram(
    source_id: str,
    format: str = Query(
        "drawio",
        description="Export format — 'drawio' (mxGraph XML) or 'mermaid' (flowchart text).",
    ),
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> Response:
    """Export the source's current diagram as a draw.io / Mermaid *string* (design §4).

    Loads the source's current diagram (latest — draft or accepted) and serialises
    its canonical :class:`DiagramGraph` through the requested emit-only renderer,
    returning the raw string with that format's content type (``application/xml``
    for draw.io, ``text/plain`` for Mermaid). These are the optional "open it in
    your own tool" exports — there is **no** runtime draw.io/Mermaid dependency on
    the server; both exporters are pure string emission over the same graph.

    Owner-scoped: the source must be the caller's (``_require_source`` → 404) and
    the diagram is read owner-private (``_current_diagram``). 404 if the source has
    no diagram yet (or it has no graph to export); 400 on an unknown ``format``.
    """
    spec = _EXPORTERS.get(format)
    if spec is None:
        # 400 (not 422): an unknown ?format is a bad request value, not a body-schema
        # violation. List the supported values so the caller can self-correct.
        supported = ", ".join(sorted(_EXPORTERS))
        raise HTTPException(400, f"unknown export format '{format}' (supported: {supported})")
    exporter, media_type, extension = spec

    src = await _require_source(repo, source_id, principal)
    store = DiagramStore(repo)
    diagram = await _current_diagram(store, src.id or source_id, principal)
    if diagram is None:
        raise HTTPException(404, "diagram not found")
    graph = diagram.graph()  # model_validate of graph_json (honours the "from" alias)
    if graph is None:
        raise HTTPException(404, "diagram has no graph to export")

    body = exporter(graph)
    log.info(
        "diagram_exported",
        source_id=src.id,
        diagram_id=diagram.id,
        format=format,
        bytes=len(body),
    )
    # Suggest a sensible download filename (the diagram id is owner-private, so the
    # source id is the stable, non-leaky handle the user already knows).
    filename = f"diagram-{source_id}.{extension}".replace("/", "_").replace(":", "_")
    return Response(
        content=body,
        media_type=media_type,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


# --- Bare /{source_id}/diagram routes (after the static sub-paths) ---------- #


@router.get("/{source_id}/diagram", response_model=DiagramResponse)
async def get_diagram(
    source_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> DiagramResponse:
    """Load the source's current diagram (draft or accepted). 404 if none yet.

    A 404 here is the tab's "empty" state — the frontend then shows the
    "Diagram this document" call-to-action that POSTs to ``/diagram/chat``.
    """
    src = await _require_source(repo, source_id, principal)
    store = DiagramStore(repo)
    diagram = await _current_diagram(store, src.id or source_id, principal)
    if diagram is None:
        raise HTTPException(404, "diagram not found")
    return _to_response(diagram, source_id)


@router.put("/{source_id}/diagram", response_model=DiagramResponse)
async def save_diagram(
    source_id: str,
    body: DiagramSaveRequest,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> DiagramResponse:
    """Save a hand-edited graph onto the source's diagram.

    Validates the body as a :class:`DiagramGraph` (422 on failure), then:

    * a **draft** is updated in place (version bumps — a refine);
    * an **accepted** diagram is not mutated; the edit opens a NEW draft version
      (design's immutability rule), so the frozen row is preserved;
    * if the source has **no** diagram yet, the saved graph creates the first
      draft (so a manual build path works without first calling ``/chat``).
    """
    src = await _require_source(repo, source_id, principal)
    graph = _validate_graph(body.graph)
    store = DiagramStore(repo)
    source_full_id = src.id or source_id
    existing = await _current_diagram(store, source_full_id, principal)
    diagram = await _persist_graph(
        store,
        owner=principal.owner,
        principal=principal,
        source_full_id=source_full_id,
        existing=existing,
        graph=graph,
    )
    return _to_response(diagram, source_id)
