"""Models API — the per-owner model registry + default-model assignments.

Port of Open Notebook's /models router (api/routers/models.py), tenant-scoped and
restricted to OpenAI + Azure OpenAI. Aligned to the frontend contract (lib/api/models.ts):

  GET    /models                 → Model[]            (optional ?type= filter)
  POST   /models                 → Model              (create, links to a credential)
  GET    /models/defaults        → ModelDefaults
  PUT    /models/defaults        → ModelDefaults      (partial update)
  GET    /models/providers       → ProviderAvailability
  GET    /models/by-provider/{p} → Model[]
  GET    /models/{id}            → Model
  DELETE /models/{id}            → {message}
  POST   /models/{id}/test       → ModelTestResult

Tenancy: models + defaults are PRIVATE to the owner — every read/write goes through the
owner-scoped ModelStore / ModelDefaultsStore. A user only ever sees their own models.

Note ordering: the literal sub-paths (/defaults, /providers, /by-provider/...) are declared
BEFORE the /{model_id} catch-all so FastAPI matches them first.

Simplifications vs ON (see manifest): model discovery / sync / auto-assign (heavy Esperanto
multi-provider features) are omitted — discovery lives on /credentials/{id}/discover, and
this deployment is OpenAI/Azure-only. `/models/{id}/test` validates shape (no live ping).
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from docx_app.db import SurrealRepository
from docx_app.deps import get_principal, get_repository
from docx_app.domain.credential import (
    SUPPORTED_PROVIDERS,
    VALID_MODEL_TYPES,
    Model,
    ModelDefaults,
    ModelDefaultsStore,
    ModelDefaultsUpdate,
    ModelStore,
    is_supported_provider,
    normalize_provider,
)
from docx_app.tenancy import Principal

router = APIRouter(prefix="/models", tags=["models"])


# --- Wire schemas (match ON ModelResponse / DefaultModelsResponse exactly) --


class ModelResponse(BaseModel):
    id: str
    name: str
    provider: str
    type: str
    credential: str | None = None
    created: str
    updated: str


class ModelCreate(BaseModel):
    name: str = Field(
        ..., description="Model name (e.g. gpt-4o, text-embedding-3-small)"
    )
    provider: str = Field(..., description="Provider name (openai or azure)")
    type: str = Field(
        ...,
        description="Model type (language, embedding, text_to_speech, speech_to_text)",
    )
    credential: str | None = Field(
        None, description="Credential ID to link this model to"
    )


class ModelDefaultsResponse(BaseModel):
    default_chat_model: str | None = None
    default_transformation_model: str | None = None
    large_context_model: str | None = None
    default_text_to_speech_model: str | None = None
    default_speech_to_text_model: str | None = None
    default_embedding_model: str | None = None
    default_tools_model: str | None = None


class ProviderAvailabilityResponse(BaseModel):
    available: list[str]
    unavailable: list[str]
    supported_types: dict[str, list[str]]


class ModelTestResponse(BaseModel):
    success: bool
    message: str


def _model_response(model: Model) -> ModelResponse:
    return ModelResponse(
        id=model.id or "",
        name=model.name or "",
        provider=model.provider or "",
        type=model.type or "",
        credential=model.credential,
        created=model.created or "",
        updated=model.updated or "",
    )


def _defaults_response(defaults: ModelDefaults) -> ModelDefaultsResponse:
    return ModelDefaultsResponse(**defaults.model_dump())


# --- Defaults (declared before /{model_id}) --------------------------------


@router.get("/defaults", response_model=ModelDefaultsResponse)
async def get_default_models(
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> ModelDefaultsResponse:
    defaults = await ModelDefaultsStore(repo).get(principal)
    return _defaults_response(defaults)


@router.put("/defaults", response_model=ModelDefaultsResponse)
async def update_default_models(
    body: ModelDefaultsUpdate,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> ModelDefaultsResponse:
    defaults = await ModelDefaultsStore(repo).upsert(principal, body)
    return _defaults_response(defaults)


# --- Provider availability (OpenAI + Azure only) ---------------------------


@router.get("/providers", response_model=ProviderAvailabilityResponse)
async def get_provider_availability() -> ProviderAvailabilityResponse:
    """Static availability: this deployment supports OpenAI + Azure OpenAI for all modalities.

    ON probes env vars / credentials per provider; Docx locks the provider set, so the
    answer is constant (and owner-independent — no tenancy read needed).
    """
    return ProviderAvailabilityResponse(
        available=list(SUPPORTED_PROVIDERS),
        unavailable=[],
        supported_types={p: list(VALID_MODEL_TYPES) for p in SUPPORTED_PROVIDERS},
    )


# --- By-provider (declared before /{model_id}) -----------------------------


@router.get("/by-provider/{provider}", response_model=list[ModelResponse])
async def get_models_by_provider(
    provider: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> list[ModelResponse]:
    models = await ModelStore(repo).list(principal, provider=provider)
    return [_model_response(m) for m in models]


# --- List / create ---------------------------------------------------------


@router.get("", response_model=list[ModelResponse])
async def list_models(
    type: str | None = Query(None, description="Filter by model type"),
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> list[ModelResponse]:
    models = await ModelStore(repo).list(principal, type=type)
    return [_model_response(m) for m in models]


@router.post("", response_model=ModelResponse)
async def create_model(
    body: ModelCreate,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> ModelResponse:
    if body.type not in VALID_MODEL_TYPES:
        raise HTTPException(
            400, f"invalid model type. Must be one of: {list(VALID_MODEL_TYPES)}"
        )
    if not is_supported_provider(body.provider):
        raise HTTPException(
            400,
            f"unsupported provider '{body.provider}' "
            f"(supported: {list(SUPPORTED_PROVIDERS)})",
        )
    store = ModelStore(repo)
    # Owner-scoped duplicate check (ON rejects same provider+name+type, case-insensitive).
    if await store.find_duplicate(
        principal, name=body.name, provider=body.provider, type=body.type
    ):
        raise HTTPException(
            400,
            f"model '{body.name}' already exists for provider "
            f"'{normalize_provider(body.provider)}' with type '{body.type}'",
        )
    model = await store.create(
        owner=principal.owner,
        name=body.name,
        provider=body.provider,
        type=body.type,
        credential=body.credential,
    )
    return _model_response(model)


# --- Get / delete / test (catch-all /{model_id}) ---------------------------


@router.get("/{model_id}", response_model=ModelResponse)
async def get_model(
    model_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> ModelResponse:
    model = await ModelStore(repo).get(model_id, principal)
    if not model:
        raise HTTPException(404, "model not found")
    return _model_response(model)


@router.delete("/{model_id}")
async def delete_model(
    model_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> dict[str, str]:
    if not await ModelStore(repo).delete(model_id, principal):
        raise HTTPException(404, "model not found")
    return {"message": "Model deleted successfully"}


@router.post("/{model_id}/test", response_model=ModelTestResponse)
async def test_model(
    model_id: str,
    principal: Principal = Depends(get_principal),
    repo: SurrealRepository = Depends(get_repository),
) -> ModelTestResponse:
    """Validate that a model the caller owns is configured (shape check, no live API call).

    A model is considered configured if it has a supported provider + valid type. If it
    links a credential, that credential must exist (and be the caller's) and carry an
    api_key. Live provider pings are out of scope here (see /credentials/{id}/test).
    """
    store = ModelStore(repo)
    model = await store.get(model_id, principal)
    if not model:
        raise HTTPException(404, "model not found")

    if model.provider is None or not is_supported_provider(model.provider):
        return ModelTestResponse(
            success=False, message=f"Unsupported provider: {model.provider}"
        )
    if model.type not in VALID_MODEL_TYPES:
        return ModelTestResponse(
            success=False, message=f"Invalid model type: {model.type}"
        )
    if model.credential:
        cred = await store.get_credential(model, principal)
        if cred is None:
            return ModelTestResponse(
                success=False, message="Linked credential not found"
            )
        if cred.api_key is None:
            return ModelTestResponse(
                success=False, message="Linked credential has no API key"
            )
    return ModelTestResponse(success=True, message="Model configuration valid")
