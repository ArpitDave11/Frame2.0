"""Ask API — POST /ask: question → scoped retrieval → grounded, cited answer."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from docx_app.ask.models import AskRequest, AskResult
from docx_app.ask.service import AskService
from docx_app.deps import get_ask_service, get_principal
from docx_app.tenancy import Principal

router = APIRouter(prefix="/ask", tags=["ask"])


@router.post("", response_model=AskResult)
async def ask(
    req: AskRequest,
    principal: Principal = Depends(get_principal),
    service: AskService = Depends(get_ask_service),
) -> AskResult:
    if not req.question.strip():
        raise HTTPException(400, "question is required")
    return await service.ask(req.question, principal, focus=req.focus, limit=req.limit)
