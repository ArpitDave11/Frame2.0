"""Corporate-CA outbound HTTP client (inbuilt hygiene standard — FINAL_DESIGN §11/A).

ALL outbound HTTPS from this service (DocMining/Docling, Azure OpenAI, etc.) MUST
go through `make_client()` so the corporate CA bundle is honoured. Do not use raw
httpx/requests for external calls.
"""

from __future__ import annotations

import httpx

from docx_app.config import DocxConfig


def _verify(config: DocxConfig) -> bool | str:
    """Return the httpx `verify` value: the corporate CA bundle path if set, else system trust."""
    return config.corporate_ca_path or True


def make_client(config: DocxConfig, timeout: float = 30.0) -> httpx.AsyncClient:
    """Create an async HTTP client with corporate-CA TLS verification configured."""
    return httpx.AsyncClient(verify=_verify(config), timeout=timeout)
