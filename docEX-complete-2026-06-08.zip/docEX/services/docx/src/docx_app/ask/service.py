"""AskService — single-pass RAG: scoped retrieve → grounded synthesis with citations.

Open Notebook's ask graph is agentic (an LLM plans up to 5 searches, then fuses the
sub-answers). v1 does one scoped retrieval pass; the agentic multi-search strategy is a
later enhancement for complex questions.
"""

from __future__ import annotations

from docx_app.ai.chat import ChatClient
from docx_app.ask.models import AskResult, Citation
from docx_app.retrieval.service import RetrievalService
from docx_app.tenancy import Principal

_SYSTEM = (
    "You are Docx, the company's document-intelligence assistant. Answer the question "
    "using ONLY the provided context from the company knowledge base. Cite the context "
    "passages you use inline as [n]. If the context does not contain the answer, say you "
    "don't have enough information — never invent facts."
)

_NO_RESULTS = (
    "I couldn't find anything relevant in the knowledge base for that question."
)


class AskService:
    def __init__(self, retrieval: RetrievalService, chat: ChatClient):
        self._retrieval = retrieval
        self._chat = chat

    async def ask(
        self,
        question: str,
        principal: Principal,
        *,
        focus: bool = False,
        limit: int = 10,
        notebook: str | None = None,
    ) -> AskResult:
        chunks = await self._retrieval.search(
            question, principal, focus=focus, limit=limit, notebook=notebook
        )
        if not chunks:
            return AskResult(answer=_NO_RESULTS, citations=[], used_chunks=0)

        # Number context and citations from ONE structure so [n] can't drift from
        # citations[n-1] if chunks are ever reordered (e.g. a future reranker).
        numbered = list(enumerate(chunks, start=1))
        context = "\n\n".join(f"[{n}] {c.content or ''}" for n, c in numbered)
        answer = await self._chat.complete(
            system=_SYSTEM, user=f"Question: {question}\n\nContext:\n{context}"
        )
        citations = [
            Citation(source=c.source, chunk=c.id, score=c.score) for _, c in numbered
        ]
        return AskResult(answer=answer, citations=citations, used_chunks=len(chunks))
