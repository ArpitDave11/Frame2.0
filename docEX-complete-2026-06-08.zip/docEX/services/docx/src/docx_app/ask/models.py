"""Ask request/response types."""

from __future__ import annotations

from pydantic import BaseModel, Field


class AskRequest(BaseModel):
    question: str
    focus: bool = False  # False = common brain (∪ own); True = only the user's own docs
    notebook: str | None = None  # narrow to a specific workspace (the user's own)
    limit: int = Field(
        default=10, ge=1, le=50
    )  # bounded: avoid a huge fuse on one request


class Citation(BaseModel):
    source: str | None = None
    chunk: str | None = None
    score: float = 0.0


class AskResult(BaseModel):
    answer: str
    citations: list[Citation] = Field(default_factory=list)
    used_chunks: int = 0
