"""Ask: retrieve scoped context + synthesize a grounded, cited answer."""
