"""Multi-tenancy + the collective-brain scoping model (LOCKED — FINAL_DESIGN §2, §5).

Rules locked with the user:
- ONE shared SurrealDB; every record carries `owner` (the user) + `scope`.
- `owner` is derived from the Entra/MSAL identity in the gateway-minted JWT (`sub`/`oid`).
- COLLECTIVE COMPANY BRAIN (HR-cleared):
    * default WRITE scope  = ORG_COMMON   (uploads enrich the shared org KB)
    * default READ  scope  = ORG_COMMON   (asking searches the shared org KB)
    * PRIVATE / FOCUS = the opt-in exception → narrow to the user's own / selected docs
- Every Docx data query MUST be owner/scope-filtered. The service connects to
  SurrealDB as a SINGLE principal (auth terminates at the gateway), so isolation is
  enforced in the APPLICATION layer via mandatory scoped queries — we do NOT rely on
  SurrealDB record permissions (they key on a per-user DB session we don't have). A
  query with no scope filter is a bug; tests/test_tenancy_isolation.py guards against it.
"""

from __future__ import annotations

from enum import Enum
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel

if TYPE_CHECKING:
    from docx_app.config import DocxConfig


class Scope(str, Enum):
    ORG_COMMON = "org-common"  # part of the shared company brain (default)
    PRIVATE = "private"  # only the owner can read it


class Principal(BaseModel):
    """The authenticated user, derived from the JWT claims."""

    owner: str  # stable user id (Entra oid/sub)
    email: str | None = None
    name: str | None = None


def principal_from_claims(claims: dict[str, Any]) -> Principal:
    """Build a Principal from decoded JWT claims (gateway passes oid/sub + profile)."""
    owner = claims.get("oid") or claims.get("sub")
    if not owner:
        raise ValueError("JWT has no 'oid'/'sub' claim — cannot determine owner")
    return Principal(owner=owner, email=claims.get("email"), name=claims.get("name"))


# --- Locked defaults -------------------------------------------------------


def default_write_scope(config: DocxConfig | None = None) -> Scope:
    """The default WRITE scope (LOCKED: uploads enrich the common brain).

    Single source of truth: `DocxConfig.default_scope` (validated at load). With no
    config (e.g. unit tests) it falls back to the locked ORG_COMMON default.
    """
    if config is not None:
        return Scope(config.default_scope)
    return Scope.ORG_COMMON


def read_scopes(focus: bool) -> list[Scope]:
    """Which scopes a read should search.

    focus=False (default): the big picture → common KB (and the user's own).
    focus=True  (Private/Focus): narrow → only the user's own docs.
    """
    if focus:
        return [Scope.PRIVATE]
    return [Scope.ORG_COMMON, Scope.PRIVATE]


def surreal_scope_predicate(
    principal: Principal, focus: bool, notebook: str | None = None
) -> str:
    """The SurrealQL WHERE predicate that scopes a read for this principal.

    This is THE isolation guard (enforced in-app — see the module docstring; we do not
    rely on SurrealDB record permissions). `$owner` (and `$notebook`) are bound as params.
        notebook → only the user's own rows IN that workspace (Focus on a workspace)
        focus    → only the user's own rows
        default  → org-common rows OR the user's own rows (the collective brain)
    """
    if notebook is not None:
        return "owner = $owner AND notebook = $notebook"
    if focus:
        return "owner = $owner"
    return "(scope = 'org-common' OR owner = $owner)"
