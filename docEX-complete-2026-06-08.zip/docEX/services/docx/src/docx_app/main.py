"""Docx FastAPI app — built on the shared FastAPIFactory (health/logging/CORS free).

v1: identity + tenancy via the gateway-minted local JWT; sources upload→extract→store.
Chat/ask routers are added in the retrieval phase.
"""

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

import structlog
from fastapi import Depends, FastAPI

from shared.factory import FastAPIFactory

from docx_app.api.ask import router as ask_router
from docx_app.api.chat import router as chat_router
from docx_app.api.chat import source_chat_router
from docx_app.api.credentials import router as credentials_router
from docx_app.api.diagrams import router as diagrams_router
from docx_app.api.models import router as models_router
from docx_app.api.notebook_diagrams import router as notebook_diagrams_router
from docx_app.api.notebooks import router as notebooks_router
from docx_app.api.notes import router as notes_router
from docx_app.api.repograph import router as repograph_router
from docx_app.api.search import router as search_router
from docx_app.api.settings import router as settings_router
from docx_app.api.sources import router as sources_router
from docx_app.api.system import router as system_router
from docx_app.api.transformations import router as transformations_router
from docx_app.db import SurrealRepository
from docx_app.deps import get_config, get_principal
from docx_app.migrate import apply_migrations
from docx_app.tenancy import Principal

log = structlog.get_logger(__name__)


@asynccontextmanager
async def lifespan(_: FastAPI) -> AsyncIterator[None]:
    cfg = get_config()
    # Fail-fast (§11): in gateway mode, refuse to start without a JWT signing secret, so an
    # empty secret can never silently accept forged tokens. (dev mode uses header auth.)
    if cfg.auth_mode == "gateway" and not cfg.local_jwt_secret:
        raise RuntimeError(
            "local_jwt_secret is not set — refusing to start (fail-fast)."
        )
    # Apply DB migrations (schema + BM25 search index) so hybrid retrieval works out-of-box.
    # A failing migration raises → startup fails rather than serving a half-migrated schema.
    if cfg.run_migrations_on_startup:
        applied = await apply_migrations(SurrealRepository(cfg))
        log.info("startup_migrations", applied=applied)
    yield


config = get_config()
app: FastAPI = FastAPIFactory.create_app(title="Docx", config=config, lifespan=lifespan)
app.include_router(sources_router)
app.include_router(ask_router)
app.include_router(notebooks_router)
app.include_router(notes_router)
app.include_router(chat_router)
app.include_router(source_chat_router)
app.include_router(diagrams_router)
app.include_router(notebook_diagrams_router)
app.include_router(repograph_router)
app.include_router(search_router)
app.include_router(transformations_router)
app.include_router(models_router)
app.include_router(credentials_router)
app.include_router(settings_router)
app.include_router(system_router)


@app.get("/")
async def root() -> dict[str, Any]:
    return {"service": "docx", "status": "running"}


@app.get("/me", response_model=Principal)
async def me(principal: Principal = Depends(get_principal)) -> Principal:
    """The authenticated principal (owner) derived from the JWT — proves tenancy wiring."""
    return principal
