"""The diagram pipeline runner — explanation -> typed JSON graph -> validate/retry.

Ported from gitdiagram's 2-step flow (``backend/app/routers/generate.py``, the
``for attempt in range(1, MAX_GRAPH_ATTEMPTS + 1)`` loop) and made
**provider-agnostic**: instead of gitdiagram's OpenAI-specific
``OpenAIService.generate_structured_output`` (the Responses API with
``text_format=DiagramGraph``), this calls DocEX's single
:meth:`~docx_app.ai.chat.ChatClient.complete` contract, which both the prod
Azure-OpenAI path and the local ``claude_cli`` path implement.

Scope: **Surface 1 — the Source "Diagram" tab** (design:
``docs/2026-06-06-diagram-platform-design.md`` §5). It therefore uses the
source-document prompts (:data:`SOURCE_FIRST_PROMPT` / :data:`SOURCE_GRAPH_PROMPT`
from :mod:`docx_app.diagram.prompts`), whose inputs describe one document
(``<source_title>``/``<source_text>``) rather than a repo. The Azure icon catalog
is injected as ``<shape_library>`` on the graph step so nodes get real Azure icon
ids. The notebook ``<entity_registry>`` (controlled-vocab) is **not** injected
here — that is a later surface — so ``node.entity`` stays null, as required.

Pipeline (design §3):

1. **Explanation** — ``SOURCE_FIRST_PROMPT`` over the document text yields a
   prose architecture analysis wrapped in ``<explanation>...</explanation>``.
2. **Graph JSON** — ``SOURCE_GRAPH_PROMPT`` turns that explanation into the
   typed :class:`~docx_app.diagram.model.DiagramGraph` JSON, retried up to
   ``MAX_GRAPH_ATTEMPTS`` with ``<validation_feedback>`` injected on each retry.

**Defensive JSON parsing (the load-bearing local-path concern).** On the prod
Azure path the model is steered hard toward clean JSON, but the local
``claude_cli`` path returns the JSON *inside a markdown fenced block*, usually
with surrounding prose, and occasionally with fence-variant / trailing-comma
quirks. Per the design, this is "the flakiest surface" and is handled
defensively here — strip prose, tolerate ``` and ```json fences, repair common
JSON defects (trailing commas, smart quotes, stray control chars), then
``DiagramGraph.model_validate``. A failure at any stage is treated as *graph
feedback* and routed into the same retry loop (it is **not** a pipeline bug). Do
not mistake local parse flakiness for a logic error; prod's structured outputs
bypass this entirely.

This module imports the graph contract from :mod:`docx_app.diagram.model` and
prompts/helpers from :mod:`docx_app.diagram.prompts`. It depends on **nothing**
in the API/domain layer — the caller (``api/diagrams.py``) fetches the source's
``full_text``/``title`` and passes them in, keeping the runner pure and testable
with a fake ``ChatClient``.
"""

from __future__ import annotations

import json
import re
from typing import Protocol

import structlog

from docx_app.diagram.model import (
    MAX_GRAPH_ATTEMPTS,
    DiagramGraph,
    format_graph_validation_feedback,
    validate_diagram_graph,
)
from docx_app.diagram.prompts import (
    SOURCE_FIRST_PROMPT,
    SOURCE_GRAPH_PROMPT,
    format_user_message,
    format_validation_feedback_block,
    get_shape_library,
    is_valid_azure_icon_form,
)

log = structlog.get_logger(__name__)

# Token budgets. The explanation is prose (modest); the graph JSON payload is
# large (up to 34 nodes / 48 edges, each with the extended DocEX fields), so it
# gets a generous ceiling — the backend map calls for >=4000 on the graph step.
EXPLANATION_MAX_TOKENS = 2000
GRAPH_MAX_TOKENS = 4000


class _ChatLike(Protocol):
    """The single LLM method the pipeline needs.

    Structurally matches :class:`docx_app.ai.chat.ChatClient` (and the test-only
    ``ClaudeCliChatClient`` subclass). Declared as a ``Protocol`` so the runner
    is decoupled from the concrete client and trivially fakeable in tests.
    """

    async def complete(
        self, *, system: str, user: str, max_tokens: int = ...
    ) -> str: ...


class DiagramPipelineError(RuntimeError):
    """Raised when the pipeline cannot produce a valid graph.

    Carries the last validation feedback (if any) so the API layer can surface a
    useful message rather than a bare stack trace.
    """

    def __init__(self, message: str, *, validation_feedback: str | None = None):
        super().__init__(message)
        self.validation_feedback = validation_feedback


# --------------------------------------------------------------------------- #
# Prompt assembly (uses prompts.format_user_message — gitdiagram's tagger).
# Tag names match the SOURCE_* prompts' declared inputs exactly.
# --------------------------------------------------------------------------- #
def build_explanation_user_prompt(*, source_title: str | None, source_text: str) -> str:
    """Step-1 user content: the document, tagged for ``SOURCE_FIRST_PROMPT``.

    Emits ``<source_title>``/``<source_text>`` — the inputs ``SOURCE_FIRST_PROMPT``
    declares. ``None``/empty values are dropped by ``format_user_message``.
    """
    return format_user_message(
        {
            "source_title": source_title,
            "source_text": source_text,
        }
    )


def build_graph_user_prompt(
    *,
    explanation: str,
    source_title: str | None,
    source_text: str,
    shape_library: str | None,
    previous_graph: str | None,
    validation_feedback: str | None,
    refinement_instruction: str | None = None,
) -> str:
    """Step-2 user content for ``SOURCE_GRAPH_PROMPT``.

    Mirrors gitdiagram's step-2 ``data`` dict, re-pointed to the source-document
    inputs the prompt declares: ``<explanation>``, ``<source_title>``,
    ``<source_text>``, optional ``<shape_library>`` (the Azure catalog), and — on
    retries only — ``<previous_graph>`` (the last raw output) and
    ``<validation_feedback>`` (wrapped by ``format_validation_feedback_block``).
    ``format_user_message`` drops any ``None``/empty value, so the prompt's
    optional inputs are simply absent on the first attempt.
    """
    return format_user_message(
        {
            "explanation": explanation,
            "source_title": source_title,
            "source_text": source_text,
            "shape_library": shape_library,
            "previous_graph": previous_graph,
            "refinement_instruction": refinement_instruction,
            "validation_feedback": validation_feedback,
        }
    )


# --------------------------------------------------------------------------- #
# Tagged-section extraction (gitdiagram `_extract_tagged_section`, verbatim logic)
# --------------------------------------------------------------------------- #
def extract_tagged_section(text: str, tag: str) -> str:
    """Return the body of ``<tag>...</tag>``; fall back to the whole text.

    Copied from gitdiagram (``generate.py`` ``_extract_tagged_section``). The
    model is asked to wrap its explanation in ``<explanation>...</explanation>``;
    if it forgets the tags we use the raw (stripped) text rather than failing.
    """
    start_tag = f"<{tag}>"
    end_tag = f"</{tag}>"
    start_index = text.find(start_tag)
    end_index = text.find(end_tag)
    if start_index == -1 or end_index == -1:
        return text.strip()
    return text[start_index + len(start_tag) : end_index].strip()


# --------------------------------------------------------------------------- #
# Defensive JSON parsing for the graph step (the flakiest surface; local path)
# --------------------------------------------------------------------------- #
class _JsonExtractionError(ValueError):
    """No JSON object could be located/parsed in the model output.

    Distinct from a Pydantic ``ValidationError`` (which means we *did* parse JSON
    but it didn't match the schema). Both are routed into the retry loop, but the
    distinction keeps the feedback message clear.
    """


# ```json ... ``` or ``` ... ``` (case-insensitive language tag, lazy body).
_FENCE_RE = re.compile(
    r"```[ \t]*(?:json|json5|jsonc)?[ \t]*\r?\n?(?P<body>.*?)```",
    re.IGNORECASE | re.DOTALL,
)
# Trailing comma before a closing } or ] (with optional whitespace between).
_TRAILING_COMMA_RE = re.compile(r",(\s*[}\]])")
# Smart / typographic quotes the model occasionally emits instead of ASCII ".
_SMART_QUOTES = {
    "“": '"',  # left double quotation mark
    "”": '"',  # right double quotation mark
    "‘": "'",  # left single quotation mark
    "’": "'",  # right single quotation mark
}

# Optional third-party repairer. We do NOT hard-depend on it (it is not in the
# project's deps, and only the Integrate phase may touch shared files), but if a
# `json_repair`/`jsonrepair` package is ever present it is used as a last resort
# before giving up — strictly additive, never required.
try:  # pragma: no cover - exercised only when the optional dep is installed
    from json_repair import repair_json as _repair_json
except Exception:  # noqa: BLE001 - any import failure -> feature simply absent
    try:  # pragma: no cover
        from jsonrepair import jsonrepair as _repair_json
    except Exception:  # noqa: BLE001
        _repair_json = None


def _candidate_json_blocks(text: str) -> list[str]:
    """Yield candidate JSON strings from raw model output, best-first.

    Ordered so the most-likely-correct candidate is tried first:

    1. Each fenced code block body (``` / ```json), in order of appearance —
       the model is *asked* to fence the JSON, so this is the common case.
    2. The widest ``{ ... }`` slice of the raw text — covers the case where the
       model returned JSON with no fences (or with prose on either side).
    3. The whole stripped text — covers already-clean JSON (the prod path).
    """
    candidates: list[str] = []
    for match in _FENCE_RE.finditer(text):
        body = match.group("body").strip()
        if body:
            candidates.append(body)

    first = text.find("{")
    last = text.rfind("}")
    if first != -1 and last != -1 and last > first:
        candidates.append(text[first : last + 1].strip())

    stripped = text.strip()
    if stripped:
        candidates.append(stripped)

    # De-dupe while preserving best-first order.
    seen: set[str] = set()
    unique: list[str] = []
    for cand in candidates:
        if cand not in seen:
            seen.add(cand)
            unique.append(cand)
    return unique


def _repair(candidate: str) -> str:
    """Best-effort fix of common LLM-JSON defects (no external dep required).

    Removes trailing commas, normalises smart quotes, and strips C0 control
    characters (other than the JSON-legal whitespace) that occasionally leak
    into long generations. Idempotent and safe on already-valid JSON.
    """
    repaired = candidate
    for smart, ascii_ in _SMART_QUOTES.items():
        repaired = repaired.replace(smart, ascii_)
    repaired = _TRAILING_COMMA_RE.sub(r"\1", repaired)
    # Drop stray C0 controls except \t \n \r (json.loads rejects raw controls).
    repaired = "".join(ch for ch in repaired if ch >= " " or ch in "\t\n\r")
    return repaired


def _repair_attempts(candidate: str) -> list[str]:
    """The progressively-more-aggressive parse attempts for one candidate."""
    attempts = [candidate, _repair(candidate)]
    if _repair_json is not None:
        try:  # pragma: no cover - only when the optional dep is installed
            deep = _repair_json(candidate)
            if isinstance(deep, str):
                attempts.append(deep)
        except Exception:  # noqa: BLE001 - deep repair is best-effort
            pass
    # De-dupe (the repair is often a no-op on clean input).
    seen: set[str] = set()
    out: list[str] = []
    for text in attempts:
        if text and text not in seen:
            seen.add(text)
            out.append(text)
    return out


def parse_graph_json(raw_output: str) -> DiagramGraph:
    """Defensively parse model output into a validated :class:`DiagramGraph`.

    Strategy (mandatory for the ``claude_cli`` path; harmless on the prod path):
    for each candidate block (fenced first, then widest braces, then whole text)
    try ``json.loads`` as-is, then on a light :func:`_repair`, then — only if the
    optional ``json_repair``/``jsonrepair`` dep is installed — on a deep repair.
    The first candidate that yields a dict is validated with
    ``DiagramGraph.model_validate`` (NOT ``**dict`` — that would not honour the
    ``from``/``from_`` alias on edges).

    Raises:
        _JsonExtractionError: nothing in the output parsed as a JSON object.
        pydantic.ValidationError: a JSON object parsed but failed the schema
            (propagated so the caller can feed Pydantic's own message back).
    """
    last_decode_error: json.JSONDecodeError | None = None

    for candidate in _candidate_json_blocks(raw_output):
        for attempt_text in _repair_attempts(candidate):
            try:
                parsed = json.loads(attempt_text)
            except json.JSONDecodeError as exc:
                last_decode_error = exc
                continue
            if isinstance(parsed, dict):
                # Found a JSON object — let Pydantic decide if it's a valid graph.
                # A ValidationError here propagates to the retry loop on purpose.
                return DiagramGraph.model_validate(parsed)
            # Parsed to a non-object (e.g. a list/scalar) — keep looking.

    detail = f" (last decode error: {last_decode_error})" if last_decode_error else ""
    raise _JsonExtractionError(
        f"No JSON object could be parsed from the model output{detail}."
    )


def _strip_invalid_icons(graph: DiagramGraph) -> None:
    """Null out any ``node.icon`` that isn't a well-formed ``azure/{cat}/{Shape}`` id.

    The model occasionally hallucinates an icon id. The renderer falls back to a
    generic glyph either way, but persisting a malformed id is noise — strip it so
    stored graphs stay clean. Logs how many were stripped; never raises.
    """
    stripped = 0
    for node in graph.nodes:
        if node.icon and not is_valid_azure_icon_form(node.icon):
            node.icon = None
            stripped += 1
    if stripped:
        log.bind(stripped=stripped).warning("diagram_icons_stripped")


# --------------------------------------------------------------------------- #
# The two-step pipeline (gitdiagram structure, provider-agnostic)
# --------------------------------------------------------------------------- #
async def generate_explanation(
    chat: _ChatLike,
    *,
    source_title: str | None,
    source_text: str,
) -> str:
    """Step 1: prose architecture explanation of the document.

    Calls ``SOURCE_FIRST_PROMPT`` and extracts the ``<explanation>`` body
    (gitdiagram step 1). Raises :class:`DiagramPipelineError` if the model
    returns nothing usable.
    """
    response = await chat.complete(
        system=SOURCE_FIRST_PROMPT,
        user=build_explanation_user_prompt(
            source_title=source_title, source_text=source_text
        ),
        max_tokens=EXPLANATION_MAX_TOKENS,
    )
    explanation = extract_tagged_section(response, "explanation")
    if not explanation.strip():
        raise DiagramPipelineError("The explanation step returned no usable output.")
    return explanation


async def generate_graph(
    chat: _ChatLike,
    *,
    explanation: str,
    source_title: str | None,
    source_text: str,
    shape_library: str | None = None,
    file_tree_lookup: set[str] | None = None,
    instruction: str | None = None,
    seed_graph: DiagramGraph | None = None,
) -> DiagramGraph:
    """Step 2: typed graph JSON with the gitdiagram validate-and-retry loop.

    For each of up to ``MAX_GRAPH_ATTEMPTS`` attempts:

    1. call ``SOURCE_GRAPH_PROMPT`` (injecting ``<shape_library>`` always, and
       ``<previous_graph>`` / ``<validation_feedback>`` on retries);
    2. defensively parse the output into a :class:`DiagramGraph`
       (:func:`parse_graph_json`);
    3. run :func:`validate_diagram_graph`. If it finds structural issues, format
       them as feedback and loop; otherwise return the graph.

    Both a parse failure (``_JsonExtractionError`` / Pydantic ``ValidationError``)
    and structural issues feed the *same* retry mechanism — exactly mirroring
    gitdiagram, with the defensive parse added for the fenced-block local path.

    Args:
        shape_library: the Azure icon catalog body (from
            :func:`docx_app.diagram.prompts.get_shape_library`), injected so the
            model sets ``node.icon`` to real ids. ``None`` omits the block.
        file_tree_lookup: passed to the validator. For **source** diagrams this
            is ``set()`` (the default) — there is no file tree, so the
            ``link``-in-tree check never fires; only duplicate-id and
            broken-edge-ref checks run.

    Raises:
        DiagramPipelineError: no valid graph after ``MAX_GRAPH_ATTEMPTS``.
    """
    lookup = file_tree_lookup if file_tree_lookup is not None else set()

    valid_graph: DiagramGraph | None = None
    validation_feedback: str | None = None
    # On a refine, seed the loop with the current graph so the first attempt EDITS
    # it (rather than regenerating from scratch); the instruction rides every
    # attempt's prompt as <refinement_instruction>.
    previous_graph: str | None = (
        json.dumps(seed_graph.model_dump(by_alias=True)) if seed_graph else None
    )

    for attempt in range(1, MAX_GRAPH_ATTEMPTS + 1):
        # On a retry, wrap the raw validator feedback in the prompt's instruction
        # block (prompts.format_validation_feedback_block); None on the first pass.
        feedback_block = (
            format_validation_feedback_block(validation_feedback)
            if validation_feedback
            else None
        )
        raw_output = await chat.complete(
            system=SOURCE_GRAPH_PROMPT,
            user=build_graph_user_prompt(
                explanation=explanation,
                source_title=source_title,
                source_text=source_text,
                shape_library=shape_library,
                previous_graph=previous_graph,
                refinement_instruction=instruction,
                validation_feedback=feedback_block,
            ),
            max_tokens=GRAPH_MAX_TOKENS,
        )

        # --- Defensive parse (mandatory for the claude_cli fenced-block path) ---
        try:
            graph = parse_graph_json(raw_output)
        except ValueError as exc:
            # ValueError covers _JsonExtractionError and pydantic.ValidationError
            # (a ValueError subclass). Either way: feed the message back and retry.
            validation_feedback = str(exc)
            previous_graph = raw_output
            log.warning(
                "diagram_graph_parse_failed",
                attempt=attempt,
                max_attempts=MAX_GRAPH_ATTEMPTS,
                error=str(exc),
            )
            continue

        # --- Structural validation (gitdiagram) ---
        issues = validate_diagram_graph(graph, lookup)
        if issues:
            validation_feedback = format_graph_validation_feedback(issues)
            # Re-serialise with by_alias so the retry's <previous_graph> shows
            # "from" (not "from_") — what the model originally emitted.
            previous_graph = json.dumps(graph.model_dump(by_alias=True))
            log.warning(
                "diagram_graph_validation_failed",
                attempt=attempt,
                max_attempts=MAX_GRAPH_ATTEMPTS,
                issue_count=len(issues),
            )
            continue

        valid_graph = graph
        break

    if valid_graph is None:
        raise DiagramPipelineError(
            f"Graph generation remained invalid after {MAX_GRAPH_ATTEMPTS} attempts.",
            validation_feedback=validation_feedback,
        )
    _strip_invalid_icons(valid_graph)
    return valid_graph


async def run_diagram_pipeline(
    chat: _ChatLike,
    *,
    source_title: str | None,
    source_text: str,
    include_azure_shapes: bool = True,
    instruction: str | None = None,
    base_graph: DiagramGraph | None = None,
) -> DiagramGraph:
    """Run the full Surface-1 pipeline: explanation -> validated graph.

    This is the single entry point the API/domain layer calls. It is
    provider-agnostic (any object with the :class:`_ChatLike` ``complete``
    contract works — prod Azure, local ``claude_cli``, or a scripted fake in
    tests) and stateless.

    Args:
        chat: the LLM client (``docx_app.ai.chat.ChatClient`` or compatible).
        source_title: the source title (may be ``None``).
        source_text: the source's extracted ``full_text``. Must be non-empty —
            the caller (the API endpoint) is responsible for returning 422 when a
            source has no extracted text yet; this guard is a defensive backstop.
        include_azure_shapes: inject the Azure icon catalog as ``<shape_library>``
            on the graph step (default ``True``; design §3 — Azure icons are
            first-class for Surface 1). Set ``False`` to skip the catalog.

    Returns:
        A Pydantic-validated, structurally-valid :class:`DiagramGraph`.
        For source diagrams the validator runs with an empty file-tree lookup, so
        ``node.link``/``node.entity`` are never failed here.

    Raises:
        DiagramPipelineError: the document text is empty, or no valid graph could
            be produced within ``MAX_GRAPH_ATTEMPTS``.
    """
    if not source_text or not source_text.strip():
        raise DiagramPipelineError("Cannot build a diagram from empty document text.")

    shape_library = get_shape_library("azure") if include_azure_shapes else None

    explanation = await generate_explanation(
        chat, source_title=source_title, source_text=source_text
    )
    graph = await generate_graph(
        chat,
        explanation=explanation,
        source_title=source_title,
        source_text=source_text,
        shape_library=shape_library,
        file_tree_lookup=set(),
        instruction=instruction,
        seed_graph=base_graph,
    )
    log.info(
        "diagram_pipeline_succeeded",
        node_count=len(graph.nodes),
        edge_count=len(graph.edges),
        group_count=len(graph.groups),
    )
    return graph
