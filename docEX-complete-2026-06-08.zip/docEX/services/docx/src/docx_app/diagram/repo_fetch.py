"""Provider-agnostic repo fetch for RepoGraph (Surface 3) — GitHub OR GitLab.

The user pastes *any* repo URL; this dispatcher detects the provider from the URL host and
delegates to the matching fetch service, then normalises BOTH the result (→ :class:`RepoData`)
and the error hierarchy (→ :class:`RepoConfigError` / :class:`RepoNotFoundError` /
:class:`RepoFetchError`) so ``api/repograph.py`` stays provider-agnostic.

Detection (host-based, deterministic):
  * ``github.com`` / ``www.github.com``         → GitHub (public; optional PAT). Always available.
  * the configured ``gitlab_base_url`` host, or any host containing ``"gitlab"`` → GitLab
    (needs ``gitlab_base_url`` configured; otherwise the GitLab service raises a config error
    the API surfaces as 503).
  * anything else                               → ``ValueError`` (422 — unsupported host).

Both underlying services (:mod:`docx_app.diagram.github_service`,
:mod:`docx_app.diagram.gitlab_service`) are leaves (they do not import this module), so there
is no import cycle; this module depends on them.
"""

from __future__ import annotations

from dataclasses import dataclass
from urllib.parse import urlparse

import structlog

from docx_app.config import DocxConfig
from docx_app.diagram.github_service import (
    GITHUB_HOSTS,
    GitHubFetchError,
    GitHubNotFoundError,
    GitHubService,
)
from docx_app.diagram.gitlab_service import (
    GitLabConfigError,
    GitLabFetchError,
    GitLabNotFoundError,
    GitLabService,
)

log = structlog.get_logger(__name__)


class RepoConfigError(ValueError):
    """The selected provider is not configured (→ HTTP 503). E.g. a GitLab URL with no base."""


class RepoNotFoundError(ValueError):
    """The repository does not exist / is inaccessible (→ HTTP 404)."""


class RepoFetchError(RuntimeError):
    """A non-retryable upstream provider error (→ HTTP 502)."""


@dataclass(frozen=True)
class RepoData:
    """Unified repo payload the pipeline consumes, from either provider.

    Same fields the graph pipeline + the RepoGraph response need; ``provider`` records which
    backend produced it (``"github"`` | ``"gitlab"``) for logging + the FE badge.
    """

    provider: str
    default_branch: str
    file_tree: str
    readme: str
    namespace: str


def detect_provider(repo_url: str, config: DocxConfig) -> str:
    """Return ``"github"`` or ``"gitlab"`` for ``repo_url``; raise ``ValueError`` if neither.

    github.com is always recognised. A GitLab host is recognised when it matches the
    configured ``gitlab_base_url`` host, or (as a convenience for self-hosted instances whose
    base URL may not be set yet) when the host contains ``"gitlab"``. Anything else is an
    unsupported host → ``ValueError`` (the API maps that to 422).
    """
    host = (urlparse(repo_url.strip()).netloc or "").lower()
    if not host:
        raise ValueError(f"repo_url {repo_url!r} has no host")
    if host in GITHUB_HOSTS:
        return "github"
    gitlab_base = (config.gitlab_base_url or "").strip()
    if gitlab_base:
        gitlab_host = (urlparse(gitlab_base).netloc or "").lower()
        if gitlab_host and host == gitlab_host:
            return "gitlab"
    if "gitlab" in host:
        return "gitlab"
    raise ValueError(
        f"unsupported repository host {host!r} — paste a github.com URL or a "
        "URL on the configured GitLab instance."
    )


class RepoFetcher:
    """Dispatches a repo URL to the GitHub or GitLab service and returns a unified RepoData.

    Injected as a FastAPI dependency (``get_repo_fetcher`` in ``deps.py``); fakeable in tests
    by overriding that dependency. Stateless — construct per request.
    """

    def __init__(self, config: DocxConfig) -> None:
        self._config = config

    async def fetch(self, repo_url: str) -> RepoData:
        """Fetch ``repo_url`` from whichever provider its host indicates.

        Raises:
            ValueError: unsupported host, a malformed URL, or a file tree over the cap (422).
            RepoConfigError: the provider (GitLab) is not configured (503).
            RepoNotFoundError: the repo does not exist / is inaccessible (404).
            RepoFetchError: any other upstream provider error (502).
        """
        provider = detect_provider(repo_url, self._config)
        if provider == "github":
            try:
                data = await GitHubService(self._config).get_github_data(repo_url)
            except GitHubNotFoundError as exc:
                raise RepoNotFoundError(str(exc)) from exc
            except GitHubFetchError as exc:
                raise RepoFetchError(str(exc)) from exc
            return RepoData(
                provider="github",
                default_branch=data.default_branch,
                file_tree=data.file_tree,
                readme=data.readme,
                namespace=data.namespace,
            )

        # provider == "gitlab"
        try:
            gl = await GitLabService(self._config).get_gitlab_data(repo_url)
        except GitLabConfigError as exc:
            raise RepoConfigError(str(exc)) from exc
        except GitLabNotFoundError as exc:
            raise RepoNotFoundError(str(exc)) from exc
        except GitLabFetchError as exc:
            raise RepoFetchError(str(exc)) from exc
        return RepoData(
            provider="gitlab",
            default_branch=gl.default_branch,
            file_tree=gl.file_tree,
            readme=gl.readme,
            namespace=gl.namespace,
        )


__all__ = [
    "RepoData",
    "RepoFetcher",
    "RepoConfigError",
    "RepoNotFoundError",
    "RepoFetchError",
    "detect_provider",
]
