"""Diagram platform — render-agnostic graph model, pipeline, and surfaces.

This package is the backend home for the DocEX diagram feature (design:
`docs/2026-06-06-diagram-platform-design.md`). One canonical graph model
(`DiagramGraph`) is produced by a 2-step LLM pipeline (ported from gitdiagram),
Pydantic-validated, and rendered by a single custom SVG renderer reused across
three surfaces (source LLD, notebook HLD, RepoGraph).

This module (the SHARED FOUNDATION) exposes only the model + its validator;
everything else in the package imports from here. The extended `DiagramGraph`
carries the gitdiagram fields plus DocEX additions (icon/link/drill/entity/meta
on nodes, animated/flow on edges). The optional `entity` field is reserved for
the later notebook-HLD entity registry (see
`docs/2026-06-07-entity-resolution-subdesign.md`); nothing consumes it yet.
"""

from __future__ import annotations

from docx_app.diagram.model import (
    MAX_GRAPH_ATTEMPTS,
    MAX_GRAPH_EDGES,
    MAX_GRAPH_GROUPS,
    MAX_GRAPH_NODES,
    DiagramGraph,
    DiagramGraphEdge,
    DiagramGraphGroup,
    DiagramGraphNode,
    GraphValidationIssue,
    build_file_tree_lookup,
    format_graph_validation_feedback,
    validate_diagram_graph,
)

__all__ = [
    "MAX_GRAPH_ATTEMPTS",
    "MAX_GRAPH_EDGES",
    "MAX_GRAPH_GROUPS",
    "MAX_GRAPH_NODES",
    "DiagramGraph",
    "DiagramGraphEdge",
    "DiagramGraphGroup",
    "DiagramGraphNode",
    "GraphValidationIssue",
    "build_file_tree_lookup",
    "format_graph_validation_feedback",
    "validate_diagram_graph",
]
