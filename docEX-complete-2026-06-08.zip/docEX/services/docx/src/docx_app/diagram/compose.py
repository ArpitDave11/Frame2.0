"""Deterministic Notebook-HLD composition (Surface 2) — the entity-bridged parent graph.

Sub-design: ``docs/2026-06-07-entity-resolution-subdesign.md`` §7 (HLD topology — recommended
**entity-bridged**), §5 (Path-B reconciliation for nodes without a Path-C ``entity`` key), §8
(determinism/immutability — reconciliation reads the frozen source LLDs but never mutates
them). Parent design §6 ("statically compose all accepted source graphs into one parent
graph via the shared-entity registry; drill down into each source's LLD").

What this does (sub-design §7 last paragraph), purely as code (no LLM except the §5
ambiguous-tail adjudication):

1. Read every **accepted** source diagram for the notebook via :class:`DiagramStore`
   (``surface="source"``, owner-scoped). Each carries a frozen ``graph_json``.
2. Resolve every node to an ``entity_key``: **Path C** when the node was born with a
   non-empty ``node.entity`` (controlled-vocab); else the **Path-B** cascade
   (:func:`docx_app.diagram.reconciler.reconcile_node`) against the notebook's registry.
3. Group-by ``entity_key`` across sources → an entity becomes a **bridge node** only when it
   appears in ``>= 2`` sources (singletons stay inside their source LLD — sub-design §7).
4. Emit a parent :class:`DiagramGraph` with ``surface='notebook'`` semantics:
   * one **source node** per accepted source (``type="source"``, ``shape="hexagon"``,
     ``drill`` = the accepted diagram id) — drillable into its LLD;
   * one **bridge node** per shared entity (``type`` = the entity ``kind`` or ``"entity"``,
     ``meta.source_refs`` = the contributing source_ids);
   * an **edge** from each source node to every bridge node it contributes, ``label`` =
     ``entity_key`` (the cross-source link anchor).

Critical serialisation (S1-map gotcha 1/2): source ``graph_json`` rows are read with
``Diagram.graph()`` (``model_validate`` — honours the ``"from"`` edge alias), and the emitted
parent graph round-trips the same way; never ``DiagramGraph(**dict)``. The frozen source rows
are **never** written back (sub-design §8). The registry is updated only by the Path-C upsert
(``EntityRegistryStore.upsert_from_graph``, called from the rebuild endpoint) and by Path-B
*new-entity* registration done here at compose time.

Tenancy: every read is owner-scoped (``DiagramStore.list`` / ``EntityRegistryStore.list`` use
``focus=True``), so a compose only ever sees the caller's own sources + registry — no
cross-owner or cross-notebook leakage (sub-design §3/§10).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Protocol

import structlog

from docx_app.diagram.domain import DiagramStore
from docx_app.diagram.entities import (
    EntityRegistryStore,
    NotebookEntity,
    local_hash_embedding,
)
from docx_app.diagram.model import (
    MAX_GRAPH_EDGES,
    MAX_GRAPH_NODES,
    DiagramGraph,
    DiagramGraphEdge,
    DiagramGraphNode,
)
from docx_app.diagram.reconciler import (
    MAX_LLM_ADJUDICATIONS_PER_COMPOSE,
    Assignment,
    EmbedFn,
    NodeRef,
    reconcile_node,
)
from docx_app.tenancy import Principal

log = structlog.get_logger(__name__)

_SURFACE_SOURCE = "source"
# Min sources an entity must appear in to be promoted to an HLD bridge (sub-design §7).
MIN_SOURCES_FOR_BRIDGE = 2
# Id sanitiser: graph ids must match ^[a-z][a-z0-9_]*$ (model.py). Map any other char to "_".
_ID_SAFE_RE = re.compile(r"[^a-z0-9_]+")


class _ChatLike(Protocol):
    """The provider-agnostic LLM contract reconciliation needs (matches ``agent._ChatLike``)."""

    async def complete(
        self, *, system: str, user: str, max_tokens: int = ...
    ) -> str: ...


def _safe_id(raw: str, *, prefix: str) -> str:
    """Deterministically map an arbitrary string to a valid graph id (``^[a-z][a-z0-9_]*$``).

    Source ids look like ``source:abcdef`` and entity keys like ``order-service`` — neither
    is a legal graph id (``:`` and ``-`` are disallowed). Lowercase, replace every
    illegal run with ``_``, then prefix (so it always starts with a letter and never
    collides across the two node kinds: ``src_…`` vs ``ent_…``). Deterministic, so the same
    source/entity always yields the same node id (stable across rebuilds).
    """
    lowered = raw.lower()
    cleaned = _ID_SAFE_RE.sub("_", lowered).strip("_")
    return f"{prefix}_{cleaned}" if cleaned else f"{prefix}_x"


@dataclass
class _SourceContribution:
    """One accepted source's contribution to the HLD (kept module-private)."""

    source_id: str  # the source's ref (e.g. "source:abc")
    diagram_id: str  # the accepted diagram id → the source node's `drill` target
    node_id: str  # the sanitised HLD source-node id
    title: str  # human label for the source node
    # entity_key → (Assignment, kind hint) contributed by this source (deduped per key).
    entities: dict[str, tuple[Assignment, str | None]] = field(default_factory=dict)


@dataclass
class ComposeResult:
    """The composed HLD plus its audit trail (returned by :func:`compose_notebook_hld`).

    ``graph`` is the entity-bridged parent :class:`DiagramGraph` (``None`` when the notebook
    has no accepted source diagrams — the caller maps that to an empty-state 404/empty). The
    audit fields let the HLD endpoint surface low-confidence merges for human review
    (sub-design §6/§10) and report any silent-cap truncation honestly.
    """

    graph: DiagramGraph | None
    assignments: list[Assignment]
    source_count: int
    bridge_count: int

    @property
    def low_confidence(self) -> list[Assignment]:
        """Heuristic merges (embedding/LLM below ``TAU_HIGH``) to flag in the UI (§6/§10)."""
        return [a for a in self.assignments if a.low_confidence]


def _entity_kind(entity: NotebookEntity, fallback: str | None) -> str:
    """The bridge node ``type`` — the entity's ``kind``, else a contributed hint, else 'entity'."""
    if entity.kind and entity.kind.strip():
        return entity.kind.strip()
    if fallback and fallback.strip():
        return fallback.strip()
    return "entity"


def _node_kind_hint(node: DiagramGraphNode) -> str | None:
    """Best-effort entity ``kind`` from a node's ``meta.kind``, else its ``type`` (mirrors
    entities._node_kind). The ``type`` fallback is what makes the homonym guard actually fire
    on real LLM output — ``meta.kind`` is only reliably present when the prompt sets it."""
    if isinstance(node.meta, dict):
        kind = node.meta.get("kind")
        if isinstance(kind, str) and kind.strip():
            return kind.strip()
    if isinstance(node.type, str) and node.type.strip():
        return node.type.strip()
    return None


async def _default_embed(text: str) -> list[float]:
    """The default async node embedder — the local lexical hash (sub-design §9)."""
    return local_hash_embedding(text)


async def compose_notebook_hld(
    repo: Any,
    principal: Principal,
    *,
    notebook_id: str,
    chat: _ChatLike | None = None,
    embedding_fn: EmbedFn | None = None,
) -> ComposeResult:
    """Compose the notebook's accepted source diagrams into one entity-bridged HLD graph.

    Deterministic for the common (Path-C) case; falls back to the §5 reconciler only for
    nodes lacking an ``entity`` key, and reaches the LLM only for that ambiguous tail
    (bounded by :data:`MAX_LLM_ADJUDICATIONS_PER_COMPOSE`, shared across all nodes in this
    compose — sub-design §11). Reads the registry once (owner+notebook scoped) and resolves
    against it; **new** entities discovered by Path B are registered so subsequent rebuilds
    see them (idempotent).

    Args:
        repo: the :class:`~docx_app.db.SurrealRepository` (or a compatible fake in tests).
        principal: the caller — every read/write is owner-scoped to them.
        notebook_id: the notebook whose accepted source diagrams compose the HLD.
        chat: provider-agnostic LLM for the reconciler's ambiguous tail (``None`` → that tail
            stays unresolved → those nodes become new entities; the fail-safe).
        embedding_fn: ASYNC ``str -> list[float]`` used to embed unmatched nodes for the
            reconciler's step 2 (must match how registry embeddings were produced). ``None``
            defaults to the local lexical hash embedder (sub-design §9).

    Returns:
        A :class:`ComposeResult`. ``graph is None`` iff the notebook has **no accepted source
        diagrams** (nothing to compose). Otherwise an entity-bridged parent graph: source
        nodes (drillable hexagons) + shared-entity bridge nodes (``len(source_refs) >= 2``).
    """
    store = DiagramStore(repo)
    registry_store = EntityRegistryStore(repo)
    embed_fn: EmbedFn = embedding_fn if embedding_fn is not None else _default_embed

    # --- 1. Read every accepted source diagram for the notebook (owner-scoped). --------- #
    # DiagramStore.list returns this owner's "source" diagrams; an accepted source belongs
    # to the notebook when its ref source's `notebook` field points here. We resolve that
    # via the source rows, but to stay decoupled from SourceStore the caller passes the set
    # of accepted source diagrams it wants composed through `_accepted_source_diagrams`.
    accepted = await accepted_source_diagrams_for_notebook(
        store, principal, notebook_id=notebook_id
    )
    if not accepted:
        log.info("hld_compose_empty", notebook_id=notebook_id)
        return ComposeResult(
            graph=None, assignments=[], source_count=0, bridge_count=0
        )

    # --- 2. Load the notebook's registry once (the candidate set for Path B). ----------- #
    registry = await registry_store.list(principal, notebook_id=notebook_id)
    # Mutable working copy so newly-registered Path-B entities become candidates for
    # later nodes within the SAME compose (so two sources coining the same fresh label
    # converge to one bridge rather than two singletons).
    candidates: list[NotebookEntity] = list(registry)

    contributions: list[_SourceContribution] = []
    all_assignments: list[Assignment] = []
    llm_budget = MAX_LLM_ADJUDICATIONS_PER_COMPOSE

    # --- 3. Resolve every node of every source to an entity_key. ------------------------ #
    for diagram in accepted:
        graph = diagram.graph()  # model_validate — honours the "from" edge alias
        if graph is None:
            continue
        source_id = diagram.ref or ""
        contribution = _SourceContribution(
            source_id=source_id,
            diagram_id=diagram.id or "",
            node_id=_safe_id(source_id or (diagram.id or "src"), prefix="src"),
            title=_source_title(diagram),
        )
        for node in graph.nodes:
            kind_hint = _node_kind_hint(node)
            born_entity = (node.entity or "").strip()
            if born_entity:
                # Path C: the node arrived with a stable entity key — trust it (deterministic).
                assignment = Assignment(
                    entity_key=born_entity,
                    method="controlled_vocab",
                    confidence=1.0,
                    is_new=not _has_key(candidates, born_entity),
                    candidate_id=_candidate_id(candidates, born_entity),
                )
            else:
                # Path B: resolve against the current candidate set (cascade §5).
                assignment = await reconcile_node(
                    NodeRef(
                        label=node.label,
                        kind=kind_hint,
                        description=node.description,
                    ),
                    candidates,
                    chat=chat,
                    embedding_fn=embed_fn,
                    llm_budget=llm_budget,
                )
                if assignment.method == "llm":
                    # An LLM adjudication was spent — decrement the shared per-compose budget.
                    llm_budget = max(0, llm_budget - 1)

            all_assignments.append(assignment)
            # Register a genuinely-new entity so later nodes/sources can bridge to it, and so
            # the persisted registry reflects Path-B discoveries (idempotent across rebuilds).
            if assignment.is_new and not _has_key(candidates, assignment.entity_key):
                new_entity = await registry_store.create(
                    owner=principal.owner,
                    notebook_id=notebook_id,
                    entity_key=assignment.entity_key,
                    canonical_label=node.label,
                    kind=kind_hint,
                    source_refs=[source_id] if source_id else [],
                    embedding=await _safe_embed(
                        embed_fn, node.label, node.description
                    ),
                )
                candidates.append(new_entity)
            # Record this source's contribution to the key (first kind hint wins per key).
            if assignment.entity_key not in contribution.entities:
                contribution.entities[assignment.entity_key] = (assignment, kind_hint)
        contributions.append(contribution)

    # --- 4. Group-by entity across sources → promote bridges (>= 2 sources). ------------ #
    # entity_key → set of source node_ids that contribute it (dedup per source already done).
    entity_sources: dict[str, list[_SourceContribution]] = {}
    entity_kind_hint: dict[str, str | None] = {}
    for contribution in contributions:
        for key, (_assignment, kind_hint) in contribution.entities.items():
            entity_sources.setdefault(key, []).append(contribution)
            entity_kind_hint.setdefault(key, kind_hint)

    by_key: dict[str, NotebookEntity] = {
        e.entity_key: e for e in candidates if e.entity_key
    }
    graph = _build_parent_graph(
        contributions=contributions,
        entity_sources=entity_sources,
        entity_kind_hint=entity_kind_hint,
        by_key=by_key,
    )

    bridge_count = sum(
        1
        for key, srcs in entity_sources.items()
        if len({c.node_id for c in srcs}) >= MIN_SOURCES_FOR_BRIDGE
    )
    log.info(
        "hld_composed",
        notebook_id=notebook_id,
        source_count=len(contributions),
        bridge_count=bridge_count,
        node_count=len(graph.nodes),
        edge_count=len(graph.edges),
        low_confidence=sum(1 for a in all_assignments if a.low_confidence),
    )
    return ComposeResult(
        graph=graph,
        assignments=all_assignments,
        source_count=len(contributions),
        bridge_count=bridge_count,
    )


def _build_parent_graph(
    *,
    contributions: list[_SourceContribution],
    entity_sources: dict[str, list[_SourceContribution]],
    entity_kind_hint: dict[str, str | None],
    by_key: dict[str, NotebookEntity],
) -> DiagramGraph:
    """Assemble the entity-bridged parent :class:`DiagramGraph` (sub-design §7 topology).

    Source nodes (drillable hexagons) for every contribution; bridge nodes only for entities
    appearing in ``>= MIN_SOURCES_FOR_BRIDGE`` distinct sources; an edge from each source to
    each bridge it contributes (``label = entity_key``). Respects the model's node/edge caps
    (``MAX_GRAPH_NODES``/``MAX_GRAPH_EDGES``) — if a very large notebook would exceed them,
    the overflow is dropped and **logged** (sub-design §10 — no silent caps), keeping the
    emitted graph schema-valid.
    """
    nodes: list[DiagramGraphNode] = []
    edges: list[DiagramGraphEdge] = []

    # Source nodes first (they always exist; bridges decorate them).
    for contribution in contributions:
        nodes.append(
            DiagramGraphNode(
                id=contribution.node_id,
                label=contribution.title,
                type="source",
                shape="hexagon",
                drill=contribution.diagram_id,
                meta={"source_id": contribution.source_id},
            )
        )

    # Bridge nodes — only shared entities (>= 2 distinct contributing sources).
    bridge_node_ids: dict[str, str] = {}
    for key in sorted(entity_sources):  # deterministic order
        contributing = entity_sources[key]
        distinct_sources = {c.node_id for c in contributing}
        if len(distinct_sources) < MIN_SOURCES_FOR_BRIDGE:
            continue  # singleton — stays inside its source LLD (sub-design §7)
        entity = by_key.get(key)
        label = entity.canonical_label if entity and entity.canonical_label else key
        kind = (
            _entity_kind(entity, entity_kind_hint.get(key))
            if entity
            else (entity_kind_hint.get(key) or "entity")
        )
        source_refs = sorted(
            {c.source_id for c in contributing if c.source_id}
        )
        bridge_id = _safe_id(key, prefix="ent")
        bridge_node_ids[key] = bridge_id
        nodes.append(
            DiagramGraphNode(
                id=bridge_id,
                label=label,
                type=kind,
                shape="circle",
                entity=key,
                meta={"source_refs": source_refs, "shared": True},
            )
        )

    # Edges: each source → every bridge it contributes (label = entity_key). Built via
    # model_validate with the "from" alias key (NOT from_=) so the alias is honoured the
    # same way stored graph JSON is loaded — see model.py's serialisation note.
    for key, bridge_id in bridge_node_ids.items():
        for contribution in entity_sources[key]:
            edges.append(
                DiagramGraphEdge.model_validate(
                    {
                        "from": contribution.node_id,
                        "to": bridge_id,
                        "label": key,
                        "flow": "shared_entity",
                    }
                )
            )

    nodes, edges = _enforce_caps(nodes, edges)
    return DiagramGraph(groups=[], nodes=nodes, edges=edges)


def _enforce_caps(
    nodes: list[DiagramGraphNode], edges: list[DiagramGraphEdge]
) -> tuple[list[DiagramGraphNode], list[DiagramGraphEdge]]:
    """Trim to the model's node/edge limits, dropping orphaned edges, logging any drop.

    The model caps a graph at ``MAX_GRAPH_NODES``/``MAX_GRAPH_EDGES``; a pathological
    notebook (very many sources/entities) could exceed them. Rather than emit an invalid
    graph (which Pydantic would reject) or silently lose data, we trim and LOG the truncation
    (sub-design §10). Source nodes are kept preferentially over bridge nodes (the index must
    stay navigable even if some cross-source bridges are dropped).
    """
    if len(nodes) > MAX_GRAPH_NODES:
        # Sources are appended before bridges, so a head-slice drops bridge nodes first — the
        # index stays navigable. Only when sources ALONE exceed the cap are source nodes
        # themselves trimmed; log that case distinctly so an incomplete index is never mistaken
        # for a complete one (sub-design §10 — no silent caps).
        source_count = sum(1 for n in nodes if n.type == "source")
        if source_count > MAX_GRAPH_NODES:
            log.warning(
                "hld_sources_exceed_cap", sources=source_count, cap=MAX_GRAPH_NODES
            )
        log.warning(
            "hld_nodes_truncated", produced=len(nodes), cap=MAX_GRAPH_NODES
        )
        nodes = nodes[:MAX_GRAPH_NODES]
    kept_ids = {n.id for n in nodes}
    # Drop edges whose endpoints were trimmed away.
    edges = [e for e in edges if e.from_ in kept_ids and e.to in kept_ids]
    if len(edges) > MAX_GRAPH_EDGES:
        log.warning(
            "hld_edges_truncated", produced=len(edges), cap=MAX_GRAPH_EDGES
        )
        edges = edges[:MAX_GRAPH_EDGES]
    return nodes, edges


# --------------------------------------------------------------------------- #
# Source-diagram selection (decoupled from SourceStore so compose stays testable).
# --------------------------------------------------------------------------- #
async def accepted_source_diagrams_for_notebook(
    store: DiagramStore, principal: Principal, *, notebook_id: str
) -> list[Any]:
    """The accepted source diagrams that belong to ``notebook_id`` (owner-scoped).

    A diagram is a notebook member when its source's ``notebook`` ref points at this
    notebook. We read the owner's accepted "source" diagrams, then keep those whose ref
    source is in the notebook — resolved via :class:`~docx_app.domain.source.SourceStore`.
    The import is local to avoid a hard module dependency from compose on the source domain.
    Returns latest-accepted per source. Reused by the rebuild endpoint for the Path-C upsert
    loop so source selection is defined once (the registry upsert and the compose see the
    exact same member set).
    """
    from docx_app.domain.source import SourceStore  # local: avoid import cycle / coupling

    rows = await store.list(principal, surface=_SURFACE_SOURCE)
    accepted = [d for d in rows if d.status == "accepted"]
    if not accepted:
        return []

    source_store = SourceStore(store._repo)  # same repo; owner-scoped reads  # noqa: SLF001
    members: list[Any] = []
    seen_refs: set[str] = set()
    for diagram in accepted:
        ref = diagram.ref or ""
        if not ref or ref in seen_refs:
            continue  # one (latest) accepted diagram per source
        src = await source_store.get(ref, principal, focus=True)
        if src is not None and (src.notebook or "") == notebook_id:
            members.append(diagram)
            seen_refs.add(ref)
    return members


def _source_title(diagram: Any) -> str:
    """A human label for a source node — falls back to a short, stable handle.

    The source's title isn't on the diagram row; compose builds the label from the source
    ref (the stable, owner-private-but-non-leaky handle the user already knows), trimmed of
    the table prefix. The endpoint may enrich this with the real source title; compose keeps
    a deterministic default so the graph is self-contained.
    """
    ref = (diagram.ref or "").split(":", 1)
    handle = ref[1] if len(ref) == 2 and ref[1] else (diagram.ref or "Source")
    return f"Source {handle}"


def _has_key(candidates: list[NotebookEntity], key: str) -> bool:
    return any(c.entity_key == key for c in candidates)


def _candidate_id(candidates: list[NotebookEntity], key: str) -> str | None:
    for candidate in candidates:
        if candidate.entity_key == key:
            return candidate.id
    return None


async def _safe_embed(
    embed_fn: EmbedFn, label: str, description: str | None
) -> list[float] | None:
    """Embed a new-entity label via the async ``embed_fn``; ``None`` on failure.

    Used when Path B registers a brand-new entity at compose time. With the local lexical
    hash embedder this still returns a (lexical) vector, which is fine — it just won't match
    synonyms (sub-design §9). An embedder failure degrades to ``None`` (a missing embedding
    never blocks a registry write), logged at warning.
    """
    text = label if not description else f"{label} — {description}"
    try:
        return await embed_fn(text)
    except Exception as exc:  # noqa: BLE001 - embedding is best-effort, never fatal
        log.warning("hld_new_entity_embedding_failed", error=str(exc))
        return None


__all__ = [
    "ComposeResult",
    "compose_notebook_hld",
    "accepted_source_diagrams_for_notebook",
    "MIN_SOURCES_FOR_BRIDGE",
]
