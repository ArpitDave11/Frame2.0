"""Optional export: ``DiagramGraph`` → Mermaid ``flowchart`` text.

One of the optional, emit-only renderers over the canonical ``DiagramGraph``
(design: ``docs/2026-06-06-diagram-platform-design.md`` §4) — a quick text /
diff-friendly view. The primary renderer is the custom SVG renderer; Mermaid is
never on the critical path and is *not* rendered in the browser by DocEX (we emit
the text, the user renders it wherever they like). There is no runtime Mermaid
dependency here — this is pure string emission.

Ported from gitdiagram's ``compile_diagram_graph`` (``backend/app/services/
graph_service.py``): the ``flowchart TD`` structure, ``subgraph`` grouping, the
per-shape node rendering, the edge rendering, the ``_escape_mermaid_text`` helper,
and the tone ``classDef`` palette are gitdiagram's, kept faithfully.

DocEX adaptations vs gitdiagram:
  - gitdiagram emitted ``click`` directives that built **GitHub** URLs from the
    repo-only ``node.path``. DocEX dropped ``path`` in favour of ``node.link``
    (any addressable file/dir/url), so ``click`` now points at ``node.link`` and
    opens it in a new tab (``_blank``) — matching the design's link-opens-new-tab
    semantics for every surface (source/notebook/repograph).
  - the repo-relative file-name hint (``_file_hint_for_node``) is dropped (it was
    ``path``-derived). The node's ``type`` is still shown as secondary detail when
    informative (gitdiagram's generic-type guard, kept).
  - ``animated`` / ``flow`` have no Mermaid representation (Mermaid flowchart has
    no per-edge animation); they are intentionally ignored here. Animated edges
    are a live-canvas affordance of the SVG renderer only.

Determinism: output is a pure function of the input graph (input ordering
preserved, stable ids), so it is snapshot-testable.
"""

from __future__ import annotations

from docx_app.diagram.model import (
    DiagramGraph,
    DiagramGraphEdge,
    DiagramGraphNode,
)

# Types so generic they add no signal as a node's secondary detail (gitdiagram).
_GENERIC_NODE_TYPES: frozenset[str] = frozenset(
    {
        "node",
        "component",
        "module",
        "service",
        "system",
        "box",
        "element",
        "item",
    }
)

# Tone palette for group-based node coloring (VERBATIM from gitdiagram). These are
# plain Mermaid ``classDef`` lines (text), not a runtime style dependency.
_TONE_CLASS_NAMES: tuple[str, ...] = (
    "toneNeutral",
    "toneBlue",
    "toneAmber",
    "toneMint",
    "toneRose",
    "toneIndigo",
    "toneTeal",
)


def _escape_mermaid_text(value: str) -> str:
    """Escape a string for use inside a Mermaid quoted label (VERBATIM gitdiagram)."""
    return value.replace("\\", "\\\\").replace('"', '\\"').strip()


def _mermaid_node_id(node_id: str) -> str:
    """Namespace a node id for the Mermaid graph (VERBATIM gitdiagram)."""
    return f"node_{node_id}"


def _mermaid_group_id(group_id: str) -> str:
    """Namespace a group id for the Mermaid subgraph (VERBATIM gitdiagram)."""
    return f"group_{group_id}"


def _detail_for_node(node: DiagramGraphNode) -> str | None:
    """Return ``node.type`` as secondary detail iff it adds signal (gitdiagram).

    Suppressed when the type is generic, mirrors/contains the label, or is long
    (>4 words) — to avoid noisy, redundant secondary lines.
    """
    node_type = node.type.strip()
    if not node_type:
        return None

    normalized_type = node_type.lower()
    normalized_label = node.label.strip().lower()
    if (
        normalized_type in _GENERIC_NODE_TYPES
        or normalized_type == normalized_label
        or normalized_type in normalized_label
        or normalized_label in normalized_type
        or len(node_type.split()) > 4
    ):
        return None

    return _escape_mermaid_text(node_type)


def _node_label(node: DiagramGraphNode) -> str:
    """Build the (possibly multi-line) Mermaid label: primary label + type hint."""
    primary_label = _escape_mermaid_text(node.label)
    secondary_detail = _detail_for_node(node)
    return "<br/>".join(
        detail for detail in (primary_label, secondary_detail) if detail
    )


def _render_node(node: DiagramGraphNode) -> str:
    """Render one node declaration with its shape (ported from gitdiagram).

    gitdiagram special-cases database/circle/hexagon; everything else (box, plus
    DocEX's queue/document for which Mermaid flowchart has no distinct native
    glyph) renders as the default rectangle.
    """
    label = _node_label(node)
    shape = node.shape or "box"
    node_id = _mermaid_node_id(node.id)
    if shape == "database":
        return f'{node_id}[("{label}")]'
    if shape == "circle":
        return f'{node_id}(("{label}"))'
    if shape == "hexagon":
        return f'{node_id}{{{{"{label}"}}}}'
    return f'{node_id}["{label}"]'


def _render_edge(edge: DiagramGraphEdge) -> str:
    """Render one edge (ported from gitdiagram); dashed → ``-.->``.

    ``animated`` / ``flow`` are not representable in Mermaid flowchart and are
    deliberately ignored (live-canvas-only affordances of the SVG renderer).
    """
    connector = "-.->" if edge.style == "dashed" else "-->"
    from_id = _mermaid_node_id(edge.from_)
    to_id = _mermaid_node_id(edge.to)
    if edge.label:
        return f'{from_id} {connector}|"{_escape_mermaid_text(edge.label)}"| {to_id}'
    return f"{from_id} {connector} {to_id}"


def _tone_class(group_id: str | None, group_order: dict[str, int]) -> str:
    """Pick a tone class for a node by its group (VERBATIM gitdiagram)."""
    if not group_id:
        return "toneNeutral"
    index = group_order.get(group_id)
    if index is None:
        return "toneNeutral"
    return _TONE_CLASS_NAMES[index % len(_TONE_CLASS_NAMES)]


def to_mermaid(graph: DiagramGraph) -> str:
    """Render ``graph`` as Mermaid ``flowchart TD`` text.

    Groups become ``subgraph`` blocks; nodes render with their shape; edges with
    dashed/solid connectors and optional labels; nodes with a ``link`` get a
    ``click`` directive opening the link in a new tab. Group-based tone classes
    color the nodes. Output is a deterministic, self-contained Mermaid string.

    (Adapted from gitdiagram's ``compile_diagram_graph``; the GitHub-URL ``click``
    is replaced with a generic ``node.link`` ``click ... _blank``.)
    """
    lines: list[str] = ["flowchart TD"]
    grouped_node_ids: set[str] = set()
    class_assignments: dict[str, list[str]] = {}
    group_order = {group.id: index for index, group in enumerate(graph.groups)}

    def push_node(node: DiagramGraphNode, indent: str = "") -> None:
        lines.append(f"{indent}{_render_node(node)}")
        class_name = _tone_class(node.groupId, group_order)
        class_assignments.setdefault(class_name, []).append(node.id)

    # --- Grouped nodes inside subgraphs (input order preserved) ---
    for group in graph.groups:
        lines.append("")
        lines.append(
            f'subgraph {_mermaid_group_id(group.id)}["{_escape_mermaid_text(group.label)}"]'
        )
        for node in (n for n in graph.nodes if n.groupId == group.id):
            push_node(node, "  ")
            grouped_node_ids.add(node.id)
        lines.append("end")

    # --- Ungrouped nodes ---
    ungrouped_nodes = [node for node in graph.nodes if node.id not in grouped_node_ids]
    if ungrouped_nodes:
        lines.append("")
        for node in ungrouped_nodes:
            push_node(node)

    # --- Edges ---
    if graph.edges:
        lines.append("")
        for edge in graph.edges:
            lines.append(_render_edge(edge))

    # --- Click directives → open node.link in a new tab (DocEX adaptation) ---
    nodes_with_links = [node for node in graph.nodes if node.link]
    if nodes_with_links:
        lines.append("")
        for node in nodes_with_links:
            # node.link is non-None here (filtered above); guard for the type checker.
            link = node.link or ""
            lines.append(
                f'click {_mermaid_node_id(node.id)} "{_escape_mermaid_text(link)}" _blank'
            )

    # --- Tone classDefs (VERBATIM gitdiagram palette) ---
    lines.append("")
    lines.append(
        "classDef toneNeutral fill:#f8fafc,stroke:#334155,stroke-width:1.5px,color:#0f172a"
    )
    lines.append(
        "classDef toneBlue fill:#dbeafe,stroke:#2563eb,stroke-width:1.5px,color:#172554"
    )
    lines.append(
        "classDef toneAmber fill:#fef3c7,stroke:#d97706,stroke-width:1.5px,color:#78350f"
    )
    lines.append(
        "classDef toneMint fill:#dcfce7,stroke:#16a34a,stroke-width:1.5px,color:#14532d"
    )
    lines.append(
        "classDef toneRose fill:#ffe4e6,stroke:#e11d48,stroke-width:1.5px,color:#881337"
    )
    lines.append(
        "classDef toneIndigo fill:#e0e7ff,stroke:#4f46e5,stroke-width:1.5px,color:#312e81"
    )
    lines.append(
        "classDef toneTeal fill:#ccfbf1,stroke:#0f766e,stroke-width:1.5px,color:#134e4a"
    )

    for class_name, node_ids in class_assignments.items():
        if node_ids:
            joined = ",".join(_mermaid_node_id(node_id) for node_id in node_ids)
            lines.append(f"class {joined} {class_name}")

    return "\n".join(lines).strip()


__all__ = ["to_mermaid"]
