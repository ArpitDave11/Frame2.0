"""Server-side static SVG snapshot of a ``DiagramGraph`` (the accepted "picture").

Design: ``docs/2026-06-06-diagram-platform-design.md`` §2 (immutability = DATA +
PICTURE) and §4 (renderers are plugins over ``DiagramGraph``; the accepted SVG
snapshot is **static**). On *accept* the API freezes the data (``graph_json``)
**and** snapshots the rendered picture into ``render_snapshot_svg``; this module
produces that snapshot **on the server**, so the frozen image never depends on a
browser, on ``elkjs``, or on any runtime draw.io path.

Why a separate renderer from the frontend's ``DiagramRenderer.tsx`` / ELK layout:
the live canvas runs ``elkjs`` (async, browser-only) and SMIL animation. Neither
is available server-side, and the accepted snapshot is **static by definition**
(the frontend's ``exportDiagram.ts`` says verbatim: *"The same static-
serialisation is the basis for the backend ``render_snapshot_svg`` accepted
snapshot"* — no ``<animateMotion>``, CSS-variable colours inlined to concrete
values, self-contained). So this is a small, dependency-free, **deterministic**
Python renderer with its own simple layered layout. It is intentionally not a
pixel-for-pixel clone of the live canvas — it is a faithful, frozen still: same
groups, nodes (icon label + type sub-label), and directed edges, in the UBS
palette.

Determinism: the output is a pure function of the input graph (input ordering
preserved, stable ids, a layered BFS layout with a fixed grid), so it is
snapshot-testable and byte-stable across re-emits.

Token note: the colour literals here mirror the **light** theme block of
``frontend/src/components/diagram/diagramTheme.ts`` (which itself mirrors the
``:root`` block of ``globals.css``) — inlined to concrete values exactly as the
frontend's ``inlineTokens`` does for a self-contained export. These are **export
content baked into an SVG string**, not UI markup, so the tokens-only/no-hex
*UI* rule does not apply (same precedent as the gitdiagram ``classDef`` palette
emitted as text by ``to_mermaid.py``). Keeping them in one ``_PALETTE`` dict
makes the single source-of-truth relationship explicit and auditable.

No external dependency, no draw.io, no network: stdlib only.
"""

from __future__ import annotations

from collections import defaultdict, deque
from xml.sax.saxutils import escape, quoteattr

from docx_app.diagram.model import (
    DiagramGraph,
    DiagramGraphEdge,
    DiagramGraphGroup,
    DiagramGraphNode,
)

# --------------------------------------------------------------------------- #
# Palette — concrete values mirroring diagramTheme.ts (light) / globals.css.
# Inlined into the SVG so the snapshot is self-contained (no CSS variables).
# --------------------------------------------------------------------------- #
_PALETTE: dict[str, str] = {
    "background": "#ffffff",  # --background
    "foreground": "#030213",  # --foreground
    "card": "#ffffff",  # --card
    "card_foreground": "#030213",  # --card-foreground
    "primary": "#e60000",  # --primary (UBS red — default edge stroke)
    "muted": "#ececf0",  # --muted (node fill)
    "muted_foreground": "#717182",  # --muted-foreground (type sub-label)
    "border": "#e5e7eb",  # --border (node / group outline)
}
# Chart cycle (mirrors diagramTheme.ts FLOW_TOKENS → --chart-1..5) used to colour
# distinct ``edge.flow`` semantics, matching the live renderer's flowColor().
_FLOW_PALETTE: tuple[str, ...] = (
    "#e60000",  # --chart-1
    "#030213",  # --chart-2
    "#717182",  # --chart-3
    "#b30000",  # --chart-4
    "#9ca3af",  # --chart-5
)

# Typography — a neutral system sans stack baked into the SVG so the standalone
# file renders consistently outside the app (an SVG snapshot is not UI chrome, so
# it carries its own font stack rather than the app's web font).
_FONT_FAMILY = (
    "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, "
    "sans-serif"
)

# --------------------------------------------------------------------------- #
# Layout constants (kept close to the FE sizing in useDiagramLayout.ts so the
# snapshot reads like the live canvas, while staying a self-contained grid).
# --------------------------------------------------------------------------- #
_NODE_W = 150
_NODE_H = 64
_COL_GAP = 56  # horizontal gap between nodes within a layer
_LAYER_GAP = 88  # vertical gap between layers
_GROUP_PAD = 18  # padding inside a group band
_GROUP_HEADER = 26  # group label header height
_GROUP_GAP = 36  # vertical gap between group bands
_MARGIN = 28  # outer canvas margin
_MAX_COLS = 5  # nodes per row before wrapping within a layer/group
_NODE_RX = 10  # node corner radius
_LABEL_SIZE = 13  # node label font size (px)
_TYPE_SIZE = 11  # node type sub-label font size (px)
_GROUP_LABEL_SIZE = 12
_ARROW_LEN = 9  # arrowhead length


class _Box:
    """An axis-aligned placed box (node or group) in canvas pixel coordinates."""

    __slots__ = ("x", "y", "w", "h")

    def __init__(self, x: float, y: float, w: float, h: float) -> None:
        self.x = x
        self.y = y
        self.w = w
        self.h = h

    @property
    def cx(self) -> float:
        return self.x + self.w / 2

    @property
    def cy(self) -> float:
        return self.y + self.h / 2


def _flow_color(flow: str | None) -> str:
    """Stable colour for an ``edge.flow`` key (mirrors diagramTheme.flowColor).

    No flow → the primary accent. A flow key is hashed to a fixed chart colour so
    the same flow reads consistently across the diagram (same algorithm as the
    live renderer, so the snapshot matches its colour choices).
    """
    if not flow:
        return _PALETTE["primary"]
    hash_ = 0
    for ch in flow:
        # Replicate the JS ``(hash * 31 + code) | 0`` 32-bit wrap so colours match.
        hash_ = (hash_ * 31 + ord(ch)) & 0xFFFFFFFF
    if hash_ >= 0x80000000:  # interpret as signed, then take abs (as JS does)
        hash_ -= 0x100000000
    return _FLOW_PALETTE[abs(hash_) % len(_FLOW_PALETTE)]


def _layer_order(graph: DiagramGraph) -> dict[str, int]:
    """Assign each node a layer index via a longest-path-from-source layering.

    A lightweight stand-in for ELK's ``layered`` algorithm: roots (no incoming
    edge) sit at layer 0; every other node sits one below the deepest of its
    predecessors. Cycles are tolerated (a node already assigned is not pushed
    deeper by a back-edge). Deterministic for a given input ordering.
    """
    node_ids = [n.id for n in graph.nodes]
    incoming: dict[str, int] = dict.fromkeys(node_ids, 0)
    adj: dict[str, list[str]] = defaultdict(list)
    id_set = set(node_ids)
    for edge in graph.edges:
        if edge.from_ in id_set and edge.to in id_set and edge.from_ != edge.to:
            adj[edge.from_].append(edge.to)
            incoming[edge.to] += 1

    layer: dict[str, int] = dict.fromkeys(node_ids, 0)
    # Kahn-style traversal from roots so layers respect edge direction. Nodes not
    # reached (pure cycles) keep layer 0 — still rendered, just at the top.
    queue: deque[str] = deque(nid for nid in node_ids if incoming[nid] == 0)
    remaining = dict(incoming)
    seen: set[str] = set(queue)
    while queue:
        nid = queue.popleft()
        for nxt in adj[nid]:
            if layer[nxt] < layer[nid] + 1:
                layer[nxt] = layer[nid] + 1
            remaining[nxt] -= 1
            if remaining[nxt] <= 0 and nxt not in seen:
                seen.add(nxt)
                queue.append(nxt)
    return layer


def _grid_positions(
    count: int, origin_x: float, origin_y: float, max_cols: int
) -> list[tuple[float, float]]:
    """Top-left corners for ``count`` node boxes in a left-aligned grid."""
    positions: list[tuple[float, float]] = []
    for idx in range(count):
        row, col = divmod(idx, max_cols)
        x = origin_x + col * (_NODE_W + _COL_GAP)
        y = origin_y + row * (_NODE_H + _LAYER_GAP)
        positions.append((x, y))
    return positions


def _layout(
    graph: DiagramGraph,
) -> tuple[dict[str, _Box], dict[str, _Box], float, float]:
    """Place every node and group, returning (node_boxes, group_boxes, w, h).

    Two layout modes, mirroring the FE's compound-vs-flat split:

    * **Grouped** (any ``groups``): each group is a horizontal band stacked
      top-to-bottom; its member nodes flow in a wrapped grid inside it; ungrouped
      nodes form a trailing band. Keeps the picture readable and matches how the
      live canvas nests grouped nodes.
    * **Flat** (no groups): nodes are placed by layer (BFS layering above), each
      layer a centred row — a clean top-down architecture read.
    """
    node_boxes: dict[str, _Box] = {}
    group_boxes: dict[str, _Box] = {}

    if graph.groups:
        # --- Compound layout: stacked group bands ---
        members_by_group: dict[str, list[str]] = {g.id: [] for g in graph.groups}
        ungrouped: list[str] = []
        valid_group_ids = set(members_by_group)
        for node in graph.nodes:
            if node.groupId and node.groupId in valid_group_ids:
                members_by_group[node.groupId].append(node.id)
            else:
                ungrouped.append(node.id)

        cursor_y: float = _MARGIN
        max_right: float = _MARGIN

        def place_band(
            label_members: list[str], group: DiagramGraphGroup | None
        ) -> None:
            nonlocal cursor_y, max_right
            members = label_members
            inner_x = _MARGIN + _GROUP_PAD
            inner_y = cursor_y + _GROUP_HEADER
            if not members:
                # Empty group: still draw the band so its label survives.
                band_h = _GROUP_HEADER + _GROUP_PAD
                band_w = _NODE_W + 2 * _GROUP_PAD
                if group is not None:
                    group_boxes[group.id] = _Box(_MARGIN, cursor_y, band_w, band_h)
                cursor_y += band_h + _GROUP_GAP
                max_right = max(max_right, _MARGIN + band_w)
                return
            positions = _grid_positions(len(members), inner_x, inner_y, _MAX_COLS)
            for nid, (x, y) in zip(members, positions, strict=True):
                node_boxes[nid] = _Box(x, y, _NODE_W, _NODE_H)
            rows = (len(members) + _MAX_COLS - 1) // _MAX_COLS
            cols = min(len(members), _MAX_COLS)
            inner_w = cols * _NODE_W + (cols - 1) * _COL_GAP
            inner_h = rows * _NODE_H + (rows - 1) * _LAYER_GAP
            band_w = inner_w + 2 * _GROUP_PAD
            band_h = _GROUP_HEADER + inner_h + _GROUP_PAD
            if group is not None:
                group_boxes[group.id] = _Box(_MARGIN, cursor_y, band_w, band_h)
            cursor_y += band_h + _GROUP_GAP
            max_right = max(max_right, _MARGIN + band_w)

        for group in graph.groups:
            place_band(members_by_group[group.id], group)
        if ungrouped:
            place_band(ungrouped, None)

        width: float = max_right + _MARGIN
        height: float = cursor_y - _GROUP_GAP + _MARGIN
        return node_boxes, group_boxes, width, height

    # --- Flat layout: centred layered rows ---
    layer = _layer_order(graph)
    by_layer: dict[int, list[str]] = defaultdict(list)
    for node in graph.nodes:  # preserve input order within a layer
        by_layer[layer[node.id]].append(node.id)

    # First pass: per-layer row widths to compute the centred canvas width.
    layer_widths: dict[int, float] = {}
    for lvl, ids in by_layer.items():
        cols = min(len(ids), _MAX_COLS)
        layer_widths[lvl] = cols * _NODE_W + (cols - 1) * _COL_GAP
    content_w = max(layer_widths.values()) if layer_widths else _NODE_W

    flat_cursor_y: float = _MARGIN
    for lvl in sorted(by_layer):
        ids = by_layer[lvl]
        rows = (len(ids) + _MAX_COLS - 1) // _MAX_COLS
        row_w = layer_widths[lvl]
        origin_x = _MARGIN + (content_w - row_w) / 2  # centre this layer's row
        positions = _grid_positions(len(ids), origin_x, flat_cursor_y, _MAX_COLS)
        for nid, (x, y) in zip(ids, positions, strict=True):
            node_boxes[nid] = _Box(x, y, _NODE_W, _NODE_H)
        flat_cursor_y += rows * _NODE_H + (rows - 1) * _LAYER_GAP + _LAYER_GAP

    flat_width: float = _MARGIN + content_w + _MARGIN
    flat_height: float = flat_cursor_y - _LAYER_GAP + _MARGIN
    # Guard against a degenerate empty canvas (min one node is enforced by Pydantic).
    return node_boxes, group_boxes, max(flat_width, _NODE_W), max(flat_height, _NODE_H)


def _f(value: float) -> str:
    """Format a coordinate compactly (ints stay int-like; floats to 2 dp)."""
    if value == int(value):
        return str(int(value))
    return f"{value:.2f}"


def _edge_endpoints(src: _Box, dst: _Box) -> tuple[float, float, float, float]:
    """A straight segment from the source box edge to the target box edge.

    Anchors on the nearer vertical face when boxes are mostly side-by-side, else
    on the horizontal face — a simple, deterministic border-to-border routing
    that avoids lines starting inside a box.
    """
    dx = dst.cx - src.cx
    dy = dst.cy - src.cy
    if abs(dy) >= abs(dx):
        # Vertical-dominant: bottom of src → top of dst (or reversed).
        if dy >= 0:
            return src.cx, src.y + src.h, dst.cx, dst.y
        return src.cx, src.y, dst.cx, dst.y + dst.h
    # Horizontal-dominant: right of src → left of dst (or reversed).
    if dx >= 0:
        return src.x + src.w, src.cy, dst.x, dst.cy
    return src.x, src.cy, dst.x + dst.w, dst.cy


def _node_svg(node: DiagramGraphNode, box: _Box) -> list[str]:
    """SVG for one node: a rounded card with a label and a type sub-label.

    Icon nodes show their ``icon`` id as a small monospace tag below the type
    (we do not embed Azure artwork in the snapshot — the names are a controlled
    vocabulary; bundling the SVG bytes is a separate governed concern per design
    §12). The card is the muted fill with a border, matching the live ShapeNode.
    """
    cx = _f(box.cx)
    label = escape(node.label)
    type_text = escape(node.type) if node.type else ""
    parts: list[str] = [
        f"    <g data-node-id={quoteattr(node.id)}>",
        (
            f'      <rect x="{_f(box.x)}" y="{_f(box.y)}" '
            f'width="{_f(box.w)}" height="{_f(box.h)}" rx="{_NODE_RX}" '
            f'fill="{_PALETTE["muted"]}" stroke="{_PALETTE["border"]}" '
            f'stroke-width="1.5" />'
        ),
    ]
    if type_text:
        # Two-line stack: label above centre, type below.
        parts.append(
            f'      <text x="{cx}" y="{_f(box.cy - 4)}" text-anchor="middle" '
            f'font-family="{_FONT_FAMILY}" font-size="{_LABEL_SIZE}" '
            f'font-weight="600" fill="{_PALETTE["card_foreground"]}">{label}</text>'
        )
        parts.append(
            f'      <text x="{cx}" y="{_f(box.cy + 13)}" text-anchor="middle" '
            f'font-family="{_FONT_FAMILY}" font-size="{_TYPE_SIZE}" '
            f'fill="{_PALETTE["muted_foreground"]}">{type_text}</text>'
        )
    else:
        parts.append(
            f'      <text x="{cx}" y="{_f(box.cy + 4)}" text-anchor="middle" '
            f'font-family="{_FONT_FAMILY}" font-size="{_LABEL_SIZE}" '
            f'font-weight="600" fill="{_PALETTE["card_foreground"]}">{label}</text>'
        )
    parts.append("    </g>")
    return parts


def _group_svg(group: DiagramGraphGroup, box: _Box) -> list[str]:
    """SVG for a group band: a dashed rounded container with a header label."""
    label = escape(group.label)
    return [
        f"    <g data-group-id={quoteattr(group.id)}>",
        (
            f'      <rect x="{_f(box.x)}" y="{_f(box.y)}" '
            f'width="{_f(box.w)}" height="{_f(box.h)}" rx="{_NODE_RX}" '
            f'fill="none" stroke="{_PALETTE["border"]}" stroke-width="1.5" '
            f'stroke-dasharray="6 4" />'
        ),
        (
            f'      <text x="{_f(box.x + _GROUP_PAD)}" '
            f'y="{_f(box.y + _GROUP_LABEL_SIZE + 4)}" '
            f'font-family="{_FONT_FAMILY}" font-size="{_GROUP_LABEL_SIZE}" '
            f'font-weight="700" fill="{_PALETTE["muted_foreground"]}">{label}</text>'
        ),
        "    </g>",
    ]


def _edge_svg(edge: DiagramGraphEdge, src: _Box, dst: _Box, index: int) -> list[str]:
    """SVG for one directed edge: a line (+ optional label), with an arrowhead.

    The snapshot is **static** (design §4): an ``animated`` edge is drawn as a
    plain solid stroke in its flow colour (no SMIL ``<animateMotion>``); only
    ``style == "dashed"`` changes the dash pattern. The arrowhead is an inline
    polygon (not a shared ``<marker>``) so each arrow can take its own per-edge
    flow colour.
    """
    x1, y1, x2, y2 = _edge_endpoints(src, dst)
    color = _flow_color(edge.flow)
    dash = ' stroke-dasharray="7 5"' if edge.style == "dashed" else ""
    lines = [
        f'    <g data-edge-index="{index}">',
        (
            f'      <line x1="{_f(x1)}" y1="{_f(y1)}" x2="{_f(x2)}" y2="{_f(y2)}" '
            f'stroke="{color}" stroke-width="2"{dash} />'
        ),
        _arrowhead(x1, y1, x2, y2, color),
    ]
    if edge.label:
        mx = (x1 + x2) / 2
        my = (y1 + y2) / 2
        label = escape(edge.label)
        # A small backing rect keeps the label legible over a crossing line.
        approx_w = max(len(edge.label) * 7 + 8, 16)
        lines.append(
            f'      <rect x="{_f(mx - approx_w / 2)}" y="{_f(my - 9)}" '
            f'width="{_f(approx_w)}" height="16" rx="3" '
            f'fill="{_PALETTE["background"]}" opacity="0.9" />'
        )
        lines.append(
            f'      <text x="{_f(mx)}" y="{_f(my + 3)}" text-anchor="middle" '
            f'font-family="{_FONT_FAMILY}" font-size="11" '
            f'fill="{_PALETTE["muted_foreground"]}">{label}</text>'
        )
    lines.append("    </g>")
    return lines


def _arrowhead(x1: float, y1: float, x2: float, y2: float, color: str) -> str:
    """An inline filled triangle at (x2, y2) pointing along the segment.

    Inline (not a shared ``<marker>``) so each arrow takes its own edge colour.
    Degenerate zero-length segments fall back to an upward arrow.
    """
    dx = x2 - x1
    dy = y2 - y1
    length = (dx * dx + dy * dy) ** 0.5
    if length == 0:
        ux, uy = 0.0, 1.0
    else:
        ux, uy = dx / length, dy / length
    # Perpendicular unit vector for the two base corners.
    px, py = -uy, ux
    half_w = _ARROW_LEN * 0.5
    bx, by = x2 - ux * _ARROW_LEN, y2 - uy * _ARROW_LEN
    p1 = f"{_f(x2)},{_f(y2)}"
    p2 = f"{_f(bx + px * half_w)},{_f(by + py * half_w)}"
    p3 = f"{_f(bx - px * half_w)},{_f(by - py * half_w)}"
    return f'      <polygon points="{p1} {p2} {p3}" fill="{color}" />'


def render_snapshot_svg(graph: DiagramGraph, *, title: str | None = None) -> str:
    """Render ``graph`` as a self-contained, **static** SVG snapshot string.

    This is the picture frozen into ``diagram.render_snapshot_svg`` on accept. The
    result is a complete ``<svg>`` document (its own font stack and concrete
    colours, no CSS variables, no SMIL animation, no external refs), so it renders
    identically anywhere — embedded as an ``<img>``, downloaded, or shown in the
    accepted view — with no browser layout engine, no ``elkjs``, and no draw.io.

    Output is a deterministic pure function of ``graph`` (and ``title``), so it is
    snapshot-testable and stable across re-emits.

    Args:
        graph: the validated canonical :class:`DiagramGraph`.
        title: optional caption rendered at the top-left (e.g. the source title).

    Returns:
        An ``<?xml ...?>``-prefixed standalone SVG document string.
    """
    node_boxes, group_boxes, width, height = _layout(graph)

    title_h = 0.0
    if title and title.strip():
        title_h = 30.0  # reserve a caption strip and shift content down

    total_w = max(width, _NODE_W + 2 * _MARGIN)
    total_h = max(height + title_h, _NODE_H + 2 * _MARGIN)
    shift = title_h

    body: list[str] = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        (
            f'<svg xmlns="http://www.w3.org/2000/svg" '
            f'width="{_f(total_w)}" height="{_f(total_h)}" '
            f'viewBox="0 0 {_f(total_w)} {_f(total_h)}" '
            f'role="img" aria-label={quoteattr(title or "Architecture diagram")}>'
        ),
        # Solid background so the file isn't transparent (FE export does the same).
        f'  <rect x="0" y="0" width="{_f(total_w)}" height="{_f(total_h)}" '
        f'fill="{_PALETTE["background"]}" />',
    ]

    if title and title.strip():
        body.append(
            f'  <text x="{_MARGIN}" y="20" font-family="{_FONT_FAMILY}" '
            f'font-size="14" font-weight="700" '
            f'fill="{_PALETTE["foreground"]}">{escape(title.strip())}</text>'
        )

    # Single content group, shifted below the caption strip. A nested transform
    # keeps node/group/edge coordinates (computed at origin) authoritative.
    body.append(f'  <g transform="translate(0 {_f(shift)})">')

    # Groups first (behind their member nodes).
    for group in graph.groups:
        box = group_boxes.get(group.id)
        if box is not None:
            body.extend(_group_svg(group, box))

    # Edges next (behind nodes so node cards sit on top of the lines).
    for index, edge in enumerate(graph.edges):
        src = node_boxes.get(edge.from_)
        dst = node_boxes.get(edge.to)
        if src is None or dst is None:
            continue  # a validated graph won't hit this, but never crash the snapshot
        body.extend(_edge_svg(edge, src, dst, index))

    # Nodes on top.
    for node in graph.nodes:
        box = node_boxes.get(node.id)
        if box is not None:
            body.extend(_node_svg(node, box))

    body.append("  </g>")
    body.append("</svg>")
    return "\n".join(body)


__all__ = ["render_snapshot_svg"]
