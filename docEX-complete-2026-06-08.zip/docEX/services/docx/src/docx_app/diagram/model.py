"""The canonical, render-agnostic diagram graph model + its validator.

Ported VERBATIM from gitdiagram (`backend/app/services/graph_service.py`) and
then extended for DocEX. The base shape, the `Field(...)` limits, the validator,
and the MAX_* constants are gitdiagram's, unchanged — so the proven 2-step LLM
pipeline's structured-output contract carries over directly.

DocEX additions (design: `docs/2026-06-06-diagram-platform-design.md` §2):
  - on `DiagramGraphNode`: `icon`, `link`, `drill`, `entity`, `meta`
    (and gitdiagram's repo-only `path` is dropped — `link` supersedes it).
  - on `DiagramGraphEdge`: `animated`, `flow`.

All DocEX additions are optional (`= None`). The gitdiagram-native *nullable*
fields (group/node/edge `description`, node `groupId`/`shape`, edge `label`/`style`)
are also given `= None` defaults — a deliberate divergence from gitdiagram's bare
`Field(...)`: gitdiagram leans on OpenAI structured outputs to force every field
present, but DocEX's local `claude_cli` path validates FREE JSON, where models
routinely omit a genuinely-null field. Defaulting them to None makes an omission
valid (it means "null", exactly as the prompt instructs) instead of forcing a
wasted retry. The required identity fields (ids, node `label`/`type`, edge
`from`/`to`) stay required.

The optional `entity` field is a pure DATA field for the later notebook-HLD
entity registry (see `docs/2026-06-07-entity-resolution-subdesign.md`); nothing
in Surface 1 consumes it — do NOT add resolution logic here.

Serialisation note: `DiagramGraphEdge.from_` is aliased to ``"from"`` (a Python
keyword). Always serialise with ``model_dump(by_alias=True)`` so stored JSON has
``"from"``, and always load with ``model_validate(...)`` (never ``**dict``) so
``"from"`` maps back to ``from_``.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

# --- Limits (VERBATIM from gitdiagram graph_service.py) --------------------
MAX_GRAPH_ATTEMPTS = 3
MAX_GRAPH_GROUPS = 10
MAX_GRAPH_NODES = 34
MAX_GRAPH_EDGES = 48


class DiagramGraphGroup(BaseModel):
    """A single-level visual grouping of nodes (gitdiagram core + DocEX ``repeat``)."""

    id: str = Field(pattern=r"^[a-z][a-z0-9_]*$")
    label: str = Field(min_length=1, max_length=72)
    description: str | None = Field(default=None, max_length=240)
    # DocEX addition: a repeated-stack annotation, e.g. a Transformer's encoder block "6x".
    repeat: str | None = Field(default=None, max_length=12)


class DiagramGraphNode(BaseModel):
    """A node in the architecture graph.

    gitdiagram core (verbatim) + DocEX fields. gitdiagram's repo-only ``path``
    field is intentionally dropped here — ``link`` replaces it (an addressable
    file/dir/url rather than a repo-relative path validated against a file tree).
    """

    # --- gitdiagram core (verbatim, minus `path`) ---
    id: str = Field(pattern=r"^[a-z][a-z0-9_]*$")
    label: str = Field(min_length=1, max_length=72)
    type: str = Field(min_length=1, max_length=72)
    description: str | None = Field(default=None, max_length=240)
    groupId: str | None = Field(default=None, pattern=r"^[a-z][a-z0-9_]*$")
    shape: (
        Literal[
            "box",
            "database",
            "queue",
            "document",
            "circle",
            "hexagon",
            "diamond",
            "cloud",
            "person",
        ]
        | None
    ) = None
    # --- DocEX additions (all optional) ---
    icon: str | None = (
        None  # e.g. "azure/compute/Virtual_Machine"; null if not an Azure service
    )
    link: str | None = None  # addressable file/dir/url → renderer opens in a new tab
    drill: str | None = (
        None  # id of a deeper sub-graph to zoom into (app-managed; LLM emits null)
    )
    entity: str | None = (
        None  # canonical shared-entity key (notebook registry; later phase)
    )
    meta: dict[str, Any] | None = (
        None  # omm per-node {description, constraint, concern, context}
    )


class DiagramGraphEdge(BaseModel):
    """A directed edge between two nodes.

    gitdiagram core (verbatim) + DocEX ``animated``/``flow``. ``from_`` is
    aliased to ``"from"``; ``populate_by_name`` lets it be set by either name.
    """

    # --- gitdiagram core (verbatim) ---
    from_: str = Field(alias="from", pattern=r"^[a-z][a-z0-9_]*$")
    to: str = Field(pattern=r"^[a-z][a-z0-9_]*$")
    label: str | None = Field(default=None, min_length=1, max_length=72)
    description: str | None = Field(default=None, max_length=240)
    style: Literal["solid", "dashed"] | None = None
    # --- DocEX additions (all optional) ---
    animated: bool | None = (
        None  # live-canvas only → renderer adds <animateMotion> particle/gradient
    )
    flow: str | None = (
        None  # short flow color/semantics hint (e.g. "read"/"write"/"event")
    )

    model_config = {"populate_by_name": True}


class DiagramGraph(BaseModel):
    """The whole graph (VERBATIM from gitdiagram — same Field limits)."""

    groups: list[DiagramGraphGroup] = Field(max_length=MAX_GRAPH_GROUPS)
    nodes: list[DiagramGraphNode] = Field(min_length=1, max_length=MAX_GRAPH_NODES)
    edges: list[DiagramGraphEdge] = Field(max_length=MAX_GRAPH_EDGES)


class GraphValidationIssue(BaseModel):
    """One structural problem found by :func:`validate_diagram_graph`."""

    path: str
    message: str


def build_file_tree_lookup(file_tree: str) -> set[str]:
    """Set of repo-relative paths from a newline-delimited file tree (gitdiagram).

    For SOURCE/document diagrams there is no file tree — pass ``set()`` (or call
    this on ``""``); document nodes don't carry ``link`` values to validate
    against a tree, so no false failures occur.
    """
    return {entry.strip() for entry in file_tree.splitlines() if entry.strip()}


def validate_diagram_graph(
    graph: DiagramGraph, file_tree_lookup: set[str]
) -> list[GraphValidationIssue]:
    """Structural validation beyond Pydantic (VERBATIM from gitdiagram).

    Catches duplicate group/node ids, edges referencing unknown nodes, nodes in
    unknown groups, and (for repo diagrams) ``link`` values absent from the file
    tree. ``file_tree_lookup`` is ``set()`` for source diagrams (no file tree).
    """
    issues: list[GraphValidationIssue] = []
    group_ids: set[str] = set()
    node_ids: set[str] = set()

    for index, group in enumerate(graph.groups):
        if group.id in group_ids:
            issues.append(
                GraphValidationIssue(
                    path=f"groups.{index}.id",
                    message=f'Duplicate group id "{group.id}".',
                )
            )
        group_ids.add(group.id)

    for index, node in enumerate(graph.nodes):
        if node.id in node_ids:
            issues.append(
                GraphValidationIssue(
                    path=f"nodes.{index}.id",
                    message=f'Duplicate node id "{node.id}".',
                )
            )
        node_ids.add(node.id)

        if node.groupId and node.groupId not in group_ids:
            issues.append(
                GraphValidationIssue(
                    path=f"nodes.{index}.groupId",
                    message=f'Unknown group id "{node.groupId}" for node "{node.id}".',
                )
            )

        # gitdiagram validated `node.path` against the repo file tree. DocEX drops
        # `path` in favour of `link`; only enforce link-in-tree when a file tree was
        # provided (repo diagrams). For source diagrams `file_tree_lookup` is empty,
        # so this never fires.
        if node.link and file_tree_lookup and node.link not in file_tree_lookup:
            issues.append(
                GraphValidationIssue(
                    path=f"nodes.{index}.link",
                    message=f'Link "{node.link}" does not exist in the repository file tree.',
                )
            )

    for index, edge in enumerate(graph.edges):
        if edge.from_ not in node_ids:
            issues.append(
                GraphValidationIssue(
                    path=f"edges.{index}.from",
                    message=f'Unknown source node id "{edge.from_}".',
                )
            )
        if edge.to not in node_ids:
            issues.append(
                GraphValidationIssue(
                    path=f"edges.{index}.to",
                    message=f'Unknown target node id "{edge.to}".',
                )
            )

    return issues


def format_graph_validation_feedback(issues: list[GraphValidationIssue]) -> str:
    """Render issues as the ``<validation_feedback>`` body for a retry (gitdiagram)."""
    return "\n".join(f"{issue.path}: {issue.message}" for issue in issues)
