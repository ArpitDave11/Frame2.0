"""The shared-entity registry — the Notebook-HLD backbone (Surface 2).

Sub-design: ``docs/2026-06-07-entity-resolution-subdesign.md`` §3 (data model), §4
(Path C — controlled-vocab upsert at accept time), §6 (human override: merge / split /
lock). This module owns the **registry** itself: the :class:`NotebookEntity` row model,
the owner-scoped :class:`EntityRegistryStore` (mirroring
:class:`~docx_app.diagram.domain.DiagramStore` and
:class:`~docx_app.domain.note.NoteStore` exactly), the normalization helper used by both
Path C and the Path-B reconciler, and the human-override merge/split helpers.

The compose-time reconciliation **cascade** (normalize → embed → LLM-adjudicate the
ambiguous tail) lives in :mod:`docx_app.diagram.reconciler` (the sub-design §5 Path B); it
is re-exported here (:func:`reconcile_node`, :class:`Assignment`) so callers can treat
``entities`` as the registry's single public surface. The split keeps the deterministic
store (this file) cleanly separable from the heuristic/LLM cascade (the reconciler), while
the brief's "entities owns normalize + merge/split + the cascade entry" still holds via the
re-export.

One registry **per notebook** — entities are never shared across notebooks (a notebook is
the unit of "one brain"; cross-notebook resolution is explicitly out of scope, sub-design
§3/§10). Linkage is via :attr:`DiagramGraphNode.entity` (the ``entity_key`` slug); the
frozen source LLDs are never mutated — entity assignments used to build the HLD live only
here and in the composed parent graph (sub-design §5 gotcha 3, §8).

Tenancy: owner-PRIVATE — every write is stamped ``owner`` + ``Scope.PRIVATE`` and every
read is ``select_scoped(focus=True)`` (owner-only). A read with no scope filter is a bug
(see ``tenancy.py`` + the leak test). The SurrealDB ``create_scoped`` returns a
SINGLE-element list — always unwrapped before ``NotebookEntity(**record)`` (the same guard
as ``DiagramStore._to_diagram`` / ``NoteStore._to_note``).
"""

from __future__ import annotations

import hashlib
import math
import re
import unicodedata
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

import structlog
from pydantic import BaseModel, ConfigDict

from docx_app.db import SurrealRepository, ensure_record_id
from docx_app.domain.source import scoped_update
from docx_app.tenancy import Principal, Scope

if TYPE_CHECKING:
    from docx_app.diagram.model import DiagramGraph

# Re-export the Path-B cascade so `entities` is the registry's single public surface.
# (Imported at module end to avoid a circular import: reconciler imports NotebookEntity
# from here.) See the bottom of this file.

log = structlog.get_logger(__name__)


# ===========================================================================
# Normalization (sub-design §5 step 1, "A — the cheap first pass inside B").
# Shared by Path C (write-time alias dedup) and Path B (compose-time matching).
# Deterministic + dependency-free: lowercase, strip accents/punctuation, collapse
# whitespace, naive singularize, strip the architectural suffixes the sub-design
# names. Used to compare an incoming node label against registry labels/aliases.
# ===========================================================================

# Suffix tokens the sub-design §5 step 1 strips so "CustomerService"/"Customer Record"
# normalize toward "customer". Matched as trailing whole tokens (after camel/word split),
# not substrings, so "ServiceBus" is NOT stripped to "bus".
_SUFFIX_TOKENS: frozenset[str] = frozenset(
    {
        "service",
        "services",
        "record",
        "records",
        "manager",
        "controller",
        "handler",
        "component",
        "module",
        "system",
        "api",
        "store",
        "repository",
        "repo",
    }
)

# Split camelCase / PascalCase / snake_case / kebab-case / spaced into word tokens.
# The separator branch must include A-Z (so a leading/standalone capital is NOT treated as a
# separator and silently dropped); the second branch inserts a zero-width boundary at a
# lower/digit→upper transition (camelCase). "CustomerService" -> "Customer Service".
_WORD_SPLIT_RE = re.compile(r"[^a-zA-Z0-9]+|(?<=[a-z0-9])(?=[A-Z])")
# Slug: lowercase words joined by '-'. The model coins slugs in this shape (sub-design §4).
_SLUG_STRIP_RE = re.compile(r"[^a-z0-9]+")


def _word_tokens(value: str) -> list[str]:
    """Split a label into lowercase word tokens (camel/snake/kebab/space aware)."""
    # Insert a boundary before each capital that follows a lower/digit (camelCase),
    # then split on any run of non-alphanumerics. Lowercase last so the camel split sees case.
    spaced = _WORD_SPLIT_RE.sub(" ", value)
    return [tok.lower() for tok in spaced.split() if tok]


def _singularize(token: str) -> str:
    """Naive English singularizer (sub-design §5: "Order"/"Orders" must collapse).

    Handles the common regular plurals only — ``-ies → -y`` (``categories`` → ``category``),
    ``-ses/-xes/-zes/-ches/-shes → drop -es`` (``boxes`` → ``box``), and a trailing ``-s``
    (``orders`` → ``order``) while protecting two-letter tokens and ``-ss`` (``class`` stays
    ``class``). It is intentionally simple — the sub-design only needs regular plurals to
    collapse for the local/string path; the LLM handles the irregular tail.
    """
    if len(token) <= 3:
        return token
    if token.endswith("ies") and len(token) > 4:
        return token[:-3] + "y"
    if token.endswith(("ses", "xes", "zes", "ches", "shes")):
        return token[:-2]
    if token.endswith("s") and not token.endswith("ss"):
        return token[:-1]
    return token


def normalize_label(label: str) -> str:
    """Normalize a node/entity label for exact/alias matching (sub-design §5 step 1).

    lowercase → strip accents → split into word tokens → singularize each → drop the
    trailing architectural suffix token (``service``/``record``/``manager``/…) → re-join
    with spaces. Returns ``""`` for an all-suffix/empty label. Deterministic and
    order-preserving. ``normalize_label("CustomerService") == normalize_label("Customer")``.
    """
    decomposed = unicodedata.normalize("NFKD", label)
    ascii_only = "".join(ch for ch in decomposed if not unicodedata.combining(ch))
    tokens = [_singularize(tok) for tok in _word_tokens(ascii_only)]
    # Strip a single trailing suffix token (e.g. "customer service" -> "customer"), but
    # never strip the only token (so a bare "Service" stays "service", not "").
    if len(tokens) > 1 and tokens[-1] in _SUFFIX_TOKENS:
        tokens = tokens[:-1]
    return " ".join(tokens)


def slugify_entity_key(label: str) -> str:
    """Coin a stable lowercase-slug ``entity_key`` from a label (sub-design §4).

    ``"Order Service"`` → ``"order-service"``. Lowercases, replaces any non-alphanumeric
    run with ``-``, and trims leading/trailing ``-``. Used when registering a brand-new
    entity discovered by Path B (Path C keys are coined by the model). Falls back to
    ``"entity"`` for an empty/symbol-only label so a key is always non-empty.
    """
    decomposed = unicodedata.normalize("NFKD", label)
    ascii_only = "".join(ch for ch in decomposed if not unicodedata.combining(ch))
    slug = _SLUG_STRIP_RE.sub("-", ascii_only.lower()).strip("-")
    return slug or "entity"


# ===========================================================================
# Local lexical embedder (sub-design §9 — honest about the hash embedder).
# A dependency-free 256-dim L2-normalized token-hash vector, identical in spirit
# to indexing/embedding.LocalTestEmbedder, used so embedding() never fails when no
# real (Azure) embedder is wired. It is LEXICAL: cosine reflects shared tokens, so
# `Customer`/`Client` is ~0 locally and the reconciler falls through to the LLM step
# (sub-design §5 gotcha / §9). Prod passes a real embedder via the reconciler.
# ===========================================================================
_LOCAL_EMBED_DIM = 256


def local_hash_embedding(text: str) -> list[float]:
    """A deterministic 256-dim lexical embedding (no network) — sub-design §9.

    Mirrors :class:`~docx_app.indexing.embedding.LocalTestEmbedder._vector`. Lexical only
    (shared-token cosine), so it captures suffix/plural overlap but **not** synonyms — that
    is the documented local caveat; the reconciler routes low-similarity pairs to the LLM.
    """
    vec = [0.0] * _LOCAL_EMBED_DIM
    for token in text.lower().split():
        digest = hashlib.md5(token.encode("utf-8")).digest()
        vec[int.from_bytes(digest[:4], "big") % _LOCAL_EMBED_DIM] += 1.0
    norm = math.sqrt(sum(x * x for x in vec)) or 1.0
    return [x / norm for x in vec]


def cosine_similarity(a: list[float], b: list[float]) -> float:
    """Cosine similarity of two equal-length vectors; 0.0 on a length/zero mismatch.

    Defensive: registry embeddings may be ``None``/empty (local) or a different dimension
    than the incoming vector (prod model change) — either way return 0.0 rather than raise,
    so the reconciler simply treats the pair as "no embedding candidate" and falls through.
    """
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b, strict=True))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(x * x for x in b))
    if na == 0.0 or nb == 0.0:
        return 0.0
    return dot / (na * nb)


# ===========================================================================
# The registry row model (sub-design §3) + the owner-scoped store.
# ===========================================================================
class NotebookEntity(BaseModel):
    """One canonical shared entity in a notebook's registry — fields mirror the
    ``notebook_entity`` table (``0010_notebook_entity.surql``).

    ``entity_key`` is the stable slug stored in :attr:`DiagramGraphNode.entity`; the
    registry is grouped + upserted by ``(notebook_id, entity_key)``. ``source_refs`` is the
    set (stored as a deduped list) of source_ids whose accepted graphs reference this
    entity — an entity becomes an HLD bridge node only when ``len(source_refs) >= 2``
    (singletons stay inside their source LLD; sub-design §7). ``locked`` makes a human
    merge/split/rename sticky: a later reconciliation pass must not alter a locked entity
    (sub-design §6, §5 gotcha 6).
    """

    # Surreal rows carry extra columns (owner/scope/created/updated) — model what we use,
    # ignore unknowns (same as Diagram / Note / Notebook / Source).
    model_config = ConfigDict(extra="ignore")

    id: str | None = None
    owner: str | None = None
    scope: str | None = None
    notebook_id: str | None = None
    entity_key: str | None = None
    canonical_label: str | None = None
    kind: str | None = None
    aliases: list[str] = []
    description: str | None = None
    embedding: list[float] | None = None
    source_refs: list[str] = []
    locked: bool = False
    created: str | None = None
    updated: str | None = None

    def registry_view(self) -> dict[str, Any]:
        """The ``{entity_key, canonical_label, kind}`` shape Path C injects into the prompt.

        Matches the dict shape :func:`docx_app.diagram.prompts.entity_registry_rules`
        consumes (the ``<entity_registry>`` block). Only the controlled-vocab fields are
        exposed — aliases/embeddings/source_refs are registry-internal.
        """
        return {
            "entity_key": self.entity_key,
            "canonical_label": self.canonical_label,
            "kind": self.kind,
        }


def _dedupe_preserve(values: list[str]) -> list[str]:
    """Order-preserving de-dupe of non-empty stripped strings (for aliases/source_refs)."""
    seen: set[str] = set()
    out: list[str] = []
    for value in values:
        cleaned = value.strip()
        if cleaned and cleaned not in seen:
            seen.add(cleaned)
            out.append(cleaned)
    return out


class EntityRegistryStore:
    """Persistence for :class:`NotebookEntity` — owner-PRIVATE, one registry per notebook.

    Mirrors :class:`~docx_app.diagram.domain.DiagramStore` /
    :class:`~docx_app.domain.note.NoteStore` exactly: ``create_scoped`` writes (returns a
    single-element list — unwrapped here), ``select_scoped(focus=True)`` reads (owner-only),
    ``scoped_update`` / ``delete_where`` carry the ``owner = $owner`` tenancy guard. The
    ``(notebook_id, entity_key)`` pair is the unique lookup/upsert path.
    """

    TABLE = "notebook_entity"

    def __init__(self, repo: SurrealRepository):
        self._repo = repo

    @staticmethod
    def _to_entity(record: dict[str, Any] | list[Any]) -> NotebookEntity:
        # create_scoped (and db.insert) return a SINGLE-element list ([{...}]) — unwrap
        # before splatting (NotebookEntity(**list) would raise → the endpoint 500s). Same
        # guard as DiagramStore._to_diagram / NoteStore._to_note / SettingsStore.upsert.
        if isinstance(record, list):
            record = record[0] if record else {}
        return NotebookEntity(**record)

    # NOTE on method order: the read-all method is named ``list`` for API parity with
    # ``DiagramStore.list`` / ``NoteStore.list``. Because ``list`` would shadow the builtin
    # ``list[...]`` in any annotation that follows it *within this class body*, it is defined
    # LAST (below ``split``); every method that annotates ``list[...]`` comes before it. This
    # is the same constraint ``DiagramStore`` satisfies by ordering — see that class.

    async def get(
        self, entity_id: str, principal: Principal
    ) -> NotebookEntity | None:
        """Fetch one entity the caller OWNS (owner-scoped). None if it isn't theirs."""
        rows = await self._repo.select_scoped(
            self.TABLE,
            principal,
            focus=True,
            extra_where="id = $eid",
            vars={"eid": ensure_record_id(entity_id)},
            limit=1,
        )
        return self._to_entity(rows[0]) if rows else None

    async def get_by_key(
        self, principal: Principal, *, notebook_id: str, entity_key: str
    ) -> NotebookEntity | None:
        """Fetch the entity with this ``entity_key`` in this notebook (the unique path).

        ``(notebook_id, entity_key)`` is unique per the migration's ``idx_ne_key`` — this is
        the lookup the Path-C upsert uses to decide create-vs-append.
        """
        rows = await self._repo.select_scoped(
            self.TABLE,
            principal,
            focus=True,
            extra_where="notebook_id = $nb AND entity_key = $key",
            vars={"nb": notebook_id, "key": entity_key},
            limit=1,
        )
        return self._to_entity(rows[0]) if rows else None

    async def create(
        self,
        *,
        owner: str,
        notebook_id: str,
        entity_key: str,
        canonical_label: str,
        kind: str | None = None,
        aliases: list[str] | None = None,
        description: str | None = None,
        embedding: list[float] | None = None,
        source_refs: list[str] | None = None,
        locked: bool = False,
    ) -> NotebookEntity:
        """Register a brand-new entity (owner-PRIVATE). Aliases/source_refs are deduped."""
        data: dict[str, Any] = {
            "notebook_id": notebook_id,
            "entity_key": entity_key,
            "canonical_label": canonical_label,
            "kind": kind,
            "aliases": _dedupe_preserve(aliases or []),
            "description": description,
            "embedding": embedding,
            "source_refs": _dedupe_preserve(source_refs or []),
            "locked": locked,
        }
        # PRIVATE: the registry is the user's own intellectual work, not the shared brain.
        record = await self._repo.create_scoped(
            self.TABLE, data, owner=owner, scope=Scope.PRIVATE
        )
        return self._to_entity(record)

    async def update_fields(
        self,
        entity_id: str,
        principal: Principal,
        *,
        fields: dict[str, Any],
    ) -> NotebookEntity | None:
        """Owner-scoped patch of named fields on an entity the caller OWNS.

        The owner-scoped read first proves ownership, so the subsequent owner-scoped UPDATE
        can never touch another owner's row (the leak guard). Empty ``fields`` is a no-op
        that returns the existing row. ``aliases``/``source_refs`` (if present) are deduped.
        """
        existing = await self.get(entity_id, principal)
        if existing is None:
            return None
        if not fields:
            return existing
        patched = dict(fields)
        if "aliases" in patched and isinstance(patched["aliases"], list):
            patched["aliases"] = _dedupe_preserve(patched["aliases"])
        if "source_refs" in patched and isinstance(patched["source_refs"], list):
            patched["source_refs"] = _dedupe_preserve(patched["source_refs"])
        patched["updated"] = datetime.now(timezone.utc)
        rows = await scoped_update(
            self._repo,
            self.TABLE,
            patched,
            owner=principal.owner,
            record_id=entity_id,
        )
        return self._to_entity(rows[0]) if rows else existing

    async def delete(self, entity_id: str, principal: Principal) -> bool:
        """Delete an entity the caller OWNS. False if it isn't theirs.

        The delete carries ``owner = $owner`` so it can never reach another owner's entity
        (the same tenancy guard as every other store)."""
        if await self.get(entity_id, principal) is None:
            return False
        await self._repo.delete_where(
            self.TABLE,
            "id = $eid AND owner = $owner",
            {"eid": ensure_record_id(entity_id), "owner": principal.owner},
        )
        return True

    # ------------------------------------------------------------------ #
    # Path-C upsert at accept time (sub-design §4).
    # ------------------------------------------------------------------ #
    async def upsert_from_graph(
        self,
        principal: Principal,
        *,
        notebook_id: str,
        source_id: str,
        graph: DiagramGraph,
        embedder: Any = None,
    ) -> list[NotebookEntity]:
        """Upsert the registry from one accepted source graph's ``node.entity`` keys (Path C).

        Idempotent (sub-design §4 + §11 "upsert idempotency on re-accept"): for each node
        that carries a non-empty ``entity`` key, either CREATE a new row (key not yet in the
        notebook) or APPEND to the existing one — the node's label is added to ``aliases``
        (deduped) and ``source_id`` to ``source_refs`` (deduped). A **locked** entity is
        never widened by this pass (sub-design §6 / §5 gotcha 6) — its human-curated
        aliases/source_refs stand. Nodes with ``entity is None`` are ignored here; they are
        resolved at compose time by the Path-B reconciler.

        Re-accepting the same source is a no-op for unchanged keys (the dedupe collapses the
        re-added label + source_id), so calling this for every accepted source on each HLD
        rebuild is safe. ``embedder`` (any object with ``async embed(list[str])``) computes
        an embedding for new entities when provided; locally it is ``None`` and the row's
        embedding stays ``None`` (the reconciler then leans on normalize + LLM — §9).

        Returns the entities that were created or updated by this call (for logging /
        review surfacing), in node order.
        """
        # Collect, in node order, the (key, label, kind) triples to upsert. A node may
        # repeat a key already handled in this graph — fold them so each key is upserted once.
        ordered_keys: list[str] = []
        contributions: dict[str, dict[str, Any]] = {}
        for node in graph.nodes:
            key = (node.entity or "").strip()
            if not key:
                continue
            if key not in contributions:
                contributions[key] = {"labels": [], "kind": None}
                ordered_keys.append(key)
            contributions[key]["labels"].append(node.label)
            # First non-empty meta-kind wins for the entity kind hint (best-effort).
            if contributions[key]["kind"] is None:
                contributions[key]["kind"] = _node_kind(node)

        touched: list[NotebookEntity] = []
        for key in ordered_keys:
            contribution = contributions[key]
            labels = _dedupe_preserve(contribution["labels"])
            kind = contribution["kind"]
            existing = await self.get_by_key(
                principal, notebook_id=notebook_id, entity_key=key
            )
            if existing is None:
                canonical = labels[0] if labels else key
                embedding = await _maybe_embed(embedder, canonical, None)
                created = await self.create(
                    owner=principal.owner,
                    notebook_id=notebook_id,
                    entity_key=key,
                    canonical_label=canonical,
                    kind=kind,
                    aliases=[label for label in labels if label != canonical],
                    source_refs=[source_id],
                    embedding=embedding,
                )
                touched.append(created)
                log.info(
                    "entity_registered",
                    entity_key=key,
                    notebook_id=notebook_id,
                    source_id=source_id,
                    method="controlled_vocab",
                )
                continue

            if existing.locked:
                # Human-curated entity: Path C must not widen it (sub-design §6).
                log.info(
                    "entity_upsert_skipped_locked",
                    entity_key=key,
                    notebook_id=notebook_id,
                    source_id=source_id,
                )
                touched.append(existing)
                continue

            # Append this source's contribution: aliases (labels not already the canonical
            # label or an alias) + source_id. Deduped by update_fields.
            new_aliases = _dedupe_preserve(
                [*existing.aliases, *labels]
            )
            new_aliases = [a for a in new_aliases if a != existing.canonical_label]
            new_source_refs = _dedupe_preserve([*existing.source_refs, source_id])
            updated = await self.update_fields(
                (existing.id or ""),
                principal,
                fields={"aliases": new_aliases, "source_refs": new_source_refs},
            )
            if updated is not None:
                touched.append(updated)
            log.info(
                "entity_appended",
                entity_key=key,
                notebook_id=notebook_id,
                source_id=source_id,
                method="controlled_vocab",
            )
        return touched

    # ------------------------------------------------------------------ #
    # Human override — merge / split (sub-design §6). Sets locked=True so a
    # later reconciliation pass treats the decision as sticky.
    # ------------------------------------------------------------------ #
    async def merge(
        self,
        principal: Principal,
        *,
        survivor_id: str,
        merged_ids: list[str],
    ) -> NotebookEntity | None:
        """Merge ``merged_ids`` into ``survivor_id`` — union aliases + source_refs (§6).

        The survivor absorbs each merged entity's ``canonical_label`` + ``aliases`` (the
        merged labels become survivor aliases) and the union of ``source_refs``; the merged
        rows are then deleted. The survivor is **locked** so a later reconciliation pass does
        not silently undo the human merge (sub-design §6 / §5 gotcha 6). All reads/writes are
        owner-scoped; a non-owned/absent id is skipped. Returns the updated survivor (or
        ``None`` if the survivor isn't the caller's).
        """
        survivor = await self.get(survivor_id, principal)
        if survivor is None:
            return None
        aliases = list(survivor.aliases)
        source_refs = list(survivor.source_refs)
        for merged_id in merged_ids:
            if merged_id == survivor_id:
                continue
            merged = await self.get(merged_id, principal)
            if merged is None:
                continue
            if merged.canonical_label:
                aliases.append(merged.canonical_label)
            aliases.extend(merged.aliases)
            source_refs.extend(merged.source_refs)
            await self.delete(merged_id, principal)
        aliases = [a for a in _dedupe_preserve(aliases) if a != survivor.canonical_label]
        updated = await self.update_fields(
            survivor_id,
            principal,
            fields={
                "aliases": aliases,
                "source_refs": _dedupe_preserve(source_refs),
                "locked": True,
            },
        )
        log.info(
            "entity_merged",
            survivor=survivor.entity_key,
            merged_count=len(merged_ids),
            notebook_id=survivor.notebook_id,
        )
        return updated

    async def split(
        self,
        principal: Principal,
        *,
        source_entity_id: str,
        new_entity_key: str,
        new_canonical_label: str,
        move_aliases: list[str] | None = None,
        move_source_refs: list[str] | None = None,
        kind: str | None = None,
    ) -> tuple[NotebookEntity, NotebookEntity] | None:
        """Split an entity — move selected aliases/source_refs to a NEW entity (§6).

        Creates ``new_entity_key`` carrying ``move_aliases`` / ``move_source_refs`` and
        removes those from the source entity. **Both** the source and the new entity are
        locked (the split is a sticky human decision; a later pass must not re-merge them —
        sub-design §6). Returns ``(source_after, new_entity)``; ``None`` if the source isn't
        the caller's. The moved sets are intersected with what the source actually has, so a
        stray id never fabricates membership.
        """
        source = await self.get(source_entity_id, principal)
        if source is None:
            return None
        move_alias_set: set[str] = set(move_aliases or [])
        move_ref_set: set[str] = set(move_source_refs or [])
        moved_aliases = [a for a in source.aliases if a in move_alias_set]
        moved_refs = [r for r in source.source_refs if r in move_ref_set]
        remaining_aliases = [a for a in source.aliases if a not in move_alias_set]
        remaining_refs = [r for r in source.source_refs if r not in move_ref_set]

        new_entity = await self.create(
            owner=principal.owner,
            notebook_id=source.notebook_id or "",
            entity_key=new_entity_key,
            canonical_label=new_canonical_label,
            kind=kind if kind is not None else source.kind,
            aliases=moved_aliases,
            source_refs=moved_refs,
            locked=True,
            embedding=source.embedding,
        )
        updated_source = await self.update_fields(
            source_entity_id,
            principal,
            fields={
                "aliases": remaining_aliases,
                "source_refs": remaining_refs,
                "locked": True,
            },
        )
        log.info(
            "entity_split",
            source=source.entity_key,
            new=new_entity_key,
            notebook_id=source.notebook_id,
        )
        return (updated_source or source, new_entity)

    # ------------------------------------------------------------------ #
    # Read-all — defined LAST so the `list` name does not shadow the builtin
    # `list[...]` in the annotations of the methods above (see the NOTE near `_to_entity`).
    # ------------------------------------------------------------------ #
    async def list(  # noqa: A003 - intentional API parity with DiagramStore.list
        self,
        principal: Principal,
        *,
        notebook_id: str,
        order_by: str = "entity_key ASC",
        limit: int = 1000,
    ) -> list[NotebookEntity]:
        """All of the caller's entities for one notebook (owner-scoped).

        Always ``focus=True`` (``owner = $owner``) AND filtered to ``notebook_id``, so
        another owner's — or another notebook's — entities are never returned (the
        per-notebook + tenancy isolation the sub-design §3/§10 requires). ``notebook_id`` is
        bound as a param (never interpolated).
        """
        rows = await self._repo.select_scoped(
            self.TABLE,
            principal,
            focus=True,  # the registry is owner-private
            extra_where="notebook_id = $nb",
            vars={"nb": notebook_id},
            order_by=order_by,
            limit=limit,
        )
        return [self._to_entity(r) for r in rows]


# ===========================================================================
# Small helpers used by upsert_from_graph (kept module-private).
# ===========================================================================
def _node_kind(node: Any) -> str | None:
    """Best-effort entity ``kind`` hint from a node's ``meta.kind`` or its ``type``.

    The registry's ``kind`` disambiguates homonyms (sub-design §3/§5 — a ``Manager`` actor
    vs a ``Manager`` service). Prefer an explicit ``meta.kind`` (the graph prompt now asks the
    model to set one from a controlled vocab); otherwise fall back to the node's required
    ``type``. ``type`` is freeform/secondary, but a present-but-noisy kind is strictly better
    than a universally-``None`` one for a guard whose only job is to BLOCK a merge on
    conflict — without this fallback the homonym guard never fired on real LLM output
    (``meta.kind`` was only ever populated in tests). Never raises.
    """
    meta = getattr(node, "meta", None)
    if isinstance(meta, dict):
        kind = meta.get("kind")
        if isinstance(kind, str) and kind.strip():
            return kind.strip()
    node_type = getattr(node, "type", None)
    if isinstance(node_type, str) and node_type.strip():
        return node_type.strip()
    return None


async def _maybe_embed(
    embedder: Any, label: str, description: str | None
) -> list[float] | None:
    """Embed ``label (+ description)`` via ``embedder`` if provided, else ``None``.

    ``embedder`` is any object exposing ``async embed(list[str]) -> list[list[float]]``
    (the project's :class:`~docx_app.indexing.embedding.Embedder` contract). When ``None``
    (local path), returns ``None`` — the row stores no embedding and the reconciler leans on
    normalize + LLM (sub-design §9). An embedder failure is swallowed to ``None`` (a missing
    embedding must never block registry writes), logged at warning.
    """
    if embedder is None:
        return None
    text = label if not description else f"{label} — {description}"
    try:
        vectors = await embedder.embed([text])
    except Exception as exc:  # noqa: BLE001 - embedding is best-effort, never fatal
        log.warning("entity_embedding_failed", error=str(exc))
        return None
    return vectors[0] if vectors else None


# Re-export the Path-B cascade (imported here, at module end, to avoid the circular
# import: reconciler imports NotebookEntity/normalize_label/cosine_similarity from this
# module). This makes `from docx_app.diagram.entities import reconcile_node, Assignment`
# work, so `entities` is the registry's single public surface (the brief's intent).
from docx_app.diagram.reconciler import (  # noqa: E402
    Assignment,
    reconcile_node,
)

__all__ = [
    # Normalization + slug + local embedding helpers
    "normalize_label",
    "slugify_entity_key",
    "local_hash_embedding",
    "cosine_similarity",
    # Registry model + store
    "NotebookEntity",
    "EntityRegistryStore",
    # Re-exported Path-B cascade (lives in reconciler.py)
    "Assignment",
    "reconcile_node",
]
