"""GitLab repo fetch service for RepoGraph (Surface 3).

Adapted from gitdiagram ``backend/app/services/github_service.py``:
  - Targets a CONFIGURABLE GitLab base URL (a self-hosted UBS instance) instead of
    github.com — ``base_url`` + ``token`` come from :class:`DocxConfig` (injected from
    FRAME 2.0 env at container startup).
  - Authenticates via a Personal/Project Access Token (the ``PRIVATE-TOKEN`` header) or
    runs unauthenticated for public repos. No JWT / GitHub-App machinery — GitLab's PAT
    model is a single header, so the whole installation-token dance in gitdiagram is gone.
  - Uses three GitLab REST v4 endpoints:
      GET /projects/:encoded_path                              → id, default_branch, visibility
      GET /projects/:id/repository/tree?recursive=true&...     → recursive file tree (paginated)
      GET /projects/:id/repository/files/:path/raw?ref=<branch> → README raw bytes
  - All outbound calls go through :func:`docx_app.http.make_client` (corporate-CA TLS —
    FINAL_DESIGN §11). Never use a raw ``httpx.AsyncClient`` for external calls.
  - Fakeable for tests: callers depend on the :class:`GitLabData` dataclass and the
    :class:`GitLabService` interface; a fixture can build :class:`GitLabData` directly or
    subclass the service and override :meth:`get_gitlab_data`.

This module mirrors gitdiagram's flat file-tree contract exactly (newline-delimited blob
paths, same :data:`EXCLUDED_PATTERNS`) so the existing 2-step pipeline
(:mod:`docx_app.diagram.agent` / :mod:`docx_app.diagram.prompts`) consumes a RepoGraph
repo's ``file_tree`` / ``readme`` with no change to the prompt contract.

Config fields read here (added to :class:`DocxConfig`):
  ``gitlab_base_url``               str   — e.g. ``"https://gitlab.example.com"``; empty → disabled
  ``gitlab_token``                  str   — ``PRIVATE-TOKEN`` header value; empty → unauthenticated
  ``gitlab_timeout_s``              float — per-request timeout (default ``30.0``)
  ``repograph_max_file_tree_chars`` int   — abort if the file tree exceeds this (default ``780_000``)
"""

from __future__ import annotations

import urllib.parse
from dataclasses import dataclass

import httpx
import structlog

from docx_app.config import DocxConfig
from docx_app.http import make_client

log = structlog.get_logger(__name__)

# The scalar value types httpx accepts for query params (its ``QueryParamTypes`` Mapping
# value). Kept explicit so the strict mypy gate is satisfied without an ``Any`` escape.
_ParamValue = str | int | float | bool | None
_Params = dict[str, _ParamValue]

REPOSITORY_TOO_LARGE_ERROR = (
    "Repository file tree is too large for analysis. Try a smaller repository."
)
# Cap the README we feed the pipeline (mirrors gitdiagram's MAX_README_BYTES). A README
# larger than this is truncated rather than rejected — the explanation step only needs the
# top-of-file orientation, not the whole document.
MAX_README_BYTES = 750_000

# GitLab returns at most this many tree entries per page; we request the max to minimise
# round-trips. Offset pagination then advances via the X-Next-Page response header.
TREE_PER_PAGE = 100

# README filenames tried, in order. GitLab is case-sensitive on the raw-file path, so we
# try the conventional capitalised forms (which dominate in practice). A 404 on all of
# these is fine — the pipeline runs happily with an empty README.
README_CANDIDATES: tuple[str, ...] = ("README.md", "README.rst", "README")

# Same exclusion list as gitdiagram (verbatim) — binary / generated artefacts that pollute
# the file tree and add no architectural signal.
EXCLUDED_PATTERNS: tuple[str, ...] = (
    "node_modules/",
    "vendor/",
    "venv/",
    ".min.",
    ".pyc",
    ".pyo",
    ".pyd",
    ".so",
    ".dll",
    ".class",
    ".jpg",
    ".jpeg",
    ".png",
    ".gif",
    ".ico",
    ".svg",
    ".ttf",
    ".woff",
    ".webp",
    "__pycache__/",
    ".cache/",
    ".tmp/",
    "yarn.lock",
    "poetry.lock",
    "*.log",
    ".vscode/",
    ".idea/",
)


class GitLabConfigError(ValueError):
    """Raised when GitLab config is absent or invalid (no base URL set).

    The API layer maps this to HTTP 503 (the RepoGraph feature is not configured) — the
    service still starts without GitLab configured; only the call fails.
    """


class GitLabNotFoundError(ValueError):
    """Project or resource not found (HTTP 404). The API maps this to HTTP 404."""


class GitLabFetchError(RuntimeError):
    """Non-retryable GitLab API error (a non-2xx that is not 404).

    The API maps this to HTTP 502 (bad gateway — the upstream GitLab failed).
    """


@dataclass(frozen=True)
class GitLabData:
    """The pieces the pipeline needs, mirroring gitdiagram's ``GithubData``.

    Attributes:
        default_branch: the repo's default branch (e.g. ``"main"``).
        file_tree: newline-delimited, filtered blob paths (same format as gitdiagram —
            the flat list the graph prompt's ``<file_tree>`` block consumes).
        readme: raw UTF-8 README content (``""`` when the repo has no README).
        namespace: ``"group/subgroup/project"`` — used to derive ``repo_owner`` /
            ``repo_name`` for the prompts and to build drill-down links.
        project_id: the numeric GitLab project id.
    """

    default_branch: str
    file_tree: str
    readme: str
    namespace: str
    project_id: int


class GitLabService:
    """Fetches repo data from a self-hosted GitLab instance.

    Construct once per request (or inject as a FastAPI dependency — see
    ``get_gitlab_service`` in ``deps.py``). All public methods are async (an
    :class:`httpx.AsyncClient` from :func:`docx_app.http.make_client` under the hood).

    Args:
        config: the :class:`DocxConfig` — reads ``gitlab_base_url``, ``gitlab_token``,
            ``gitlab_timeout_s`` and ``repograph_max_file_tree_chars``.
    """

    def __init__(self, config: DocxConfig) -> None:
        self._config = config

    # -- internals ---------------------------------------------------------- #

    def _base(self) -> str:
        """Return the normalised GitLab API v4 root, or raise :class:`GitLabConfigError`.

        ``gitlab_base_url`` is trimmed of a trailing slash and suffixed with ``/api/v4``.
        An empty base URL means the feature is disabled → raise (the API turns this into a
        clear 503 instead of failing the request opaquely).
        """
        url = (self._config.gitlab_base_url or "").strip().rstrip("/")
        if not url:
            raise GitLabConfigError(
                "GitLab is not configured (gitlab_base_url is empty). "
                "Set GITLAB_BASE_URL in the environment (injected by FRAME 2.0)."
            )
        return f"{url}/api/v4"

    def _headers(self) -> dict[str, str]:
        """The ``PRIVATE-TOKEN`` header when a token is configured; ``{}`` otherwise.

        An empty token is valid: GitLab serves public projects unauthenticated.
        """
        token = (self._config.gitlab_token or "").strip()
        if token:
            return {"PRIVATE-TOKEN": token}
        return {}

    @staticmethod
    def _encode_path(namespace_with_project: str) -> str:
        """URL-encode the ``group/subgroup/project`` path for GitLab's ``:id`` segment.

        ``safe=""`` encodes the slashes too (``%2F``), which is exactly how GitLab expects
        a namespaced path to be passed as the ``:id`` parameter.
        """
        return urllib.parse.quote(namespace_with_project, safe="")

    @staticmethod
    def _should_include(path: str) -> bool:
        """``True`` when ``path`` matches none of :data:`EXCLUDED_PATTERNS` (gitdiagram)."""
        lower = path.lower()
        return not any(pattern in lower for pattern in EXCLUDED_PATTERNS)

    async def _request(self, url: str, params: _Params | None = None) -> httpx.Response:
        """Single GET via the corporate-CA async client; raises typed errors on failure.

        Returns the raw :class:`httpx.Response` so callers that need response *headers*
        (pagination via ``X-Next-Page``) or raw *bytes* (the README) can read them; JSON
        callers go through :meth:`_get_json`. A 404 becomes :class:`GitLabNotFoundError`;
        any other non-2xx becomes :class:`GitLabFetchError`.
        """
        async with make_client(
            self._config, timeout=self._config.gitlab_timeout_s
        ) as client:
            resp = await client.get(url, headers=self._headers(), params=params or {})
        if resp.status_code == 404:
            raise GitLabNotFoundError(f"GitLab 404: {url}")
        if not resp.is_success:
            raise GitLabFetchError(
                f"GitLab request failed ({resp.status_code}): {resp.text[:300]}"
            )
        return resp

    async def _get_json(
        self, url: str, params: _Params | None = None
    ) -> dict[str, object] | list[object]:
        """GET ``url`` and return the parsed JSON body (dict or list)."""
        resp = await self._request(url, params=params)
        body: dict[str, object] | list[object] = resp.json()
        return body

    # -- public API --------------------------------------------------------- #

    async def get_project(self, repo_url: str) -> tuple[int, str, str]:
        """Resolve a full GitLab URL to ``(project_id, default_branch, namespace_path)``.

        Accepts both shapes::

            https://gitlab.example.com/group/subgroup/project
            https://gitlab.example.com/group/project          (no subgroup)

        It strips the configured ``gitlab_base_url`` prefix to obtain the
        ``group/.../project`` path, URL-encodes it, and calls ``GET /projects/:id``.

        Returns:
            ``(project_id, default_branch, namespace_with_project)``.

        Raises:
            GitLabConfigError: ``gitlab_base_url`` is not set.
            GitLabNotFoundError: the project does not exist or is inaccessible.
            GitLabFetchError: any other API error.
            ValueError: ``repo_url`` does not start with the configured ``gitlab_base_url``,
                or no project path remains after stripping the base.
        """
        base = (self._config.gitlab_base_url or "").strip().rstrip("/")
        if not base:
            # Surface the same clear "not configured" error as _base() before we even
            # attempt to parse the URL.
            raise GitLabConfigError(
                "GitLab is not configured (gitlab_base_url is empty). "
                "Set GITLAB_BASE_URL in the environment (injected by FRAME 2.0)."
            )

        normalized = repo_url.strip().rstrip("/")
        if not normalized.startswith(base):
            raise ValueError(
                f"repo_url {repo_url!r} does not start with gitlab_base_url {base!r}"
            )
        namespace_with_project = normalized[len(base) :].strip("/")
        if not namespace_with_project:
            raise ValueError(
                f"repo_url {repo_url!r} has no project path after the base URL "
                f"{base!r} (expected '<base>/<group>/<project>')."
            )

        encoded = self._encode_path(namespace_with_project)
        data = await self._get_json(f"{self._base()}/projects/{encoded}")
        if not isinstance(data, dict):
            # GET /projects/:id always returns an object; anything else is an upstream
            # contract break, not a normal 404.
            raise GitLabFetchError(
                f"Unexpected GitLab response for project {namespace_with_project!r} "
                f"(expected an object, got {type(data).__name__})."
            )

        raw_id = data.get("id")
        if not isinstance(raw_id, (int, str)):
            raise GitLabFetchError(
                f"GitLab project response has no usable numeric 'id' "
                f"(got {type(raw_id).__name__})."
            )
        try:
            project_id = int(raw_id)
        except ValueError as exc:
            raise GitLabFetchError(
                f"GitLab project 'id' is not an integer: {exc}"
            ) from exc
        # GitLab returns null default_branch for an empty repo; fall back to "main" so the
        # tree/readme calls still target a sensible ref.
        raw_branch = data.get("default_branch")
        default_branch = (
            raw_branch if isinstance(raw_branch, str) and raw_branch else "main"
        )

        log.debug(
            "gitlab_project_resolved",
            project_id=project_id,
            default_branch=default_branch,
            namespace=namespace_with_project,
        )
        return project_id, default_branch, namespace_with_project

    async def get_repository_tree(self, project_id: int, ref: str) -> str:
        """Return a filtered, newline-delimited file-tree string (gitdiagram format).

        Calls ``GET /projects/:id/repository/tree?recursive=true&ref=<ref>&per_page=100``
        and paginates via the ``X-Next-Page`` response header (offset pagination; absent or
        empty header = last page). Only ``type == "blob"`` entries (files) are kept — tree
        (directory) entries are dropped so the LLM sees the same flat file list gitdiagram
        produces. Each path is filtered through :data:`EXCLUDED_PATTERNS`.

        The final joined string is checked against ``repograph_max_file_tree_chars``; a repo
        whose filtered tree exceeds the cap raises (mirroring gitdiagram's size gate).

        Args:
            project_id: the numeric GitLab project id (from :meth:`get_project`).
            ref: the branch/tag to read (typically the default branch).

        Returns:
            Newline-delimited blob paths (possibly empty if the repo has no included files).

        Raises:
            GitLabConfigError: ``gitlab_base_url`` is not set.
            GitLabFetchError: an API error, or a malformed (non-list) tree page.
            GitLabNotFoundError: the project/ref is not found.
            ValueError: the filtered tree exceeds ``repograph_max_file_tree_chars``
                (message is :data:`REPOSITORY_TOO_LARGE_ERROR`).
        """
        tree_url = f"{self._base()}/projects/{project_id}/repository/tree"
        paths: list[str] = []
        max_chars = self._config.repograph_max_file_tree_chars
        page = 1

        while True:
            resp = await self._request(
                tree_url,
                params={
                    "recursive": "true",
                    "ref": ref,
                    "per_page": TREE_PER_PAGE,
                    "page": page,
                },
            )
            items = resp.json()
            if not isinstance(items, list):
                raise GitLabFetchError(
                    f"Unexpected GitLab tree response (expected a list, got "
                    f"{type(items).__name__})."
                )
            for item in items:
                if not isinstance(item, dict) or item.get("type") != "blob":
                    continue
                path = item.get("path")
                if isinstance(path, str) and path and self._should_include(path):
                    paths.append(path)

            # Offset pagination: X-Next-Page carries the next page number, or is absent /
            # empty on the last page. Parallel pagination is deliberately NOT used — the
            # GitLab rate limiter is per-token, so sequential page fetches are safer.
            next_page = (resp.headers.get("X-Next-Page") or "").strip()
            if not next_page:
                break
            try:
                page = int(next_page)
            except ValueError:  # pragma: no cover - GitLab always sends an int here
                break

        file_tree = "\n".join(paths)
        if len(file_tree) > max_chars:
            raise ValueError(REPOSITORY_TOO_LARGE_ERROR)
        return file_tree

    async def get_readme(self, project_id: int, ref: str) -> str:
        """Fetch the raw README content (best-effort; returns ``""`` if absent).

        Tries each name in :data:`README_CANDIDATES` (``README.md`` → ``README.rst`` →
        ``README``) via ``GET /projects/:id/repository/files/:filename/raw?ref=:ref``,
        URL-encoding the filename. Returns the decoded UTF-8 text of the first one that
        exists, truncated to :data:`MAX_README_BYTES`. If all candidates 404, returns ``""``
        (no README is fine — the pipeline still runs and the explanation notes its absence).

        Never raises on a missing README; raises :class:`GitLabFetchError` only for a
        non-404 upstream error.

        Args:
            project_id: the numeric GitLab project id.
            ref: the branch/tag to read the README from.

        Returns:
            The README text, or ``""`` when none of the candidates exist.
        """
        files_base = f"{self._base()}/projects/{project_id}/repository/files"
        for filename in README_CANDIDATES:
            encoded_name = urllib.parse.quote(filename, safe="")
            url = f"{files_base}/{encoded_name}/raw"
            try:
                resp = await self._request(url, params={"ref": ref})
            except GitLabNotFoundError:
                continue  # this candidate doesn't exist — try the next name
            # Decode defensively: a README may contain invalid byte sequences; never let a
            # decode error abort the whole fetch (a partial README is still useful context).
            text = resp.content.decode("utf-8", errors="replace")
            if len(text.encode("utf-8")) > MAX_README_BYTES:
                # Truncate on a character boundary so the result stays valid UTF-8.
                text = text.encode("utf-8")[:MAX_README_BYTES].decode(
                    "utf-8", errors="ignore"
                )
            return text
        return ""

    async def get_gitlab_data(self, repo_url: str) -> GitLabData:
        """Full fetch: project lookup + tree + README. The single entry point for the API.

        Args:
            repo_url: the full GitLab project URL the user pasted (e.g.
                ``"https://gitlab.example.com/infra/k8s-platform"``).

        Returns:
            A :class:`GitLabData` with ``default_branch``, ``file_tree``, ``readme``,
            ``namespace`` and ``project_id``.

        Raises:
            GitLabConfigError: ``gitlab_base_url`` is not set.
            GitLabNotFoundError: the project does not exist or is inaccessible.
            GitLabFetchError: any other upstream GitLab error.
            ValueError: a bad ``repo_url`` (not under the base) or a file tree over the cap.
        """
        project_id, default_branch, namespace = await self.get_project(repo_url)
        file_tree = await self.get_repository_tree(project_id, default_branch)
        readme = await self.get_readme(project_id, default_branch)
        log.info(
            "gitlab_data_fetched",
            project_id=project_id,
            namespace=namespace,
            tree_lines=(file_tree.count("\n") + 1 if file_tree else 0),
            readme_bytes=len(readme.encode("utf-8")),
        )
        return GitLabData(
            default_branch=default_branch,
            file_tree=file_tree,
            readme=readme,
            namespace=namespace,
            project_id=project_id,
        )


__all__ = [
    "GitLabService",
    "GitLabData",
    "GitLabConfigError",
    "GitLabNotFoundError",
    "GitLabFetchError",
    "REPOSITORY_TOO_LARGE_ERROR",
    "MAX_README_BYTES",
    "EXCLUDED_PATTERNS",
]
