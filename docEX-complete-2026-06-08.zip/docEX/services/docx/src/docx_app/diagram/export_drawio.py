"""Optional export: ``DiagramGraph`` → a draw.io / mxGraph XML *string*.

This is one of the optional, emit-only renderers over the canonical
``DiagramGraph`` (design: ``docs/2026-06-06-diagram-platform-design.md`` §4).
The primary renderer is the custom SVG renderer; draw.io is **never** on the
critical path and is offered only so a user can open the diagram in *their own*
draw.io for hand-editing or the pixel-exact Microsoft icon look.

CRITICAL — there is **no runtime draw.io dependency on any path.** This module
emits a plain mxGraph-XML *string* and nothing else. It does **not** import
``react-drawio`` / ``<DrawIoEmbed>`` and never contacts ``embed.diagrams.net``
(which would be dead inside UBS's air-gapped network). The ``flowAnimation=1``
edge style and the ``image=img/lib/azure2/...`` Azure stencils are written as
*text* into the XML; draw.io itself interprets them when the user opens the file.

Reuse map:
  - the mxCell / mxGeometry / edge structure, the ``image;...;image=img/lib/
    azure2/{category}/{Shape}.svg;`` Azure stencil style, the ``flowAnimation=1``
    animated-edge style, the ``dashed=1`` style, and the child ``edgeLabel`` cell
    pattern are all taken from next-ai-draw-io (``docs/shape-libraries/azure2.md``
    usage block + ``lib/cached-responses.ts`` reference XML).
  - ``DiagramGraphNode.icon`` carries the ``"azure/{category}/{Shape}"`` form
    (design §2); it maps 1:1 to draw.io's bundled stencil path
    ``img/lib/azure2/{category}/{Shape}.svg``.

Determinism: the output is a pure function of the input graph (stable cell ids,
input ordering preserved), so it is snapshot-testable.
"""

from __future__ import annotations

from xml.sax.saxutils import quoteattr

from docx_app.diagram.model import (
    DiagramGraph,
    DiagramGraphEdge,
    DiagramGraphGroup,
    DiagramGraphNode,
)

# --- Layout constants ------------------------------------------------------
# draw.io has no auto-layout on import, so we emit a simple, deterministic grid.
# The user re-arranges in their own draw.io (or runs its built-in layout). These
# are only seed coordinates — the value of the export is the typed content, not
# the placement.
_NODE_W = 160
_NODE_H = 60
_ICON_W = 60  # Azure stencils render square (matches azure2.md usage: 60×60)
_ICON_H = 60
_COL_GAP = 80
_ROW_GAP = 60
_COLS = 4  # nodes per row in the seed grid
_GROUP_PAD = 24  # padding inside a group container
_GROUP_GAP = 40  # vertical gap between group bands

# mxGraph vertex styles for the model's generic ``shape`` literals. Icon nodes
# bypass these entirely (they use the Azure stencil image style instead).
_SHAPE_STYLES: dict[str, str] = {
    "box": "rounded=1;whiteSpace=wrap;html=1;",
    "database": "shape=cylinder3;whiteSpace=wrap;html=1;boundedLbl=1;backgroundOutline=1;",
    "queue": "shape=process;whiteSpace=wrap;html=1;",
    "document": "shape=document;whiteSpace=wrap;html=1;",
    "circle": "ellipse;whiteSpace=wrap;html=1;",
    "hexagon": "shape=hexagon;whiteSpace=wrap;html=1;",
}
_DEFAULT_SHAPE = "box"


def _attr(value: str) -> str:
    """Return an XML-escaped, double-quoted attribute value (incl. the quotes)."""
    return quoteattr(value)


def _azure_stencil_style(icon: str) -> str | None:
    """Map a ``"azure/{category}/{Shape}"`` icon id to a draw.io image style.

    Returns ``None`` if ``icon`` is not a well-formed Azure id, so the caller can
    fall back to a generic shape (never crash on an unknown icon).
    """
    parts = icon.split("/")
    if len(parts) != 3 or parts[0] != "azure" or not parts[1] or not parts[2]:
        return None
    category, shape = parts[1], parts[2]
    image_path = f"img/lib/azure2/{category}/{shape}.svg"
    return (
        "image;aspect=fixed;html=1;"
        "verticalLabelPosition=bottom;verticalAlign=top;align=center;"
        f"image={image_path};"
    )


def _node_style(node: DiagramGraphNode) -> tuple[str, int, int]:
    """Resolve a node to its mxGraph ``style`` string and (width, height).

    Azure-icon nodes render as a stencil image (square, label below). Everything
    else uses the generic shape style for ``node.shape`` (default: box).
    """
    if node.icon:
        stencil = _azure_stencil_style(node.icon)
        if stencil is not None:
            return stencil, _ICON_W, _ICON_H
    shape_key = node.shape if node.shape in _SHAPE_STYLES else _DEFAULT_SHAPE
    return _SHAPE_STYLES[shape_key], _NODE_W, _NODE_H


def _edge_style(edge: DiagramGraphEdge) -> str:
    """Build the mxGraph edge ``style`` string.

    ``flowAnimation=1`` is added only for ``edge.animated`` (next-ai-draw-io's
    animated-connector affordance, emitted as *text* — draw.io animates it, this
    module has no runtime draw.io dependency). ``dashed=1`` for dashed edges.
    """
    style = (
        "edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;"
        "html=1;strokeWidth=2;"
    )
    if edge.style == "dashed":
        style += "dashed=1;"
    if edge.animated:
        style += "flowAnimation=1;"
    return style


def _node_cell(node: DiagramGraphNode, x: int, y: int, parent: str) -> list[str]:
    """Emit the mxCell lines for one node placed at ``(x, y)`` under ``parent``."""
    style, width, height = _node_style(node)
    return [
        f'        <mxCell id={_attr(node.id)} value={_attr(node.label)} '
        f"style={_attr(style)} vertex=\"1\" parent={_attr(parent)}>",
        f'          <mxGeometry x="{x}" y="{y}" width="{width}" height="{height}" as="geometry" />',
        "        </mxCell>",
    ]


def _group_cell(group: DiagramGraphGroup, x: int, y: int, width: int, height: int) -> list[str]:
    """Emit the mxCell lines for a group container (a labelled dashed box)."""
    style = (
        "rounded=0;whiteSpace=wrap;html=1;dashed=1;"
        "verticalAlign=top;fontStyle=1;fillColor=none;"
    )
    return [
        f'        <mxCell id={_attr(group.id)} value={_attr(group.label)} '
        f"style={_attr(style)} vertex=\"1\" parent=\"1\">",
        f'          <mxGeometry x="{x}" y="{y}" width="{width}" height="{height}" as="geometry" />',
        "        </mxCell>",
    ]


def _edge_cells(edge: DiagramGraphEdge, index: int) -> list[str]:
    """Emit the mxCell lines for one edge (+ a child ``edgeLabel`` if labelled)."""
    edge_id = f"edge_{index}"
    lines = [
        f'        <mxCell id={_attr(edge_id)} '
        f"style={_attr(_edge_style(edge))} edge=\"1\" parent=\"1\" "
        f"source={_attr(edge.from_)} target={_attr(edge.to)}>",
        '          <mxGeometry relative="1" as="geometry" />',
        "        </mxCell>",
    ]
    if edge.label:
        # Child label cell parented to the edge — the next-ai-draw-io pattern.
        label_style = (
            "edgeLabel;html=1;align=center;verticalAlign=middle;"
            "resizable=0;points=[];"
        )
        lines += [
            f'        <mxCell id={_attr(edge_id + "_label")} value={_attr(edge.label)} '
            f"style={_attr(label_style)} vertex=\"1\" connectable=\"0\" parent={_attr(edge_id)}>",
            '          <mxGeometry x="-0.1" relative="1" as="geometry">',
            '            <mxPoint as="offset" />',
            "          </mxGeometry>",
            "        </mxCell>",
        ]
    return lines


def export_drawio(graph: DiagramGraph, *, diagram_name: str = "DocEX Diagram") -> str:
    """Render ``graph`` as a self-contained draw.io / mxGraph XML *string*.

    The result is a complete ``<mxfile>`` a user can paste into / open with their
    own draw.io. Nodes with an Azure ``icon`` become draw.io ``azure2`` stencils;
    other nodes use a generic shape for ``node.shape``. Animated edges carry
    ``flowAnimation=1`` (draw.io animates them on open — no runtime dependency
    here). Grouped nodes are laid out inside a labelled container per group;
    ungrouped nodes flow in a seed grid below.

    Layout is a deterministic seed grid only (draw.io has no auto-layout on
    import); the user re-arranges or runs draw.io's built-in layout. The export's
    value is the typed content, not the placement.

    Args:
        graph: the validated canonical graph.
        diagram_name: the ``<diagram name=...>`` shown as the draw.io tab title.

    Returns:
        A pretty-printed mxGraph XML document string.
    """
    lines: list[str] = [
        '<mxfile host="app.diagrams.net">',
        f"  <diagram name={_attr(diagram_name)} id=\"docex-diagram\">",
        '    <mxGraphModel dx="800" dy="600" grid="1" gridSize="10" guides="1" '
        'tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" '
        'pageWidth="1169" pageHeight="826" math="0" shadow="0">',
        "      <root>",
        '        <mxCell id="0" />',
        '        <mxCell id="1" parent="0" />',
    ]

    # Index nodes by group, preserving the graph's node order within each group.
    group_ids = {group.id for group in graph.groups}
    nodes_by_group: dict[str, list[DiagramGraphNode]] = {gid: [] for gid in group_ids}
    ungrouped: list[DiagramGraphNode] = []
    for node in graph.nodes:
        if node.groupId and node.groupId in nodes_by_group:
            nodes_by_group[node.groupId].append(node)
        else:
            ungrouped.append(node)

    cursor_y = 40

    # --- Group containers (each a labelled band of its child nodes) ---
    for group in graph.groups:
        members = nodes_by_group.get(group.id, [])
        if not members:
            # Empty group: still emit the container so the label survives a round-trip.
            lines += _group_cell(group, 40, cursor_y, _NODE_W + 2 * _GROUP_PAD, _NODE_H + 2 * _GROUP_PAD)
            cursor_y += _NODE_H + 2 * _GROUP_PAD + _GROUP_GAP
            continue
        rows = (len(members) + _COLS - 1) // _COLS
        cols = min(len(members), _COLS)
        inner_w = cols * _NODE_W + (cols - 1) * _COL_GAP
        inner_h = rows * _NODE_H + (rows - 1) * _ROW_GAP
        group_w = inner_w + 2 * _GROUP_PAD
        group_h = inner_h + 2 * _GROUP_PAD + 16  # +16 for the top label band
        lines += _group_cell(group, 40, cursor_y, group_w, group_h)
        for idx, node in enumerate(members):
            row, col = divmod(idx, _COLS)
            x = 40 + _GROUP_PAD + col * (_NODE_W + _COL_GAP)
            y = cursor_y + _GROUP_PAD + 16 + row * (_NODE_H + _ROW_GAP)
            lines += _node_cell(node, x, y, parent="1")
        cursor_y += group_h + _GROUP_GAP

    # --- Ungrouped nodes (seed grid) ---
    for idx, node in enumerate(ungrouped):
        row, col = divmod(idx, _COLS)
        x = 40 + col * (_NODE_W + _COL_GAP)
        y = cursor_y + row * (_NODE_H + _ROW_GAP)
        lines += _node_cell(node, x, y, parent="1")

    # --- Edges (after all vertices so source/target ids resolve) ---
    for index, edge in enumerate(graph.edges):
        lines += _edge_cells(edge, index)

    lines += [
        "      </root>",
        "    </mxGraphModel>",
        "  </diagram>",
        "</mxfile>",
    ]
    return "\n".join(lines)


__all__ = ["export_drawio"]
