"""GitHub repo fetch service for RepoGraph (Surface 3) — github.com, optional PAT.

Ported from gitdiagram ``backend/app/services/github_service.py`` and adapted to DocEX,
the sibling of :mod:`docx_app.diagram.gitlab_service`:
  - **async**, all outbound calls via :func:`docx_app.http.make_client` (corporate-CA TLS),
    never a raw ``httpx`` client — same as the GitLab service.
  - Auth = an **optional** Personal Access Token (``Authorization: token <pat>``) from
    config; public repos need none. The GitHub-App / JWT installation-token dance in
    gitdiagram is intentionally dropped (a single optional token is sufficient here, exactly
    like GitLab's PAT model).
  - Three GitHub REST v3 endpoints (gitdiagram, verbatim shapes):
      GET /repos/{owner}/{repo}                              → default_branch
      GET /repos/{owner}/{repo}/git/trees/{branch}?recursive=1 → file tree (``truncated`` gate)
      GET /repos/{owner}/{repo}/readme                       → base64 README
  - Reuses :data:`~docx_app.diagram.gitlab_service.EXCLUDED_PATTERNS` + the size caps so the
    flat file-tree contract the 2-step pipeline consumes is **identical** across providers.

The provider dispatcher (:mod:`docx_app.diagram.repo_fetch`) detects github.com URLs and
delegates here; ``api/repograph.py`` never imports this module directly (it talks to the
dispatcher's unified ``RepoData`` + error hierarchy).
"""

from __future__ import annotations

import base64
import binascii
from dataclasses import dataclass
from urllib.parse import urlparse

import structlog

from docx_app.config import DocxConfig
from docx_app.diagram.gitlab_service import (
    EXCLUDED_PATTERNS,
    MAX_README_BYTES,
    REPOSITORY_TOO_LARGE_ERROR,
)
from docx_app.http import make_client

log = structlog.get_logger(__name__)

_ParamValue = str | int | float | bool | None
_Params = dict[str, _ParamValue]

# Hosts we treat as github.com (the dispatcher also checks these).
GITHUB_HOSTS: frozenset[str] = frozenset({"github.com", "www.github.com"})


class GitHubNotFoundError(ValueError):
    """Repository or resource not found (HTTP 404). The dispatcher maps this to 404."""


class GitHubFetchError(RuntimeError):
    """Non-retryable GitHub API error (a non-2xx that is not 404) → mapped to 502."""


@dataclass(frozen=True)
class GitHubData:
    """The pieces the pipeline needs (parallel to ``GitLabData``).

    ``namespace`` is ``"owner/repo"`` — used to derive repo_owner/repo_name for the prompts
    and the FE repo label; there is no numeric project id on GitHub (the API keys on the
    ``owner/repo`` path), so unlike ``GitLabData`` there is no ``project_id``.
    """

    default_branch: str
    file_tree: str
    readme: str
    namespace: str


def parse_github_url(repo_url: str) -> tuple[str, str]:
    """Extract ``(owner, repo)`` from a github.com URL; raise ``ValueError`` otherwise.

    Accepts ``https://github.com/owner/repo`` (with or without a trailing ``/``, ``.git``
    suffix, or extra path segments like ``/tree/main``). A non-github host or a path without
    at least ``<owner>/<repo>`` is a caller error (the dispatcher maps ``ValueError`` → 422).
    """
    parsed = urlparse(repo_url.strip())
    host = (parsed.netloc or "").lower()
    if host not in GITHUB_HOSTS:
        raise ValueError(f"not a github.com URL: {repo_url!r}")
    parts = [p for p in parsed.path.split("/") if p]
    if len(parts) < 2:
        raise ValueError(
            f"github URL {repo_url!r} has no '<owner>/<repo>' path "
            "(expected 'https://github.com/<owner>/<repo>')."
        )
    owner, repo = parts[0], parts[1]
    if repo.endswith(".git"):
        repo = repo[:-4]
    return owner, repo


class GitHubService:
    """Fetches repo data from github.com (or a configured GitHub Enterprise API base).

    Stateless; construct per request. Reads ``github_api_url`` / ``github_token`` /
    ``gitlab_timeout_s`` (shared per-request timeout) / ``repograph_max_file_tree_chars``
    from :class:`DocxConfig`.
    """

    def __init__(self, config: DocxConfig) -> None:
        self._config = config

    def _api_base(self) -> str:
        """The GitHub REST API root (``https://api.github.com`` by default; Enterprise override)."""
        return (self._config.github_api_url or "https://api.github.com").strip().rstrip("/")

    def _headers(self) -> dict[str, str]:
        """Standard GitHub headers + an optional ``token`` auth (public repos need none)."""
        headers = {
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        token = (self._config.github_token or "").strip()
        if token:
            headers["Authorization"] = f"token {token}"
        return headers

    @staticmethod
    def _should_include(path: str) -> bool:
        """``True`` when ``path`` matches none of the shared :data:`EXCLUDED_PATTERNS`."""
        lower = path.lower()
        return not any(pattern in lower for pattern in EXCLUDED_PATTERNS)

    async def _get_json(
        self, url: str, params: _Params | None = None
    ) -> dict[str, object] | list[object]:
        """GET ``url`` via the corporate-CA client; typed errors on failure.

        404 → :class:`GitHubNotFoundError`; any other non-2xx → :class:`GitHubFetchError`.
        """
        async with make_client(
            self._config, timeout=self._config.gitlab_timeout_s
        ) as client:
            resp = await client.get(url, headers=self._headers(), params=params or {})
        if resp.status_code == 404:
            raise GitHubNotFoundError(f"GitHub 404: {url}")
        if not resp.is_success:
            raise GitHubFetchError(
                f"GitHub request failed ({resp.status_code}): {resp.text[:300]}"
            )
        body: dict[str, object] | list[object] = resp.json()
        return body

    async def get_default_branch(self, owner: str, repo: str) -> str:
        """``GET /repos/{owner}/{repo}`` → the default branch (falls back to ``"main"``)."""
        data = await self._get_json(f"{self._api_base()}/repos/{owner}/{repo}")
        if not isinstance(data, dict):
            raise GitHubFetchError(
                f"Unexpected GitHub repo response for {owner}/{repo} "
                f"(expected an object, got {type(data).__name__})."
            )
        branch = data.get("default_branch")
        return branch if isinstance(branch, str) and branch else "main"

    async def get_file_tree(self, owner: str, repo: str, branch: str) -> str:
        """Recursive blob tree as a filtered, newline-delimited string (gitdiagram contract).

        ``GET /repos/{owner}/{repo}/git/trees/{branch}?recursive=1``. GitHub flags a tree it
        could not return in full with ``truncated: true`` → that is the "too large" gate
        (mirrors gitdiagram). Only ``type == "blob"`` entries are kept (files), filtered
        through :data:`EXCLUDED_PATTERNS`; the joined string is checked against
        ``repograph_max_file_tree_chars``.
        """
        data = await self._get_json(
            f"{self._api_base()}/repos/{owner}/{repo}/git/trees/{branch}",
            params={"recursive": "1"},
        )
        if not isinstance(data, dict):
            raise GitHubFetchError(
                f"Unexpected GitHub tree response (expected an object, got "
                f"{type(data).__name__})."
            )
        if data.get("truncated") is True:
            raise ValueError(REPOSITORY_TOO_LARGE_ERROR)
        tree = data.get("tree")
        if not isinstance(tree, list):
            raise GitHubFetchError("GitHub tree response has no 'tree' list.")
        paths: list[str] = []
        for item in tree:
            if not isinstance(item, dict) or item.get("type") != "blob":
                continue
            path = item.get("path")
            if isinstance(path, str) and path and self._should_include(path):
                paths.append(path)
        file_tree = "\n".join(paths)
        if len(file_tree) > self._config.repograph_max_file_tree_chars:
            raise ValueError(REPOSITORY_TOO_LARGE_ERROR)
        return file_tree

    async def get_readme(self, owner: str, repo: str) -> str:
        """``GET /repos/{owner}/{repo}/readme`` → decoded README, or ``""`` if none.

        GitHub returns the README (any conventional name) base64-encoded. A 404 (no README)
        is fine → ``""``. The result is truncated to :data:`MAX_README_BYTES`. Never raises
        on a missing/garbled README; only a non-404 upstream error raises.
        """
        try:
            data = await self._get_json(
                f"{self._api_base()}/repos/{owner}/{repo}/readme"
            )
        except GitHubNotFoundError:
            return ""
        if not isinstance(data, dict):
            return ""
        content = data.get("content")
        if not isinstance(content, str) or not content:
            return ""
        if data.get("encoding") == "base64":
            try:
                text = base64.b64decode(content).decode("utf-8", errors="replace")
            except (binascii.Error, ValueError):
                return ""
        else:
            text = content
        if len(text.encode("utf-8")) > MAX_README_BYTES:
            text = text.encode("utf-8")[:MAX_README_BYTES].decode("utf-8", errors="ignore")
        return text

    async def get_github_data(self, repo_url: str) -> GitHubData:
        """Full fetch: metadata + tree + README. The single entry point for the dispatcher.

        Raises:
            ValueError: a non-github URL or a file tree over the cap.
            GitHubNotFoundError: the repo does not exist / is private + inaccessible.
            GitHubFetchError: any other upstream GitHub error.
        """
        owner, repo = parse_github_url(repo_url)
        default_branch = await self.get_default_branch(owner, repo)
        file_tree = await self.get_file_tree(owner, repo, default_branch)
        readme = await self.get_readme(owner, repo)
        namespace = f"{owner}/{repo}"
        log.info(
            "github_data_fetched",
            namespace=namespace,
            tree_lines=(file_tree.count("\n") + 1 if file_tree else 0),
            readme_bytes=len(readme.encode("utf-8")),
        )
        return GitHubData(
            default_branch=default_branch,
            file_tree=file_tree,
            readme=readme,
            namespace=namespace,
        )


__all__ = [
    "GitHubService",
    "GitHubData",
    "GitHubNotFoundError",
    "GitHubFetchError",
    "GITHUB_HOSTS",
    "parse_github_url",
]
