"""Bundled shape/icon catalogs for the diagram pipeline + a guarded accessor.

This subpackage holds the controlled vocabularies of icon ids the LLM may set on
``DiagramGraphNode.icon`` (so icons are chosen from a known catalog, never
hallucinated) and that the SVG renderer maps to bundled artwork. Surface 1 (the
Source "Diagram" tab) ships the Azure catalog (``azure.py``), transcribed from
next-ai-draw-io's ``docs/shape-libraries/azure2.md``.

Public surface:
  - ``get_shape_library(name)`` — path-traversal-guarded accessor (mirrors the
    next-ai-draw-io tool), returns ``{category: (ShapeName, ...)}``.
  - ``AZURE_CATALOG`` / ``AZURE_ICON_IDS`` / ``azure_icon_ids()`` — the Azure data.
  - ``is_known_icon(id)`` / ``split_icon_id(id)`` — non-raising lookups for the
    renderer's generic-shape fallback path.

IMPORTANT (design §12): this subpackage ships only the *names*. The SVG *bytes*
are a separate, governed asset bundle — draw.io ``azure2`` stencils and the
official Microsoft "Azure Architecture Icons" set are DIFFERENT artifacts with
DIFFERENT licenses; pin the source-of-bytes + license before bundling. See the
header of ``azure.py`` for the full caveat. No filesystem/network access and no
draw.io runtime dependency on any path.
"""

from __future__ import annotations

from docx_app.diagram.shape_libraries.azure import (
    AZURE_CATALOG,
    AZURE_ICON_IDS,
    ICON_ID_PREFIX,
    LIBRARY_NAME,
    azure_icon_ids,
    get_shape_library,
    is_known_icon,
    split_icon_id,
)

__all__ = [
    "AZURE_CATALOG",
    "AZURE_ICON_IDS",
    "ICON_ID_PREFIX",
    "LIBRARY_NAME",
    "azure_icon_ids",
    "get_shape_library",
    "is_known_icon",
    "split_icon_id",
]
