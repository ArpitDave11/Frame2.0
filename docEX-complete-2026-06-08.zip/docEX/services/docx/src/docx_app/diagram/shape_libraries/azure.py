"""Azure shape/icon catalog + a path-traversal-guarded library accessor.

This is the SHARED-FOUNDATION catalog of Azure icon ids that the diagram
pipeline offers to the LLM (so a node's ``icon`` is chosen from a known set,
never hallucinated) and that the renderer maps to bundled SVG bytes.

Source / provenance
-------------------
The category/shape names below are transcribed from the next-ai-draw-io
reference catalog ``docs/shape-libraries/azure2.md`` (the draw.io ``azure2``
stencil index, 648 shapes, asset path ``img/lib/azure2/{category}/{Shape}.svg``).
That index is REUSED VERBATIM here as the controlled vocabulary; only the id
*format* is adapted (see below).

Icon id format
--------------
A ``DiagramGraphNode.icon`` value is ``"azure/{category}/{ShapeName}"`` — e.g.
``"azure/compute/Virtual_Machine"`` (design `docs/2026-06-06-diagram-platform-
design.md` §2; matches `docx_app.diagram.model.DiagramGraphNode.icon`). Note the
single ``azure/`` prefix, NOT the draw.io ``azure2/`` / ``img/lib/azure2/`` asset
path — this module is the bridge between the model's id namespace and the catalog.

LICENSING / PROVENANCE CAVEAT  (design §12 — HARD CONSTRAINT, read before bundling SVG bytes)
--------------------------------------------------------------------------------------------
This module ships only the *names* (a controlled vocabulary), which carry no
artwork. The actual SVG *bytes* are a separate, governed asset bundle, and the
two legitimate sources are DIFFERENT artifacts with DIFFERENT terms:

  * draw.io ``azure2`` stencils — draw.io-reformatted outlines under draw.io's
    own license (diagrams.net/draw.io OSS, Apache-2.0). These are the artifacts
    this catalog's *names* come from. They are NOT Microsoft brand assets.
  * Microsoft "Azure Architecture Icons" — the canonical Microsoft brand set,
    under Microsoft's *Azure Architecture Icons Terms of Use*: use only in
    architecture diagrams; do NOT alter the icons; do NOT imply Microsoft
    endorsement; distribute only within an organization's own tooling/docs.

Per design §12, before committing 600+ SVGs into a UBS-internal product you MUST
pin the exact source-of-bytes (URL), the version/date downloaded, and the
applicable license in a ``NOTICE``/``ATTRIBUTION`` file, and obtain a quick
third-party-asset/licensing nod — this is separate from the npm-dependency check.
The draw.io stencils and the official MS set are NOT interchangeable artifacts.

Scope note
----------
This module is the SHARED FOUNDATION used by Surface 1 (the Source "Diagram"
tab). It is pure data + a read-only accessor: no I/O of SVG bytes, no network,
no draw.io runtime dependency on any path.
"""

from __future__ import annotations

from typing import Final

# ---------------------------------------------------------------------------
# The id namespace prefix. A node's ``icon`` is ``f"{ICON_ID_PREFIX}/{category}/{shape}"``.
# (The draw.io on-disk asset tree uses ``azure2/`` / ``img/lib/azure2/`` — different.)
# ---------------------------------------------------------------------------
ICON_ID_PREFIX: Final = "azure"

# The catalog is keyed as a single library name so the accessor mirrors
# next-ai-draw-io's ``get_shape_library('azure2')`` shape (one library → its index).
LIBRARY_NAME: Final = "azure"

# ---------------------------------------------------------------------------
# AZURE_CATALOG: category -> ordered tuple of ShapeName.
#
# Transcribed from ``docs/shape-libraries/azure2.md``. Categories whose full
# member list is enumerated in that file are reproduced in full; the ``other``
# category (149 shapes, only a partial "Selected shapes" list published in the
# reference) carries that published subset. The catalog is intentionally a
# superset of what any one diagram needs — the pipeline filters/suggests from it.
# ---------------------------------------------------------------------------
AZURE_CATALOG: Final[dict[str, tuple[str, ...]]] = {
    "ai_machine_learning": (
        "AI_Studio",
        "Anomaly_Detector",
        "Azure_Applied_AI",
        "Azure_Experimentation_Studio",
        "Azure_Object_Understanding",
        "Azure_OpenAI",
        "Batch_AI",
        "Bonsai",
        "Bot_Services",
        "Cognitive_Services",
        "Cognitive_Services_Decisions",
        "Computer_Vision",
        "Content_Moderators",
        "Content_Safety",
        "Custom_Vision",
        "Face_APIs",
        "Form_Recognizers",
        "Genomics",
        "Immersive_Readers",
        "Language_Services",
        "Language_Understanding",
        "Machine_Learning",
        "Machine_Learning_Studio_Classic_Web_Services",
        "Machine_Learning_Studio_Web_Service_Plans",
        "Machine_Learning_Studio_Workspaces",
        "Personalizers",
        "QnA_Makers",
        "Serverless_Search",
        "Speech_Services",
        "Translator_Text",
    ),
    "analytics": (
        "Analysis_Services",
        "Azure_Databricks",
        "Azure_Synapse_Analytics",
        "Azure_Workbooks",
        "Data_Lake_Analytics",
        "Data_Lake_Store_Gen1",
        "Endpoint_Analytics",
        "Event_Hub_Clusters",
        "Event_Hubs",
        "HD_Insight_Clusters",
        "Log_Analytics_Workspaces",
        "Power_BI_Embedded",
        "Power_Platform",
        "Stream_Analytics_Jobs",
    ),
    "app_services": (
        "API_Management_Services",
        "App_Service_Certificates",
        "App_Service_Domains",
        "App_Service_Environments",
        "App_Service_Plans",
        "App_Services",
        "CDN_Profiles",
        "Notification_Hubs",
        "Search_Services",
    ),
    "compute": (
        "App_Services",
        "Application_Group",
        "Automanaged_VM",
        "Availability_Sets",
        "Azure_Compute_Galleries",
        "Azure_Spring_Cloud",
        "Batch_Accounts",
        "Cloud_Services_Classic",
        "Container_Instances",
        "Container_Services_Deprecated",
        "Disk_Encryption_Sets",
        "Disks",
        "Disks_Classic",
        "Disks_Snapshots",
        "Function_Apps",
        "Host_Groups",
        "Host_Pools",
        "Hosts",
        "Image_Definitions",
        "Image_Templates",
        "Image_Versions",
        "Images",
        "Kubernetes_Services",
        "Maintenance_Configuration",
        "Managed_Service_Fabric",
        "Mesh_Applications",
        "Metrics_Advisor",
        "OS_Images_Classic",
        "Restore_Points",
        "Restore_Points_Collections",
        "Service_Fabric_Clusters",
        "Shared_Image_Galleries",
        "VM_Images_Classic",
        "VM_Scale_Sets",
        "Virtual_Machine",
        "Virtual_Machines_Classic",
        "Workspaces",
        "Workspaces2",
    ),
    "containers": (
        "App_Services",
        "Azure_Red_Hat_OpenShift",
        "Batch_Accounts",
        "Container_Instances",
        "Container_Registries",
        "Kubernetes_Services",
        "Service_Fabric_Clusters",
    ),
    "databases": (
        "Azure_Cosmos_DB",
        "Azure_Data_Explorer_Clusters",
        "Azure_Database_MariaDB_Server",
        "Azure_Database_Migration_Services",
        "Azure_Database_MySQL_Server",
        "Azure_Database_PostgreSQL_Server",
        "Azure_Database_PostgreSQL_Server_Group",
        "Azure_Purview_Accounts",
        "Azure_SQL",
        "Azure_SQL_Edge",
        "Azure_SQL_Server_Stretch_Databases",
        "Azure_SQL_VM",
        "Azure_Synapse_Analytics",
        "Cache_Redis",
        "Data_Factory",
        "Elastic_Job_Agents",
        "Instance_Pools",
        "Managed_Database",
        "Oracle_Database",
        "SQL_Data_Warehouses",
        "SQL_Database",
        "SQL_Elastic_Pools",
        "SQL_Managed_Instance",
        "SQL_Server",
        "SQL_Server_Registries",
        "SSIS_Lift_And_Shift_IR",
        "Virtual_Clusters",
    ),
    "identity": (
        "AAD_Licenses",
        "Active_Directory_Connect_Health",
        "Active_Directory_Connect_Health2",
        "Administrative_Units",
        "App_Registrations",
        "Azure_AD_B2C",
        "Azure_AD_B2C2",
        "Azure_AD_Domain_Services",
        "Azure_AD_Identity_Protection",
        "Azure_AD_Privilege_Identity_Management",
        "Azure_Active_Directory",
        "Azure_Information_Protection",
        "Custom_Azure_AD_Roles",
        "Enterprise_Applications",
        "Entra_Connect",
        "Entra_Domain_Services",
        "Entra_Global_Secure_Access",
        "Entra_ID_Protection",
        "Entra_Internet_Access",
        "Entra_Managed_Identities",
        "Entra_Private_Access",
        "Entra_Privileged_Identity_Management",
        "Entra_Verified_ID",
        "External_Identities",
        "Groups",
        "Identity_Governance",
        "Managed_Identities",
        "Multi_Factor_Authentication",
        "PIM",
        "Security",
        "Tenant_Properties",
        "User_Settings",
        "Users",
        "Verifiable_Credentials",
        "Verification_As_A_Service",
    ),
    "networking": (
        "ATM_Multistack",
        "Application_Gateway_Containers",
        "Application_Gateways",
        "Azure_Communications_Gateway",
        "Azure_Firewall_Manager",
        "Azure_Firewall_Policy",
        "Bastions",
        "CDN_Profiles",
        "Connections",
        "DDoS_Protection_Plans",
        "DNS_Multistack",
        "DNS_Private_Resolver",
        "DNS_Security_Policy",
        "DNS_Zones",
        "ExpressRoute_Circuits",
        "Firewalls",
        "Front_Doors",
        "IP_Address_manager",
        "IP_Groups",
        "Load_Balancer_Hub",
        "Load_Balancers",
        "Local_Network_Gateways",
        "NAT",
        "Network_Interfaces",
        "Network_Security_Groups",
        "Network_Watcher",
        "On_Premises_Data_Gateways",
        "Private_Endpoint",
        "Private_Link",
        "Private_Link_Hub",
        "Private_Link_Service",
        "Proximity_Placement_Groups",
        "Public_IP_Addresses",
        "Public_IP_Addresses_Classic",
        "Public_IP_Prefixes",
        "Reserved_IP_Addresses_Classic",
        "Resource_Management_Private_Link",
        "Route_Filters",
        "Route_Tables",
        "Service_Endpoint_Policies",
        "Spot_VM",
        "Spot_VMSS",
        "Subnet",
        "Traffic_Manager_Profiles",
        "Virtual_Network_Gateways",
        "Virtual_Networks",
        "Virtual_Networks_Classic",
        "Virtual_Router",
        "Virtual_WAN_Hub",
        "Virtual_WANs",
        "Web_Application_Firewall_Policies_WAF",
    ),
    "security": (
        "Application_Security_Groups",
        "Azure_AD_Risky_Signins",
        "Azure_AD_Risky_Users",
        "Azure_Defender",
        "Azure_Sentinel",
        "Conditional_Access",
        "Detonation",
        "ExtendedSecurityUpdates",
        "Identity_Secure_Score",
        "Key_Vaults",
        "Keys",
        "MS_Defender_EASM",
        "Multifactor_Authentication",
        "Security_Center",
    ),
    "storage": (
        "Azure_Fileshare",
        "Azure_HCP_Cache",
        "Azure_NetApp_Files",
        "Azure_Stack_Edge",
        "Data_Box",
        "Data_Box_Edge",
        "Data_Lake_Storage_Gen1",
        "Data_Share_Invitations",
        "Data_Shares",
        "Import_Export_Jobs",
        "Recovery_Services_Vaults",
        "StorSimple_Data_Managers",
        "StorSimple_Device_Managers",
        "Storage_Accounts",
        "Storage_Accounts_Classic",
        "Storage_Explorer",
        "Storage_Sync_Services",
    ),
    "general": (
        "All_Resources",
        "Backlog",
        "Biz_Talk",
        "Blob_Block",
        "Blob_Page",
        "Branch",
        "Browser",
        "Bug",
        "Builds",
        "Cache",
        "Code",
        "Commit",
        "Controls",
        "Controls_Horizontal",
        "Cost_Alerts",
        "Cost_Analysis",
        "Cost_Budgets",
        "Cost_Management",
        "Cost_Management_and_Billing",
        "Counter",
        "Cubes",
        "Dashboard",
        "Dashboard2",
        "Dev_Console",
        "Download",
        "Error",
        "Extensions",
        "FTP",
        "File",
        "Files",
        "Folder_Blank",
        "Folder_Website",
        "Free_Services",
        "Gear",
        "Globe",
        "Globe_Error",
        "Globe_Success",
        "Globe_Warning",
        "Guide",
        "Heart",
        "Help_and_Support",
        "Image",
        "Information",
        "Input_Output",
        "Journey_Hub",
        "Launch_Portal",
        "Learn",
        "Load_Test",
        "Location",
        "Log_Streaming",
        "Management_Groups",
        "Management_Portal",
        "Marketplace",
        "Media",
        "Media_File",
        "Mobile",
        "Mobile_Engagement",
        "Module",
        "Power",
        "Power_Up",
        "Powershell",
        "Preview",
        "Preview_Features",
        "Process_Explorer",
        "Production_Ready_Database",
        "Quickstart_Center",
        "Recent",
        "Reservations",
        "Resource_Explorer",
        "Resource_Group_List",
        "Resource_Groups",
        "Resource_Linked",
        "SSD",
        "Scale",
        "Scheduler",
        "Search",
        "Search_Grid",
        "Server_Farm",
        "Service_Bus",
        "Service_Health",
        "Storage_Azure_Files",
        "Storage_Container",
        "Storage_Queue",
        "Subscriptions",
        "TFS_VC_Repository",
        "Table",
        "Tag",
        "Tags",
        "Templates",
        "Toolbox",
        "Troubleshoot",
        "Versions",
        "Web_Slots",
        "Web_Test",
        "Website_Power",
        "Website_Staging",
        "Workbooks",
        "Workflow",
    ),
    # 149 shapes total in draw.io; azure2.md publishes only this "Selected
    # shapes" subset. The catalog therefore carries the named subset; an
    # unrecognised "other" id still resolves to the generic-shape fallback in
    # the renderer (it is never an error).
    "other": (
        "Azure_Backup_Center",
        "Azure_Chaos_Studio",
        "Azure_Cloud_Shell",
        "Azure_Communication_Services",
        "Azure_Deployment_Environments",
        "Azure_Load_Testing",
        "Azure_Monitor_Dashboard",
        "Azure_Network_Manager",
        "Azure_Orbital",
        "Azure_Sphere",
        "Azure_Storage_Mover",
        "Grafana",
        "Kubernetes_Fleet_Manager",
        "SSH_Keys",
    ),
    "azure_ecosystem": (
        "Applens",
        "Azure_Hybrid_Center",
        "Collaborative_Service",
    ),
    "azure_stack": (
        "Azure_Stack",
        "Capacity",
        "Infrastructure_Backup",
        "Multi_Tenancy",
        "Offers",
        "Plans",
        "Updates",
        "User_Subscriptions",
    ),
    "azure_vmware_solution": ("AVS",),
    "blockchain": (
        "ABS_Member",
        "Azure_Blockchain_Service",
        "Azure_Token_Service",
        "Blockchain_Applications",
        "Consortium",
        "Outbound_Connection",
    ),
    "cxp": (
        "Elixir",
        "Elixir_Purple",
    ),
    "devops": (
        "API_Connections",
        "Application_Insights",
        "Azure_DevOps",
        "Change_Analysis",
        "CloudTest",
        "Code_Optimization",
        "DevOps_Starter",
        "DevTest_Labs",
        "Lab_Accounts",
        "Lab_Services",
    ),
    "hybrid_multicloud": (
        "Azure_Operator_5G_Core",
        "Azure_Operator_Insights",
        "Azure_Operator_Nexus",
        "Azure_Operator_Service_Manager",
        "Azure_Programmable_Connectivity",
    ),
    "integration": (
        "API_Management_Services",
        "App_Configuration",
        "Azure_API_for_FHIR",
        "Azure_Data_Catalog",
        "Event_Grid_Domains",
        "Event_Grid_Subscriptions",
        "Event_Grid_Topics",
        "Integration_Accounts",
        "Integration_Environments",
        "Integration_Service_Environments",
        "Logic_Apps",
        "Logic_Apps_Custom_Connector",
        "Partner_Namespace",
        "Partner_Registration",
        "Partner_Topic",
        "Relays",
        "SQL_Data_Warehouses",
        "SendGrid_Accounts",
        "Service_Bus",
        "Software_as_a_Service",
        "System_Topic",
    ),
    "internet_of_things": (
        "Digital_Twins",
        "Logic_Apps",
        "Time_Series_Insights_Access_Policies",
    ),
    "iot": (
        "Azure_IoT_Operations",
        "Azure_Maps_Accounts",
        "Azure_Stack_HCI_Sizer",
        "Device_Provisioning_Services",
        "Digital_Twins",
        "Event_Hubs",
        "Function_Apps",
        "Industrial_IoT",
        "IoT_Central_Applications",
        "IoT_Edge",
        "IoT_Hub",
        "Logic_Apps",
        "Notification_Hubs",
        "Stack_HCI_Premium",
        "Stream_Analytics_Jobs",
        "Time_Series_Data_Sets",
        "Time_Series_Insights_Environments",
        "Time_Series_Insights_Event_Sources",
        "Windows10_Core_Services",
    ),
    "intune": (
        "Azure_AD_Roles_and_Administrators",
        "Client_Apps",
        "Device_Compliance",
        "Device_Configuration",
        "Device_Enrollment",
        "Device_Security_Apple",
        "Device_Security_Google",
        "Device_Security_Windows",
        "Devices",
        "Exchange_Access",
        "Intune",
        "Intune_For_Education",
        "Mindaro",
        "Security_Baselines",
        "Software_Updates",
        "Tenant_Status",
        "eBooks",
    ),
    "management_governance": (
        "Activity_Log",
        "Advisor",
        "Alerts",
        "Application_Insights",
        "Arc_Machines",
        "Automation_Accounts",
        "Azure_Arc",
        "Azure_Lighthouse",
        "Blueprints",
        "Compliance",
        "Cost_Management_and_Billing",
        "Customer_Lockbox_for_MS_Azure",
        "Diagnostics_Settings",
        "Education",
        "Log_Analytics_Workspaces",
        "MachinesAzureArc",
        "Managed_Applications_Center",
        "Managed_Desktop",
        "Metrics",
        "Monitor",
        "My_Customers",
        "Operation_Log_Classic",
        "Policy",
        "Recovery_Services_Vaults",
        "Resource_Graph_Explorer",
        "Resources_Provider",
        "Scheduler_Job_Collections",
        "Service_Catalog_MAD",
        "Service_Providers",
        "Solutions",
        "Universal_Print",
        "User_Privacy",
    ),
    "menu": ("Keys",),
    "migrate": (
        "Azure_Migrate",
        "Cost_Management_and_Billing",
        "Data_Box",
        "Data_Box_Edge",
        "Recovery_Services_Vaults",
    ),
    "mixed_reality": (
        "Remote_Rendering",
        "Spatial_Anchor_Accounts",
    ),
    "monitor": ("SAP_Azure_Monitor",),
    "power_platform": (
        "AIBuilder",
        "CopilotStudio",
        "Dataverse",
        "PowerApps",
        "PowerAutomate",
        "PowerBI",
        "PowerFx",
        "PowerPages",
        "PowerPlatform",
    ),
    "preview": (
        "Azure_Cloud_Shell",
        "Azure_Sphere",
        "Azure_Workbooks",
        "IoT_Edge",
        "Private_Link_Hub",
        "RTOS",
        "Static_Apps",
        "Time_Series_Data_Sets",
        "Web_Environment",
    ),
    "web": (
        "API_Center",
        "App_Space",
        "Azure_Media_Service",
        "Notification_Hub_Namespaces",
        "SignalR",
    ),
}


def _build_icon_id_index() -> frozenset[str]:
    """Flatten :data:`AZURE_CATALOG` into the set of full ``icon`` id strings.

    Each entry is ``f"{ICON_ID_PREFIX}/{category}/{shape}"`` — the exact value a
    ``DiagramGraphNode.icon`` may hold. Built once at import time; immutable.
    """
    ids: set[str] = set()
    for category, shapes in AZURE_CATALOG.items():
        for shape in shapes:
            ids.add(f"{ICON_ID_PREFIX}/{category}/{shape}")
    return frozenset(ids)


# All valid ``azure/{category}/{shape}`` icon ids, precomputed once.
AZURE_ICON_IDS: Final[frozenset[str]] = _build_icon_id_index()


def azure_icon_ids() -> tuple[str, ...]:
    """Return every valid ``azure/{category}/{shape}`` icon id, sorted.

    Useful for prompt construction (offering the catalog to the LLM) and tests.
    """
    return tuple(sorted(AZURE_ICON_IDS))


def is_known_icon(icon_id: str) -> bool:
    """True iff ``icon_id`` is a recognised ``azure/{category}/{shape}`` id.

    The renderer/pipeline must treat an unknown id as a soft miss (fall back to
    the node's generic ``shape``), NEVER as an error — so this is a pure lookup
    with no exceptions.
    """
    return icon_id in AZURE_ICON_IDS


def split_icon_id(icon_id: str) -> tuple[str, str] | None:
    """Split a valid icon id into ``(category, shape)``; ``None`` if unknown/malformed.

    Example: ``"azure/compute/Virtual_Machine" -> ("compute", "Virtual_Machine")``.
    Returns ``None`` (never raises) for any id not in the catalog so callers can
    branch to the generic-shape fallback.
    """
    if not is_known_icon(icon_id):
        return None
    # Known ids are exactly ``azure/{category}/{shape}`` (shape names contain no
    # ``/``), so a 3-way split on the two separators is unambiguous.
    _prefix, category, shape = icon_id.split("/", 2)
    return (category, shape)


def get_shape_library(library: str) -> dict[str, tuple[str, ...]]:
    """Return a shape catalog by library name, with a path-traversal guard.

    Mirrors next-ai-draw-io's ``get_shape_library`` tool (sanitise the name →
    confine resolution to a known base → reject anything that escapes it), but
    serves an in-memory catalog rather than reading a ``{library}.md`` file, so
    there is no filesystem access and no draw.io runtime dependency. The guard is
    retained because ``library`` may be model- or user-supplied, and the call
    site is intended to look exactly like the reference tool.

    Args:
        library: Library name (only ``"azure"`` is bundled for Surface 1).

    Returns:
        A fresh ``{category: (ShapeName, ...)}`` mapping (a shallow copy, so the
        module-level :data:`AZURE_CATALOG` can never be mutated by a caller).

    Raises:
        KeyError: if ``library`` is unknown *after* sanitisation. The message
            lists the available libraries (only ``"azure"`` today).
        ValueError: if ``library`` contains characters outside ``[a-z0-9_-]``
            (after lowercasing) — i.e. a name that could attempt path traversal
            or otherwise does not match the allow-list (e.g. ``"../secrets"``).
    """
    # 1. Normalise + sanitise: lowercase, then strip anything outside the
    #    allow-list. This neutralises ``/``, ``.``, ``\\`` and other separators.
    normalised = library.lower()
    sanitised = "".join(ch for ch in normalised if ch in _ALLOWED_LIBRARY_CHARS)

    # 2. Reject if sanitisation changed the (lowercased) input — a mismatch means
    #    the caller passed disallowed characters (the path-traversal guard).
    if sanitised != normalised:
        raise ValueError(
            f"Invalid library name {library!r}: use only lowercase letters, "
            "digits, underscores, and hyphens."
        )

    # 3. Allow-list lookup. Only catalogs registered in _LIBRARIES are served;
    #    there is no path to construct, so traversal is impossible by design —
    #    this dict membership IS the confinement.
    try:
        catalog = _LIBRARIES[sanitised]
    except KeyError as exc:
        available = ", ".join(sorted(_LIBRARIES))
        raise KeyError(
            f"Shape library {library!r} not found. Available: {available}."
        ) from exc

    # 4. Return a shallow copy so the immutable module-level catalog is never
    #    handed out by reference (the tuples themselves are already immutable).
    return dict(catalog)


# Characters permitted in a (lowercased) library name — the allow-list that
# powers the path-traversal guard in :func:`get_shape_library`.
_ALLOWED_LIBRARY_CHARS: Final[frozenset[str]] = frozenset(
    "abcdefghijklmnopqrstuvwxyz0123456789_-"
)

# Registry of bundled shape libraries. Surface 1 ships only Azure; adding a
# library later is a one-line entry here (plus its catalog + governed SVG bytes).
_LIBRARIES: Final[dict[str, dict[str, tuple[str, ...]]]] = {
    LIBRARY_NAME: AZURE_CATALOG,
}
