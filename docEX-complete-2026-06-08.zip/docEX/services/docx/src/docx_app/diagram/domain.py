"""DiagramStore — owner-scoped persistence for a source/notebook/repo diagram.

Slim, owner/scope-native store for the diagram feature, mirroring `domain/note.py`
and `domain/settings.py` exactly. A diagram is the canonical, render-agnostic
`DiagramGraph` (see `diagram/model.py`) produced by the 2-step LLM pipeline, stored
as `graph_json`. One table (`diagram`, migration `0009_diagram.surql`) backs all
three surfaces (source LLD / notebook HLD / RepoGraph), distinguished by
`surface` + `ref`. Surface 1 (the source "Diagram" tab) is the only consumer here.

Tenancy: diagrams are owner-PRIVATE (a user's diagram is their own intellectual
work, NOT part of the shared org brain) — same rule as Note + Settings. Every write
is stamped owner + `Scope.PRIVATE`; every read is `select_scoped(focus=True)`
(owner-only). A read with no scope filter is a bug (see tenancy.py + the leak test).

Lifecycle:
  - `create` writes a `draft` (version 1) with `graph_json` from the pipeline.
  - `update_graph` replaces a *draft's* graph and bumps `version` (a refine step).
  - `accept` freezes the picture: it stamps `status="accepted"`, re-freezes the
    (final) `graph_json`, and stores the rendered `render_snapshot_svg`. Per the
    design (§2 immutability = DATA + PICTURE), the JSON is frozen for
    re-derivation/diff/compose and the SVG snapshot is the guaranteed-stable image
    the accepted view shows. Editing an accepted diagram is a NEW version row
    (`new_version`), never a mutation of the accepted one.

Serialisation note: `graph_json` round-trips through `DiagramGraph` via
`model_dump(by_alias=True)` (store) / `model_validate(...)` (load) so the edge
`from_` alias is persisted/read as ``"from"`` — NEVER `DiagramGraph(**graph_json)`.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, ConfigDict

from docx_app.db import SurrealRepository, ensure_record_id
from docx_app.diagram.model import DiagramGraph
from docx_app.domain.source import scoped_update
from docx_app.tenancy import Principal, Scope

# A diagram describes one of three surfaces. The router validates incoming values
# against this set (anything else → HTTP 400). Surface 1 only ever uses "source".
DIAGRAM_SURFACES = frozenset({"source", "notebook", "repograph"})

# A diagram is an editable draft, the one frozen accepted artefact, or a prior
# accepted artefact that a newer accept has demoted ("superseded" — kept for
# history/versioning but no longer "the accepted diagram").
DIAGRAM_STATUSES = frozenset({"draft", "accepted", "superseded"})


def validate_surface(value: str) -> str:
    """Validate a diagram `surface` ('source' | 'notebook' | 'repograph'). Else ValueError."""
    if value not in DIAGRAM_SURFACES:
        raise ValueError("surface must be 'source', 'notebook' or 'repograph'")
    return value


class Diagram(BaseModel):
    """A stored diagram row — fields mirror the `diagram` table (0009_diagram.surql).

    `graph_json` is the canonical `DiagramGraph` as a plain dict (the renderer-agnostic
    artefact). Use :meth:`graph` to materialise it as a validated `DiagramGraph` (honours
    the edge `from` alias); do NOT splat it into `DiagramGraph(**...)`.
    """

    # Surreal rows carry extra columns (created/updated handled here, plus any future
    # fields) — keep what we model, ignore unknowns (same as Note/Source/Settings).
    model_config = ConfigDict(extra="ignore")

    id: str | None = None
    owner: str | None = None
    scope: str | None = None
    surface: str | None = None  # 'source' | 'notebook' | 'repograph'
    ref: str | None = None  # source_id | notebook_id | repo_url (the subject)
    parent_id: str | None = None  # composed-from / drill parent (HLD; later phase)
    status: str | None = None  # 'draft' | 'accepted'
    graph_json: dict[str, Any] | None = None  # the canonical DiagramGraph
    render_snapshot_svg: str | None = None  # frozen-on-accept static SVG (the picture)
    version: int | None = None
    created: str | None = None
    updated: str | None = None

    def graph(self) -> DiagramGraph | None:
        """Materialise `graph_json` as a validated `DiagramGraph`, or None if unset.

        Loaded with `model_validate` (NOT `**graph_json`) so the persisted ``"from"``
        edge key maps back to `DiagramGraphEdge.from_` — see the model's docstring.
        """
        if self.graph_json is None:
            return None
        return DiagramGraph.model_validate(self.graph_json)


class DiagramStore:
    """Persistence for Diagram — owner-PRIVATE (a user only ever sees their own diagrams)."""

    TABLE = "diagram"

    def __init__(self, repo: SurrealRepository):
        self._repo = repo

    @staticmethod
    def _to_diagram(record: dict[str, Any] | list[Any]) -> Diagram:
        # create_scoped (and db.insert) return a SINGLE-element list ([{...}]) — unwrap
        # before splatting (Diagram(**list) would raise → the endpoint 500s). Same guard
        # as NoteStore._to_note / SourceStore._to_source / SettingsStore.upsert.
        if isinstance(record, list):
            record = record[0] if record else {}
        return Diagram(**record)

    async def create(
        self,
        *,
        owner: str,
        surface: str,
        ref: str,
        graph: DiagramGraph | None = None,
        status: str = "draft",
        parent_id: str | None = None,
    ) -> Diagram:
        """Create a new diagram (version 1) for a subject — owner-PRIVATE.

        `graph` is serialised with `model_dump(by_alias=True)` so the edge `from_`
        alias persists as ``"from"``. A brand-new diagram starts at version 1; a fresh
        re-diagram of an already-diagrammed subject should go through :meth:`new_version`
        so the version counter continues.
        """
        validate_surface(surface)
        data: dict[str, Any] = {
            "surface": surface,
            "ref": ref,
            "status": status,
            "graph_json": graph.model_dump(by_alias=True) if graph else None,
            "render_snapshot_svg": None,
            "version": 1,
        }
        if parent_id is not None:
            data["parent_id"] = parent_id
        # PRIVATE: a diagram is the user's own intellectual work, not the shared brain.
        record = await self._repo.create_scoped(
            self.TABLE, data, owner=owner, scope=Scope.PRIVATE
        )
        return self._to_diagram(record)

    async def list(
        self,
        principal: Principal,
        *,
        surface: str | None = None,
        ref: str | None = None,
        order_by: str = "updated DESC",
        limit: int = 1000,
    ) -> list[Diagram]:
        """The caller's diagrams, optionally restricted to a surface and/or subject.

        Always owner-scoped (`focus=True` → `owner = $owner`), so another owner's
        diagrams are never returned. `surface`/`ref` narrow to a given subject (e.g. one
        source's diagrams) and are bound as params (never interpolated).
        """
        clauses: list[str] = []
        vars: dict[str, Any] = {}
        if surface is not None:
            clauses.append("surface = $surface")
            vars["surface"] = surface
        if ref is not None:
            clauses.append("ref = $ref")
            vars["ref"] = ref
        rows = await self._repo.select_scoped(
            self.TABLE,
            principal,
            focus=True,  # diagrams are owner-private
            extra_where=" AND ".join(clauses),
            vars=vars or None,
            order_by=order_by,
            limit=limit,
        )
        return [self._to_diagram(r) for r in rows]

    async def get(self, diagram_id: str, principal: Principal) -> Diagram | None:
        """Fetch one diagram the caller OWNS (owner-scoped). None if it isn't theirs."""
        rows = await self._repo.select_scoped(
            self.TABLE,
            principal,
            focus=True,  # own diagrams only
            extra_where="id = $did",
            vars={"did": ensure_record_id(diagram_id)},
            limit=1,
        )
        return self._to_diagram(rows[0]) if rows else None

    async def update_graph(
        self,
        diagram_id: str,
        principal: Principal,
        *,
        graph: DiagramGraph,
    ) -> Diagram | None:
        """Replace a DRAFT's graph and bump its version (a refine step). None if not theirs.

        The owner-scoped read first proves ownership, so the subsequent owner-scoped
        UPDATE can never touch another owner's row (the leak guard). Accepted diagrams are
        immutable — refining one yields a NEW version via :meth:`new_version`, so this
        refuses to mutate a non-draft and returns the (unchanged) existing record.
        """
        existing = await self.get(diagram_id, principal)
        if existing is None:
            return None
        if existing.status != "draft":
            return existing  # accepted diagrams are frozen — never mutate in place
        rows = await scoped_update(
            self._repo,
            self.TABLE,
            {
                "graph_json": graph.model_dump(by_alias=True),
                "version": (existing.version or 1) + 1,
                "updated": datetime.now(timezone.utc),
            },
            owner=principal.owner,
            record_id=diagram_id,
        )
        return self._to_diagram(rows[0]) if rows else existing

    async def accept(
        self,
        diagram_id: str,
        principal: Principal,
        *,
        render_snapshot_svg: str,
        graph: DiagramGraph | None = None,
    ) -> Diagram | None:
        """Freeze a diagram the caller OWNS — DATA + PICTURE. None if it isn't theirs.

        Stamps `status="accepted"`, freezes `graph_json` (the data, for
        re-derivation/diff/compose) and stores `render_snapshot_svg` (the picture — the
        guaranteed-stable image the accepted view shows), per the design's
        immutability decision (§2). `graph` lets the caller freeze the exact final graph
        alongside its rendered snapshot in one atomic write; if omitted, the row's current
        `graph_json` is kept as-is. The owner-scoped UPDATE can never reach another
        owner's row (the tenancy guard, even though `get` proves ownership first).
        """
        existing = await self.get(diagram_id, principal)
        if existing is None:
            return None
        # Enforce one-accepted-diagram-per-subject (design §2/§5): demote any
        # previously-accepted sibling for the same (owner, surface, ref) to
        # 'superseded' before freezing this one, so "the accepted diagram" is
        # unambiguous for downstream readers (e.g. the notebook-HLD compose). The
        # UPDATE carries owner = $owner (tenancy guard) and excludes this row.
        await self._repo.query(
            f"UPDATE {self.TABLE} SET status = 'superseded', updated = $updated "
            "WHERE owner = $owner AND surface = $surface AND ref = $ref "
            "AND status = 'accepted' AND id != $rid",
            {
                "updated": datetime.now(timezone.utc),
                "owner": principal.owner,
                "surface": existing.surface,
                "ref": existing.ref,
                "rid": ensure_record_id(diagram_id),
            },
        )
        fields: dict[str, Any] = {
            "status": "accepted",
            "render_snapshot_svg": render_snapshot_svg,
            "updated": datetime.now(timezone.utc),
        }
        if graph is not None:
            fields["graph_json"] = graph.model_dump(by_alias=True)
        rows = await scoped_update(
            self._repo,
            self.TABLE,
            fields,
            owner=principal.owner,
            record_id=diagram_id,
        )
        return self._to_diagram(rows[0]) if rows else None

    async def new_version(
        self,
        diagram_id: str,
        principal: Principal,
        *,
        graph: DiagramGraph | None = None,
    ) -> Diagram | None:
        """Start a fresh DRAFT from an existing (e.g. accepted) diagram the caller OWNS.

        Editing an accepted diagram must not mutate the frozen row, so this writes a NEW
        draft row for the same subject (`surface`/`ref`/`parent_id`) with `version`
        continued (parent.version + 1) and a cleared snapshot. Returns None if the parent
        isn't the caller's. `graph` seeds the new draft (defaults to the parent's graph).
        """
        parent = await self.get(diagram_id, principal)
        if parent is None:
            return None
        seed = graph if graph is not None else parent.graph()
        data: dict[str, Any] = {
            "surface": parent.surface,
            "ref": parent.ref,
            "status": "draft",
            "graph_json": seed.model_dump(by_alias=True) if seed else None,
            "render_snapshot_svg": None,
            "version": (parent.version or 1) + 1,
        }
        if parent.parent_id is not None:
            data["parent_id"] = parent.parent_id
        record = await self._repo.create_scoped(
            self.TABLE, data, owner=principal.owner, scope=Scope.PRIVATE
        )
        return self._to_diagram(record)

    async def delete(self, diagram_id: str, principal: Principal) -> bool:
        """Delete a diagram the caller OWNS. False if it isn't theirs.

        The delete carries `owner = $owner` so it can never reach another owner's diagram
        (same tenancy guard as NoteStore.delete / SourceStore.delete)."""
        if await self.get(diagram_id, principal) is None:
            return False
        await self._repo.delete_where(
            self.TABLE,
            "id = $did AND owner = $owner",
            {"did": ensure_record_id(diagram_id), "owner": principal.owner},
        )
        return True
