"""RepoGraph pipeline runner — the repo-surface twin of :mod:`docx_app.diagram.agent`.

Scope: **Surface 3 — RepoGraph** (design ``docs/2026-06-06-diagram-platform-design.md``
§7). RepoGraph runs the *same* 2-step gitdiagram flow as the Source tab, but over a
GitLab repository instead of one document, so its inputs are repo-shaped
(``<file_tree>`` / ``<readme>`` / ``<repo_owner>`` / ``<repo_name>``) and it uses the
repo-centric prompts (:data:`SYSTEM_FIRST_PROMPT` / :data:`SYSTEM_GRAPH_PROMPT`) rather
than the source-document prompts the frozen ``agent.py`` hard-wires.

Why a separate module (not a call into ``run_diagram_pipeline``): ``agent.py`` is the
frozen Surface-1 runner — its :func:`~docx_app.diagram.agent.generate_explanation` /
:func:`~docx_app.diagram.agent.generate_graph` are bound to ``SOURCE_*`` and emit
``<source_title>`` / ``<source_text>``. Per the reuse contract, that file is **not**
rewritten; instead this module **reuses every provider-agnostic, prompt-independent
building block** from it verbatim — :func:`~docx_app.diagram.agent.extract_tagged_section`,
the defensive :func:`~docx_app.diagram.agent.parse_graph_json`,
:func:`~docx_app.diagram.agent._strip_invalid_icons`, the :class:`_ChatLike` protocol,
:class:`DiagramPipelineError`, and the token budgets — and only swaps the prompt pair and
the user-message shape. The validate-and-retry loop is structurally identical to
``agent.generate_graph`` (and to gitdiagram's ``generate.py`` loop), re-pointed at the repo
prompts and run with a **real** ``file_tree_lookup`` so ``node.link`` paths are validated
against the repository tree (the one validator check that does *not* fire for source
diagrams).

This mirrors gitdiagram's step-2 ``data`` dict exactly
(``{"explanation", "file_tree", "repo_owner", "repo_name", "previous_graph",
"validation_feedback"}``), with the DocEX ``<shape_library>`` (Azure catalog) added so
nodes get real icon ids, and the design's ``<refinement_instruction>`` carried for the
later refine-by-prompt path. The ``<entity_registry>`` is **not** injected — per design §3
RepoGraph never populates ``node.entity`` (that is Surface-2 territory), so it stays null.

Defensive JSON parsing (the load-bearing local-path concern) is inherited unchanged from
``agent.parse_graph_json``: on the prod path the model is steered toward clean JSON, but the
local ``claude_cli`` path returns fenced JSON with prose, so a parse wobble is routed into
the same retry loop as a structural issue — never mistaken for a pipeline bug.

The runner depends on **nothing** in the API/domain layer — the caller
(``api/repograph.py``) fetches the repo's ``file_tree`` / ``readme`` / namespace (via
``gitlab_service``) and passes them in, keeping this pure and testable with a fake
``ChatClient``.
"""

from __future__ import annotations

import json

import structlog

# Reuse the frozen agent.py machinery VERBATIM (never re-implement these here):
#   - extract_tagged_section / parse_graph_json / _strip_invalid_icons — the
#     prompt-independent parse + clean steps;
#   - DiagramPipelineError — the single error type the API maps to HTTP 502;
#   - _ChatLike — the provider-agnostic completion protocol;
#   - the token budgets — same ceilings as the source pipeline.
from docx_app.diagram.agent import (
    EXPLANATION_MAX_TOKENS,
    GRAPH_MAX_TOKENS,
    DiagramPipelineError,
    _ChatLike,
    _strip_invalid_icons,
    extract_tagged_section,
    parse_graph_json,
)
from docx_app.diagram.model import (
    MAX_GRAPH_ATTEMPTS,
    DiagramGraph,
    build_file_tree_lookup,
    format_graph_validation_feedback,
    validate_diagram_graph,
)
from docx_app.diagram.prompts import (
    SYSTEM_FIRST_PROMPT,
    SYSTEM_GRAPH_PROMPT,
    format_user_message,
    format_validation_feedback_block,
    get_shape_library,
)

log = structlog.get_logger(__name__)


# --------------------------------------------------------------------------- #
# Namespace → (repo_owner, repo_name) — the gitdiagram ``parsed.username`` /
# ``parsed.repo`` pair, derived from GitLab's namespaced path.
# --------------------------------------------------------------------------- #
def split_namespace(namespace: str) -> tuple[str, str]:
    """Split a GitLab ``"group/subgroup/project"`` path into ``(repo_owner, repo_name)``.

    ``repo_name`` is the final path segment (the project); ``repo_owner`` is everything
    before it (the group / nested-subgroup path), which is what the graph prompt's
    ``<repo_owner>`` / ``<repo_name>`` blocks expect. Mirrors gitdiagram's
    ``parsed.username`` / ``parsed.repo`` for ``owner/repo``, generalised to GitLab's
    arbitrary-depth namespaces:

        ``"infra/k8s-platform"``           -> ``("infra", "k8s-platform")``
        ``"infra/team/k8s-platform"``      -> ``("infra/team", "k8s-platform")``
        ``"k8s-platform"``                 -> ``("", "k8s-platform")`` (no group)

    An empty / whitespace namespace yields ``("", "")`` — ``format_user_message`` then
    simply omits the empty blocks rather than emitting empty tags.
    """
    cleaned = namespace.strip().strip("/")
    if not cleaned:
        return "", ""
    owner, _, name = cleaned.rpartition("/")
    return owner, name


# --------------------------------------------------------------------------- #
# Prompt assembly (uses prompts.format_user_message — gitdiagram's tagger).
# Tag names match the SYSTEM_* (repo) prompts' declared inputs exactly.
# --------------------------------------------------------------------------- #
def build_explanation_user_prompt(*, file_tree: str, readme: str) -> str:
    """Step-1 user content: the repo, tagged for :data:`SYSTEM_FIRST_PROMPT`.

    Emits ``<file_tree>`` / ``<readme>`` — the inputs ``SYSTEM_FIRST_PROMPT`` declares
    (gitdiagram step 1). An empty ``readme`` is dropped by ``format_user_message`` (the
    prompt runs happily with no README — the explanation just notes its absence).
    """
    return format_user_message(
        {
            "file_tree": file_tree,
            "readme": readme,
        }
    )


def build_graph_user_prompt(
    *,
    explanation: str,
    file_tree: str,
    repo_owner: str,
    repo_name: str,
    shape_library: str | None,
    previous_graph: str | None,
    validation_feedback: str | None,
    refinement_instruction: str | None = None,
) -> str:
    """Step-2 user content for :data:`SYSTEM_GRAPH_PROMPT` (gitdiagram's ``data`` dict).

    Mirrors gitdiagram's step-2 ``data`` exactly — ``<explanation>``, ``<file_tree>``,
    ``<repo_owner>``, ``<repo_name>``, optional ``<previous_graph>`` /
    ``<validation_feedback>`` on retries — plus the DocEX additions: ``<shape_library>``
    (the Azure catalog, always injected so ``node.icon`` is a real id) and
    ``<refinement_instruction>`` (the design's refine-by-prompt seam). The
    ``<entity_registry>`` is deliberately absent: RepoGraph never sets ``node.entity``.
    ``format_user_message`` drops any ``None`` / empty value, so the prompt's optional
    inputs are simply absent on the first attempt.
    """
    return format_user_message(
        {
            "explanation": explanation,
            "file_tree": file_tree,
            "repo_owner": repo_owner,
            "repo_name": repo_name,
            "shape_library": shape_library,
            "previous_graph": previous_graph,
            "refinement_instruction": refinement_instruction,
            "validation_feedback": validation_feedback,
        }
    )


# --------------------------------------------------------------------------- #
# The two-step pipeline (gitdiagram structure, repo prompts, provider-agnostic).
# --------------------------------------------------------------------------- #
async def generate_repo_explanation(
    chat: _ChatLike,
    *,
    file_tree: str,
    readme: str,
) -> str:
    """Step 1: prose architecture explanation of the repository.

    Calls :data:`SYSTEM_FIRST_PROMPT` over the file tree + README and extracts the
    ``<explanation>`` body (gitdiagram step 1, via the frozen
    :func:`~docx_app.diagram.agent.extract_tagged_section`). Raises
    :class:`DiagramPipelineError` if the model returns nothing usable.
    """
    response = await chat.complete(
        system=SYSTEM_FIRST_PROMPT,
        user=build_explanation_user_prompt(file_tree=file_tree, readme=readme),
        max_tokens=EXPLANATION_MAX_TOKENS,
    )
    explanation = extract_tagged_section(response, "explanation")
    if not explanation.strip():
        raise DiagramPipelineError("The explanation step returned no usable output.")
    return explanation


async def generate_repo_graph(
    chat: _ChatLike,
    *,
    explanation: str,
    file_tree: str,
    repo_owner: str,
    repo_name: str,
    shape_library: str | None = None,
    instruction: str | None = None,
    seed_graph: DiagramGraph | None = None,
) -> DiagramGraph:
    """Step 2: typed graph JSON with the gitdiagram validate-and-retry loop (repo prompts).

    Structurally identical to :func:`docx_app.diagram.agent.generate_graph` — same loop,
    same defensive parse, same feedback wiring — re-pointed at :data:`SYSTEM_GRAPH_PROMPT`
    and run with a **real** ``file_tree_lookup`` (built from ``file_tree``) so the
    validator's ``link``-in-tree check fires: a ``node.link`` that is not an actual path in
    the repository is flagged and retried, exactly as gitdiagram validated ``node.path``.

    For each of up to ``MAX_GRAPH_ATTEMPTS`` attempts:

    1. call :data:`SYSTEM_GRAPH_PROMPT` (injecting ``<shape_library>`` always, and
       ``<previous_graph>`` / ``<validation_feedback>`` on retries);
    2. defensively parse the output into a :class:`DiagramGraph`
       (:func:`~docx_app.diagram.agent.parse_graph_json`);
    3. run :func:`~docx_app.diagram.model.validate_diagram_graph` against the file-tree
       lookup. If it finds structural issues, format them as feedback and loop; otherwise
       return the graph.

    Both a parse failure and structural issues feed the *same* retry mechanism — exactly
    mirroring gitdiagram.

    Raises:
        DiagramPipelineError: no valid graph after ``MAX_GRAPH_ATTEMPTS``.
    """
    lookup = build_file_tree_lookup(file_tree)

    valid_graph: DiagramGraph | None = None
    validation_feedback: str | None = None
    # On a refine, seed the loop with the current graph so the first attempt EDITS it
    # (rather than regenerating from scratch); the instruction rides every attempt's prompt
    # as <refinement_instruction>. Re-serialised with by_alias so <previous_graph> shows
    # "from" (the wire form the model emits), never "from_".
    previous_graph: str | None = (
        json.dumps(seed_graph.model_dump(by_alias=True)) if seed_graph else None
    )

    for attempt in range(1, MAX_GRAPH_ATTEMPTS + 1):
        feedback_block = (
            format_validation_feedback_block(validation_feedback)
            if validation_feedback
            else None
        )
        raw_output = await chat.complete(
            system=SYSTEM_GRAPH_PROMPT,
            user=build_graph_user_prompt(
                explanation=explanation,
                file_tree=file_tree,
                repo_owner=repo_owner,
                repo_name=repo_name,
                shape_library=shape_library,
                previous_graph=previous_graph,
                refinement_instruction=instruction,
                validation_feedback=feedback_block,
            ),
            max_tokens=GRAPH_MAX_TOKENS,
        )

        # --- Defensive parse (inherited from agent.py; mandatory for claude_cli) ---
        try:
            graph = parse_graph_json(raw_output)
        except ValueError as exc:
            # ValueError covers _JsonExtractionError and pydantic.ValidationError (a
            # ValueError subclass). Either way: feed the message back and retry.
            validation_feedback = str(exc)
            previous_graph = raw_output
            log.warning(
                "repograph_graph_parse_failed",
                attempt=attempt,
                max_attempts=MAX_GRAPH_ATTEMPTS,
                error=str(exc),
            )
            continue

        # --- Structural validation (gitdiagram), WITH the real file-tree lookup ---
        issues = validate_diagram_graph(graph, lookup)
        if issues:
            validation_feedback = format_graph_validation_feedback(issues)
            previous_graph = json.dumps(graph.model_dump(by_alias=True))
            log.warning(
                "repograph_graph_validation_failed",
                attempt=attempt,
                max_attempts=MAX_GRAPH_ATTEMPTS,
                issue_count=len(issues),
            )
            continue

        valid_graph = graph
        break

    if valid_graph is None:
        raise DiagramPipelineError(
            f"Graph generation remained invalid after {MAX_GRAPH_ATTEMPTS} attempts.",
            validation_feedback=validation_feedback,
        )
    _strip_invalid_icons(valid_graph)
    return valid_graph


async def run_repo_diagram_pipeline(
    chat: _ChatLike,
    *,
    file_tree: str,
    readme: str,
    namespace: str,
    include_azure_shapes: bool = True,
    instruction: str | None = None,
    base_graph: DiagramGraph | None = None,
) -> DiagramGraph:
    """Run the full RepoGraph pipeline: explanation -> validated graph.

    The single entry point the RepoGraph API calls — the repo-surface analogue of
    :func:`docx_app.diagram.agent.run_diagram_pipeline`. Provider-agnostic (any object with
    the :class:`_ChatLike` ``complete`` contract works — prod Azure, local ``claude_cli``,
    or a scripted fake in tests) and stateless.

    Args:
        chat: the LLM client (``docx_app.ai.chat.ChatClient`` or compatible).
        file_tree: newline-delimited filtered blob paths (from ``gitlab_service``). Must be
            non-empty — an empty tree means nothing to diagram (the caller maps this to a
            clear error; this guard is a defensive backstop).
        readme: the repo README (``""`` when the repo has no README — the pipeline still
            runs; the explanation notes the absence).
        namespace: the GitLab ``"group/.../project"`` path, split into ``<repo_owner>`` /
            ``<repo_name>`` for the graph prompt.
        include_azure_shapes: inject the Azure icon catalog as ``<shape_library>`` on the
            graph step (default ``True`` — design §7 keeps Azure icons first-class for
            RepoGraph). Set ``False`` to skip the catalog.
        instruction: refine-by-prompt instruction; ``None`` for a first generation.
        base_graph: seed graph for a refine; ``None`` for a first generation.

    Returns:
        A Pydantic-validated, structurally-valid :class:`DiagramGraph`. The validator runs
        with the repo's file-tree lookup, so ``node.link`` values are guaranteed to be real
        repository paths.

    Raises:
        DiagramPipelineError: the file tree is empty, or no valid graph could be produced
            within ``MAX_GRAPH_ATTEMPTS``.
    """
    if not file_tree or not file_tree.strip():
        raise DiagramPipelineError(
            "Cannot build a diagram from an empty repository tree."
        )

    shape_library = get_shape_library("azure") if include_azure_shapes else None
    repo_owner, repo_name = split_namespace(namespace)

    explanation = await generate_repo_explanation(
        chat, file_tree=file_tree, readme=readme
    )
    graph = await generate_repo_graph(
        chat,
        explanation=explanation,
        file_tree=file_tree,
        repo_owner=repo_owner,
        repo_name=repo_name,
        shape_library=shape_library,
        instruction=instruction,
        seed_graph=base_graph,
    )
    log.info(
        "repograph_pipeline_succeeded",
        node_count=len(graph.nodes),
        edge_count=len(graph.edges),
        group_count=len(graph.groups),
    )
    return graph


__all__ = [
    "run_repo_diagram_pipeline",
    "generate_repo_explanation",
    "generate_repo_graph",
    "build_explanation_user_prompt",
    "build_graph_user_prompt",
    "split_namespace",
]
