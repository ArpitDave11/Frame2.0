"""Path-B compose-time entity reconciliation — the cascade (sub-design §5).

Sub-design: ``docs/2026-06-07-entity-resolution-subdesign.md`` §5 (the fallback cascade),
§9 (the honest local hash-embedder caveat). This module is the **fallback** that runs for
any source node reaching ``compose.py`` *without* a Path-C registry-matched ``entity`` key
(legacy/frozen graphs, or a fresh label the model didn't link). It is the one piece with
**no reference code** — gitdiagram has no cross-graph logic — so it is specified precisely.

The cascade (cheapest first, stop at the first confident hit), per sub-design §5:

1. **Normalize (A)** — :func:`docx_app.diagram.entities.normalize_label` the incoming label
   and each candidate's ``canonical_label``/``aliases``; an exact normalized match →
   ``method="exact"`` (vs canonical) / ``method="alias"`` (vs an alias), ``confidence=1.0``.
2. **Embedding (B)** — cosine of the node's ``(label + description)`` embedding vs each
   candidate's embedding; ``>= τ_high`` auto-accepts (``method="embedding"``);
   ``τ_low..τ_high`` becomes an ambiguous candidate for step 3. **Locally** the hash
   embedder is lexical, so synonyms score ~0 and almost everything falls through to step 3
   (sub-design §9) — that is expected, not a bug.
3. **LLM adjudication (B), ambiguous tail only — batched** — one "same entity?" call decides
   the uncertain candidates. ``same`` → ``method="llm"``; ``different``/``uncertain`` → not
   merged. **Kind mismatch short-circuits to ``different`` WITHOUT an LLM call**
   (``method="kind_mismatch"``, ``confidence=0.0``) — a ``Manager`` actor is never merged
   with a ``Manager`` service (sub-design §5 / §5 gotcha 4).
4. **No candidate** → a **new** entity (``method="new"``).

A **locked** candidate that matches deterministically (step 1) is honoured as a forced
assignment (``method="locked"``) and never re-adjudicated (sub-design §6 / §5 gotcha 6).

Every result is an :class:`Assignment` carrying ``{entity_key, method, confidence}`` so
merges are auditable and the HLD endpoint can surface low-confidence ones for human review
(sub-design §5 last line / §5 gotcha 9). Thresholds and the per-compose LLM budget are
module-level constants (sub-design §11 — "tunable; proposed at implementation time"). The
LLM is reached through the same provider-agnostic :class:`_ChatLike` ``complete`` contract
the agent uses, so tests inject a scripted fake and prod/local are identical.

This module imports only from :mod:`docx_app.diagram.entities` (normalize / cosine /
``NotebookEntity``) — it does **not** import the store or the API layer, so it is pure and
trivially testable with a fake embedder + fake LLM (sub-design §9 test matrix).
"""

from __future__ import annotations

import json
import re
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Literal, Protocol

import structlog

from docx_app.diagram.entities import (
    NotebookEntity,
    cosine_similarity,
    local_hash_embedding,
    normalize_label,
)

# An async embedding function: text -> vector. Must produce vectors in the SAME space the
# registry embeddings were produced in (so cosine is meaningful). ``None`` falls back to the
# local lexical hash embedder (sub-design §9). Async because the project's real embedder
# (Azure) is async and the reconciler runs in an async context.
EmbedFn = Callable[[str], Awaitable[list[float]]]

log = structlog.get_logger(__name__)

# --- Thresholds + budget (sub-design §11 — tunable module constants, not config) --- #
# τ_high: cosine at/above which an embedding match auto-accepts (no LLM).
# τ_low : cosine below which an embedding candidate is dropped (not even sent to the LLM).
# The τ_low..τ_high band is the "ambiguous tail" routed to LLM adjudication.
TAU_HIGH = 0.88
TAU_LOW = 0.60
# Per-compose cap on LLM "same entity?" adjudications, batched into a SINGLE call when
# possible (sub-design §11). When the ambiguous-pair count exceeds this, the overflow is
# resolved as "different" and the truncation is LOGGED, never swallowed (sub-design §10 —
# "no silent caps"; a partially-resolved HLD must not look fully resolved).
MAX_LLM_ADJUDICATIONS_PER_COMPOSE = 20

# How the assignment was decided — surfaced for audit + human review.
ResolutionMethod = Literal[
    "exact",
    "alias",
    "embedding",
    "llm",
    "kind_mismatch",
    "new",
    "locked",
    "controlled_vocab",
]


@dataclass(frozen=True)
class Assignment:
    """The result of resolving one node to an entity — ``{entity_key, method, confidence}``.

    ``is_new`` tells ``compose.py`` whether this introduced a brand-new entity (so it can
    register one) vs matched an existing registry entity. ``candidate_id`` is the matched
    registry row id (``None`` for a new entity), so the caller can append source_refs to the
    exact row without a second lookup. ``confidence`` is in ``[0.0, 1.0]``.
    """

    entity_key: str
    method: ResolutionMethod
    confidence: float
    is_new: bool = False
    candidate_id: str | None = None

    @property
    def low_confidence(self) -> bool:
        """True for a machine match the UI should surface for review (sub-design §6/§10).

        An embedding/LLM merge is heuristic — flag it so low-confidence merges are visible,
        not hidden. Deterministic (exact/alias/locked/controlled_vocab) and brand-new
        entities are not "merges" and are never flagged.
        """
        return self.method in ("embedding", "llm") and self.confidence < TAU_HIGH


class _ChatLike(Protocol):
    """The single LLM method the reconciler needs (matches ``agent._ChatLike``).

    Structurally matches :class:`docx_app.ai.chat.ChatClient`. Declared as a ``Protocol`` so
    the reconciler is decoupled from the concrete client and trivially fakeable in tests.
    """

    async def complete(
        self, *, system: str, user: str, max_tokens: int = ...
    ) -> str: ...


@dataclass(frozen=True)
class NodeRef:
    """The minimal description of an incoming (unresolved) source node for matching.

    ``compose.py`` builds these from each source's frozen ``graph_json`` (read-only — the
    source LLD is never mutated; sub-design §8). ``key`` is the node's coined slug used when
    registering a new entity (defaults from the label).
    """

    label: str
    kind: str | None = None
    description: str | None = None
    key: str | None = None


# --------------------------------------------------------------------------- #
# Step 1 — normalization match (deterministic; covers exact / plural / suffix / alias).
# --------------------------------------------------------------------------- #
def _normalized_match(
    node: NodeRef, candidates: list[NotebookEntity]
) -> Assignment | None:
    """Return a deterministic assignment if the node's normalized label matches a candidate.

    Matches the node's :func:`normalize_label` against each candidate's normalized
    ``canonical_label`` (→ ``exact``) and normalized ``aliases`` (→ ``alias``). The
    **kind-mismatch guard applies here too** (sub-design §5): a same-label candidate whose
    ``kind`` conflicts with the node's is NOT merged (a ``Manager`` actor ≠ a ``Manager``
    service even on an exact label) — *unless* the candidate is **locked**, in which case the
    human override wins and it is returned as ``method="locked"`` (a forced, sticky
    assignment — sub-design §6). The first candidate wins (registry order is stable by
    ``entity_key``). ``confidence=1.0`` for a deterministic hit.
    """
    target = normalize_label(node.label)
    if not target:
        return None
    for candidate in candidates:
        if not candidate.entity_key:
            continue
        # A locked (human-curated) candidate overrides the kind guard; otherwise a kind
        # conflict prevents even an exact-label merge (the homonym guard, universal §5).
        if not candidate.locked and _kind_conflict(node.kind, candidate.kind):
            continue
        canonical_norm = normalize_label(candidate.canonical_label or "")
        alias_norms = {normalize_label(a) for a in candidate.aliases}
        if target == canonical_norm or target in alias_norms:
            method: ResolutionMethod = "locked" if candidate.locked else (
                "exact" if target == canonical_norm else "alias"
            )
            return Assignment(
                entity_key=candidate.entity_key,
                method=method,
                confidence=1.0,
                is_new=False,
                candidate_id=candidate.id,
            )
    return None


# --------------------------------------------------------------------------- #
# Step 2 — embedding candidates (auto-accept >= τ_high; τ_low..τ_high → step 3).
# --------------------------------------------------------------------------- #
async def _embed_node(node: NodeRef, embedding_fn: EmbedFn | None) -> list[float]:
    """Embed the node's ``(label + description)`` text for step 2.

    ``embedding_fn`` must be the same embedder used to produce registry embeddings so the
    vectors are comparable. When ``None`` (local), uses the deterministic lexical hash
    embedder (sub-design §9) — which only matches lexical overlap, so synonyms fall through
    to the LLM step. Never raises: an embedder failure degrades to an empty vector (→ no
    embedding candidates → fall through), logged at warning.
    """
    text = node.label if not node.description else f"{node.label} — {node.description}"
    if embedding_fn is None:
        return local_hash_embedding(text)
    try:
        return await embedding_fn(text)
    except Exception as exc:  # noqa: BLE001 - embedding is best-effort, never fatal
        log.warning("entity_node_embedding_failed", node_label=node.label, error=str(exc))
        return []


def _embedding_candidates(
    node: NodeRef, node_vec: list[float], candidates: list[NotebookEntity]
) -> tuple[Assignment | None, list[tuple[NotebookEntity, float]]]:
    """Score the node vector against candidate embeddings (sub-design §5 step 2).

    Returns ``(auto_accept, ambiguous)``:
      * ``auto_accept`` — an :class:`Assignment` for the single best candidate at/above
        ``TAU_HIGH`` (``method="embedding"``), or ``None``;
      * ``ambiguous`` — candidates scoring in ``[TAU_LOW, TAU_HIGH)``, best-first, to route
        to the LLM step. Candidates below ``TAU_LOW`` are dropped.

    **Kind-mismatch guard is universal** (sub-design §5 — "a ``Manager`` actor ≠ a ``Manager``
    service"): a candidate whose ``kind`` conflicts with the node's is skipped here too, so a
    near-identical embedding can NEVER auto-merge a homonym at step 2 (the guard is not
    limited to the LLM step). Candidates with no/empty/mismatched-dimension embedding score
    0.0 (handled by :func:`cosine_similarity`) and are dropped — exactly the local case (no
    embeddings → everything falls through to the LLM step; sub-design §9).
    """
    scored: list[tuple[NotebookEntity, float]] = []
    for candidate in candidates:
        if _kind_conflict(node.kind, candidate.kind):
            continue  # homonym with a different kind — never an embedding match
        sim = cosine_similarity(node_vec, candidate.embedding or [])
        if sim > 0.0:
            scored.append((candidate, sim))
    scored.sort(key=lambda pair: pair[1], reverse=True)

    if scored and scored[0][1] >= TAU_HIGH:
        best, score = scored[0]
        if best.entity_key:
            return (
                Assignment(
                    entity_key=best.entity_key,
                    method="embedding",
                    confidence=round(score, 4),
                    is_new=False,
                    candidate_id=best.id,
                ),
                [],
            )
    ambiguous = [(c, s) for c, s in scored if TAU_LOW <= s < TAU_HIGH]
    return (None, ambiguous)


# --------------------------------------------------------------------------- #
# Step 3 — LLM adjudication of the ambiguous tail (batched; kind-mismatch short-circuit).
# --------------------------------------------------------------------------- #
ADJUDICATION_SYSTEM_PROMPT = (
    "You are an expert software architect performing entity resolution across "
    "architecture diagrams of one project. For each numbered pair, decide whether the two "
    "items denote the SAME real-world architectural entity (same actor / service / "
    "datastore / component), judging by meaning and role, not just label spelling. Two "
    "items with different roles (e.g. an actor named 'Manager' vs a service named "
    "'Manager') are DIFFERENT. Reply with ONLY a JSON array, one object per pair, in order: "
    '[{"index": <int>, "verdict": "same"|"different"|"uncertain"}]. No prose, no fences.'
)

# Strict array-of-verdicts extraction (the local claude_cli path may wrap it in a fence /
# prose, like the graph step). We parse defensively: widest [...] slice, tolerate a fence.
_VERDICT_FENCE_RE = re.compile(
    r"```[ \t]*(?:json)?[ \t]*\r?\n?(?P<body>.*?)```", re.IGNORECASE | re.DOTALL
)


def _kind_conflict(node_kind: str | None, candidate_kind: str | None) -> bool:
    """True iff both kinds are set and differ — the homonym short-circuit (sub-design §5).

    A kind mismatch means "never auto-merge" (a ``Manager`` actor ≠ a ``Manager`` service),
    so it skips the LLM call entirely. If either kind is unknown (``None``), there is no
    conflict to assert — defer to the LLM. Comparison is case-insensitive/trimmed.
    """
    if not node_kind or not candidate_kind:
        return False
    return node_kind.strip().lower() != candidate_kind.strip().lower()


def _parse_verdicts(raw: str, expected: int) -> dict[int, str]:
    """Defensively parse the model's verdict array into ``{index: verdict}``.

    Tolerates a fenced block / surrounding prose (the local path), then takes the widest
    ``[...]`` slice. Unknown/missing indices are simply absent from the map (the caller then
    treats them as "uncertain" → not merged — fail-safe, never a false merge). Never raises.
    """
    text = raw.strip()
    fence = _VERDICT_FENCE_RE.search(text)
    if fence:
        text = fence.group("body").strip()
    first = text.find("[")
    last = text.rfind("]")
    if first != -1 and last != -1 and last > first:
        text = text[first : last + 1]
    out: dict[int, str] = {}
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        log.warning("entity_adjudication_unparsable", expected=expected)
        return out
    if not isinstance(parsed, list):
        return out
    for item in parsed:
        if not isinstance(item, dict):
            continue
        idx = item.get("index")
        verdict = item.get("verdict")
        if isinstance(idx, int) and isinstance(verdict, str):
            out[idx] = verdict.strip().lower()
    return out


@dataclass
class _AmbiguousPair:
    """One node↔candidate pair awaiting LLM adjudication (kept module-private)."""

    candidate: NotebookEntity
    score: float


async def _adjudicate(
    chat: _ChatLike | None,
    node: NodeRef,
    pairs: list[_AmbiguousPair],
    *,
    budget: int,
) -> Assignment | None:
    """LLM-adjudicate the ambiguous tail for ONE node (sub-design §5 step 3, batched).

    Drops kind-conflicting pairs up front (the homonym short-circuit — no LLM spend). If
    nothing survives, returns ``None``. Otherwise issues a SINGLE ``complete`` call listing
    every surviving pair and maps the first ``same`` verdict (best-score order) to an
    ``method="llm"`` assignment. ``budget`` caps how many pairs are sent; overflow pairs are
    treated as ``different`` and the truncation is logged (sub-design §10/§11 — no silent
    caps). With ``chat is None`` (no LLM available), the ambiguous tail is conservatively
    left unresolved (returns ``None`` → the node becomes a new entity), which is the
    fail-safe (never a false merge).
    """
    # Kind-mismatch short-circuit: a different-kind candidate is never the same entity.
    survivors: list[_AmbiguousPair] = []
    for pair in pairs:
        if _kind_conflict(node.kind, pair.candidate.kind):
            log.info(
                "entity_kind_mismatch",
                node_label=node.label,
                candidate=pair.candidate.entity_key,
                node_kind=node.kind,
                candidate_kind=pair.candidate.kind,
            )
            continue
        survivors.append(pair)
    if not survivors:
        return None
    if chat is None:
        # No adjudicator wired — do not guess; leave unresolved (fail-safe).
        return None

    capped = survivors[:budget]
    if len(survivors) > budget:
        log.warning(
            "entity_adjudication_truncated",
            node_label=node.label,
            requested=len(survivors),
            cap=budget,
        )
    if not capped:
        # Budget exhausted (e.g. 0) — do not spend an LLM call; leave unresolved (fail-safe).
        return None

    lines = [
        f"Project entity to match: \"{node.label}\""
        + (f" (role: {node.kind})" if node.kind else "")
        + (f" — {node.description}" if node.description else ""),
        "",
        "Candidates:",
    ]
    for index, pair in enumerate(capped):
        candidate = pair.candidate
        desc = f" — {candidate.description}" if candidate.description else ""
        role = f" (role: {candidate.kind})" if candidate.kind else ""
        lines.append(
            f"{index}: \"{candidate.canonical_label}\"{role}{desc}"
        )
    user = "\n".join(lines)

    raw = await chat.complete(
        system=ADJUDICATION_SYSTEM_PROMPT, user=user, max_tokens=512
    )
    verdicts = _parse_verdicts(raw, expected=len(capped))
    for index, pair in enumerate(capped):
        if verdicts.get(index) == "same" and pair.candidate.entity_key:
            log.info(
                "entity_adjudicated_same",
                node_label=node.label,
                candidate=pair.candidate.entity_key,
            )
            return Assignment(
                entity_key=pair.candidate.entity_key,
                method="llm",
                confidence=round(pair.score, 4),
                is_new=False,
                candidate_id=pair.candidate.id,
            )
    return None


# --------------------------------------------------------------------------- #
# The cascade entry point (one node) — used by compose.py and re-exported by entities.
# --------------------------------------------------------------------------- #
async def reconcile_node(
    node: NodeRef,
    candidates: list[NotebookEntity],
    *,
    chat: _ChatLike | None = None,
    embedding_fn: EmbedFn | None = None,
    llm_budget: int = MAX_LLM_ADJUDICATIONS_PER_COMPOSE,
) -> Assignment:
    """Resolve one unmatched node to an entity via the §5 cascade (the Path-B fallback).

    Runs steps 1→4 in order, stopping at the first confident hit:
      1. normalize match (``exact``/``alias``/``locked``, confidence 1.0);
      2. embedding (``>= TAU_HIGH`` → ``embedding``; ``TAU_LOW..TAU_HIGH`` → step 3);
      3. LLM adjudication of the ambiguous tail (``llm``), with the kind-mismatch
         short-circuit (``kind_mismatch`` is implicit — those pairs are dropped pre-LLM);
      4. otherwise a brand-new entity (``method="new"``, ``is_new=True``).

    Args:
        candidates: the notebook's existing registry entities to match against (compose.py
            passes the full per-notebook registry; reconciliation is per-notebook only —
            sub-design §3).
        chat: the provider-agnostic LLM client for step 3 (``None`` → step 3 never merges,
            the fail-safe). Same ``complete`` contract as the agent.
        embedding_fn: an ASYNC callable ``str -> list[float]`` used to embed the node (and
            which must match how registry embeddings were produced). ``None`` defaults to the
            local lexical hash embedder (sub-design §9). Prod passes a closure over the real
            embedder so the node vector lives in the registry's embedding space.
        llm_budget: remaining LLM-adjudication budget for THIS compose (sub-design §11).

    Returns:
        An :class:`Assignment` — always non-None. For a new entity the ``entity_key`` is the
        node's ``key`` (or a slug of its label); ``is_new=True`` tells compose to register.
    """
    # Step 1 — deterministic normalize match (covers exact / plural / suffix / alias / locked).
    deterministic = _normalized_match(node, candidates)
    if deterministic is not None:
        return deterministic

    # Step 2 — embedding candidates. node_vec uses the same fn as registry rows.
    node_vec = await _embed_node(node, embedding_fn)
    auto_accept, ambiguous = _embedding_candidates(node, node_vec, candidates)
    if auto_accept is not None:
        return auto_accept

    # Step 3 — LLM adjudication of the ambiguous tail (batched; kind-mismatch short-circuit).
    pairs = [_AmbiguousPair(candidate=c, score=s) for c, s in ambiguous]
    adjudicated = await _adjudicate(chat, node, pairs, budget=llm_budget)
    if adjudicated is not None:
        return adjudicated

    # Step 4 — no candidate → a new entity. Guard against a homonym key collision: the coined
    # slug may already exist in the registry as a DIFFERENT entity that steps 1-3 declined to
    # merge (e.g. a different-kind homonym — "Manager" actor vs "Manager" service). Reusing the
    # colliding key would let compose fold the two under one key → a false cross-source bridge
    # (sub-design §1). So mint a DISTINCT key: disambiguate by kind when known, else a counter.
    from docx_app.diagram.entities import slugify_entity_key  # local: avoid cycle at import

    base_key = (node.key or "").strip() or slugify_entity_key(node.label)
    key = base_key
    if any(c.entity_key == key for c in candidates):
        suffix = slugify_entity_key(node.kind) if node.kind else ""
        key = f"{base_key}_{suffix}" if suffix else f"{base_key}_2"
        counter = 2
        while any(c.entity_key == key for c in candidates):
            key = f"{base_key}_{suffix}_{counter}" if suffix else f"{base_key}_{counter}"
            counter += 1
    return Assignment(
        entity_key=key,
        method="new",
        confidence=1.0,
        is_new=True,
        candidate_id=None,
    )


__all__ = [
    "Assignment",
    "NodeRef",
    "ResolutionMethod",
    "reconcile_node",
    "TAU_HIGH",
    "TAU_LOW",
    "MAX_LLM_ADJUDICATIONS_PER_COMPOSE",
]
