"""Embedder — batching + dimensions, with Azure OpenAI mocked (no network)."""

from types import SimpleNamespace

import pytest

from docx_app.config import DocxConfig
from docx_app.indexing import embedding as emb_mod
from docx_app.indexing.embedding import Embedder

_REC: dict = {}


class _FakeEmbeddings:
    async def create(self, *, model, input, **kwargs):
        _REC["calls"].append(list(input))
        _REC["model"] = model
        _REC["dimensions"] = kwargs.get("dimensions")
        return SimpleNamespace(
            data=[SimpleNamespace(embedding=[float(len(t))] * 3) for t in input]
        )


class _FakeClient:
    def __init__(self, **kwargs):
        self.embeddings = _FakeEmbeddings()

    async def close(self):
        pass


@pytest.fixture
def mocked(monkeypatch):
    _REC.clear()
    _REC["calls"] = []
    monkeypatch.setattr(emb_mod, "AsyncAzureOpenAI", _FakeClient)
    return _REC


def _cfg(**over) -> DocxConfig:
    return DocxConfig(service_name="docx", **over)


async def test_embed_empty_makes_no_call(mocked):
    assert await Embedder(_cfg()).embed([]) == []
    assert mocked["calls"] == []


async def test_embed_returns_one_vector_per_text(mocked):
    out = await Embedder(_cfg()).embed(["a", "bb"])
    assert len(out) == 2
    assert out[0] == [1.0, 1.0, 1.0] and out[1] == [2.0, 2.0, 2.0]


async def test_embed_batches_by_config(mocked):
    out = await Embedder(_cfg(embedding_batch_size=2)).embed(["a", "b", "c", "d", "e"])
    assert len(out) == 5
    assert len(mocked["calls"]) == 3  # 2 + 2 + 1


async def test_dimensions_omitted_by_default_and_sent_when_set(mocked):
    await Embedder(_cfg()).embed(["x"])
    assert mocked["dimensions"] is None
    await Embedder(_cfg(embedding_dimensions=256)).embed(["x"])
    assert mocked["dimensions"] == 256
