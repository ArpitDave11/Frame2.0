"""Markdown-aware chunking — pure, offline."""

from docx_app.indexing.chunking import chunk_text


def test_empty_or_blank_returns_no_chunks():
    assert chunk_text("") == []
    assert chunk_text("   \n  \t ") == []


def test_markdown_headers_split_into_sections():
    md = (
        "# Title\n\nIntro paragraph.\n\n"
        "## Section A\n\nAlpha body content.\n\n"
        "## Section B\n\nBeta body content."
    )
    chunks = chunk_text(md)
    assert len(chunks) >= 2
    joined = "\n".join(chunks)
    assert "Alpha body content." in joined
    assert "Beta body content." in joined


def test_long_unheadered_section_is_size_split():
    chunks = chunk_text("word " * 1000, chunk_size=400, overlap=40)
    assert len(chunks) > 1  # one big section gets broken into multiple chunks


def test_short_text_is_a_single_chunk():
    chunks = chunk_text("Just a short note.")
    assert chunks == ["Just a short note."]
