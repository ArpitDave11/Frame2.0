"""SourceStore — owner/scope is applied on every write and read (uses a fake repo)."""

import pytest

from docx_app.domain.source import Asset, Source, SourceStore
from docx_app.tenancy import Principal, Scope


class FakeRepo:
    def __init__(self):
        self.created: list[dict] = []
        self.selects: list[dict] = []
        self.rows: list[dict] = []

    async def create_scoped(self, table, data, *, owner, scope):
        self.created.append(
            {"table": table, "data": data, "owner": owner, "scope": scope}
        )
        return {**data, "id": f"{table}:1", "owner": owner, "scope": scope.value}

    async def select_scoped(
        self,
        table,
        principal,
        *,
        focus=False,
        extra_where="",
        order_by="updated DESC",
        limit=None,
        vars=None,
        notebook=None,
    ):
        self.selects.append(
            {"table": table, "focus": focus, "extra_where": extra_where, "vars": vars}
        )
        return self.rows


@pytest.mark.asyncio
async def test_create_stamps_owner_and_scope():
    repo = FakeRepo()
    store = SourceStore(repo)
    src = await store.create(
        owner="u1",
        scope=Scope.ORG_COMMON,
        title="Report",
        full_text="hello",
        asset=Asset(file_path="/x/a.pdf"),
        engine_used="docling",
    )
    assert repo.created[0]["owner"] == "u1"
    assert (
        repo.created[0]["scope"] == Scope.ORG_COMMON
    )  # default collective-brain scope
    assert isinstance(src, Source)
    assert src.title == "Report" and src.owner == "u1" and src.scope == "org-common"
    assert src.asset and src.asset.file_path == "/x/a.pdf"


@pytest.mark.asyncio
async def test_list_is_scoped_default_common():
    repo = FakeRepo()
    repo.rows = [{"id": "source:1", "title": "A"}, {"id": "source:2", "title": "B"}]
    out = await SourceStore(repo).list(Principal(owner="u1"))
    assert len(out) == 2 and all(isinstance(s, Source) for s in out)
    assert repo.selects[0]["focus"] is False  # default = common big-picture


@pytest.mark.asyncio
async def test_get_is_scoped_by_id_and_owner():
    repo = FakeRepo()
    repo.rows = [{"id": "source:1", "title": "A"}]
    out = await SourceStore(repo).get("source:1", Principal(owner="u1"), focus=True)
    assert out is not None and out.title == "A"
    assert repo.selects[0]["extra_where"] == "id = $sid"
    assert repo.selects[0]["focus"] is True
