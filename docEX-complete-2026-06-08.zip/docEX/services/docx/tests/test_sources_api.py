"""Sources API — upload→extract→store, owner/scope enforced (TestClient + overrides)."""

import pytest
from fastapi.testclient import TestClient

from docx_app import deps
from docx_app.db import parse_record_ids
from docx_app.extraction.models import EngineName, ExtractedDoc, ExtractStatus
from docx_app.extraction.router import ExtractionError
from docx_app.main import app
from docx_app.tenancy import Principal, Scope


class FakeRepo:
    def __init__(self):
        self.created: list[dict] = []
        self.selects: list[dict] = []
        self.rows: list[dict] = []
        self.queries: list[dict] = []
        self.deletes: list[dict] = []
        # per-table rows the chunk-existence / scoped-table lookups read from; falls back
        # to `rows` when a table isn't seeded (keeps the simple single-table tests terse).
        self.table_rows: dict[str, list[dict]] = {}
        # rows returned by `query` (the scoped UPDATE ... RETURN AFTER path)
        self.query_rows: list[dict] = []

    async def create_scoped(self, table, data, *, owner, scope):
        self.created.append({"data": data, "owner": owner, "scope": scope})
        # mirror the real repo: RecordID values (e.g. notebook) come back stringified
        return parse_record_ids(
            {**data, "id": f"{table}:1", "owner": owner, "scope": scope.value}
        )

    async def select_scoped(
        self,
        table,
        principal,
        *,
        focus=False,
        extra_where="",
        order_by="updated DESC",
        limit=None,
        vars=None,
        notebook=None,
    ):
        self.selects.append(
            {
                "table": table,
                "focus": focus,
                "extra_where": extra_where,
                "vars": vars,
                "notebook": notebook,
                "limit": limit,
            }
        )
        return parse_record_ids(self.table_rows.get(table, self.rows))

    async def query(self, query_str, vars=None):
        self.queries.append({"query": query_str, "vars": vars})
        return parse_record_ids(self.query_rows)

    async def delete_where(self, table, where, vars=None):
        self.deletes.append({"table": table, "where": where, "vars": vars})


class FakeExtractor:
    def __init__(self, result=None, error=None):
        self._result = result
        self._error = error

    async def extract(self, inp):
        if self._error:
            raise self._error
        return self._result


class _NoopIndexer:
    async def index_source(self, source):
        return 0


@pytest.fixture
def ctx():
    repo = FakeRepo()
    app.dependency_overrides[deps.get_principal] = lambda: Principal(owner="u1")
    app.dependency_overrides[deps.get_repository] = lambda: repo
    app.dependency_overrides[deps.get_indexer] = lambda: _NoopIndexer()  # no network
    client = TestClient(app)
    yield client, repo
    app.dependency_overrides.clear()


def test_create_from_text_defaults_to_common(ctx):
    client, repo = ctx
    resp = client.post("/sources", data={"text": "hello world content", "title": "T"})
    assert resp.status_code == 200
    body = resp.json()
    assert body["title"] == "T" and body["full_text"] == "hello world content"
    assert repo.created[0]["owner"] == "u1"
    assert repo.created[0]["scope"] == Scope.ORG_COMMON  # collective-brain default


def test_create_text_private_scope(ctx):
    client, repo = ctx
    resp = client.post("/sources", data={"text": "secret", "scope": "private"})
    assert resp.status_code == 200
    assert repo.created[0]["scope"] == Scope.PRIVATE


def test_create_from_file_uses_extractor(ctx):
    client, repo = ctx
    app.dependency_overrides[deps.get_extractor] = lambda: FakeExtractor(
        result=ExtractedDoc(
            markdown="extracted body",
            engine_used=EngineName.DOCLING,
            status=ExtractStatus.SUCCESS,
            metadata={"title": "Doc Title"},
        )
    )
    resp = client.post(
        "/sources",
        data={"scope": "org-common"},
        files={"file": ("r.docx", b"binarydata", "application/octet-stream")},
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["full_text"] == "extracted body"
    assert body["engine_used"] == "docling"
    assert body["title"] == "Doc Title"


def test_extraction_failure_returns_422(ctx):
    client, _ = ctx
    app.dependency_overrides[deps.get_extractor] = lambda: FakeExtractor(
        error=ExtractionError("both engines failed")
    )
    resp = client.post("/sources", files={"file": ("a.pdf", b"x", "application/pdf")})
    assert resp.status_code == 422


def test_missing_input_returns_400(ctx):
    client, _ = ctx
    resp = client.post("/sources", data={})
    assert resp.status_code == 400


def test_invalid_scope_returns_400(ctx):
    client, _ = ctx
    resp = client.post("/sources", data={"text": "x", "scope": "public"})
    assert resp.status_code == 400


def test_list_sources_scoped(ctx):
    client, repo = ctx
    repo.rows = [{"id": "source:1", "title": "A"}, {"id": "source:2", "title": "B"}]
    resp = client.get("/sources")
    assert resp.status_code == 200 and len(resp.json()) == 2
    assert repo.selects[0]["focus"] is False


def test_get_source_found_and_404(ctx):
    client, repo = ctx
    repo.rows = [{"id": "source:1", "title": "A"}]
    assert client.get("/sources/source:1").status_code == 200
    repo.rows = []
    assert client.get("/sources/source:999").status_code == 404


def test_create_triggers_indexing(ctx):
    client, _ = ctx
    indexed = []

    class RecordingIndexer:
        async def index_source(self, source):
            indexed.append(source)
            return 1

    app.dependency_overrides[deps.get_indexer] = lambda: RecordingIndexer()
    resp = client.post("/sources", data={"text": "hello world content"})
    assert resp.status_code == 200
    assert len(indexed) == 1
    assert indexed[0].full_text == "hello world content"
    assert resp.json()["chunk_count"] == 1  # indexed → count surfaced


def test_indexing_failure_does_not_fail_upload(ctx):
    client, _ = ctx

    class BoomIndexer:
        async def index_source(self, source):
            raise RuntimeError("azure down")

    app.dependency_overrides[deps.get_indexer] = lambda: BoomIndexer()
    resp = client.post("/sources", data={"text": "hello"})
    assert (
        resp.status_code == 200
    )  # doc is saved despite the indexing failure (fail-open)
    assert resp.json()["chunk_count"] is None  # signals "not yet indexed" → recoverable


def test_reindex_owned_source_returns_chunk_count(ctx):
    client, repo = ctx
    repo.rows = [
        {"id": "source:1", "full_text": "body", "owner": "u1", "scope": "private"}
    ]

    class CountIndexer:
        async def index_source(self, source):
            return 3

    app.dependency_overrides[deps.get_indexer] = lambda: CountIndexer()
    resp = client.post("/sources/source:1/reindex")
    assert resp.status_code == 200 and resp.json()["chunk_count"] == 3


def test_reindex_missing_source_returns_404(ctx):
    client, repo = ctx
    repo.rows = []
    assert client.post("/sources/source:999/reindex").status_code == 404


def test_create_with_notebook_stamps_it(ctx):
    client, repo = ctx
    repo.rows = [
        {"id": "notebook:1", "name": "W", "owner": "u1"}
    ]  # NotebookStore.get finds it
    resp = client.post("/sources", data={"text": "hello", "notebook": "notebook:1"})
    assert resp.status_code == 200
    assert repo.created[0]["data"].get("notebook") is not None  # stamped on the source


def test_create_with_unknown_notebook_returns_400(ctx):
    client, repo = ctx
    repo.rows = []  # NotebookStore.get returns None → reject
    resp = client.post("/sources", data={"text": "hello", "notebook": "notebook:999"})
    assert resp.status_code == 400


# --- Open Notebook frontend field aliases (content / notebook_id / notebooks) ---
# The ON-ported frontend posts `content` (not `text`) and `notebook_id`/`notebooks`
# (not `notebook`). The create endpoint must accept these or a UI-created text source
# 400s and its workspace association is dropped.


def test_create_accepts_content_alias_for_text(ctx):
    client, repo = ctx
    resp = client.post("/sources", data={"content": "hello from content", "title": "T"})
    assert resp.status_code == 200
    assert resp.json()["full_text"] == "hello from content"


def test_create_accepts_notebook_id_alias(ctx):
    client, repo = ctx
    repo.rows = [{"id": "notebook:1", "name": "W", "owner": "u1"}]
    resp = client.post("/sources", data={"text": "hi", "notebook_id": "notebook:1"})
    assert resp.status_code == 200
    assert repo.created[0]["data"].get("notebook") is not None  # workspace stamped


def test_create_accepts_notebooks_json_array(ctx):
    client, repo = ctx
    repo.rows = [{"id": "notebook:1", "name": "W", "owner": "u1"}]
    resp = client.post("/sources", data={"text": "hi", "notebooks": '["notebook:1"]'})
    assert resp.status_code == 200
    assert repo.created[0]["data"].get("notebook") is not None


def test_create_malformed_notebooks_is_ignored(ctx):
    # A malformed `notebooks` value must not 500 — treat it as "no workspace".
    client, repo = ctx
    resp = client.post("/sources", data={"text": "hi", "notebooks": "not-json"})
    assert resp.status_code == 200
    assert repo.created[0]["data"].get("notebook") is None


# --- Open Notebook contract: list pagination/sort + response shape ----------


def test_list_sources_on_response_shape(ctx):
    client, repo = ctx
    repo.table_rows["source"] = [
        {
            "id": "source:1",
            "title": "A",
            "topics": ["x"],
            "asset": {"url": "http://e.com", "file_path": None},
            "created": "2026-01-01",
            "updated": "2026-01-02",
        }
    ]
    repo.table_rows["source_chunk"] = [{"id": "source_chunk:1", "source": "source:1"}]
    body = client.get("/sources").json()
    assert len(body) == 1
    row = body[0]
    # ON SourceListResponse field names + shapes
    assert set(row) >= {
        "id",
        "title",
        "topics",
        "asset",
        "embedded",
        "embedded_chunks",
        "insights_count",
        "created",
        "updated",
    }
    assert row["embedded"] is True  # has a chunk → embedded
    assert row["embedded_chunks"] == 0  # ON parity: list view does not count chunks
    assert row["insights_count"] == 0  # Docx has no insights table
    assert row["asset"] == {"url": "http://e.com", "file_path": None}
    assert "full_text" not in row  # list response is the slim shape


def test_list_sources_pagination_and_sort_passed_through(ctx):
    client, repo = ctx
    repo.table_rows["source"] = [
        {"id": f"source:{i}", "title": str(i)} for i in range(5)
    ]
    resp = client.get(
        "/sources",
        params={"limit": 2, "offset": 1, "sort_by": "created", "sort_order": "asc"},
    )
    assert resp.status_code == 200
    list_select = repo.selects[0]
    assert list_select["table"] == "source"
    assert list_select["limit"] == 3  # offset(1) + limit(2): window fetched then sliced
    # in-app offset slice applied → rows[1:3]
    assert [r["id"] for r in resp.json()] == ["source:1", "source:2"]


def test_list_sources_invalid_sort_by_returns_400(ctx):
    client, _ = ctx
    assert client.get("/sources", params={"sort_by": "name"}).status_code == 400


def test_list_sources_invalid_sort_order_returns_400(ctx):
    client, _ = ctx
    assert client.get("/sources", params={"sort_order": "sideways"}).status_code == 400


def test_list_sources_filters_by_notebook_id(ctx):
    client, repo = ctx
    repo.table_rows["notebook"] = [{"id": "notebook:1", "name": "W", "owner": "u1"}]
    repo.table_rows["source"] = [
        {"id": "source:1", "title": "A", "notebook": "notebook:1"}
    ]
    resp = client.get("/sources", params={"notebook_id": "notebook:1"})
    assert resp.status_code == 200 and len(resp.json()) == 1
    # the source list select carries the workspace predicate (owner = $owner AND notebook = …)
    src_select = next(s for s in repo.selects if s["table"] == "source")
    assert src_select["notebook"] == "notebook:1"


def test_list_sources_unknown_notebook_id_returns_404(ctx):
    client, repo = ctx
    repo.table_rows["notebook"] = []  # NotebookStore.get → None
    assert (
        client.get("/sources", params={"notebook_id": "notebook:999"}).status_code
        == 404
    )


# --- Open Notebook contract: detail / update / delete / status --------------


def test_get_source_detail_shape_counts_chunks(ctx):
    client, repo = ctx
    repo.table_rows["source"] = [
        {"id": "source:1", "title": "A", "full_text": "body", "notebook": "notebook:1"}
    ]
    repo.table_rows["source_chunk"] = [
        {"id": "source_chunk:1", "source": "source:1"},
        {"id": "source_chunk:2", "source": "source:1"},
    ]
    row = client.get("/sources/source:1").json()
    assert row["full_text"] == "body"  # detail adds full_text
    assert row["embedded_chunks"] == 2 and row["embedded"] is True
    assert row["notebooks"] == ["notebook:1"]  # workspace surfaced as a list


def test_update_source_title(ctx):
    client, repo = ctx
    repo.table_rows["source"] = [{"id": "source:1", "title": "old", "owner": "u1"}]
    repo.query_rows = [{"id": "source:1", "title": "new", "owner": "u1"}]
    resp = client.put("/sources/source:1", json={"title": "new"})
    assert resp.status_code == 200 and resp.json()["title"] == "new"
    # the UPDATE is owner-scoped (tenancy guard on the write itself)
    assert "owner = $owner" in repo.queries[0]["query"]
    assert repo.queries[0]["vars"]["owner"] == "u1"


def test_update_missing_source_returns_404(ctx):
    client, repo = ctx
    repo.table_rows["source"] = []  # store.get → None
    assert client.put("/sources/source:9", json={"title": "x"}).status_code == 404


def test_delete_source_removes_chunks_and_record(ctx):
    client, repo = ctx
    repo.table_rows["source"] = [{"id": "source:1", "title": "A", "owner": "u1"}]
    resp = client.delete("/sources/source:1")
    assert resp.status_code == 200
    tables = {d["table"] for d in repo.deletes}
    assert tables == {"source", "source_chunk"}  # both removed
    # every delete is owner-scoped
    assert all("owner = $owner" in d["where"] for d in repo.deletes)
    assert all(d["vars"]["owner"] == "u1" for d in repo.deletes)


def test_delete_missing_source_returns_404(ctx):
    client, repo = ctx
    repo.table_rows["source"] = []
    assert client.delete("/sources/source:9").status_code == 404


def test_source_status_completed_when_embedded(ctx):
    client, repo = ctx
    repo.table_rows["source"] = [{"id": "source:1", "title": "A"}]
    repo.table_rows["source_chunk"] = [{"id": "source_chunk:1", "source": "source:1"}]
    body = client.get("/sources/source:1/status").json()
    assert body["status"] == "completed"
    assert body["processing_info"]["embedded_chunks"] == 1


def test_source_status_new_when_not_indexed(ctx):
    client, repo = ctx
    repo.table_rows["source"] = [{"id": "source:1", "title": "A"}]
    repo.table_rows["source_chunk"] = []
    body = client.get("/sources/source:1/status").json()
    assert body["status"] == "new"


def test_source_status_missing_returns_404(ctx):
    client, repo = ctx
    repo.table_rows["source"] = []
    assert client.get("/sources/source:9/status").status_code == 404


def test_cross_owner_cannot_read_source_via_api():
    """End-to-end leak guard at the API layer: the scoped repo really applies the
    predicate, so u2 gets a 404 for u1's private source (and u1 gets 200)."""
    from tests.test_tenancy_isolation import InMemoryScopedRepo

    repo = InMemoryScopedRepo()

    async def seed():
        from docx_app.domain.source import SourceStore

        await SourceStore(repo).create(
            owner="u1", scope=Scope.PRIVATE, title="u1-secret", full_text="x"
        )

    import asyncio

    asyncio.run(seed())

    app.dependency_overrides[deps.get_repository] = lambda: repo
    app.dependency_overrides[deps.get_indexer] = lambda: _NoopIndexer()
    try:
        app.dependency_overrides[deps.get_principal] = lambda: Principal(owner="u2")
        assert (
            TestClient(app).get("/sources/source:1").status_code == 404
        )  # leak blocked
        app.dependency_overrides[deps.get_principal] = lambda: Principal(owner="u1")
        assert (
            TestClient(app).get("/sources/source:1").status_code == 200
        )  # owner sees it
    finally:
        app.dependency_overrides.clear()
