"""Migration runner — statement splitting + apply/skip logic (no DB)."""

from docx_app.migrate import _split_statements, apply_migrations


def test_split_statements_strips_comments_and_splits():
    surql = "-- header\nDEFINE TABLE t; -- trailing note\nDEFINE FIELD f;\n\n"
    assert _split_statements(surql) == ["DEFINE TABLE t", "DEFINE FIELD f"]


def test_split_statements_keeps_multiline_statement_intact():
    surql = "DEFINE ANALYZER a\n    TOKENIZERS blank\n    FILTERS lowercase;"
    stmts = _split_statements(surql)
    assert len(stmts) == 1
    assert stmts[0].startswith("DEFINE ANALYZER a")
    assert "FILTERS lowercase" in stmts[0]


class FakeRepo:
    def __init__(self, already=()):
        self.queries: list = []
        self._applied = set(already)

    async def query(self, q, vars=None):
        self.queries.append((q, vars))
        if q.startswith("SELECT name FROM"):
            return [{"name": n} for n in self._applied]
        if q.startswith("CREATE") and vars:
            self._applied.add(vars["name"])
        return []


async def test_apply_migrations_runs_in_order_and_records(tmp_path):
    (tmp_path / "0002_b.surql").write_text("DEFINE INDEX b;")
    (tmp_path / "0001_a.surql").write_text("-- c\nDEFINE TABLE a;\nDEFINE FIELD x;")
    repo = FakeRepo()

    applied = await apply_migrations(repo, tmp_path)

    assert applied == ["0001_a.surql", "0002_b.surql"]  # sorted filename order
    defines = [q for q, _ in repo.queries if q.startswith("DEFINE")]
    assert "DEFINE TABLE a" in defines
    assert "DEFINE FIELD x" in defines
    assert "DEFINE INDEX b" in defines


async def test_apply_migrations_skips_already_applied(tmp_path):
    (tmp_path / "0001_a.surql").write_text("DEFINE TABLE a;")
    repo = FakeRepo(already={"0001_a.surql"})

    applied = await apply_migrations(repo, tmp_path)

    assert applied == []  # nothing new
    assert not any(q == "DEFINE TABLE a" for q, _ in repo.queries)  # not re-run
