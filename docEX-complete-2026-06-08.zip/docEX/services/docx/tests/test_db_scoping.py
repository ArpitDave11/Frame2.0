"""Proves owner/scope is injected into every Docx query (collective-brain enforcement)."""

from docx_app.db import build_scoped_select, scoped_write_fields
from docx_app.tenancy import Principal, Scope


def test_write_fields_stamp_owner_and_scope():
    fields = scoped_write_fields("u1", Scope.ORG_COMMON)
    assert fields == {"owner": "u1", "scope": "org-common"}


def test_default_select_includes_common_and_own():
    q, vars = build_scoped_select("source", Principal(owner="u1"))
    assert "scope = 'org-common' OR owner = $owner" in q
    assert vars == {"owner": "u1"}


def test_focus_select_is_owner_only():
    q, _ = build_scoped_select("source", Principal(owner="u1"), focus=True)
    assert "owner = $owner" in q
    assert "org-common" not in q


def test_extra_where_is_anded():
    q, _ = build_scoped_select(
        "source", Principal(owner="u1"), extra_where="topic = $t"
    )
    assert " AND (topic = $t)" in q


def test_order_and_limit():
    q, _ = build_scoped_select(
        "source", Principal(owner="u1"), order_by="created DESC", limit=10
    )
    assert q.endswith("ORDER BY created DESC LIMIT 10")


def test_never_bare_select():
    # every built query carries a WHERE scope predicate
    q, _ = build_scoped_select("source", Principal(owner="u1"))
    assert "WHERE" in q
