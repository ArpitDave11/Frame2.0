"""Notes — store + API, owner-private, with a cross-owner leak guard.

Two fakes, mirroring the rest of the suite:
  * FakeRepo — records calls (asserts scoping/shape) but returns seeded rows verbatim.
  * ScopedNoteRepo — ACTUALLY applies the owner/scope predicate (like
    tests/test_tenancy_isolation.InMemoryScopedRepo) so a private note leaking across
    owners would fail the leak test. Notes are owner-private, so even the default
    (focus=False) view must never surface another owner's note.
"""

import asyncio

import pytest
from fastapi.testclient import TestClient

from docx_app import deps
from docx_app.api.notes import router as notes_router
from docx_app.db import ensure_record_id, parse_record_ids
from docx_app.domain.note import Note, NoteStore, validate_note_type
from docx_app.main import app
from docx_app.tenancy import Principal, Scope


def _ensure_notes_router_mounted() -> None:
    """Mount the notes router on the shared app for the duration of these tests.

    main.py is owned by the orchestrator (it adds the permanent registration); registering
    here too is idempotent — `include_router` is guarded so re-runs / the eventual real
    registration don't double-mount, and the tests exercise the real /notes routes today.
    """
    if not any(getattr(r, "path", "").startswith("/notes") for r in app.routes):
        app.include_router(notes_router)


class FakeRepo:
    def __init__(self):
        self.created: list[dict] = []
        self.rows: list[dict] = []
        self.selects: list[dict] = []
        self.queries: list[dict] = []
        self.deletes: list[dict] = []
        self.inserted: list[dict] = []
        # per-table seed; falls back to `rows` when a table isn't explicitly set.
        self.table_rows: dict[str, list[dict]] = {}
        self.query_rows: list[dict] = []

    async def create_scoped(self, table, data, *, owner, scope):
        self.created.append({"data": data, "owner": owner, "scope": scope})
        return parse_record_ids(
            {**data, "id": f"{table}:1", "owner": owner, "scope": scope.value}
        )

    async def select_scoped(
        self,
        table,
        principal,
        *,
        focus=False,
        extra_where="",
        order_by="updated DESC",
        limit=None,
        vars=None,
        notebook=None,
    ):
        self.selects.append(
            {
                "table": table,
                "focus": focus,
                "extra_where": extra_where,
                "vars": vars,
                "notebook": notebook,
                "order_by": order_by,
                "limit": limit,
            }
        )
        return parse_record_ids(self.table_rows.get(table, self.rows))

    async def query(self, query_str, vars=None):
        self.queries.append({"query": query_str, "vars": vars})
        return parse_record_ids(self.query_rows)

    async def delete_where(self, table, where, vars=None):
        self.deletes.append({"table": table, "where": where, "vars": vars})

    async def insert_scoped(self, table, rows, *, owner, scope):
        self.inserted.append(
            {"table": table, "rows": rows, "owner": owner, "scope": scope}
        )
        return len(rows)


class FakeEmbedder:
    """Stand-in Embedder: one trivial vector per chunk, no network."""

    def __init__(self):
        self.calls: list[list[str]] = []

    async def embed(self, texts):
        self.calls.append(list(texts))
        return [[float(i)] for i, _ in enumerate(texts)]


class ScopedNoteRepo:
    """A repo fake that REALLY enforces the tenancy predicate for the note table.

    Mirrors build_scoped_select / surreal_scope_predicate:
        focus=True            : owner == me
        notebook set          : owner == me AND notebook == $notebook
        default (focus=False) : scope == 'org-common' OR owner == me
    """

    def __init__(self) -> None:
        self._rows: list[dict] = []

    async def create_scoped(self, table, data, *, owner, scope):
        # normalise a RecordID notebook ref to a string, like the real driver does on read
        notebook = data.get("notebook")
        row = {
            **data,
            "notebook": str(notebook) if notebook is not None else None,
            "id": f"{table}:{len(self._rows) + 1}",
            "owner": owner,
            "scope": scope.value,
        }
        self._rows.append(row)
        return parse_record_ids(row)

    async def select_scoped(
        self,
        table,
        principal,
        *,
        focus=False,
        extra_where="",
        order_by="updated DESC",
        limit=None,
        vars=None,
        notebook=None,
    ):
        def visible(r: dict) -> bool:
            if notebook is not None:
                return r["owner"] == principal.owner and r.get("notebook") == str(
                    ensure_record_id(notebook)
                )
            if focus:
                return r["owner"] == principal.owner
            return r["scope"] == "org-common" or r["owner"] == principal.owner

        rows = [r for r in self._rows if r["id"].startswith(f"{table}:") and visible(r)]
        if vars and "nid" in vars:  # NoteStore.get → extra_where "id = $nid"
            target = str(ensure_record_id(vars["nid"]))
            rows = [r for r in rows if str(ensure_record_id(r["id"])) == target]
        return parse_record_ids(rows[: limit or len(rows)])

    async def delete_where(self, table, where, vars=None):
        pass

    async def query(self, query_str, vars=None):
        return []

    async def insert_scoped(self, table, rows, *, owner, scope):
        return len(rows)


# --- validate_note_type -----------------------------------------------------


def test_validate_note_type_accepts_human_ai_and_none():
    assert validate_note_type("human") == "human"
    assert validate_note_type("ai") == "ai"
    assert validate_note_type(None) is None


def test_validate_note_type_rejects_other():
    with pytest.raises(ValueError):
        validate_note_type("robot")


# --- NoteStore (unit) -------------------------------------------------------


async def test_create_stamps_owner_and_is_private():
    repo = FakeRepo()
    note = await NoteStore(repo).create(owner="u1", content="body", note_type="human")
    assert isinstance(note, Note) and note.content == "body" and note.owner == "u1"
    assert repo.created[0]["owner"] == "u1"
    assert repo.created[0]["scope"] == Scope.PRIVATE  # notes are owner-private
    assert repo.created[0]["data"]["note_type"] == "human"


async def test_create_with_notebook_stamps_record_ref():
    repo = FakeRepo()
    await NoteStore(repo).create(owner="u1", content="x", notebook="notebook:1")
    assert repo.created[0]["data"]["notebook"] is not None


async def test_list_and_get_are_owner_scoped():
    repo = FakeRepo()
    repo.rows = [{"id": "note:1", "content": "A", "owner": "u1"}]
    notes = await NoteStore(repo).list(Principal(owner="u1"))
    assert len(notes) == 1 and notes[0].content == "A"
    assert repo.selects[0]["focus"] is True  # only your own notes
    assert repo.selects[0]["notebook"] is None  # no workspace filter → all own notes
    got = await NoteStore(repo).get("note:1", Principal(owner="u1"))
    assert got is not None and got.content == "A"
    assert repo.selects[1]["extra_where"] == "id = $nid"
    assert repo.selects[1]["focus"] is True


async def test_list_filtered_by_notebook_passes_workspace_predicate():
    repo = FakeRepo()
    repo.rows = [{"id": "note:1", "content": "A", "owner": "u1"}]
    await NoteStore(repo).list(Principal(owner="u1"), notebook="notebook:1")
    # notebook set → select_scoped carries the workspace (owner = $owner AND notebook = …)
    assert repo.selects[0]["notebook"] == "notebook:1"
    assert repo.selects[0]["focus"] is True


async def test_update_is_owner_scoped_write():
    repo = FakeRepo()
    repo.rows = [{"id": "note:1", "content": "old", "owner": "u1"}]
    repo.query_rows = [{"id": "note:1", "content": "new", "owner": "u1"}]
    note = await NoteStore(repo).update("note:1", Principal(owner="u1"), content="new")
    assert note is not None and note.content == "new"
    # the UPDATE is owner-scoped (tenancy guard on the write itself)
    assert "owner = $owner" in repo.queries[0]["query"]
    assert repo.queries[0]["vars"]["owner"] == "u1"


async def test_update_missing_returns_none():
    repo = FakeRepo()
    repo.rows = []  # get → None
    assert (
        await NoteStore(repo).update("note:9", Principal(owner="u1"), content="x")
        is None
    )


async def test_delete_removes_chunks_and_record_owner_scoped():
    repo = FakeRepo()
    repo.rows = [{"id": "note:1", "content": "A", "owner": "u1"}]
    assert await NoteStore(repo).delete("note:1", Principal(owner="u1")) is True
    tables = {d["table"] for d in repo.deletes}
    assert tables == {"note", "note_chunk"}  # both removed
    assert all("owner = $owner" in d["where"] for d in repo.deletes)
    assert all(d["vars"]["owner"] == "u1" for d in repo.deletes)


async def test_delete_missing_returns_false():
    repo = FakeRepo()
    repo.rows = []
    assert await NoteStore(repo).delete("note:9", Principal(owner="u1")) is False


# --- NoteStore.embed (inline stand-in for ON's embed_note) ------------------


async def test_embed_chunks_and_stores_with_owner_scope():
    repo, emb = FakeRepo(), FakeEmbedder()
    note = Note(
        id="note:1", content="# Heading\n\nSome body.", owner="u1", scope="private"
    )
    n = await NoteStore(repo).embed(note, emb, chunk_size=1600, overlap=240)
    assert n >= 1
    assert emb.calls and len(emb.calls[0]) == n  # every chunk embedded
    ins = repo.inserted[0]
    assert ins["table"] == "note_chunk"
    assert ins["owner"] == "u1" and ins["scope"] == Scope.PRIVATE


async def test_embed_blank_content_is_noop():
    repo, emb = FakeRepo(), FakeEmbedder()
    note = Note(id="note:1", content="   ", owner="u1", scope="private")
    assert await NoteStore(repo).embed(note, emb, chunk_size=1600, overlap=240) == 0
    assert emb.calls == []  # never called the embedder
    assert repo.inserted == []


async def test_embed_missing_scope_fails_closed_to_private():
    repo, emb = FakeRepo(), FakeEmbedder()
    note = Note(id="note:1", content="plain body", owner="u1")  # no scope
    await NoteStore(repo).embed(note, emb, chunk_size=1600, overlap=240)
    # never silently widen to the shared brain — fail closed to the narrowest scope
    assert repo.inserted[0]["scope"] == Scope.PRIVATE


# --- API (TestClient + overrides) -------------------------------------------


@pytest.fixture
def ctx():
    _ensure_notes_router_mounted()
    repo = FakeRepo()
    app.dependency_overrides[deps.get_principal] = lambda: Principal(owner="u1")
    app.dependency_overrides[deps.get_repository] = lambda: repo
    app.dependency_overrides[deps.get_embedder] = lambda: FakeEmbedder()  # no network
    client = TestClient(app)
    yield client, repo
    app.dependency_overrides.clear()


def test_api_create_note(ctx):
    client, repo = ctx
    resp = client.post("/notes", json={"content": "hello", "title": "T"})
    assert resp.status_code == 200
    body = resp.json()
    assert body["content"] == "hello" and body["title"] == "T"
    assert body["note_type"] == "human"  # default
    assert repo.created[0]["scope"] == Scope.PRIVATE
    assert "owner" not in body and "scope" not in body  # never leak tenancy columns


def test_api_create_blank_content_returns_400(ctx):
    client, _ = ctx
    assert client.post("/notes", json={"content": "   "}).status_code == 400


def test_api_create_invalid_note_type_returns_400(ctx):
    client, _ = ctx
    resp = client.post("/notes", json={"content": "x", "note_type": "robot"})
    assert resp.status_code == 400


def test_api_create_note_response_shape(ctx):
    client, repo = ctx
    resp = client.post("/notes", json={"content": "hello"})
    body = resp.json()
    # ON NoteResponse field names + shapes (lib/api/notes.ts / NoteResponse)
    assert set(body) == {"id", "title", "content", "note_type", "created", "updated"}


def test_api_create_embeds_note_content(ctx):
    client, repo = ctx
    emb = FakeEmbedder()
    app.dependency_overrides[deps.get_embedder] = lambda: emb
    resp = client.post("/notes", json={"content": "embed me"})
    assert resp.status_code == 200
    assert emb.calls  # content was chunked + embedded inline
    assert repo.inserted and repo.inserted[0]["table"] == "note_chunk"


def test_api_create_embedding_failure_does_not_fail_request(ctx):
    client, _ = ctx

    class BoomEmbedder:
        async def embed(self, texts):
            raise RuntimeError("azure down")

    app.dependency_overrides[deps.get_embedder] = lambda: BoomEmbedder()
    resp = client.post("/notes", json={"content": "hello"})
    assert resp.status_code == 200  # note saved despite embed failure (fail-open)


def test_api_create_with_notebook(ctx):
    client, repo = ctx
    repo.table_rows["notebook"] = [{"id": "notebook:1", "name": "W", "owner": "u1"}]
    resp = client.post("/notes", json={"content": "hello", "notebook_id": "notebook:1"})
    assert resp.status_code == 200
    assert repo.created[0]["data"].get("notebook") is not None  # stamped on the note


def test_api_create_with_unknown_notebook_returns_404(ctx):
    client, repo = ctx
    repo.table_rows["notebook"] = []  # NotebookStore.get → None
    resp = client.post(
        "/notes", json={"content": "hello", "notebook_id": "notebook:999"}
    )
    assert resp.status_code == 404


def test_api_list_notes(ctx):
    client, repo = ctx
    repo.table_rows["note"] = [
        {"id": "note:1", "content": "A"},
        {"id": "note:2", "content": "B"},
    ]
    resp = client.get("/notes")
    assert resp.status_code == 200 and len(resp.json()) == 2
    note_select = next(s for s in repo.selects if s["table"] == "note")
    assert note_select["focus"] is True  # only your own notes


def test_api_list_notes_filtered_by_notebook(ctx):
    client, repo = ctx
    repo.table_rows["notebook"] = [{"id": "notebook:1", "name": "W", "owner": "u1"}]
    repo.table_rows["note"] = [
        {"id": "note:1", "content": "A", "notebook": "notebook:1"}
    ]
    resp = client.get("/notes", params={"notebook_id": "notebook:1"})
    assert resp.status_code == 200 and len(resp.json()) == 1
    note_select = next(s for s in repo.selects if s["table"] == "note")
    assert note_select["notebook"] == "notebook:1"  # workspace-scoped read


def test_api_list_notes_unknown_notebook_returns_404(ctx):
    client, repo = ctx
    repo.table_rows["notebook"] = []  # NotebookStore.get → None
    assert client.get("/notes", params={"notebook_id": "notebook:9"}).status_code == 404


def test_api_get_note_found_and_404(ctx):
    client, repo = ctx
    repo.table_rows["note"] = [{"id": "note:1", "content": "A"}]
    assert client.get("/notes/note:1").status_code == 200
    repo.table_rows["note"] = []
    assert client.get("/notes/note:999").status_code == 404


def test_api_update_note(ctx):
    client, repo = ctx
    repo.table_rows["note"] = [{"id": "note:1", "content": "old", "owner": "u1"}]
    repo.query_rows = [{"id": "note:1", "content": "new", "owner": "u1"}]
    resp = client.put("/notes/note:1", json={"content": "new"})
    assert resp.status_code == 200 and resp.json()["content"] == "new"
    # owner-scoped UPDATE (tenancy guard on the write)
    assert "owner = $owner" in repo.queries[0]["query"]
    assert repo.queries[0]["vars"]["owner"] == "u1"


def test_api_update_invalid_note_type_returns_400(ctx):
    client, _ = ctx
    assert client.put("/notes/note:1", json={"note_type": "robot"}).status_code == 400


def test_api_update_missing_note_returns_404(ctx):
    client, repo = ctx
    repo.table_rows["note"] = []  # store.get → None
    assert client.put("/notes/note:9", json={"content": "x"}).status_code == 404


def test_api_delete_note(ctx):
    client, repo = ctx
    repo.table_rows["note"] = [{"id": "note:1", "content": "A", "owner": "u1"}]
    resp = client.delete("/notes/note:1")
    assert resp.status_code == 200
    tables = {d["table"] for d in repo.deletes}
    assert tables == {"note", "note_chunk"}
    assert all("owner = $owner" in d["where"] for d in repo.deletes)


def test_api_delete_missing_note_returns_404(ctx):
    client, repo = ctx
    repo.table_rows["note"] = []
    assert client.delete("/notes/note:9").status_code == 404


# --- Cross-owner / cross-scope leak guard -----------------------------------


async def test_private_notes_never_leak_across_owners():
    """Notes are owner-private, so even the default (collective-brain) read must never
    surface another owner's note. Uses a repo that ACTUALLY applies the predicate."""
    repo = ScopedNoteRepo()
    store = NoteStore(repo)
    alice = await store.create(owner="alice", content="alice-secret")
    await store.create(owner="bob", content="bob-secret")

    bob = Principal(owner="bob")
    # default (focus=False at the repo level) view for bob → never alice's private note
    bob_contents = {n.content for n in await store.list(bob)}
    assert "bob-secret" in bob_contents
    assert "alice-secret" not in bob_contents

    # even with the exact id, bob cannot GET alice's note...
    assert await store.get(alice.id, bob) is None
    # ...but alice can.
    got = await store.get(alice.id, Principal(owner="alice"))
    assert got is not None and got.content == "alice-secret"


def test_api_cross_owner_cannot_read_note():
    """End-to-end leak guard at the API layer: the scoped repo really applies the
    predicate, so u2 gets a 404 for u1's note (and u1 gets 200)."""
    _ensure_notes_router_mounted()
    repo = ScopedNoteRepo()

    async def seed():
        await NoteStore(repo).create(owner="u1", content="u1-secret")

    asyncio.run(seed())

    app.dependency_overrides[deps.get_repository] = lambda: repo
    app.dependency_overrides[deps.get_embedder] = lambda: FakeEmbedder()
    try:
        app.dependency_overrides[deps.get_principal] = lambda: Principal(owner="u2")
        assert TestClient(app).get("/notes/note:1").status_code == 404  # leak blocked
        app.dependency_overrides[deps.get_principal] = lambda: Principal(owner="u1")
        assert TestClient(app).get("/notes/note:1").status_code == 200  # owner sees it
    finally:
        app.dependency_overrides.clear()
