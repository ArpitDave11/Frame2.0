"""Ask API — POST /ask wiring (mocked service)."""

import pytest
from fastapi.testclient import TestClient

from docx_app import deps
from docx_app.ask.models import AskResult, Citation
from docx_app.main import app
from docx_app.tenancy import Principal


class FakeAsk:
    async def ask(self, question, principal, *, focus=False, limit=10):
        return AskResult(
            answer=f"A: {question} (focus={focus})",
            citations=[Citation(source="source:1", chunk="source_chunk:1", score=0.9)],
            used_chunks=1,
        )


@pytest.fixture
def client():
    app.dependency_overrides[deps.get_principal] = lambda: Principal(owner="u1")
    app.dependency_overrides[deps.get_ask_service] = lambda: FakeAsk()
    c = TestClient(app)
    yield c
    app.dependency_overrides.clear()


def test_ask_returns_grounded_answer(client):
    resp = client.post("/ask", json={"question": "hello?", "focus": True})
    assert resp.status_code == 200
    body = resp.json()
    assert "hello?" in body["answer"] and "focus=True" in body["answer"]
    assert body["used_chunks"] == 1
    assert body["citations"][0]["source"] == "source:1"


def test_ask_blank_question_returns_400(client):
    assert client.post("/ask", json={"question": "   "}).status_code == 400
