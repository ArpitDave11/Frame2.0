"""Entity-reconciler + registry tests — the cross-source matching backbone (Surface 2).

Covers the sub-design's §9 test matrix
(``docs/2026-06-07-entity-resolution-subdesign.md``) for the Path-B cascade
(:func:`docx_app.diagram.reconciler.reconcile_node`) and the registry store
(:class:`docx_app.diagram.entities.EntityRegistryStore`):

  exact · plural · suffix · synonym (embedding + LLM) · homonym (kind mismatch) · new ·
  controlled-vocab (Path-C upsert) · human-merge sticky (locked) · budget cap · tenancy.

The reconciler is provider-agnostic and pure, so tests inject a **deterministic fake
embedder** (NOT the lexical hash embedder — the sub-design is explicit that synonyms need a
real/fake semantic embedder, §9) and a **scripted fake LLM**. Registry-store tests use a
table-aware ``FakeRepo`` mirroring ``test_diagram.py`` (no DB, ``asyncio_mode="auto"``).
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from docx_app.db import ensure_record_id
from docx_app.diagram.entities import (
    EntityRegistryStore,
    NotebookEntity,
    cosine_similarity,
    normalize_label,
)
from docx_app.diagram.model import DiagramGraph
from docx_app.diagram.reconciler import (
    MAX_LLM_ADJUDICATIONS_PER_COMPOSE,
    NodeRef,
    reconcile_node,
)
from docx_app.tenancy import Principal, Scope

P = Principal(owner="u1")


def _id_eq(row_id: Any, want: Any) -> bool:
    """RecordID-aware id equality for the fake repo.

    The store binds ``ensure_record_id(entity_id)`` (a ``RecordID``) as the query var, whose
    ``str`` is ``table:⟨1⟩`` (angle-bracketed), while a seeded row's ``id`` is the plain
    ``"table:1"``. The real driver matches by RecordID semantics; the fake mirrors that by
    parsing both sides to ``RecordID`` and comparing ``(table_name, record_id)``.
    """
    a = ensure_record_id(str(row_id)) if not hasattr(row_id, "table_name") else row_id
    b = ensure_record_id(str(want)) if not hasattr(want, "table_name") else want
    return (a.table_name, str(a.id)) == (b.table_name, str(b.id))


# --------------------------------------------------------------------------- #
# Fakes — a FULLY deterministic semantic embedder + a scripted LLM.
# --------------------------------------------------------------------------- #
# NOTE on determinism: the embedder must NOT use the builtin ``hash()`` (salted per process
# by PYTHONHASHSEED) — that made an engineered cosine land either side of TAU_HIGH depending
# on the run, a real test flake. Indices are derived from a stable md5 hash instead, and the
# mid-band vectors are constructed with an EXACT, run-independent cosine (see _mid_band_vec).
_FAKE_DIM = 64


def _stable_index(word: str) -> int:
    """A stable basis index for a word (md5-derived; never the salted builtin ``hash()``)."""
    import hashlib

    return int.from_bytes(hashlib.md5(word.encode()).digest()[:4], "big") % _FAKE_DIM


class FakeEmbedder:
    """A deterministic *semantic* embedder for tests (NOT the lexical hash embedder).

    Words sharing a concept share a basis direction, so synonyms (``Customer``/``Client``)
    are intentionally close (cosine 1.0) and unrelated words are orthogonal — letting us
    exercise step 2 (embedding auto-accept) deterministically, which the lexical hash embedder
    cannot do (sub-design §9). Fully reproducible across processes (md5, not ``hash()``).
    """

    # Words sharing a concept share a vector direction.
    _CONCEPTS: dict[str, str] = {
        "customer": "person",
        "client": "person",
        "order": "order",
        "orders": "order",
        "payment": "payment",
        "invoice": "billing",
        "billing": "billing",
    }

    async def embed(self, texts: list[str]) -> list[list[float]]:
        return [self._vector(t) for t in texts]

    def _vector(self, text: str) -> list[float]:
        vec = [0.0] * _FAKE_DIM
        for raw in text.lower().split():
            word = "".join(ch for ch in raw if ch.isalnum())
            if not word:
                continue
            concept = self._CONCEPTS.get(word, word)
            vec[_stable_index(concept)] += 1.0
        norm = sum(x * x for x in vec) ** 0.5 or 1.0
        return [x / norm for x in vec]

    async def fn(self, text: str) -> list[float]:
        """The async ``EmbedFn`` adapter the reconciler/compose expect (single text)."""
        vectors = await self.embed([text])
        return vectors[0]


def _mid_band_vec(node_text: str) -> list[float]:
    """A vector whose cosine to ``node_text``'s embedding is EXACTLY 0.7 (mid-band, run-stable).

    Built as ``0.7 * e_i + 0.714... * e_j`` where ``e_i`` is the node's (single) basis
    direction and ``e_j`` is a guaranteed-distinct orthogonal direction. Cosine to ``e_i`` is
    ``0.7 / sqrt(0.7² + 0.714²) ≈ 0.70`` — safely inside ``[TAU_LOW=0.60, TAU_HIGH=0.88)`` on
    every run, so it deterministically routes to the LLM step (no flake at the boundary).
    """
    concept = FakeEmbedder._CONCEPTS.get(  # noqa: SLF001 - test helper mirrors the embedder
        node_text.lower().split()[0], node_text.lower().split()[0]
    )
    i = _stable_index(concept)
    j = (i + 1) % _FAKE_DIM  # a distinct, orthogonal basis index
    vec = [0.0] * _FAKE_DIM
    vec[i] = 0.7
    vec[j] = 0.714  # 0.7/sqrt(0.7^2+0.714^2) ≈ 0.70 cosine to the node's one-hot e_i
    return vec


class FakeChat:
    """Scripted LLM — returns queued strings in order; records calls for assertions."""

    def __init__(self, responses: list[str]) -> None:
        self._responses = list(responses)
        self.calls: list[dict[str, str]] = []

    async def complete(self, *, system: str, user: str, max_tokens: int = 1000) -> str:
        self.calls.append({"system": system, "user": user})
        return self._responses.pop(0) if self._responses else "[]"


def _entity(
    key: str,
    label: str,
    *,
    kind: str | None = None,
    aliases: list[str] | None = None,
    embedding: list[float] | None = None,
    source_refs: list[str] | None = None,
    locked: bool = False,
    eid: str | None = None,
) -> NotebookEntity:
    return NotebookEntity(
        id=eid or f"notebook_entity:{key}",
        owner="u1",
        scope="private",
        notebook_id="notebook:1",
        entity_key=key,
        canonical_label=label,
        kind=kind,
        aliases=aliases or [],
        embedding=embedding,
        source_refs=source_refs or [],
        locked=locked,
    )


async def _embed(embedder: FakeEmbedder, text: str) -> list[float]:
    return await embedder.fn(text)


# =========================================================================== #
# §9 test matrix — the cascade.
# =========================================================================== #
async def test_exact_match_is_method_exact_no_llm() -> None:
    chat = FakeChat([])
    out = await reconcile_node(
        NodeRef(label="Customer"),
        [_entity("customer", "Customer")],
        chat=chat,
    )
    assert out.entity_key == "customer"
    assert out.method == "exact"
    assert out.confidence == 1.0
    assert out.is_new is False
    assert chat.calls == []  # deterministic — never reached the LLM


async def test_plural_collapses_to_singular_via_normalize() -> None:
    out = await reconcile_node(
        NodeRef(label="Orders"), [_entity("order", "Order")]
    )
    assert out.entity_key == "order"
    assert out.method == "exact"  # normalized forms equal


async def test_suffix_strip_matches_alias_or_canonical() -> None:
    # "CustomerService" normalizes to "customer" == canonical "Customer".
    out = await reconcile_node(
        NodeRef(label="CustomerService", kind="service"),
        [_entity("customer", "Customer", kind="service")],
    )
    assert out.entity_key == "customer"
    assert out.method in ("exact", "alias")


async def test_alias_match_is_method_alias() -> None:
    out = await reconcile_node(
        NodeRef(label="Client"),
        [_entity("customer", "Customer", aliases=["Client"])],
    )
    assert out.entity_key == "customer"
    assert out.method == "alias"


async def test_synonym_merges_via_embedding_auto_accept() -> None:
    """Customer/Client are semantically close in the FAKE embedder → step 2 auto-accepts."""
    embedder = FakeEmbedder()
    client_vec = await embedder.fn("Customer")  # registry stored under canonical "Customer"
    chat = FakeChat([])  # must NOT be reached (embedding auto-accepts)
    out = await reconcile_node(
        NodeRef(label="Client"),  # different label, same concept vector
        [_entity("customer", "Customer", embedding=client_vec)],
        chat=chat,
        embedding_fn=lambda t: _embed(embedder, t),
    )
    assert out.entity_key == "customer"
    assert out.method == "embedding"
    assert out.confidence >= 0.88  # >= TAU_HIGH
    assert chat.calls == []  # auto-accepted before the LLM step


async def test_synonym_merges_via_llm_when_embedding_ambiguous() -> None:
    """A mid-band embedding score routes to the LLM, which answers 'same' → method=llm."""
    # The candidate embedding sits deterministically in [TAU_LOW, TAU_HIGH) vs the node's
    # vector (cosine ~0.70), so step 2 does NOT auto-accept and the pair reaches the LLM.
    embedder = FakeEmbedder()
    node_label = "Buyer"  # same kind as the candidate so the kind guard does not block it
    chat = FakeChat(['[{"index": 0, "verdict": "same"}]'])
    out = await reconcile_node(
        NodeRef(label=node_label, kind="actor"),
        [_entity("customer", "Customer", kind="actor", embedding=_mid_band_vec(node_label))],
        chat=chat,
        embedding_fn=lambda t: _embed(embedder, t),
    )
    assert out.method == "llm"
    assert out.entity_key == "customer"
    assert len(chat.calls) == 1  # exactly one batched adjudication call


async def test_homonym_kind_mismatch_never_merges_and_skips_llm() -> None:
    """A 'Manager' actor vs a 'Manager' service: the kind guard blocks every step → new.

    Same label + identical embedding would merge at step 1 (normalize) AND step 2 (embedding)
    if kind were ignored. Because the kind guard is universal (sub-design §5), the candidate
    is skipped at every step and the node becomes a new entity — and the LLM is never spent.
    """
    embedder = FakeEmbedder()
    mgr_vec = await embedder.fn("Manager")
    chat = FakeChat(['[{"index": 0, "verdict": "same"}]'])  # must NOT be consulted
    out = await reconcile_node(
        NodeRef(label="Manager", kind="actor"),
        [_entity("manager_svc", "Manager", kind="service", embedding=mgr_vec)],
        chat=chat,
        embedding_fn=lambda t: _embed(embedder, t),
    )
    assert out.method == "new"  # not merged across the kind boundary
    assert out.is_new is True
    assert chat.calls == []  # the LLM is never spent on a kind-mismatched pair


async def test_homonym_distinct_labels_same_concept_diff_kind_is_new() -> None:
    """Distinct labels, same concept vector, DIFFERENT kind → not merged → a new entity.

    This is the real homonym guard: the embedding is close (same concept), but the kind
    differs, so step 3 drops the pair before any LLM call and the node becomes a new entity.
    """
    embedder = FakeEmbedder()
    # The candidate is mid-band (cosine ~0.70) so it WOULD reach step 3 if kinds matched; the
    # kind conflict (actor vs service) drops it before any LLM call → node becomes new.
    chat = FakeChat(['[{"index": 0, "verdict": "same"}]'])  # must NOT be consulted
    out = await reconcile_node(
        NodeRef(label="Supervisor", kind="actor"),
        [
            _entity(
                "handler_svc", "Coordinator", kind="service",
                embedding=_mid_band_vec("Supervisor"),
            )
        ],
        chat=chat,
        embedding_fn=lambda t: _embed(embedder, t),
    )
    assert out.method == "new"
    assert out.is_new is True
    assert chat.calls == []  # kind mismatch dropped the only candidate → no LLM


async def test_same_kind_exact_still_merges() -> None:
    """The kind guard must NOT over-block: same label + same kind merges (exact)."""
    out = await reconcile_node(
        NodeRef(label="Customer", kind="actor"),
        [_entity("customer", "Customer", kind="actor")],
    )
    assert out.method == "exact"
    assert out.entity_key == "customer"


async def test_unknown_kind_does_not_block_exact_match() -> None:
    """A None kind on either side is not a conflict — exact label still merges (defer to LLM)."""
    # Node has no kind; candidate has a kind → no conflict asserted → exact match holds.
    out = await reconcile_node(
        NodeRef(label="Customer", kind=None),
        [_entity("customer", "Customer", kind="actor")],
    )
    assert out.method == "exact"


async def test_no_candidate_is_a_new_entity() -> None:
    out = await reconcile_node(NodeRef(label="Widget Factory", key="widget-factory"), [])
    assert out.method == "new"
    assert out.is_new is True
    assert out.entity_key == "widget-factory"  # uses the node's coined key


async def test_new_entity_slugs_label_when_no_key_given() -> None:
    out = await reconcile_node(NodeRef(label="Payment Gateway"), [])
    assert out.is_new is True
    assert out.entity_key == "payment-gateway"  # slugified from the label


async def test_locked_candidate_match_is_method_locked() -> None:
    """A human-locked entity that matches deterministically is a forced, sticky assignment."""
    out = await reconcile_node(
        NodeRef(label="Customer"),
        [_entity("customer", "Customer", locked=True)],
    )
    assert out.method == "locked"
    assert out.entity_key == "customer"


async def test_llm_different_verdict_does_not_merge() -> None:
    embedder = FakeEmbedder()
    chat = FakeChat(['[{"index": 0, "verdict": "different"}]'])
    out = await reconcile_node(
        NodeRef(label="Ledger", kind="datastore"),
        [_entity("journal", "Journal", kind="datastore", embedding=_mid_band_vec("Ledger"))],
        chat=chat,
        embedding_fn=lambda t: _embed(embedder, t),
    )
    assert out.method == "new"  # 'different' → not merged → new entity
    assert len(chat.calls) == 1


async def test_llm_unparsable_response_fails_safe_to_new() -> None:
    """A garbled adjudication response must never false-merge — fall through to new."""
    embedder = FakeEmbedder()
    chat = FakeChat(["not json at all"])
    out = await reconcile_node(
        NodeRef(label="Vault", kind="datastore"),
        [_entity("safe", "Safe", kind="datastore", embedding=_mid_band_vec("Vault"))],
        chat=chat,
        embedding_fn=lambda t: _embed(embedder, t),
    )
    assert out.method == "new"


async def test_no_chat_leaves_ambiguous_tail_unresolved() -> None:
    """With chat=None the ambiguous tail is not guessed — node becomes a new entity."""
    embedder = FakeEmbedder()
    out = await reconcile_node(
        NodeRef(label="Cart", kind="component"),
        [_entity("basket", "Basket", kind="component", embedding=_mid_band_vec("Cart"))],
        chat=None,
        embedding_fn=lambda t: _embed(embedder, t),
    )
    assert out.method == "new"


async def test_llm_budget_zero_skips_adjudication() -> None:
    """A spent budget treats the ambiguous tail as different (no LLM), logged upstream."""
    embedder = FakeEmbedder()
    chat = FakeChat(['[{"index": 0, "verdict": "same"}]'])
    out = await reconcile_node(
        NodeRef(label="Tote", kind="component"),
        [_entity("bag", "Bag", kind="component", embedding=_mid_band_vec("Tote"))],
        chat=chat,
        embedding_fn=lambda t: _embed(embedder, t),
        llm_budget=0,
    )
    assert out.method == "new"
    assert chat.calls == []  # budget 0 → no call


# =========================================================================== #
# cosine_similarity — defensive contract.
# =========================================================================== #
def test_cosine_handles_empty_and_mismatched_dims() -> None:
    assert cosine_similarity([], [1.0]) == 0.0
    assert cosine_similarity([1.0, 0.0], [1.0]) == 0.0  # length mismatch → 0.0
    assert cosine_similarity([0.0, 0.0], [1.0, 0.0]) == 0.0  # zero vector → 0.0
    assert cosine_similarity([1.0, 0.0], [1.0, 0.0]) == 1.0


# =========================================================================== #
# EntityRegistryStore — Path-C upsert, tenancy, merge/split (human override §6).
# =========================================================================== #
class FakeRepo:
    """Table-aware owner-scoped fake (mirrors test_diagram.py). ``create_scoped`` returns a
    single-element LIST so the store's unwrap is exercised; ``select_scoped`` is
    owner+notebook+key filtered enough for the registry's read paths.
    """

    def __init__(self, rows: list[dict[str, Any]] | None = None) -> None:
        self.rows = rows or []
        self.created: list[dict[str, Any]] = []
        self.queries: list[dict[str, Any]] = []
        self.deletes: list[dict[str, Any]] = []
        self._counter = 0

    async def create_scoped(
        self, table: str, data: dict[str, Any], *, owner: str, scope: Scope
    ) -> list[dict[str, Any]]:
        self._counter += 1
        row = {
            **data,
            "id": f"{table}:{self._counter}",
            "owner": owner,
            "scope": scope.value,
        }
        self.created.append(row)
        self.rows.append(row)
        return [row]  # LIST — the store must unwrap

    async def select_scoped(
        self,
        table: str,
        principal: Principal,
        *,
        focus: bool = False,
        extra_where: str = "",
        order_by: str = "updated DESC",
        limit: int | None = None,
        vars: dict[str, Any] | None = None,
        notebook: Any = None,
    ) -> list[dict[str, Any]]:
        rows = [r for r in self.rows if r.get("owner") == principal.owner] if focus else list(self.rows)
        v = vars or {}
        if "nb" in v:
            rows = [r for r in rows if r.get("notebook_id") == v["nb"]]
        if "key" in v:
            rows = [r for r in rows if r.get("entity_key") == v["key"]]
        if "eid" in v:
            rows = [r for r in rows if _id_eq(r.get("id"), v["eid"])]
        return rows

    async def query(
        self, query: str, vars: dict[str, Any] | None = None
    ) -> list[dict[str, Any]]:
        # Simulate scoped_update's UPDATE ... RETURN AFTER by merging field vars into the row.
        self.queries.append({"query": query, "vars": vars})
        v = vars or {}
        for row in self.rows:
            if _id_eq(row.get("id"), v.get("rid")) and row.get("owner") == v.get("owner"):
                for key, value in v.items():
                    if key in ("rid", "owner"):
                        continue
                    # Mirror the real repo: db.query() runs results through parse_record_ids,
                    # so datetimes come back as ISO strings (NotebookEntity.updated is str).
                    row[key] = (
                        value.isoformat() if isinstance(value, datetime) else value
                    )
                return [dict(row)]
        return []

    async def delete_where(
        self, table: str, where: str, vars: dict[str, Any] | None = None
    ) -> None:
        self.deletes.append({"where": where, "vars": vars})
        v = vars or {}
        self.rows = [
            r
            for r in self.rows
            if not (_id_eq(r.get("id"), v.get("eid")) and r.get("owner") == v.get("owner"))
        ]


def _graph_with_entities(pairs: list[tuple[str, str]]) -> DiagramGraph:
    """A minimal graph whose nodes carry the given (id, entity_key) — for upsert tests."""
    nodes = [
        {
            "id": nid,
            "label": nid.title(),
            "type": "service",
            "description": None,
            "groupId": None,
            "shape": None,
            "entity": ekey,
        }
        for nid, ekey in pairs
    ]
    return DiagramGraph.model_validate({"groups": [], "nodes": nodes, "edges": []})


async def test_upsert_from_graph_registers_new_keys() -> None:
    repo = FakeRepo()
    store = EntityRegistryStore(repo)
    graph = _graph_with_entities([("a", "customer"), ("b", "order")])
    touched = await store.upsert_from_graph(
        P, notebook_id="notebook:1", source_id="source:1", graph=graph
    )
    assert {e.entity_key for e in touched} == {"customer", "order"}
    # Both stored owner-PRIVATE, with the source in source_refs.
    customer = await store.get_by_key(P, notebook_id="notebook:1", entity_key="customer")
    assert customer is not None
    assert customer.source_refs == ["source:1"]
    assert customer.scope == "private"


async def test_upsert_from_graph_is_idempotent_on_reaccept() -> None:
    """Re-accepting the same source must not duplicate rows or refs (sub-design §4/§11)."""
    repo = FakeRepo()
    store = EntityRegistryStore(repo)
    graph = _graph_with_entities([("a", "customer")])
    await store.upsert_from_graph(
        P, notebook_id="notebook:1", source_id="source:1", graph=graph
    )
    await store.upsert_from_graph(  # same source, again
        P, notebook_id="notebook:1", source_id="source:1", graph=graph
    )
    entities = await store.list(P, notebook_id="notebook:1")
    customers = [e for e in entities if e.entity_key == "customer"]
    assert len(customers) == 1  # not duplicated
    assert customers[0].source_refs == ["source:1"]  # ref not duplicated


async def test_upsert_appends_alias_and_source_ref_across_sources() -> None:
    repo = FakeRepo()
    store = EntityRegistryStore(repo)
    await store.upsert_from_graph(
        P,
        notebook_id="notebook:1",
        source_id="source:1",
        graph=_graph_with_entities([("a", "customer")]),
    )
    # A second source references the same key with a different node label.
    g2 = DiagramGraph.model_validate(
        {
            "groups": [],
            "nodes": [
                {
                    "id": "a",
                    "label": "Client",
                    "type": "actor",
                    "description": None,
                    "groupId": None,
                    "shape": None,
                    "entity": "customer",
                }
            ],
            "edges": [],
        }
    )
    await store.upsert_from_graph(
        P, notebook_id="notebook:1", source_id="source:2", graph=g2
    )
    customer = await store.get_by_key(P, notebook_id="notebook:1", entity_key="customer")
    assert customer is not None
    assert set(customer.source_refs) == {"source:1", "source:2"}
    assert "Client" in customer.aliases  # the new label became an alias


async def test_upsert_skips_locked_entity() -> None:
    """Path C must not widen a human-locked entity (sub-design §6)."""
    repo = FakeRepo(
        rows=[
            {
                "id": "notebook_entity:1",
                "owner": "u1",
                "scope": "private",
                "notebook_id": "notebook:1",
                "entity_key": "customer",
                "canonical_label": "Customer",
                "aliases": [],
                "source_refs": ["source:1"],
                "locked": True,
            }
        ]
    )
    store = EntityRegistryStore(repo)
    g = DiagramGraph.model_validate(
        {
            "groups": [],
            "nodes": [
                {
                    "id": "a",
                    "label": "Client",
                    "type": "actor",
                    "description": None,
                    "groupId": None,
                    "shape": None,
                    "entity": "customer",
                }
            ],
            "edges": [],
        }
    )
    await store.upsert_from_graph(
        P, notebook_id="notebook:1", source_id="source:2", graph=g
    )
    customer = await store.get_by_key(P, notebook_id="notebook:1", entity_key="customer")
    assert customer is not None
    assert customer.source_refs == ["source:1"]  # NOT widened (locked)
    assert customer.aliases == []


async def test_registry_list_is_owner_and_notebook_scoped() -> None:
    repo = FakeRepo(
        rows=[
            {"id": "notebook_entity:1", "owner": "u1", "notebook_id": "notebook:1",
             "entity_key": "a", "canonical_label": "A", "aliases": [], "source_refs": []},
            {"id": "notebook_entity:2", "owner": "u2", "notebook_id": "notebook:1",
             "entity_key": "b", "canonical_label": "B", "aliases": [], "source_refs": []},
            {"id": "notebook_entity:3", "owner": "u1", "notebook_id": "notebook:2",
             "entity_key": "c", "canonical_label": "C", "aliases": [], "source_refs": []},
        ]
    )
    store = EntityRegistryStore(repo)
    out = await store.list(P, notebook_id="notebook:1")
    # Only u1's entity in notebook:1 — not u2's (cross-owner) nor notebook:2 (cross-notebook).
    assert {e.entity_key for e in out} == {"a"}


async def test_merge_unions_and_locks_survivor() -> None:
    repo = FakeRepo(
        rows=[
            {"id": "notebook_entity:1", "owner": "u1", "notebook_id": "notebook:1",
             "entity_key": "customer", "canonical_label": "Customer",
             "aliases": ["Buyer"], "source_refs": ["source:1"], "locked": False},
            {"id": "notebook_entity:2", "owner": "u1", "notebook_id": "notebook:1",
             "entity_key": "client", "canonical_label": "Client",
             "aliases": ["Patron"], "source_refs": ["source:2"], "locked": False},
        ]
    )
    store = EntityRegistryStore(repo)
    survivor = await store.merge(
        P, survivor_id="notebook_entity:1", merged_ids=["notebook_entity:2"]
    )
    assert survivor is not None
    assert survivor.locked is True  # sticky after a human merge
    assert set(survivor.source_refs) == {"source:1", "source:2"}
    # The merged entity's label + aliases are now survivor aliases.
    assert "Client" in survivor.aliases and "Patron" in survivor.aliases
    # The merged row was deleted.
    remaining = await store.list(P, notebook_id="notebook:1")
    assert {e.entity_key for e in remaining} == {"customer"}


async def test_split_moves_refs_and_locks_both() -> None:
    repo = FakeRepo(
        rows=[
            {"id": "notebook_entity:1", "owner": "u1", "notebook_id": "notebook:1",
             "entity_key": "manager", "canonical_label": "Manager",
             "aliases": ["Lead", "Supervisor"],
             "source_refs": ["source:1", "source:2"], "locked": False},
        ]
    )
    store = EntityRegistryStore(repo)
    result = await store.split(
        P,
        source_entity_id="notebook_entity:1",
        new_entity_key="manager-service",
        new_canonical_label="Manager Service",
        move_aliases=["Supervisor"],
        move_source_refs=["source:2"],
        kind="service",
    )
    assert result is not None
    source_after, new_entity = result
    assert source_after.locked is True and new_entity.locked is True
    assert "Supervisor" not in source_after.aliases  # moved out
    assert source_after.source_refs == ["source:1"]
    assert new_entity.source_refs == ["source:2"]
    assert new_entity.aliases == ["Supervisor"]
    assert new_entity.kind == "service"


async def test_human_merge_is_sticky_against_reconciliation() -> None:
    """After a human merge (locked), a later reconcile of a matching label honours it (§6)."""
    # The survivor is locked and carries "Client" as an alias; reconciling a "Client" node
    # must return method="locked" (forced assignment), not re-adjudicate or split.
    survivor = _entity(
        "customer", "Customer", aliases=["Client"], locked=True
    )
    out = await reconcile_node(NodeRef(label="Client"), [survivor])
    assert out.method == "locked"
    assert out.entity_key == "customer"


# =========================================================================== #
# normalize_label — the §5 step-1 contract (sub-design §9 matrix rows).
# =========================================================================== #
def test_normalize_collapses_plurals_and_suffixes() -> None:
    assert normalize_label("Customer") == normalize_label("CustomerService")
    assert normalize_label("Order") == normalize_label("Orders")
    assert normalize_label("Customer") == normalize_label("Customer Record")
    # Guards: a bare suffix word is not emptied; -ss is protected.
    assert normalize_label("Service") == "service"
    assert normalize_label("class") == "class"


async def test_default_budget_constant_is_respected() -> None:
    """Sanity: the module exposes the documented per-compose LLM cap (sub-design §11)."""
    assert MAX_LLM_ADJUDICATIONS_PER_COMPOSE == 20
