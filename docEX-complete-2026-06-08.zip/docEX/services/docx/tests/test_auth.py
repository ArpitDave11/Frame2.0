"""Auth → principal: dev-header mode and gateway-JWT mode, exercised via /me."""

import pytest
from fastapi.testclient import TestClient

from shared.auth.jwt import create_local_jwt

from docx_app import deps
from docx_app.config import DocxConfig
from docx_app.main import app


@pytest.fixture
def client_for():
    def make(config: DocxConfig) -> TestClient:
        app.dependency_overrides[deps.get_config] = lambda: config
        return TestClient(app)

    yield make
    app.dependency_overrides.clear()


def test_dev_mode_uses_header_owner(client_for):
    client = client_for(DocxConfig(service_name="t", auth_mode="dev"))
    resp = client.get("/me", headers={"X-Docx-User": "alice@corp.com"})
    assert resp.status_code == 200
    body = resp.json()
    assert body["owner"] == "alice@corp.com" and body["email"] == "alice@corp.com"


def test_dev_mode_falls_back_to_dev_owner(client_for):
    client = client_for(
        DocxConfig(service_name="t", auth_mode="dev", dev_owner="fallback")
    )
    resp = client.get("/me")
    assert resp.status_code == 200 and resp.json()["owner"] == "fallback"


def test_gateway_mode_rejects_missing_token(client_for):
    client = client_for(
        DocxConfig(service_name="t", auth_mode="gateway", local_jwt_secret="s")
    )
    assert client.get("/me").status_code == 401


def test_gateway_mode_accepts_valid_jwt(client_for):
    client = client_for(
        DocxConfig(service_name="t", auth_mode="gateway", local_jwt_secret="s")
    )
    token = create_local_jwt("s", subject="u-oid")
    resp = client.get("/me", headers={"Authorization": f"Bearer {token}"})
    assert resp.status_code == 200 and resp.json()["owner"] == "u-oid"


def test_gateway_mode_rejects_bad_signature(client_for):
    client = client_for(
        DocxConfig(service_name="t", auth_mode="gateway", local_jwt_secret="right")
    )
    forged = create_local_jwt("wrong-secret", subject="u-oid")
    assert (
        client.get("/me", headers={"Authorization": f"Bearer {forged}"}).status_code
        == 401
    )
