"""Settings + system endpoints — contract shape, tenancy scoping, and a cross-owner LEAK test.

Two layers, mirroring the rest of the suite:
  - API tests (TestClient + dependency_overrides with light fakes) prove the wire contract
    matches what the Open Notebook frontend expects (settings.ts / embedding.ts).
  - The LEAK test uses InMemorySettingsRepo, which ACTUALLY applies the owner predicate (like
    tests/test_tenancy_isolation.py), proving one owner can never read/overwrite another's
    settings — the locked tenancy guarantee for this slice.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any, cast

import pytest
from fastapi.testclient import TestClient

from docx_app import deps
from docx_app.api.settings import router as settings_router
from docx_app.api.system import router as system_router
from docx_app.db import SurrealRepository, parse_record_ids
from docx_app.domain.settings import SettingsStore, SettingsUpdate
from docx_app.main import app
from docx_app.tenancy import Principal, Scope

# --- Fakes -----------------------------------------------------------------


class FakeSettingsRepo:
    """API-level fake: records writes, returns canned rows. Does NOT enforce scoping
    (the InMemorySettingsRepo below does that — this one just exercises the router/store path)."""

    def __init__(self, rows: list[dict[str, Any]] | None = None):
        self.rows = rows or []
        self.created: list[dict[str, Any]] = []
        self.deleted: list[dict[str, Any]] = []
        self.selects: list[dict[str, Any]] = []

    async def select_scoped(
        self,
        table: str,
        principal: Principal,
        *,
        focus: bool = False,
        extra_where: str = "",
        order_by: str = "updated DESC",
        limit: int | None = None,
        vars: dict[str, Any] | None = None,
        notebook: str | None = None,
    ) -> list[dict[str, Any]]:
        self.selects.append({"table": table, "focus": focus, "notebook": notebook})
        return self.rows

    async def create_scoped(
        self, table: str, data: dict[str, Any], *, owner: str, scope: Scope
    ) -> dict[str, Any]:
        self.created.append({"data": data, "owner": owner, "scope": scope})
        return parse_record_ids(
            {**data, "id": f"{table}:1", "owner": owner, "scope": scope.value}
        )

    async def delete_where(
        self, table: str, where: str, vars: dict[str, Any] | None = None
    ) -> None:
        self.deleted.append({"table": table, "where": where, "vars": vars})


class InMemorySettingsRepo:
    """A repo fake that REALLY enforces the owner predicate for owner_settings.

    select_scoped(focus=True) → owner-only (the predicate SettingsStore uses).
    delete_where("owner = $owner") → only the bound owner's row is removed.
    A leak (owner A reading/overwriting owner B's settings) would fail the assertions below.
    """

    def __init__(self) -> None:
        self._rows: list[dict[str, Any]] = []

    async def select_scoped(
        self,
        table: str,
        principal: Principal,
        *,
        focus: bool = False,
        extra_where: str = "",
        order_by: str = "updated DESC",
        limit: int | None = None,
        vars: dict[str, Any] | None = None,
        notebook: str | None = None,
    ) -> list[dict[str, Any]]:
        def visible(r: dict[str, Any]) -> bool:
            if focus:
                return r["owner"] == principal.owner
            return r["scope"] == "org-common" or r["owner"] == principal.owner

        rows = [r for r in self._rows if r["id"].startswith(f"{table}:") and visible(r)]
        return rows[: limit or len(rows)]

    async def create_scoped(
        self, table: str, data: dict[str, Any], *, owner: str, scope: Scope
    ) -> dict[str, Any]:
        row = {
            **data,
            "id": f"{table}:{len(self._rows) + 1}",
            "owner": owner,
            "scope": scope.value,
        }
        self._rows.append(row)
        return row

    async def delete_where(
        self, table: str, where: str, vars: dict[str, Any] | None = None
    ) -> None:
        # Mirror the store's only delete: "owner = $owner" — scoped to the bound owner.
        owner = (vars or {}).get("owner")
        self._rows = [
            r
            for r in self._rows
            if not (r["id"].startswith(f"{table}:") and r["owner"] == owner)
        ]


class _NoopIndexer:
    def __init__(self) -> None:
        self.indexed: list[Any] = []

    async def index_source(self, source: Any) -> int:
        self.indexed.append(source)
        return 1


# --- API: /settings --------------------------------------------------------


def _ensure_routers_mounted() -> None:
    """Mount this slice's routers on the app for the test (idempotent).

    main.py is owned by the orchestrator (it adds the include_router lines for real); the test
    app instance doesn't have them yet, so we attach them here without touching main.py. The
    path check keeps repeated fixture setups from double-registering the same routes.
    """
    mounted = {getattr(r, "path", None) for r in app.routes}
    if "/settings" not in mounted:
        app.include_router(settings_router)
    if "/embeddings/rebuild" not in mounted:
        app.include_router(system_router)


@pytest.fixture
def settings_ctx() -> Iterator[tuple[TestClient, FakeSettingsRepo]]:
    _ensure_routers_mounted()
    repo = FakeSettingsRepo()
    app.dependency_overrides[deps.get_principal] = lambda: Principal(owner="u1")
    app.dependency_overrides[deps.get_repository] = lambda: repo
    client = TestClient(app)
    yield client, repo
    app.dependency_overrides.clear()


def test_get_settings_returns_defaults_when_none(
    settings_ctx: tuple[TestClient, FakeSettingsRepo],
) -> None:
    client, repo = settings_ctx
    repo.rows = []  # owner has no settings row yet
    resp = client.get("/settings")
    assert resp.status_code == 200
    body = resp.json()
    # ON defaults round-tripped, exact contract field names.
    assert body["default_content_processing_engine_doc"] == "auto"
    assert body["default_content_processing_engine_url"] == "auto"
    assert body["default_embedding_option"] == "ask"
    assert body["auto_delete_files"] == "yes"
    assert "en" in body["youtube_preferred_languages"]
    # The read used the owner-only predicate.
    assert repo.selects[0]["focus"] is True


def test_get_settings_returns_stored_row(
    settings_ctx: tuple[TestClient, FakeSettingsRepo],
) -> None:
    client, repo = settings_ctx
    repo.rows = [
        {
            "id": "owner_settings:1",
            "owner": "u1",
            "scope": "private",
            "default_embedding_option": "always",
            "auto_delete_files": "no",
        }
    ]
    resp = client.get("/settings")
    assert resp.status_code == 200
    body = resp.json()
    assert body["default_embedding_option"] == "always"
    assert body["auto_delete_files"] == "no"
    # Unset fields fall back to defaults.
    assert body["default_content_processing_engine_doc"] == "auto"


def test_put_settings_merges_and_stamps_private(
    settings_ctx: tuple[TestClient, FakeSettingsRepo],
) -> None:
    client, repo = settings_ctx
    repo.rows = []  # no existing row → merge over defaults
    resp = client.put("/settings", json={"default_embedding_option": "never"})
    assert resp.status_code == 200
    body = resp.json()
    assert body["default_embedding_option"] == "never"
    assert body["auto_delete_files"] == "yes"  # untouched default preserved
    # Written as PRIVATE, stamped to the caller, and the owner-scoped delete ran first.
    assert repo.created[0]["owner"] == "u1"
    assert repo.created[0]["scope"] == Scope.PRIVATE
    assert repo.deleted[0]["where"] == "owner = $owner"
    assert repo.deleted[0]["vars"] == {"owner": "u1"}


def test_put_settings_ignores_unknown_fields(
    settings_ctx: tuple[TestClient, FakeSettingsRepo],
) -> None:
    client, repo = settings_ctx
    repo.rows = []
    resp = client.put(
        "/settings", json={"auto_delete_files": "no", "owner": "attacker", "id": "x"}
    )
    assert resp.status_code == 200
    # owner/id from the body must never override the authenticated principal's stamping.
    assert repo.created[0]["owner"] == "u1"
    assert "owner" not in repo.created[0]["data"]
    assert "id" not in repo.created[0]["data"]


# --- API: /auth/status + /config -------------------------------------------


def test_auth_status_reports_no_password(
    settings_ctx: tuple[TestClient, FakeSettingsRepo],
) -> None:
    client, _ = settings_ctx
    resp = client.get("/auth/status")
    assert resp.status_code == 200
    body = resp.json()
    # Frontend reads `auth_enabled`; Docx never requires an app password.
    assert body["auth_enabled"] is False
    assert body["auth_required"] is False


def test_config_returns_empty_api_url(
    settings_ctx: tuple[TestClient, FakeSettingsRepo],
) -> None:
    client, _ = settings_ctx
    resp = client.get("/config")
    assert resp.status_code == 200
    assert resp.json()["apiUrl"] == ""


# --- API: /embeddings/rebuild ----------------------------------------------


@pytest.fixture
def rebuild_ctx() -> Iterator[tuple[TestClient, FakeSettingsRepo, _NoopIndexer]]:
    _ensure_routers_mounted()
    repo = FakeSettingsRepo()
    indexer = _NoopIndexer()
    app.dependency_overrides[deps.get_principal] = lambda: Principal(owner="u1")
    app.dependency_overrides[deps.get_repository] = lambda: repo
    app.dependency_overrides[deps.get_indexer] = lambda: indexer
    client = TestClient(app)
    yield client, repo, indexer
    app.dependency_overrides.clear()


def test_rebuild_all_reindexes_owned_sources(
    rebuild_ctx: tuple[TestClient, FakeSettingsRepo, _NoopIndexer],
) -> None:
    client, repo, indexer = rebuild_ctx
    # SourceStore.list(focus=True) returns these rows from the (fake) scoped select.
    repo.rows = [
        {"id": "source:1", "full_text": "a", "owner": "u1", "scope": "private"},
        {"id": "source:2", "full_text": "b", "owner": "u1", "scope": "org-common"},
    ]
    resp = client.post("/embeddings/rebuild", json={"mode": "all"})
    assert resp.status_code == 200
    body = resp.json()
    assert body["estimated_items"] == 2
    assert body["command_id"]  # synthetic id present
    assert len(indexer.indexed) == 2
    # Rebuild reads OWN sources only (focus=True) — never the shared brain.
    assert repo.selects[0]["focus"] is True


def test_rebuild_existing_only_touches_indexed_sources(
    rebuild_ctx: tuple[TestClient, FakeSettingsRepo, _NoopIndexer],
) -> None:
    client, repo, indexer = rebuild_ctx
    repo.rows = [
        {"id": "source:1", "owner": "u1", "scope": "private", "chunk_count": 3},
        {"id": "source:2", "owner": "u1", "scope": "private", "chunk_count": None},
    ]
    resp = client.post("/embeddings/rebuild", json={"mode": "existing"})
    assert resp.status_code == 200
    # Only the already-indexed source (chunk_count set) is re-embedded.
    assert resp.json()["estimated_items"] == 1
    assert [s.id for s in indexer.indexed] == ["source:1"]


def test_rebuild_excluding_sources_is_noop(
    rebuild_ctx: tuple[TestClient, FakeSettingsRepo, _NoopIndexer],
) -> None:
    client, repo, indexer = rebuild_ctx
    repo.rows = [
        {"id": "source:1", "owner": "u1", "scope": "private", "chunk_count": 1}
    ]
    resp = client.post(
        "/embeddings/rebuild", json={"mode": "all", "include_sources": False}
    )
    assert resp.status_code == 200
    assert resp.json()["estimated_items"] == 0
    assert indexer.indexed == []


def test_rebuild_continues_past_a_failing_source(
    rebuild_ctx: tuple[TestClient, FakeSettingsRepo, _NoopIndexer],
) -> None:
    client, repo, _ = rebuild_ctx
    repo.rows = [
        {"id": "source:1", "owner": "u1", "scope": "private"},
        {"id": "source:2", "owner": "u1", "scope": "private"},
    ]

    class BoomThenOk:
        def __init__(self) -> None:
            self.calls = 0

        async def index_source(self, source: Any) -> int:
            self.calls += 1
            if self.calls == 1:
                raise RuntimeError("azure down")
            return 1

    app.dependency_overrides[deps.get_indexer] = lambda: BoomThenOk()
    resp = client.post("/embeddings/rebuild", json={"mode": "all"})
    assert resp.status_code == 200  # one failure does not abort the run
    assert resp.json()["estimated_items"] == 1  # the second source still succeeded


# --- Cross-owner LEAK test (real predicate enforcement) --------------------


async def test_settings_never_leak_across_owners() -> None:
    """Owner A's settings must be invisible to owner B, and B's PUT must not touch A's row."""
    repo = InMemorySettingsRepo()
    store = SettingsStore(cast("SurrealRepository", repo))
    alice = Principal(owner="alice")
    bob = Principal(owner="bob")

    # Alice sets a distinctive value.
    await store.upsert(alice, SettingsUpdate(auto_delete_files="no"))

    # Bob, who has set nothing, sees the ON DEFAULTS — never alice's "no".
    bob_settings = await store.get(bob)
    assert bob_settings.auto_delete_files == "yes"

    # Bob writes his own settings...
    await store.upsert(bob, SettingsUpdate(default_embedding_option="never"))

    # ...which must not have disturbed alice's row (her value still stands).
    alice_settings = await store.get(alice)
    assert alice_settings.auto_delete_files == "no"
    assert alice_settings.default_embedding_option == "ask"  # alice never set this

    # And each owner still has exactly one row (upsert replaced in place, per owner).
    assert len(repo._rows) == 2


async def test_settings_upsert_replaces_own_row_in_place() -> None:
    """Repeated PUTs by one owner keep a single row (upsert, not append)."""
    repo = InMemorySettingsRepo()
    store = SettingsStore(cast("SurrealRepository", repo))
    alice = Principal(owner="alice")

    await store.upsert(alice, SettingsUpdate(default_embedding_option="always"))
    await store.upsert(alice, SettingsUpdate(auto_delete_files="no"))

    rows = [r for r in repo._rows if r["owner"] == "alice"]
    assert len(rows) == 1  # one row per owner
    # The second PUT merged over the first (both fields retained).
    final = await store.get(alice)
    assert final.default_embedding_option == "always"
    assert final.auto_delete_files == "no"


# Assert the routers the orchestrator will mount expose the expected paths (and that they
# import cleanly in this environment) — these are the lines main.py adds for this slice.
def test_routers_expose_expected_paths() -> None:
    assert settings_router.prefix == "/settings"
    system_paths = {getattr(r, "path", None) for r in system_router.routes}
    assert "/embeddings/rebuild" in system_paths
    assert "/auth/status" in system_paths
    assert "/config" in system_paths
