"""Rerankers — identity passthrough, LLM listwise reorder, robust parsing."""

from docx_app.retrieval.models import RetrievedChunk
from docx_app.retrieval.rerank import IdentityReranker, LLMReranker, _parse_order


def _chunks(*contents):
    return [
        RetrievedChunk(id=f"source_chunk:{i}", content=c, score=1.0)
        for i, c in enumerate(contents, start=1)
    ]


class FakeChat:
    def __init__(self, reply):
        self.reply = reply
        self.user = None

    async def complete(self, *, system, user, max_tokens=1000):
        self.user = user
        return self.reply


def test_parse_order_tolerates_junk_and_completes_permutation():
    # model says 3 then 1, omits 2, repeats 3, emits out-of-range 9 → [2,0,1]
    assert _parse_order("3, 1, 3, 9", 3) == [2, 0, 1]
    assert _parse_order("garbage", 2) == [0, 1]  # nothing parsed → original order


async def test_identity_reranker_is_passthrough():
    chunks = _chunks("a", "b")
    assert await IdentityReranker().rerank("q", chunks) == chunks


async def test_llm_reranker_reorders_by_model_ranking():
    chunks = _chunks("first", "second", "third")
    chat = FakeChat("2, 3, 1")
    out = await LLMReranker(chat).rerank("q", chunks)
    assert [c.content for c in out] == ["second", "third", "first"]
    assert "[1] first" in chat.user  # passages were listed for the model


async def test_llm_reranker_keeps_order_on_chat_failure():
    class BoomChat:
        async def complete(self, *, system, user, max_tokens=1000):
            raise RuntimeError("model down")

    chunks = _chunks("a", "b")
    out = await LLMReranker(BoomChat()).rerank("q", chunks)
    assert out == chunks  # best-effort: fusion order preserved


async def test_llm_reranker_skips_trivial_inputs():
    chat = FakeChat("1")
    assert await LLMReranker(chat).rerank("q", []) == []
    one = _chunks("only")
    assert await LLMReranker(chat).rerank("q", one) == one
    assert chat.user is None  # never called the model
