"""RepoGraph (Surface 3) tests — the repo pipeline + the ``/repograph`` HTTP seam.

Two layers, both deterministic and offline (no network, no real DB, no real GitLab):

  * **Repo pipeline** (:mod:`docx_app.diagram.repo_pipeline`) with a fake LLM — the happy
    path, the gitdiagram validate-and-retry loop, the file-tree ``link`` validation (the one
    validator check that does *not* fire for source diagrams), the namespace → owner/name
    split, the Azure-catalog injection, and the empty-tree guard. Proves RepoGraph reuses the
    frozen ``agent.py`` machinery while pointing at the ``SYSTEM_*`` (repo) prompts.
  * **HTTP seam** (:mod:`docx_app.api.repograph`) end-to-end via a ``TestClient`` with
    dependency overrides — a fake ``gitlab_service`` + a fake LLM. Proves ``POST /repograph``
    fetches → runs the pipeline → persists a ``surface='repograph'`` diagram (owner-scoped),
    ``GET /repograph`` lists, ``GET /repograph/{id}`` loads, ``POST /repograph/{id}/accept``
    freezes (DATA + PICTURE), and the GitLab error → HTTP mapping (503/404/502/422).

Style mirrors ``test_diagram.py`` (the ``FakeRepo``/``FakeChat`` shapes, ``asyncio_mode =
"auto"``) and ``test_notebook_diagrams_api.py`` (the table-aware ``_ApiRepo`` + the override
``TestClient`` builder).
"""

from __future__ import annotations

import json
from datetime import datetime
from typing import TYPE_CHECKING, Any

import pytest

if TYPE_CHECKING:
    from fastapi.testclient import TestClient

from docx_app.db import ensure_record_id
from docx_app.diagram.agent import DiagramPipelineError
from docx_app.diagram.repo_fetch import (
    RepoConfigError,
    RepoData,
    RepoFetchError,
    RepoNotFoundError,
)
from docx_app.diagram.model import DiagramGraph
from docx_app.diagram.repo_pipeline import (
    run_repo_diagram_pipeline,
    split_namespace,
)
from docx_app.tenancy import Principal


# --------------------------------------------------------------------------- #
# Fixtures / helpers
# --------------------------------------------------------------------------- #
def _valid_graph_dict(
    *, link: str | None = None, icon: str | None = None
) -> dict[str, Any]:
    """A minimal, schema-valid graph (edges keyed by ``"from"``, as stored).

    ``link`` lets a node carry a repo path so the file-tree link validation can be exercised;
    ``icon`` lets a node carry an Azure icon id for the icon-strip path.
    """
    return {
        "groups": [],
        "nodes": [
            {
                "id": "api",
                "label": "API",
                "type": "service",
                "description": None,
                "groupId": None,
                "shape": None,
                "icon": icon,
                "link": link,
                "drill": None,
                "entity": None,
                "meta": None,
            },
            {
                "id": "db",
                "label": "DB",
                "type": "database",
                "description": None,
                "groupId": None,
                "shape": "database",
            },
        ],
        "edges": [
            {
                "from": "api",
                "to": "db",
                "label": "reads",
                "description": None,
                "style": None,
                "animated": True,
                "flow": "read",
            },
        ],
    }


def _fenced(graph: dict[str, Any]) -> str:
    """The graph as the local ``claude_cli`` path returns it — JSON in a fenced block."""
    return "Here is the diagram:\n\n```json\n" + json.dumps(graph) + "\n```\n"


class FakeChat:
    """A scripted ``ChatClient`` — returns the next queued response per ``complete`` call.

    Matches the ``_ChatLike`` protocol (``async complete(*, system, user, max_tokens)``) the
    pipeline depends on. Records every call so tests can assert the prompt/user content (e.g.
    that the repo blocks were injected) and the call count (explanation + N graph attempts).
    """

    def __init__(self, responses: list[str]) -> None:
        self._responses = list(responses)
        self.calls: list[dict[str, Any]] = []

    async def complete(self, *, system: str, user: str, max_tokens: int = 1000) -> str:
        self.calls.append({"system": system, "user": user, "max_tokens": max_tokens})
        if not self._responses:
            raise AssertionError("FakeChat ran out of scripted responses")
        return self._responses.pop(0)


P = Principal(owner="u1")


# =========================================================================== #
# split_namespace — GitLab "group/.../project" → (repo_owner, repo_name)
# =========================================================================== #
def test_split_namespace_simple() -> None:
    assert split_namespace("infra/k8s-platform") == ("infra", "k8s-platform")


def test_split_namespace_nested_subgroups() -> None:
    assert split_namespace("infra/team/k8s-platform") == ("infra/team", "k8s-platform")


def test_split_namespace_no_group() -> None:
    assert split_namespace("k8s-platform") == ("", "k8s-platform")


def test_split_namespace_empty() -> None:
    assert split_namespace("   ") == ("", "")
    assert split_namespace("/") == ("", "")


# =========================================================================== #
# run_repo_diagram_pipeline — repo prompts, file-tree lookup, retry loop
# =========================================================================== #
async def test_pipeline_happy_path_returns_validated_graph() -> None:
    """Explanation + one graph step → a validated graph; repo blocks are injected."""
    chat = FakeChat(
        [
            "<explanation>The API reads the DB.</explanation>",
            _fenced(_valid_graph_dict()),
        ]
    )
    graph = await run_repo_diagram_pipeline(
        chat,
        file_tree="api/main.py\nstorage/db.py",
        readme="# Service\nA small service.",
        namespace="infra/svc",
        include_azure_shapes=False,
    )
    assert isinstance(graph, DiagramGraph)
    assert {n.id for n in graph.nodes} == {"api", "db"}
    assert graph.edges[0].from_ == "api"  # the "from" alias mapped through
    assert len(chat.calls) == 2  # explanation + 1 graph step

    # Step 1 used the REPO prompt + the <file_tree>/<readme> blocks (not source blocks).
    explain_call = chat.calls[0]
    assert "repository" in explain_call["system"].lower()
    assert "<file_tree>" in explain_call["user"]
    assert "<readme>" in explain_call["user"]
    assert "<source_text>" not in explain_call["user"]

    # Step 2 carried <repo_owner>/<repo_name> derived from the namespace.
    graph_call = chat.calls[1]
    assert "<repo_owner>\ninfra\n</repo_owner>" in graph_call["user"]
    assert "<repo_name>\nsvc\n</repo_name>" in graph_call["user"]


async def test_pipeline_injects_azure_catalog_when_enabled() -> None:
    """include_azure_shapes=True injects the <shape_library> block on the graph step."""
    chat = FakeChat(["<explanation>x</explanation>", _fenced(_valid_graph_dict())])
    await run_repo_diagram_pipeline(
        chat,
        file_tree="a.py",
        readme="",
        namespace="g/p",
        include_azure_shapes=True,
    )
    assert "<shape_library>" in chat.calls[1]["user"]
    assert "azure/" in chat.calls[1]["user"]


async def test_pipeline_retries_when_first_graph_is_structurally_invalid() -> None:
    """An edge to an unknown node fails the validator → feedback → retry → ok."""
    invalid = {
        "groups": [],
        "nodes": [
            {
                "id": "api",
                "label": "API",
                "type": "t",
                "description": None,
                "groupId": None,
                "shape": None,
            }
        ],
        "edges": [
            {
                "from": "api",
                "to": "ghost",  # unknown target
                "label": None,
                "description": None,
                "style": None,
            }
        ],
    }
    chat = FakeChat(
        [
            "<explanation>x</explanation>",
            _fenced(invalid),  # attempt 1 → validator fails
            _fenced(_valid_graph_dict()),  # attempt 2 → ok
        ]
    )
    graph = await run_repo_diagram_pipeline(
        chat, file_tree="api/main.py", readme="", namespace="g/p"
    )
    assert isinstance(graph, DiagramGraph)
    assert len(chat.calls) == 3  # 1 explanation + 2 graph attempts
    # The retry carried the validation feedback (gitdiagram's loop).
    assert "<validation_feedback>" in chat.calls[2]["user"]


async def test_pipeline_validates_link_against_file_tree() -> None:
    """A node.link absent from the file tree fails validation (the repo-only check).

    This is the validator behaviour RepoGraph adds over Surface 1: a fabricated repo path is
    flagged (and retried), whereas the source pipeline passes ``set()`` so the check never
    fires.
    """
    bad_link = _valid_graph_dict(link="does/not/exist.py")
    good = _valid_graph_dict()  # no link → passes
    chat = FakeChat(
        [
            "<explanation>x</explanation>",
            _fenced(bad_link),  # link not in tree → validator fails
            _fenced(good),  # retry → ok
        ]
    )
    graph = await run_repo_diagram_pipeline(
        chat,
        file_tree="api/main.py\nstorage/db.py",  # 'does/not/exist.py' is NOT here
        readme="",
        namespace="g/p",
    )
    assert isinstance(graph, DiagramGraph)
    assert len(chat.calls) == 3
    # The feedback names the offending link (proves the file-tree lookup was used).
    assert "does/not/exist.py" in chat.calls[2]["user"]


async def test_pipeline_accepts_link_present_in_file_tree() -> None:
    """A node.link that IS a real repo path passes on the first attempt (no retry)."""
    chat = FakeChat(
        [
            "<explanation>x</explanation>",
            _fenced(_valid_graph_dict(link="api/main.py")),  # link in tree → ok
        ]
    )
    graph = await run_repo_diagram_pipeline(
        chat, file_tree="api/main.py\nstorage/db.py", readme="", namespace="g/p"
    )
    assert isinstance(graph, DiagramGraph)
    assert len(chat.calls) == 2  # no retry
    assert any(n.link == "api/main.py" for n in graph.nodes)


async def test_pipeline_strips_invalid_icon() -> None:
    """A malformed node.icon is nulled out before the graph is returned (agent.py reuse)."""
    chat = FakeChat(
        [
            "<explanation>x</explanation>",
            _fenced(_valid_graph_dict(icon="not-a-real-icon")),
        ]
    )
    graph = await run_repo_diagram_pipeline(
        chat, file_tree="a.py", readme="", namespace="g/p", include_azure_shapes=False
    )
    assert all(n.icon is None for n in graph.nodes)  # the bad icon was stripped


async def test_pipeline_rejects_empty_file_tree() -> None:
    """An empty repository tree → DiagramPipelineError (the defensive backstop)."""
    with pytest.raises(DiagramPipelineError):
        await run_repo_diagram_pipeline(
            FakeChat(["unused"]),
            file_tree="   ",
            readme="x",
            namespace="g/p",
        )


async def test_pipeline_raises_after_exhausting_attempts() -> None:
    """Persistent invalid graphs → DiagramPipelineError carrying the last feedback."""
    invalid = {
        "groups": [],
        "nodes": [
            {
                "id": "api",
                "label": "API",
                "type": "t",
                "description": None,
                "groupId": None,
                "shape": None,
            }
        ],
        "edges": [
            {
                "from": "api",
                "to": "ghost",
                "label": None,
                "description": None,
                "style": None,
            }
        ],
    }
    chat = FakeChat(
        ["<explanation>x</explanation>"] + [_fenced(invalid)] * 3  # 3 attempts all fail
    )
    with pytest.raises(DiagramPipelineError) as exc:
        await run_repo_diagram_pipeline(
            chat, file_tree="api/main.py", readme="", namespace="g/p"
        )
    assert exc.value.validation_feedback is not None


# =========================================================================== #
# HTTP seam — POST/GET /repograph, accept, error mapping.
# A table-aware, owner-scoped, RecordID-aware fake repo (the diagram table only).
# =========================================================================== #
def _id_eq(row_id: Any, want: Any) -> bool:
    a = ensure_record_id(str(row_id)) if not hasattr(row_id, "table_name") else row_id
    b = ensure_record_id(str(want)) if not hasattr(want, "table_name") else want
    return (a.table_name, str(a.id)) == (b.table_name, str(b.id))


class _ApiRepo:
    """Owner-scoped, RecordID-aware fake for the RepoGraph router's single ``diagram`` table.

    ``create_scoped`` returns a single-element LIST (exercises the store's unwrap);
    ``select_scoped`` applies the owner filter on ``focus=True`` reads and the
    ``surface``/``ref``/id var filters the store binds; ``query`` simulates
    ``scoped_update``'s ``UPDATE … RETURN AFTER`` (the persist + the accept demote-sibling
    write). Mirrors ``test_notebook_diagrams_api.py``'s ``_ApiRepo``.
    """

    def __init__(self, diagrams: list[dict[str, Any]] | None = None) -> None:
        self.tables: dict[str, list[dict[str, Any]]] = {"diagram": list(diagrams or [])}
        self.created: list[dict[str, Any]] = []
        self._counter = 0

    async def create_scoped(
        self, table: str, data: dict[str, Any], *, owner: str, scope: Any
    ) -> list[dict[str, Any]]:
        self._counter += 1
        row = {
            **data,
            "id": f"{table}:new{self._counter}",
            "owner": owner,
            "scope": scope.value,
        }
        self.created.append(row)
        self.tables.setdefault(table, []).append(row)
        return [row]

    async def select_scoped(
        self,
        table: str,
        principal: Principal,
        *,
        focus: bool = False,
        extra_where: str = "",
        order_by: str = "updated DESC",
        limit: int | None = None,
        vars: dict[str, Any] | None = None,
        notebook: Any = None,
    ) -> list[dict[str, Any]]:
        rows = list(self.tables.get(table, []))
        if focus:
            rows = [r for r in rows if r.get("owner") == principal.owner]
        v = vars or {}
        if "surface" in v:
            rows = [r for r in rows if r.get("surface") == v["surface"]]
        if "ref" in v:
            rows = [r for r in rows if r.get("ref") == v["ref"]]
        if "did" in v:
            rows = [r for r in rows if _id_eq(r.get("id"), v["did"])]
        if limit is not None:
            rows = rows[:limit]
        return rows

    async def query(
        self, query: str, vars: dict[str, Any] | None = None
    ) -> list[dict[str, Any]]:
        # scoped_update (UPDATE … RETURN AFTER): merge field vars into the owned row. The
        # accept-path demote (UPDATE … WHERE … id != $rid) no-ops here (no sibling in tests).
        v = vars or {}
        rid = v.get("rid")
        if rid is None:
            return []
        for table_rows in self.tables.values():
            for row in table_rows:
                if _id_eq(row.get("id"), rid) and row.get("owner") == v.get("owner"):
                    for key, value in v.items():
                        if key in ("rid", "owner", "surface", "ref"):
                            continue
                        row[key] = (
                            value.isoformat() if isinstance(value, datetime) else value
                        )
                    return [dict(row)]
        return []


class _FakeFetcher:
    """A fake ``GitLabService`` — returns scripted ``GitLabData`` or raises a scripted error.

    The router depends only on ``get_gitlab_data(repo_url) -> GitLabData`` and the service's
    typed errors, so a fake that returns data (happy path) or raises one of
    ``RepoConfigError`` / ``RepoNotFoundError`` / ``RepoFetchError`` / ``ValueError``
    fully exercises the router's error mapping without any HTTP.
    """

    def __init__(
        self, *, data: RepoData | None = None, error: Exception | None = None
    ) -> None:
        self._data = data
        self._error = error
        self.calls: list[str] = []

    async def fetch(self, repo_url: str) -> RepoData:
        self.calls.append(repo_url)
        if self._error is not None:
            raise self._error
        assert self._data is not None
        return self._data


def _gitlab_data() -> RepoData:
    return RepoData(
        provider="gitlab",
        default_branch="main",
        file_tree="api/main.py\nstorage/db.py",
        readme="# Svc",
        namespace="infra/svc",
    )


def _repograph_row(
    diagram_id: str,
    repo_url: str,
    graph_json: dict[str, Any],
    *,
    owner: str = "u1",
    status: str = "draft",
    surface: str = "repograph",
) -> dict[str, Any]:
    return {
        "id": diagram_id,
        "owner": owner,
        "scope": "private",
        "surface": surface,
        "ref": repo_url,
        "status": status,
        "graph_json": graph_json,
        "render_snapshot_svg": None,
        "version": 1,
    }


def _build_client(
    repo: _ApiRepo,
    *,
    gitlab: _FakeFetcher | None = None,
    chat: FakeChat | None = None,
    owner: str = "u1",
) -> TestClient:
    """A TestClient with repo + principal + chat + gitlab overridden (caller clears)."""
    from fastapi.testclient import TestClient

    from docx_app import deps
    from docx_app.main import app

    app.dependency_overrides[deps.get_principal] = lambda: Principal(owner=owner)
    app.dependency_overrides[deps.get_repository] = lambda: repo
    if chat is not None:
        app.dependency_overrides[deps.get_chat_client] = lambda: chat
    if gitlab is not None:
        app.dependency_overrides[deps.get_repo_fetcher] = lambda: gitlab
    return TestClient(app)


@pytest.fixture(autouse=True)
def _clear_overrides():  # type: ignore[no-untyped-def]
    """Always clear dependency overrides after each test (shared module-level app)."""
    yield
    from docx_app.main import app

    app.dependency_overrides.clear()


# --- POST /repograph — fetch → pipeline → persist ----------------------------- #


def test_generate_persists_repograph_diagram() -> None:
    """POST /repograph composes via the pipeline and persists a surface='repograph' draft."""
    repo = _ApiRepo()
    gitlab = _FakeFetcher(data=_gitlab_data())
    chat = FakeChat(
        [
            "<explanation>The API reads the DB.</explanation>",
            _fenced(_valid_graph_dict()),
        ]
    )
    client = _build_client(repo, gitlab=gitlab, chat=chat)

    resp = client.post(
        "/repograph",
        json={
            "repo_url": "https://gitlab.example.com/infra/svc",
            "include_azure_shapes": False,
        },
    )
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert body["surface"] == "repograph"
    assert body["status"] == "draft"
    assert body["repo_url"] == "https://gitlab.example.com/infra/svc"
    assert body["version"] == 1

    graph = body["graph"]
    assert graph is not None
    assert {n["id"] for n in graph["nodes"]} == {"api", "db"}
    assert "from" in graph["edges"][0]  # the renderer's wire form

    # It was fetched once and persisted as a surface='repograph' row.
    assert gitlab.calls == ["https://gitlab.example.com/infra/svc"]
    rg_rows = [r for r in repo.created if r.get("surface") == "repograph"]
    assert len(rg_rows) == 1
    assert rg_rows[0]["ref"] == "https://gitlab.example.com/infra/svc"


def test_generate_requires_repo_url() -> None:
    """A blank repo_url → 422 before any GitLab call."""
    gitlab = _FakeFetcher(data=_gitlab_data())
    client = _build_client(_ApiRepo(), gitlab=gitlab, chat=FakeChat([]))
    resp = client.post("/repograph", json={"repo_url": "   "})
    assert resp.status_code == 422
    assert gitlab.calls == []  # never reached GitLab


def test_generate_loads_back_via_get() -> None:
    """After generate, GET /repograph/{id} returns the same persisted diagram."""
    repo = _ApiRepo()
    client = _build_client(
        repo,
        gitlab=_FakeFetcher(data=_gitlab_data()),
        chat=FakeChat(["<explanation>x</explanation>", _fenced(_valid_graph_dict())]),
    )
    created = client.post(
        "/repograph",
        json={
            "repo_url": "https://gitlab.example.com/infra/svc",
            "include_azure_shapes": False,
        },
    )
    assert created.status_code == 200
    diagram_id = created.json()["id"]

    loaded = client.get(f"/repograph/{diagram_id}")
    assert loaded.status_code == 200
    assert loaded.json()["graph"] == created.json()["graph"]


def test_generate_after_accept_opens_new_version() -> None:
    """Regenerating for a repo whose current diagram is accepted starts a new draft version."""
    accepted = _repograph_row(
        "diagram:1",
        "https://gitlab.example.com/infra/svc",
        _valid_graph_dict(),
        status="accepted",
    )
    accepted["version"] = 2
    repo = _ApiRepo(diagrams=[accepted])
    client = _build_client(
        repo,
        gitlab=_FakeFetcher(data=_gitlab_data()),
        chat=FakeChat(["<explanation>x</explanation>", _fenced(_valid_graph_dict())]),
    )
    resp = client.post(
        "/repograph",
        json={
            "repo_url": "https://gitlab.example.com/infra/svc",
            "include_azure_shapes": False,
        },
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["status"] == "draft"  # a fresh draft, not the frozen accepted row
    assert body["version"] == 3  # version continues from the accepted parent


# --- GET /repograph (list) ---------------------------------------------------- #


def test_list_returns_owner_repographs() -> None:
    """GET /repograph lists the caller's repograph diagrams (and nothing else)."""
    repo = _ApiRepo(
        diagrams=[
            _repograph_row("diagram:1", "https://gl/infra/a", _valid_graph_dict()),
            _repograph_row("diagram:2", "https://gl/infra/b", _valid_graph_dict()),
            # A non-repograph surface and another owner's row must be excluded.
            _repograph_row(
                "diagram:3", "source:1", _valid_graph_dict(), surface="source"
            ),
            _repograph_row(
                "diagram:4", "https://gl/infra/c", _valid_graph_dict(), owner="u2"
            ),
        ]
    )
    client = _build_client(repo, owner="u1")
    resp = client.get("/repograph")
    assert resp.status_code == 200
    body = resp.json()
    refs = {d["repo_url"] for d in body}
    assert refs == {"https://gl/infra/a", "https://gl/infra/b"}
    assert all(d["surface"] == "repograph" for d in body)


def test_list_empty_when_none() -> None:
    client = _build_client(_ApiRepo(), owner="u1")
    resp = client.get("/repograph")
    assert resp.status_code == 200
    assert resp.json() == []


# --- GET /repograph/{id} ------------------------------------------------------ #


def test_get_404_for_other_owner() -> None:
    """A repograph diagram owned by u2 is not readable by u1 (owner isolation)."""
    repo = _ApiRepo(
        diagrams=[
            _repograph_row("diagram:1", "https://gl/x", _valid_graph_dict(), owner="u2")
        ]
    )
    client = _build_client(repo, owner="u1")
    resp = client.get("/repograph/diagram:1")
    assert resp.status_code == 404


def test_get_404_for_non_repograph_surface() -> None:
    """An id that is a *source* diagram is not served by the repograph GET (surface guard)."""
    repo = _ApiRepo(
        diagrams=[
            _repograph_row(
                "diagram:1", "source:1", _valid_graph_dict(), surface="source"
            )
        ]
    )
    client = _build_client(repo, owner="u1")
    resp = client.get("/repograph/diagram:1")
    assert resp.status_code == 404


# --- POST /repograph/{id}/accept --------------------------------------------- #


def test_accept_freezes_data_and_picture() -> None:
    """Accept stamps accepted + snapshots an SVG (DATA + PICTURE, design §2)."""
    repo = _ApiRepo(
        diagrams=[
            _repograph_row("diagram:1", "https://gl/infra/svc", _valid_graph_dict())
        ]
    )
    client = _build_client(repo, owner="u1")
    resp = client.post("/repograph/diagram:1/accept", json={})
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert body["status"] == "accepted"
    svg = body["render_snapshot_svg"]
    assert svg is not None
    assert "<svg" in svg and svg.rstrip().endswith("</svg>")
    assert "animateMotion" not in svg  # the accepted snapshot is STATIC


def test_accept_404_for_non_repograph_surface() -> None:
    repo = _ApiRepo(
        diagrams=[
            _repograph_row(
                "diagram:1", "source:1", _valid_graph_dict(), surface="source"
            )
        ]
    )
    client = _build_client(repo, owner="u1")
    resp = client.post("/repograph/diagram:1/accept", json={})
    assert resp.status_code == 404


# --- GitLab error mapping (503 / 404 / 502 / 422) ----------------------------- #


def test_generate_503_when_gitlab_not_configured() -> None:
    """An unconfigured GitLab (empty base URL) → 503 (feature disabled)."""
    gitlab = _FakeFetcher(error=RepoConfigError("gitlab_base_url is empty"))
    client = _build_client(_ApiRepo(), gitlab=gitlab, chat=FakeChat([]))
    resp = client.post("/repograph", json={"repo_url": "https://gl/x/y"})
    assert resp.status_code == 503
    assert "not configured" in resp.json()["detail"]


def test_generate_404_when_project_not_found() -> None:
    gitlab = _FakeFetcher(error=RepoNotFoundError("GitLab 404"))
    client = _build_client(_ApiRepo(), gitlab=gitlab, chat=FakeChat([]))
    resp = client.post("/repograph", json={"repo_url": "https://gl/x/y"})
    assert resp.status_code == 404


def test_generate_502_on_upstream_gitlab_failure() -> None:
    gitlab = _FakeFetcher(error=RepoFetchError("GitLab request failed (500)"))
    client = _build_client(_ApiRepo(), gitlab=gitlab, chat=FakeChat([]))
    resp = client.post("/repograph", json={"repo_url": "https://gl/x/y"})
    assert resp.status_code == 502


def test_generate_422_on_bad_repo_url_or_too_large() -> None:
    """A ValueError from the service (bad URL / tree over cap) → 422."""
    gitlab = _FakeFetcher(
        error=ValueError("repo_url does not start with gitlab_base_url")
    )
    client = _build_client(_ApiRepo(), gitlab=gitlab, chat=FakeChat([]))
    resp = client.post("/repograph", json={"repo_url": "https://other/x/y"})
    assert resp.status_code == 422


def test_generate_502_when_pipeline_fails() -> None:
    """A DiagramPipelineError (model can't produce a valid graph) → 502."""
    gitlab = _FakeFetcher(data=_gitlab_data())
    # Explanation ok, but every graph attempt is unparseable → pipeline raises.
    chat = FakeChat(
        ["<explanation>x</explanation>", "no json here", "still none", "nope"]
    )
    client = _build_client(_ApiRepo(), gitlab=gitlab, chat=chat)
    resp = client.post(
        "/repograph",
        json={"repo_url": "https://gl/infra/svc", "include_azure_shapes": False},
    )
    assert resp.status_code == 502
    assert "diagram generation failed" in resp.json()["detail"]
