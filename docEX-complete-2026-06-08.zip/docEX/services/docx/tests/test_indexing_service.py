"""IndexingService — chunk → embed → store, scoped to the source's owner."""

from docx_app.domain.source import Source
from docx_app.indexing.service import IndexingService
from docx_app.tenancy import Scope


class FakeEmbedder:
    def __init__(self):
        self.seen = None

    async def embed(self, texts):
        self.seen = list(texts)
        return [[float(i)] for i, _ in enumerate(texts)]


class FakeRepo:
    def __init__(self):
        self.inserted = None
        self.updated = None

    async def delete_where(self, table, where, vars=None):
        pass

    async def insert_scoped(self, table, rows, *, owner, scope):
        self.inserted = {"rows": rows, "owner": owner, "scope": scope}
        return len(rows)

    async def query(self, query_str, vars=None):
        self.updated = vars  # the owner-scoped chunk_count UPDATE
        return []


def _svc(repo, emb):
    return IndexingService(repo, emb, chunk_size=1600, overlap=240)


async def test_index_source_chunks_embeds_and_stores_with_owner_scope():
    repo, emb = FakeRepo(), FakeEmbedder()
    src = Source(
        id="source:1",
        full_text="# Heading\n\nSome body text.",
        owner="u1",
        scope="private",
    )
    n = await _svc(repo, emb).index_source(src)

    assert n >= 1
    assert emb.seen is not None and len(emb.seen) == n  # every chunk embedded
    assert repo.inserted["owner"] == "u1"
    assert repo.inserted["scope"] == Scope.PRIVATE  # inherited from the source
    assert (
        repo.updated and repo.updated.get("chunk_count") == n
    )  # persisted to source row


async def test_index_source_blank_text_is_noop():
    repo, emb = FakeRepo(), FakeEmbedder()
    src = Source(id="source:1", full_text="   ", owner="u1", scope="org-common")
    assert await _svc(repo, emb).index_source(src) == 0
    assert emb.seen is None  # never called the embedder
    assert repo.inserted is None


async def test_index_source_missing_scope_fails_closed_to_private():
    repo, emb = FakeRepo(), FakeEmbedder()
    src = Source(id="source:1", full_text="plain body", owner="u1")  # no scope set
    await _svc(repo, emb).index_source(src)
    # never silently widen to the shared brain — fail closed to the narrowest scope
    assert repo.inserted["scope"] == Scope.PRIVATE
