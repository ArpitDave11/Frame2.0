"""Diagram platform — Surface 1 (Source Diagram tab) tests.

Covers the casualties of the (hung) workflow Verify phase:
  * DiagramStore — owner tenancy, draft/accept immutability + snapshot, version
    bump, and the SurrealDB ``create_scoped`` single-element-list unwrap.
  * The 2-step pipeline (``run_diagram_pipeline``) with a fake LLM — happy path
    and the gitdiagram validate-and-retry loop.
  * The defensive fenced-JSON parser (the flakiest local-path surface).
  * The graph validator + the static SVG snapshot renderer.

Style mirrors the rest of the suite: a ``FakeRepo`` (no real DB), ``asyncio_mode
= "auto"`` (no per-test marker needed). All deterministic — no network.
"""

from __future__ import annotations

import json
from datetime import datetime
from typing import TYPE_CHECKING, Any

import pytest

if TYPE_CHECKING:
    from fastapi.testclient import TestClient

from docx_app.diagram.agent import (
    DiagramPipelineError,
    _JsonExtractionError,
    parse_graph_json,
    run_diagram_pipeline,
)
from docx_app.diagram.domain import Diagram, DiagramStore
from docx_app.diagram.model import DiagramGraph, validate_diagram_graph
from docx_app.diagram.render_svg import render_snapshot_svg
from docx_app.tenancy import Principal, Scope


# --------------------------------------------------------------------------- #
# Fixtures / helpers
# --------------------------------------------------------------------------- #
def valid_graph_dict() -> dict[str, Any]:
    """A minimal, schema-valid graph (edges keyed by ``"from"``, as stored).

    Every gitdiagram-core field is present (they are required-but-nullable), plus
    the DocEX edge extensions ``animated``/``flow``.
    """
    return {
        "groups": [],
        "nodes": [
            {"id": "a", "label": "A", "type": "service",
             "description": None, "groupId": None, "shape": None},
            {"id": "b", "label": "B", "type": "database",
             "description": None, "groupId": None, "shape": "database"},
        ],
        "edges": [
            {"from": "a", "to": "b", "label": "writes",
             "description": None, "style": None, "animated": True, "flow": "write"},
        ],
    }


def valid_graph() -> DiagramGraph:
    return DiagramGraph.model_validate(valid_graph_dict())


def _row(**over: Any) -> dict[str, Any]:
    """A stored diagram row (what select_scoped returns), overridable per test."""
    base: dict[str, Any] = {
        "id": "diagram:1",
        "owner": "u1",
        "scope": "private",
        "surface": "source",
        "ref": "source:1",
        "status": "draft",
        "graph_json": valid_graph_dict(),
        "render_snapshot_svg": None,
        "version": 1,
    }
    base.update(over)
    return base


class FakeRepo:
    """Stateful enough to exercise tenancy + the update/accept write path.

    * ``create_scoped`` returns a SINGLE-element LIST (``[{...}]``) — exactly the
      Surreal shape the store must unwrap; if the store forgot, ``Diagram(**list)``
      would raise here.
    * ``select_scoped`` returns seeded rows, owner-filtered when ``owner_enforce``
      (so a cross-owner read yields nothing → ``None``).
    * ``query`` simulates ``scoped_update``'s ``UPDATE ... RETURN AFTER`` by merging
      the bound field vars into the seeded row.
    """

    def __init__(self, rows: list[dict[str, Any]] | None = None,
                 owner_enforce: bool = False) -> None:
        self.rows = rows or []
        self.owner_enforce = owner_enforce
        self.created: list[dict[str, Any]] = []
        self.selects: list[dict[str, Any]] = []
        self.queries: list[dict[str, Any]] = []
        self.deletes: list[dict[str, Any]] = []

    async def create_scoped(self, table: str, data: dict[str, Any], *,
                            owner: str, scope: Scope) -> list[dict[str, Any]]:
        self.created.append({"data": data, "owner": owner, "scope": scope})
        row = {**data, "id": f"{table}:new", "owner": owner, "scope": scope.value}
        return [row]  # LIST — the store must unwrap before Diagram(**row)

    async def select_scoped(self, table: str, principal: Principal, *,
                            focus: bool = False, extra_where: str = "",
                            order_by: str = "updated DESC", limit: int | None = None,
                            vars: dict[str, Any] | None = None,
                            notebook: Any = None) -> list[dict[str, Any]]:
        self.selects.append({"focus": focus, "extra_where": extra_where, "vars": vars})
        rows = self.rows
        if self.owner_enforce and focus:
            rows = [r for r in rows if r.get("owner") == principal.owner]
        return rows

    async def query(self, query: str, vars: dict[str, Any] | None = None
                    ) -> list[dict[str, Any]]:
        self.queries.append({"query": query, "vars": vars})
        if not self.rows:
            return []
        updated = {**self.rows[0]}
        for key, value in (vars or {}).items():
            if key in ("rid", "owner"):
                continue
            # Mirror the real repo: db.query() runs results through parse_record_ids,
            # so datetimes come back as ISO strings (Diagram.updated is str | None).
            updated[key] = value.isoformat() if isinstance(value, datetime) else value
        return [updated]

    async def delete_where(self, table: str, where: str,
                           vars: dict[str, Any] | None = None) -> None:
        self.deletes.append({"where": where, "vars": vars})


P = Principal(owner="u1")


# --------------------------------------------------------------------------- #
# DiagramStore — tenancy, immutability, the list-unwrap gotcha
# --------------------------------------------------------------------------- #
async def test_create_stamps_owner_private_and_version_one() -> None:
    repo = FakeRepo()
    diagram = await DiagramStore(repo).create(
        owner="u1", surface="source", ref="source:1", graph=valid_graph()
    )
    assert isinstance(diagram, Diagram)  # LIST return was unwrapped, not crashed
    created = repo.created[0]
    assert created["owner"] == "u1"
    assert created["scope"] is Scope.PRIVATE          # diagrams are owner-PRIVATE
    assert created["data"]["status"] == "draft"
    assert created["data"]["version"] == 1
    assert created["data"]["render_snapshot_svg"] is None
    # graph persisted with the "from" edge alias (NOT "from_")
    assert "from" in created["data"]["graph_json"]["edges"][0]


async def test_list_is_owner_scoped_and_subject_filtered() -> None:
    repo = FakeRepo(rows=[_row()])
    out = await DiagramStore(repo).list(P, surface="source", ref="source:1")
    assert len(out) == 1 and isinstance(out[0], Diagram)
    sel = repo.selects[0]
    assert sel["focus"] is True                         # owner-private read
    assert sel["vars"] == {"surface": "source", "ref": "source:1"}


async def test_update_graph_bumps_version_on_a_draft() -> None:
    repo = FakeRepo(rows=[_row(status="draft", version=1)])
    three_node = DiagramGraph.model_validate({
        "groups": [],
        "nodes": [
            {"id": "a", "label": "A", "type": "t",
             "description": None, "groupId": None, "shape": None},
            {"id": "b", "label": "B", "type": "t",
             "description": None, "groupId": None, "shape": None},
            {"id": "c", "label": "C", "type": "t",
             "description": None, "groupId": None, "shape": None},
        ],
        "edges": [],
    })
    out = await DiagramStore(repo).update_graph("diagram:1", P, graph=three_node)
    assert out is not None
    assert out.version == 2                              # bumped
    assert out.graph() is not None and len(out.graph().nodes) == 3  # replaced
    assert len(repo.queries) == 1                        # a scoped UPDATE happened


async def test_update_graph_refuses_to_mutate_an_accepted_diagram() -> None:
    repo = FakeRepo(rows=[_row(status="accepted", version=2)])
    out = await DiagramStore(repo).update_graph("diagram:1", P, graph=valid_graph())
    assert out is not None and out.status == "accepted"
    assert repo.queries == []                            # frozen — no UPDATE issued


async def test_accept_freezes_status_and_stores_svg_snapshot() -> None:
    repo = FakeRepo(rows=[_row(status="draft")])
    out = await DiagramStore(repo).accept(
        "diagram:1", P, render_snapshot_svg="<svg>frozen</svg>", graph=valid_graph()
    )
    assert out is not None
    assert out.status == "accepted"                      # DATA frozen
    assert out.render_snapshot_svg == "<svg>frozen</svg>"  # PICTURE frozen


async def test_accept_demotes_prior_accepted_sibling() -> None:
    repo = FakeRepo(rows=[_row(status="draft")])
    await DiagramStore(repo).accept(
        "diagram:1", P, render_snapshot_svg="<svg/>", graph=valid_graph()
    )
    demote = [q for q in repo.queries if "superseded" in q["query"]]
    assert demote, "accept must demote any previously-accepted sibling"
    assert "id != $rid" in demote[0]["query"]
    assert demote[0]["vars"]["surface"] == "source"


async def test_new_version_opens_a_fresh_draft_from_accepted() -> None:
    repo = FakeRepo(rows=[_row(status="accepted", version=2)])
    out = await DiagramStore(repo).new_version("diagram:1", P, graph=valid_graph())
    assert out is not None
    data = repo.created[-1]["data"]
    assert data["status"] == "draft"                     # a NEW editable draft
    assert data["version"] == 3                           # version continues
    assert data["render_snapshot_svg"] is None            # snapshot cleared


async def test_get_is_owner_isolated() -> None:
    repo = FakeRepo(rows=[_row(owner="u1")], owner_enforce=True)
    assert await DiagramStore(repo).get("diagram:1", Principal(owner="u1")) is not None
    # another owner can never read it — the owner predicate yields nothing.
    assert await DiagramStore(repo).get("diagram:1", Principal(owner="u2")) is None


async def test_delete_is_owner_scoped() -> None:
    repo = FakeRepo(rows=[_row(owner="u1")], owner_enforce=True)
    assert await DiagramStore(repo).delete("diagram:1", Principal(owner="u1")) is True
    assert "owner = $owner" in repo.deletes[0]["where"]
    # not the caller's → refused, no delete issued.
    repo2 = FakeRepo(rows=[_row(owner="u1")], owner_enforce=True)
    assert await DiagramStore(repo2).delete("diagram:1", Principal(owner="u2")) is False
    assert repo2.deletes == []


# --------------------------------------------------------------------------- #
# Graph model + validator
# --------------------------------------------------------------------------- #
def test_validator_passes_a_clean_graph() -> None:
    assert validate_diagram_graph(valid_graph(), set()) == []


def test_validator_flags_edge_to_unknown_node() -> None:
    graph = DiagramGraph.model_validate({
        "groups": [],
        "nodes": [{"id": "a", "label": "A", "type": "t",
                   "description": None, "groupId": None, "shape": None}],
        "edges": [{"from": "a", "to": "zzz", "label": None,
                   "description": None, "style": None}],
    })
    issues = validate_diagram_graph(graph, set())
    assert any("zzz" in i.message for i in issues)


def test_edge_from_alias_round_trips() -> None:
    graph = valid_graph()
    assert graph.edges[0].from_ == "a"                   # "from" → from_
    assert graph.model_dump(by_alias=True)["edges"][0]["from"] == "a"  # back to "from"


# --------------------------------------------------------------------------- #
# Pipeline (fake LLM) — happy path + validate/retry loop
# --------------------------------------------------------------------------- #
class FakeChat:
    """Scripted ``ChatClient`` — returns queued strings in order."""

    def __init__(self, responses: list[str]) -> None:
        self._responses = list(responses)
        self.calls: list[dict[str, str]] = []

    async def complete(self, *, system: str, user: str, max_tokens: int = 1000) -> str:
        self.calls.append({"system": system, "user": user})
        return self._responses.pop(0)


async def test_pipeline_happy_path_returns_validated_graph() -> None:
    chat = FakeChat([
        "<explanation>A writes to B.</explanation>",
        "Here is the diagram:\n\n```json\n" + json.dumps(valid_graph_dict()) + "\n```\n",
    ])
    graph = await run_diagram_pipeline(
        chat, source_title="Doc", source_text="A writes to B.",
        include_azure_shapes=False,
    )
    assert isinstance(graph, DiagramGraph)
    assert {n.id for n in graph.nodes} == {"a", "b"}
    assert graph.edges[0].from_ == "a"                   # alias mapped through
    assert len(chat.calls) == 2                          # explanation + 1 graph step


async def test_pipeline_retries_when_first_graph_is_structurally_invalid() -> None:
    invalid = {
        "groups": [],
        "nodes": [{"id": "a", "label": "A", "type": "t",
                   "description": None, "groupId": None, "shape": None}],
        "edges": [{"from": "a", "to": "ghost", "label": None,
                   "description": None, "style": None}],   # edge to unknown node
    }
    chat = FakeChat([
        "<explanation>x</explanation>",
        "```json\n" + json.dumps(invalid) + "\n```",       # attempt 1 → validator fails
        "```json\n" + json.dumps(valid_graph_dict()) + "\n```",  # attempt 2 → ok
    ])
    graph = await run_diagram_pipeline(
        chat, source_title=None, source_text="doc", include_azure_shapes=False
    )
    assert isinstance(graph, DiagramGraph)
    assert len(chat.calls) == 3                          # 1 explanation + 2 graph attempts


async def test_pipeline_rejects_empty_document_text() -> None:
    with pytest.raises(DiagramPipelineError):
        await run_diagram_pipeline(
            FakeChat(["unused"]), source_title=None, source_text="   ",
            include_azure_shapes=False,
        )


# --------------------------------------------------------------------------- #
# Defensive fenced-JSON parser (the flakiest local-path surface)
# --------------------------------------------------------------------------- #
def test_parser_handles_fenced_json_with_surrounding_prose() -> None:
    raw = "Sure! Here you go:\n\n```json\n" + json.dumps(valid_graph_dict()) + "\n```\nEnjoy."
    assert isinstance(parse_graph_json(raw), DiagramGraph)


def test_parser_repairs_trailing_comma() -> None:
    raw = (
        '{"groups": [], "nodes": [{"id": "a", "label": "A", "type": "t", '
        '"description": null, "groupId": null, "shape": null},], "edges": []}'  # trailing comma
    )
    graph = parse_graph_json(raw)
    assert len(graph.nodes) == 1


def test_parser_repairs_smart_quotes() -> None:
    weird = json.dumps(valid_graph_dict()).replace('"', "“")  # all → left-double quote
    assert isinstance(parse_graph_json(weird), DiagramGraph)


def test_parser_extracts_bare_braces_amid_prose() -> None:
    raw = "noise before " + json.dumps(valid_graph_dict()) + " noise after"
    assert isinstance(parse_graph_json(raw), DiagramGraph)


def test_parser_raises_when_no_json_present() -> None:
    with pytest.raises(_JsonExtractionError):
        parse_graph_json("Sorry, I can't produce a diagram for that.")


# --------------------------------------------------------------------------- #
# Static SVG snapshot renderer (the accepted "picture")
# --------------------------------------------------------------------------- #
def test_snapshot_is_static_self_contained_svg() -> None:
    svg = render_snapshot_svg(valid_graph(), title="My Document")
    assert svg.lstrip().startswith("<?xml")
    assert "<svg" in svg
    assert "animateMotion" not in svg                    # accepted snapshot is STATIC
    assert "My Document" in svg                           # caption rendered
    assert ">A<" in svg                                   # node label present


def test_snapshot_is_deterministic() -> None:
    g = valid_graph()
    assert render_snapshot_svg(g, title="T") == render_snapshot_svg(g, title="T")


# --------------------------------------------------------------------------- #
# Export endpoint — GET /sources/{id}/diagram/export?format=drawio|mermaid
#
# Exercises the real FastAPI route (query-param parsing, owner scoping, the
# format→exporter dispatch, and the response content type) via a TestClient with
# dependency overrides — the same style as test_sources_api.py. A table-aware fake
# is needed here because the route reads TWO tables: ``source`` (SourceStore.get,
# the owner check) then ``diagram`` (DiagramStore.list, the current diagram).
# --------------------------------------------------------------------------- #
class _TableRepo:
    """Owner-scoped fake repo that returns rows per table (``source`` vs ``diagram``).

    The single-table ``FakeRepo`` above returns the same rows for every table, which
    would feed a diagram row into ``SourceStore.get``; this keys ``select_scoped`` on
    the table name so the export route's two reads resolve correctly. Reads are
    owner-filtered (a cross-owner caller sees nothing → 404).
    """

    def __init__(self, table_rows: dict[str, list[dict[str, Any]]]) -> None:
        self.table_rows = table_rows

    async def select_scoped(
        self,
        table: str,
        principal: Principal,
        *,
        focus: bool = False,
        extra_where: str = "",
        order_by: str = "updated DESC",
        limit: int | None = None,
        vars: dict[str, Any] | None = None,
        notebook: Any = None,
    ) -> list[dict[str, Any]]:
        rows = self.table_rows.get(table, [])
        if focus:  # owner-private reads (both source.get and diagram.list use focus)
            rows = [r for r in rows if r.get("owner") == principal.owner]
        return rows


def _export_client(
    table_rows: dict[str, list[dict[str, Any]]], owner: str = "u1"
) -> tuple[TestClient, _TableRepo]:
    """A TestClient with the repo + principal overridden (caller closes via teardown)."""
    from fastapi.testclient import TestClient

    from docx_app import deps
    from docx_app.main import app

    repo = _TableRepo(table_rows)
    app.dependency_overrides[deps.get_principal] = lambda: Principal(owner=owner)
    app.dependency_overrides[deps.get_repository] = lambda: repo
    return TestClient(app), repo


@pytest.fixture
def export_ctx():  # type: ignore[no-untyped-def]
    """One owned source with one current (draft) diagram, ready to export."""
    from docx_app import deps
    from docx_app.main import app

    source_row = {"id": "source:1", "owner": "u1", "title": "My Document",
                  "full_text": "A writes to B."}
    diagram_row = _row(id="diagram:1", owner="u1", ref="source:1")
    client, repo = _export_client(
        {"source": [source_row], "diagram": [diagram_row]}
    )
    yield client
    app.dependency_overrides.clear()
    _ = (deps, app)  # keep imports referenced for the linter


def test_export_drawio_returns_mxgraph_xml(export_ctx) -> None:  # type: ignore[no-untyped-def]
    resp = export_ctx.get("/sources/source:1/diagram/export", params={"format": "drawio"})
    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("application/xml")
    body = resp.text
    assert body.startswith("<mxfile")               # the draw.io document root
    assert "</mxfile>" in body
    assert 'value="A"' in body                        # node A made it into the export
    # the suggested download filename is sanitised (no ':' from the source id)
    assert 'filename="diagram-source_1.drawio"' in resp.headers["content-disposition"]


def test_export_mermaid_returns_flowchart_text(export_ctx) -> None:  # type: ignore[no-untyped-def]
    resp = export_ctx.get("/sources/source:1/diagram/export", params={"format": "mermaid"})
    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("text/plain")
    body = resp.text
    assert body.startswith("flowchart TD")            # the Mermaid flowchart header
    assert "node_a" in body and "node_b" in body      # both nodes rendered
    assert "-->" in body                              # the a→b edge
    assert resp.headers["content-disposition"].endswith('.mmd"')


def test_export_unknown_format_is_400(export_ctx) -> None:  # type: ignore[no-untyped-def]
    resp = export_ctx.get("/sources/source:1/diagram/export", params={"format": "pdf"})
    assert resp.status_code == 400
    detail = resp.json()["detail"]
    assert "pdf" in detail and "drawio" in detail and "mermaid" in detail


def test_export_defaults_to_drawio_when_format_omitted(export_ctx) -> None:  # type: ignore[no-untyped-def]
    resp = export_ctx.get("/sources/source:1/diagram/export")
    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("application/xml")
    assert resp.text.startswith("<mxfile")


def test_export_404_when_source_has_no_diagram() -> None:
    # Source is owned, but it has no diagram row → 404 (the empty-tab state).
    from docx_app import deps
    from docx_app.main import app

    client, _ = _export_client(
        {"source": [{"id": "source:1", "owner": "u1", "title": "T",
                     "full_text": "x"}], "diagram": []}
    )
    try:
        resp = client.get("/sources/source:1/diagram/export", params={"format": "drawio"})
        assert resp.status_code == 404
    finally:
        app.dependency_overrides.clear()
        _ = deps


def test_export_404_when_source_not_owned() -> None:
    # The source belongs to u2; u1 must not be able to export it (owner isolation).
    from docx_app import deps
    from docx_app.main import app

    client, _ = _export_client(
        {"source": [{"id": "source:1", "owner": "u2", "title": "T",
                     "full_text": "x"}],
         "diagram": [_row(id="diagram:1", owner="u2", ref="source:1")]},
        owner="u1",
    )
    try:
        resp = client.get("/sources/source:1/diagram/export", params={"format": "drawio"})
        assert resp.status_code == 404
    finally:
        app.dependency_overrides.clear()
        _ = deps
