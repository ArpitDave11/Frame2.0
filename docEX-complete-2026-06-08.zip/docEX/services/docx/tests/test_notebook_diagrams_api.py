"""Notebook-HLD API tests — the ``POST /notebooks/{id}/diagram/build`` verb (Surface 2).

Exercises the real FastAPI routes in :mod:`docx_app.api.notebook_diagrams` end-to-end via a
``TestClient`` with dependency overrides (the same style as ``test_diagram.py``'s export-route
tests), against a table-aware, owner-scoped, RecordID-aware fake repo (the same shape as
``test_compose.py``'s ``ComposeRepo``). The compose/reconciler internals are unit-tested in
``test_compose.py`` / ``test_entity_reconciler.py``; this file proves the *HTTP seam* — that
``/diagram/build`` composes the notebook's accepted source diagrams into a persisted
``surface='notebook'`` :class:`~docx_app.diagram.domain.Diagram`, owner-scoped, and loads back
via ``GET /diagram`` — and that ``/build`` is an exact alias of ``/rebuild`` (design §6).

The build route reads four tables (``notebook`` for the owner check, ``diagram`` for the
accepted source LLDs, ``source`` for notebook membership, ``notebook_entity`` for the registry)
and writes the HLD ``diagram`` row, so the fake is table-aware. Deterministic, no network — the
controlled-vocab ``node.entity`` keys make the path LLM-free, so ``get_chat_client`` is overridden
to a fake that is never called and ``get_embedder`` to the local lexical embedder.
"""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Any

import pytest

if TYPE_CHECKING:
    from fastapi.testclient import TestClient

from docx_app.db import ensure_record_id
from docx_app.tenancy import Principal


# --------------------------------------------------------------------------- #
# RecordID-aware id equality (the stores bind ``ensure_record_id(...)`` as the var) —
# identical to test_compose.py / test_entity_reconciler.py.
# --------------------------------------------------------------------------- #
def _id_eq(row_id: Any, want: Any) -> bool:
    a = ensure_record_id(str(row_id)) if not hasattr(row_id, "table_name") else row_id
    b = ensure_record_id(str(want)) if not hasattr(want, "table_name") else want
    return (a.table_name, str(a.id)) == (b.table_name, str(b.id))


def _source_graph(nodes: list[dict[str, Any]]) -> dict[str, Any]:
    """A stored graph_json dict (every required DiagramGraph field set)."""
    full_nodes = [
        {
            "id": n["id"],
            "label": n.get("label", n["id"].title()),
            "type": n.get("type", "service"),
            "description": n.get("description"),
            "groupId": None,
            "shape": n.get("shape"),
            "icon": None,
            "link": None,
            "drill": None,
            "entity": n.get("entity"),
            "meta": n.get("meta"),
        }
        for n in nodes
    ]
    return {"groups": [], "nodes": full_nodes, "edges": []}


def _diagram_row(
    diagram_id: str,
    source_ref: str,
    graph_json: dict[str, Any],
    *,
    owner: str = "u1",
    status: str = "accepted",
) -> dict[str, Any]:
    return {
        "id": diagram_id,
        "owner": owner,
        "scope": "private",
        "surface": "source",
        "ref": source_ref,
        "status": status,
        "graph_json": graph_json,
        "render_snapshot_svg": None,
        "version": 1,
    }


def _source_row(source_id: str, notebook_id: str, *, owner: str = "u1") -> dict[str, Any]:
    return {
        "id": source_id,
        "owner": owner,
        "scope": "private",
        "notebook": notebook_id,
        "title": source_id.split(":", 1)[-1].title(),
    }


def _notebook_row(notebook_id: str, *, owner: str = "u1") -> dict[str, Any]:
    return {
        "id": notebook_id,
        "owner": owner,
        "scope": "private",
        "name": "My Notebook",
        "archived": False,
    }


def _entity_row(
    entity_id: str,
    notebook_id: str,
    entity_key: str,
    canonical_label: str,
    source_refs: list[str],
    *,
    owner: str = "u1",
) -> dict[str, Any]:
    return {
        "id": entity_id,
        "owner": owner,
        "scope": "private",
        "notebook_id": notebook_id,
        "entity_key": entity_key,
        "canonical_label": canonical_label,
        "aliases": [],
        "source_refs": source_refs,
        "locked": False,
    }


class _ApiRepo:
    """Table-aware, owner-scoped, RecordID-aware fake for the HLD API's four tables.

    * ``notebook`` — served on ``id`` (NotebookStore.get, the owner check).
    * ``diagram``  — served on ``surface``/``ref``/``id`` (accepted source LLDs + the HLD write).
    * ``source``   — served on ``id`` (notebook-membership check via SourceStore.get).
    * ``notebook_entity`` — served on ``notebook_id``/``entity_key``/``id`` (the registry).

    ``create_scoped`` returns a single-element LIST (exercises the store's unwrap);
    ``select_scoped`` applies the owner filter on ``focus=True`` reads; ``query`` simulates
    ``scoped_update``'s ``UPDATE … RETURN AFTER`` (used by the HLD persist + the demote-sibling
    write on accept). Mirrors ``test_compose.py``'s ``ComposeRepo`` + ``test_diagram.py``'s
    ``FakeRepo`` so behaviour matches the unit suites.
    """

    def __init__(
        self,
        *,
        notebooks: list[dict[str, Any]] | None = None,
        diagrams: list[dict[str, Any]] | None = None,
        sources: list[dict[str, Any]] | None = None,
        entities: list[dict[str, Any]] | None = None,
    ) -> None:
        self.tables: dict[str, list[dict[str, Any]]] = {
            "notebook": list(notebooks or []),
            "diagram": list(diagrams or []),
            "source": list(sources or []),
            "notebook_entity": list(entities or []),
        }
        self.created: list[dict[str, Any]] = []
        self._counter = 0

    async def create_scoped(
        self, table: str, data: dict[str, Any], *, owner: str, scope: Any
    ) -> list[dict[str, Any]]:
        self._counter += 1
        row = {
            **data,
            "id": f"{table}:new{self._counter}",
            "owner": owner,
            "scope": scope.value,
        }
        self.created.append(row)
        self.tables.setdefault(table, []).append(row)
        return [row]

    async def select_scoped(
        self,
        table: str,
        principal: Principal,
        *,
        focus: bool = False,
        extra_where: str = "",
        order_by: str = "updated DESC",
        limit: int | None = None,
        vars: dict[str, Any] | None = None,
        notebook: Any = None,
    ) -> list[dict[str, Any]]:
        rows = list(self.tables.get(table, []))
        if focus:
            rows = [r for r in rows if r.get("owner") == principal.owner]
        v = vars or {}
        if "surface" in v:
            rows = [r for r in rows if r.get("surface") == v["surface"]]
        if "ref" in v:
            rows = [r for r in rows if r.get("ref") == v["ref"]]
        if "nb" in v:
            rows = [r for r in rows if r.get("notebook_id") == v["nb"]]
        if "key" in v:
            rows = [r for r in rows if r.get("entity_key") == v["key"]]
        for id_var in ("did", "eid", "sid", "nid"):
            if id_var in v:
                rows = [r for r in rows if _id_eq(r.get("id"), v[id_var])]
        if limit is not None:
            rows = rows[:limit]
        return rows

    async def query(
        self, query: str, vars: dict[str, Any] | None = None
    ) -> list[dict[str, Any]]:
        # scoped_update (UPDATE … RETURN AFTER): merge field vars into the owned row.
        # The accept-path demote (UPDATE … SET status='superseded' WHERE … id != $rid) has
        # no $rid bound to a single row, so it no-ops here (no sibling to demote in tests).
        v = vars or {}
        rid = v.get("rid")
        if rid is None:
            return []
        for table_rows in self.tables.values():
            for row in table_rows:
                if _id_eq(row.get("id"), rid) and row.get("owner") == v.get("owner"):
                    for key, value in v.items():
                        if key in ("rid", "owner", "surface", "ref"):
                            continue
                        row[key] = (
                            value.isoformat() if isinstance(value, datetime) else value
                        )
                    return [dict(row)]
        return []

    async def delete_where(
        self, table: str, where: str, vars: dict[str, Any] | None = None
    ) -> None:
        v = vars or {}
        self.tables[table] = [
            r
            for r in self.tables.get(table, [])
            if not (
                _id_eq(r.get("id"), v.get("eid")) and r.get("owner") == v.get("owner")
            )
        ]


class _UnusedChat:
    """A fake ChatClient that must never be called on the controlled-vocab (LLM-free) path."""

    async def complete(self, *, system: str, user: str, max_tokens: int = 1024) -> str:
        raise AssertionError("LLM must not be reached for controlled-vocab compose")


def _build_client(repo: _ApiRepo, owner: str = "u1") -> TestClient:
    """A TestClient with repo + principal + chat + embedder overridden (caller clears)."""
    from fastapi.testclient import TestClient

    from docx_app import deps
    from docx_app.indexing.embedding import LocalTestEmbedder
    from docx_app.main import app

    app.dependency_overrides[deps.get_principal] = lambda: Principal(owner=owner)
    app.dependency_overrides[deps.get_repository] = lambda: repo
    app.dependency_overrides[deps.get_chat_client] = lambda: _UnusedChat()
    app.dependency_overrides[deps.get_embedder] = lambda: LocalTestEmbedder(
        deps.get_config()
    )
    return TestClient(app)


def _two_source_shared_entity_repo() -> _ApiRepo:
    """Two accepted source diagrams in notebook:1 both referencing entity 'customer'."""
    g1 = _source_graph([{"id": "n1", "label": "Customer", "entity": "customer"}])
    g2 = _source_graph([{"id": "n2", "label": "Customer", "entity": "customer"}])
    return _ApiRepo(
        notebooks=[_notebook_row("notebook:1")],
        diagrams=[
            _diagram_row("diagram:1", "source:1", g1),
            _diagram_row("diagram:2", "source:2", g2),
        ],
        sources=[
            _source_row("source:1", "notebook:1"),
            _source_row("source:2", "notebook:1"),
        ],
        entities=[
            _entity_row(
                "notebook_entity:1",
                "notebook:1",
                "customer",
                "Customer",
                ["source:1", "source:2"],
            )
        ],
    )


@pytest.fixture(autouse=True)
def _clear_overrides():  # type: ignore[no-untyped-def]
    """Always clear dependency overrides after each test (shared module-level app)."""
    yield
    from docx_app.main import app

    app.dependency_overrides.clear()


# =========================================================================== #
# POST /notebooks/{id}/diagram/build — composes + persists a surface='notebook' HLD.
# =========================================================================== #
def test_build_composes_and_persists_notebook_hld() -> None:
    """Build composes the accepted source LLDs into a persisted notebook HLD with a bridge."""
    repo = _two_source_shared_entity_repo()
    client = _build_client(repo)

    resp = client.post("/notebooks/notebook:1/diagram/build")
    assert resp.status_code == 200
    body = resp.json()

    assert body["surface"] == "notebook"
    assert body["status"] == "draft"
    assert body["notebook_id"] == "notebook:1"
    assert body["source_count"] == 2
    assert body["bridge_count"] == 1  # the shared 'customer' entity bridges both sources
    assert body["low_confidence"] == []  # controlled-vocab → deterministic, nothing to flag

    # The persisted graph is the entity-bridged parent (two source nodes + one bridge),
    # edges keyed by the "from" alias (the renderer contract).
    graph = body["graph"]
    assert graph is not None
    source_nodes = [n for n in graph["nodes"] if n["type"] == "source"]
    bridge_nodes = [n for n in graph["nodes"] if (n.get("meta") or {}).get("shared")]
    assert len(source_nodes) == 2
    assert len(bridge_nodes) == 1
    assert bridge_nodes[0]["entity"] == "customer"
    assert all(n["shape"] == "hexagon" for n in source_nodes)
    assert graph["edges"] and "from" in graph["edges"][0]

    # It was persisted as a surface='notebook' diagram row (the HLD write).
    hld_rows = [r for r in repo.created if r.get("surface") == "notebook"]
    assert len(hld_rows) == 1
    assert hld_rows[0]["status"] == "draft"


def test_build_result_loads_back_via_get() -> None:
    """After build, GET /notebooks/{id}/diagram returns the same persisted HLD."""
    repo = _two_source_shared_entity_repo()
    client = _build_client(repo)

    built = client.post("/notebooks/notebook:1/diagram/build")
    assert built.status_code == 200

    loaded = client.get("/notebooks/notebook:1/diagram")
    assert loaded.status_code == 200
    got = loaded.json()
    assert got["surface"] == "notebook"
    assert got["graph"] == built.json()["graph"]


def test_build_is_an_alias_of_rebuild() -> None:
    """``/build`` and ``/rebuild`` produce structurally identical HLDs (same operation)."""
    a = client_a = _build_client(_two_source_shared_entity_repo())
    via_build = client_a.post("/notebooks/notebook:1/diagram/build").json()
    a.app.dependency_overrides.clear()  # type: ignore[attr-defined]

    client_b = _build_client(_two_source_shared_entity_repo())
    via_rebuild = client_b.post("/notebooks/notebook:1/diagram/rebuild").json()

    assert via_build["graph"] == via_rebuild["graph"]
    assert via_build["source_count"] == via_rebuild["source_count"]
    assert via_build["bridge_count"] == via_rebuild["bridge_count"]


def test_build_is_idempotent() -> None:
    """Re-building over the same accepted sources yields a structurally identical graph."""
    repo = _two_source_shared_entity_repo()
    client = _build_client(repo)

    first = client.post("/notebooks/notebook:1/diagram/build")
    second = client.post("/notebooks/notebook:1/diagram/build")
    assert first.status_code == second.status_code == 200
    # The second build overwrites the draft in place (no proliferation of HLD rows).
    assert first.json()["graph"] == second.json()["graph"]
    hld_rows = [r for r in repo.created if r.get("surface") == "notebook"]
    assert len(hld_rows) == 1


def test_build_404_when_no_accepted_source_diagrams() -> None:
    """A notebook with no accepted source diagrams → 404 (the HLD empty-state)."""
    repo = _ApiRepo(notebooks=[_notebook_row("notebook:1")])
    client = _build_client(repo)
    resp = client.post("/notebooks/notebook:1/diagram/build")
    assert resp.status_code == 404
    assert "no accepted source diagrams" in resp.json()["detail"]


def test_build_404_when_notebook_not_owned() -> None:
    """A notebook owned by u2 must not be buildable by u1 (owner isolation)."""
    g1 = _source_graph([{"id": "n1", "label": "Customer", "entity": "customer"}])
    repo = _ApiRepo(
        notebooks=[_notebook_row("notebook:1", owner="u2")],  # not u1's
        diagrams=[_diagram_row("diagram:1", "source:1", g1, owner="u2")],
        sources=[_source_row("source:1", "notebook:1", owner="u2")],
    )
    client = _build_client(repo, owner="u1")
    resp = client.post("/notebooks/notebook:1/diagram/build")
    assert resp.status_code == 404
    assert "notebook not found" in resp.json()["detail"]


def test_build_then_accept_freezes_the_hld() -> None:
    """Build → accept stamps accepted + snapshots an SVG (DATA + PICTURE, design §2)."""
    repo = _two_source_shared_entity_repo()
    client = _build_client(repo)

    assert client.post("/notebooks/notebook:1/diagram/build").status_code == 200
    accepted = client.post("/notebooks/notebook:1/diagram/accept")
    assert accepted.status_code == 200
    body = accepted.json()
    assert body["status"] == "accepted"
    svg = body["render_snapshot_svg"]
    assert svg is not None
    assert "<svg" in svg and svg.rstrip().endswith("</svg>")
