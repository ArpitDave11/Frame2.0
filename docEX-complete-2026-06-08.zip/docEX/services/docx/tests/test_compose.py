"""Notebook-HLD composition tests — topology, tenancy, idempotency (Surface 2).

Covers the sub-design §7 (entity-bridged topology; singletons excluded; source nodes
drillable) and §11 test list (compose topology, registry tenancy, upsert idempotency on
re-accept) for :func:`docx_app.diagram.compose.compose_notebook_hld`.

Compose reads two tables (``diagram`` for accepted source LLDs, ``source`` for notebook
membership) plus ``notebook_entity`` (the registry), so the fake repo here is table-aware,
owner-scoped, and RecordID-aware (mirrors ``test_diagram.py`` / ``test_entity_reconciler.py``
patterns). ``asyncio_mode="auto"`` — no per-test marker. All deterministic, no network; the
Path-C ``node.entity`` keys make the common case LLM-free, so most tests pass ``chat=None``.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from docx_app.db import ensure_record_id
from docx_app.diagram.compose import MIN_SOURCES_FOR_BRIDGE, compose_notebook_hld
from docx_app.diagram.model import DiagramGraph
from docx_app.tenancy import Principal

P = Principal(owner="u1")


def _id_eq(row_id: Any, want: Any) -> bool:
    """RecordID-aware id equality (the store binds ``ensure_record_id(...)`` as the var)."""
    a = ensure_record_id(str(row_id)) if not hasattr(row_id, "table_name") else row_id
    b = ensure_record_id(str(want)) if not hasattr(want, "table_name") else want
    return (a.table_name, str(a.id)) == (b.table_name, str(b.id))


def _source_graph(
    nodes: list[dict[str, Any]], edges: list[dict[str, Any]] | None = None
) -> dict[str, Any]:
    """A stored graph_json dict (edges keyed by ``"from"``) with every required field set."""
    full_nodes = [
        {
            "id": n["id"],
            "label": n.get("label", n["id"].title()),
            "type": n.get("type", "service"),
            "description": n.get("description"),
            "groupId": None,
            "shape": n.get("shape"),
            "icon": None,
            "link": None,
            "drill": None,
            "entity": n.get("entity"),
            "meta": n.get("meta"),
        }
        for n in nodes
    ]
    return {"groups": [], "nodes": full_nodes, "edges": edges or []}


def _diagram_row(
    diagram_id: str,
    source_ref: str,
    graph_json: dict[str, Any],
    *,
    owner: str = "u1",
    status: str = "accepted",
) -> dict[str, Any]:
    return {
        "id": diagram_id,
        "owner": owner,
        "scope": "private",
        "surface": "source",
        "ref": source_ref,
        "status": status,
        "graph_json": graph_json,
        "render_snapshot_svg": None,
        "version": 1,
    }


def _source_row(
    source_id: str, notebook_id: str, *, owner: str = "u1"
) -> dict[str, Any]:
    return {
        "id": source_id,
        "owner": owner,
        "scope": "private",
        "notebook": notebook_id,
        "title": source_id.split(":", 1)[-1].title(),
    }


class ComposeRepo:
    """Table-aware, owner-scoped, RecordID-aware fake for compose's three tables.

    * ``diagram`` — served on ``surface``/``ref`` filters (the accepted-source list).
    * ``source``  — served on ``id`` (the membership check via SourceStore.get).
    * ``notebook_entity`` — served on ``notebook_id``/``entity_key``/``id`` (the registry).

    ``create_scoped`` returns a single-element LIST (exercises the unwrap). ``select_scoped``
    applies the owner filter for ``focus=True`` reads (so cross-owner reads yield nothing).
    """

    def __init__(
        self,
        *,
        diagrams: list[dict[str, Any]] | None = None,
        sources: list[dict[str, Any]] | None = None,
        entities: list[dict[str, Any]] | None = None,
    ) -> None:
        self.tables: dict[str, list[dict[str, Any]]] = {
            "diagram": list(diagrams or []),
            "source": list(sources or []),
            "notebook_entity": list(entities or []),
        }
        self.created: list[dict[str, Any]] = []
        self._counter = 0

    async def create_scoped(
        self, table: str, data: dict[str, Any], *, owner: str, scope: Any
    ) -> list[dict[str, Any]]:
        self._counter += 1
        row = {
            **data,
            "id": f"{table}:new{self._counter}",
            "owner": owner,
            "scope": scope.value,
        }
        self.created.append(row)
        self.tables.setdefault(table, []).append(row)
        return [row]

    async def select_scoped(
        self,
        table: str,
        principal: Principal,
        *,
        focus: bool = False,
        extra_where: str = "",
        order_by: str = "updated DESC",
        limit: int | None = None,
        vars: dict[str, Any] | None = None,
        notebook: Any = None,
    ) -> list[dict[str, Any]]:
        rows = list(self.tables.get(table, []))
        if focus:
            rows = [r for r in rows if r.get("owner") == principal.owner]
        v = vars or {}
        if "surface" in v:
            rows = [r for r in rows if r.get("surface") == v["surface"]]
        if "ref" in v:
            rows = [r for r in rows if r.get("ref") == v["ref"]]
        if "nb" in v:
            rows = [r for r in rows if r.get("notebook_id") == v["nb"]]
        if "key" in v:
            rows = [r for r in rows if r.get("entity_key") == v["key"]]
        for id_var in ("did", "eid", "sid", "nid"):
            if id_var in v:
                rows = [r for r in rows if _id_eq(r.get("id"), v[id_var])]
        if limit is not None:
            rows = rows[:limit]
        return rows

    async def query(
        self, query: str, vars: dict[str, Any] | None = None
    ) -> list[dict[str, Any]]:
        # Only scoped_update (UPDATE ... RETURN AFTER) is exercised by compose's registry
        # writes; merge field vars into the matching owned row, ISO-stringifying datetimes
        # (the real repo's parse_record_ids does this; NotebookEntity.updated is str).
        v = vars or {}
        for table_rows in self.tables.values():
            for row in table_rows:
                if _id_eq(row.get("id"), v.get("rid")) and row.get("owner") == v.get(
                    "owner"
                ):
                    for key, value in v.items():
                        if key in ("rid", "owner"):
                            continue
                        row[key] = (
                            value.isoformat()
                            if isinstance(value, datetime)
                            else value
                        )
                    return [dict(row)]
        return []

    async def delete_where(
        self, table: str, where: str, vars: dict[str, Any] | None = None
    ) -> None:
        v = vars or {}
        self.tables[table] = [
            r
            for r in self.tables.get(table, [])
            if not (_id_eq(r.get("id"), v.get("eid")) and r.get("owner") == v.get("owner"))
        ]


def _bridge_nodes(graph: DiagramGraph) -> list[Any]:
    return [n for n in graph.nodes if (n.meta or {}).get("shared")]


def _source_nodes(graph: DiagramGraph) -> list[Any]:
    return [n for n in graph.nodes if n.type == "source"]


# =========================================================================== #
# Topology — entity-bridged; singletons excluded; source nodes drillable.
# =========================================================================== #
async def test_empty_notebook_yields_no_graph() -> None:
    repo = ComposeRepo()
    result = await compose_notebook_hld(repo, P, notebook_id="notebook:1", chat=None)
    assert result.graph is None
    assert result.source_count == 0


async def test_shared_entity_becomes_a_bridge_node() -> None:
    """Two sources both referencing entity 'customer' → one bridge node connecting them."""
    g1 = _source_graph([{"id": "n1", "label": "Customer", "entity": "customer"}])
    g2 = _source_graph([{"id": "n2", "label": "Customer", "entity": "customer"}])
    repo = ComposeRepo(
        diagrams=[
            _diagram_row("diagram:1", "source:1", g1),
            _diagram_row("diagram:2", "source:2", g2),
        ],
        sources=[
            _source_row("source:1", "notebook:1"),
            _source_row("source:2", "notebook:1"),
        ],
        entities=[
            {
                "id": "notebook_entity:1",
                "owner": "u1",
                "scope": "private",
                "notebook_id": "notebook:1",
                "entity_key": "customer",
                "canonical_label": "Customer",
                "aliases": [],
                "source_refs": ["source:1", "source:2"],
                "locked": False,
            }
        ],
    )
    result = await compose_notebook_hld(repo, P, notebook_id="notebook:1", chat=None)
    assert result.graph is not None
    graph = result.graph
    # Two source nodes (hexagon, drillable) + one shared-entity bridge node.
    sources = _source_nodes(graph)
    bridges = _bridge_nodes(graph)
    assert len(sources) == 2
    assert len(bridges) == 1
    assert result.bridge_count == 1
    bridge = bridges[0]
    assert bridge.entity == "customer"
    assert bridge.label == "Customer"  # the registry canonical label
    assert sorted(bridge.meta["source_refs"]) == ["source:1", "source:2"]
    # Each source node drills into its accepted diagram and is a hexagon.
    drills = {n.drill for n in sources}
    assert drills == {"diagram:1", "diagram:2"}
    assert all(n.shape == "hexagon" for n in sources)
    # Edges connect each source to the bridge, labelled with the entity key.
    assert len(graph.edges) == 2
    assert all(e.label == "customer" for e in graph.edges)
    assert {e.to for e in graph.edges} == {bridge.id}


async def test_singleton_entity_is_not_promoted() -> None:
    """An entity in only ONE source is NOT a bridge (stays in its LLD) — sub-design §7."""
    g1 = _source_graph(
        [
            {"id": "n1", "label": "Customer", "entity": "customer"},
            {"id": "n2", "label": "Local Cache", "entity": "local-cache"},  # singleton
        ]
    )
    g2 = _source_graph([{"id": "n3", "label": "Customer", "entity": "customer"}])
    repo = ComposeRepo(
        diagrams=[
            _diagram_row("diagram:1", "source:1", g1),
            _diagram_row("diagram:2", "source:2", g2),
        ],
        sources=[
            _source_row("source:1", "notebook:1"),
            _source_row("source:2", "notebook:1"),
        ],
        entities=[
            {
                "id": "notebook_entity:1", "owner": "u1", "scope": "private",
                "notebook_id": "notebook:1", "entity_key": "customer",
                "canonical_label": "Customer", "aliases": [],
                "source_refs": ["source:1", "source:2"], "locked": False,
            },
            {
                "id": "notebook_entity:2", "owner": "u1", "scope": "private",
                "notebook_id": "notebook:1", "entity_key": "local-cache",
                "canonical_label": "Local Cache", "aliases": [],
                "source_refs": ["source:1"], "locked": False,
            },
        ],
    )
    result = await compose_notebook_hld(repo, P, notebook_id="notebook:1", chat=None)
    assert result.graph is not None
    bridges = _bridge_nodes(result.graph)
    # Only the shared 'customer' is a bridge; the singleton 'local-cache' is excluded.
    assert {b.entity for b in bridges} == {"customer"}
    assert result.bridge_count == 1


async def test_three_sources_sharing_one_entity_bridge_all_three() -> None:
    graphs = [
        _source_graph([{"id": f"n{i}", "label": "Order Service", "entity": "order-service"}])
        for i in range(3)
    ]
    repo = ComposeRepo(
        diagrams=[
            _diagram_row(f"diagram:{i}", f"source:{i}", graphs[i]) for i in range(3)
        ],
        sources=[_source_row(f"source:{i}", "notebook:1") for i in range(3)],
        entities=[
            {
                "id": "notebook_entity:1", "owner": "u1", "scope": "private",
                "notebook_id": "notebook:1", "entity_key": "order-service",
                "canonical_label": "Order Service", "aliases": [],
                "source_refs": ["source:0", "source:1", "source:2"], "locked": False,
            }
        ],
    )
    result = await compose_notebook_hld(repo, P, notebook_id="notebook:1", chat=None)
    assert result.graph is not None
    bridges = _bridge_nodes(result.graph)
    assert len(bridges) == 1
    assert len(result.graph.edges) == 3  # one edge per contributing source
    assert sorted(bridges[0].meta["source_refs"]) == [
        "source:0", "source:1", "source:2",
    ]


async def test_emitted_graph_round_trips_the_from_alias() -> None:
    """The composed parent graph must serialise edges with the ``"from"`` alias (S1 gotcha)."""
    g1 = _source_graph([{"id": "n1", "label": "Customer", "entity": "customer"}])
    g2 = _source_graph([{"id": "n2", "label": "Customer", "entity": "customer"}])
    repo = ComposeRepo(
        diagrams=[
            _diagram_row("diagram:1", "source:1", g1),
            _diagram_row("diagram:2", "source:2", g2),
        ],
        sources=[
            _source_row("source:1", "notebook:1"),
            _source_row("source:2", "notebook:1"),
        ],
        entities=[
            {
                "id": "notebook_entity:1", "owner": "u1", "scope": "private",
                "notebook_id": "notebook:1", "entity_key": "customer",
                "canonical_label": "Customer", "aliases": [],
                "source_refs": ["source:1", "source:2"], "locked": False,
            }
        ],
    )
    result = await compose_notebook_hld(repo, P, notebook_id="notebook:1", chat=None)
    assert result.graph is not None
    dumped = result.graph.model_dump(by_alias=True)
    assert dumped["edges"], "expected bridge edges"
    assert "from" in dumped["edges"][0]  # the alias, not "from_"
    assert "from_" not in dumped["edges"][0]


# =========================================================================== #
# Tenancy — owner-scoped + per-notebook isolation (no cross leakage).
# =========================================================================== #
async def test_compose_ignores_other_owners_diagrams() -> None:
    """Another owner's accepted diagram must never enter u1's HLD (owner isolation)."""
    g_mine = _source_graph([{"id": "n1", "label": "Customer", "entity": "customer"}])
    g_other = _source_graph([{"id": "n2", "label": "Customer", "entity": "customer"}])
    repo = ComposeRepo(
        diagrams=[
            _diagram_row("diagram:1", "source:1", g_mine, owner="u1"),
            _diagram_row("diagram:2", "source:2", g_other, owner="u2"),  # not u1's
        ],
        sources=[
            _source_row("source:1", "notebook:1", owner="u1"),
            _source_row("source:2", "notebook:1", owner="u2"),
        ],
        entities=[
            {
                "id": "notebook_entity:1", "owner": "u1", "scope": "private",
                "notebook_id": "notebook:1", "entity_key": "customer",
                "canonical_label": "Customer", "aliases": [],
                "source_refs": ["source:1"], "locked": False,
            }
        ],
    )
    result = await compose_notebook_hld(repo, P, notebook_id="notebook:1", chat=None)
    # u1 sees only their own one source → no shared entity → no bridges (customer is a
    # singleton from u1's perspective; u2's diagram is invisible).
    assert result.graph is not None
    assert result.source_count == 1
    assert result.bridge_count == 0


async def test_compose_ignores_other_notebooks_sources() -> None:
    """A source belonging to a different notebook must not enter this notebook's HLD."""
    g1 = _source_graph([{"id": "n1", "label": "Customer", "entity": "customer"}])
    g2 = _source_graph([{"id": "n2", "label": "Customer", "entity": "customer"}])
    repo = ComposeRepo(
        diagrams=[
            _diagram_row("diagram:1", "source:1", g1),
            _diagram_row("diagram:2", "source:2", g2),
        ],
        sources=[
            _source_row("source:1", "notebook:1"),
            _source_row("source:2", "notebook:2"),  # different notebook
        ],
        entities=[
            {
                "id": "notebook_entity:1", "owner": "u1", "scope": "private",
                "notebook_id": "notebook:1", "entity_key": "customer",
                "canonical_label": "Customer", "aliases": [],
                "source_refs": ["source:1"], "locked": False,
            }
        ],
    )
    result = await compose_notebook_hld(repo, P, notebook_id="notebook:1", chat=None)
    # Only source:1 is in notebook:1 → one source node, no bridge (customer is a singleton).
    assert result.graph is not None
    assert result.source_count == 1
    assert result.bridge_count == 0


# =========================================================================== #
# Path-B fallback at compose time — a node WITHOUT an entity key gets reconciled.
# =========================================================================== #
async def test_unlabelled_nodes_in_two_sources_converge_via_normalize() -> None:
    """Two frozen sources with no entity keys but identical labels converge to one bridge.

    Source 1's node registers a new entity (Path B step-4 'new'); source 2's identical label
    then matches it via normalization (step 1), so both bridge to the SAME entity — proving
    the in-compose registration makes a fresh entity available to later sources.
    """
    g1 = _source_graph([{"id": "n1", "label": "Payment Gateway"}])  # no entity key
    g2 = _source_graph([{"id": "n2", "label": "Payment Gateway"}])  # no entity key
    repo = ComposeRepo(
        diagrams=[
            _diagram_row("diagram:1", "source:1", g1),
            _diagram_row("diagram:2", "source:2", g2),
        ],
        sources=[
            _source_row("source:1", "notebook:1"),
            _source_row("source:2", "notebook:1"),
        ],
        entities=[],  # empty registry — Path B must discover + register
    )
    result = await compose_notebook_hld(repo, P, notebook_id="notebook:1", chat=None)
    assert result.graph is not None
    bridges = _bridge_nodes(result.graph)
    assert len(bridges) == 1  # converged to ONE shared entity
    assert bridges[0].entity == "payment-gateway"  # slugified, registered once
    # The reconciler registered exactly one new notebook_entity (idempotent across sources).
    created_entities = [r for r in repo.created if r.get("entity_key")]
    assert len(created_entities) == 1


async def test_distinct_unlabelled_nodes_stay_singletons() -> None:
    """Two different labels (no entity keys) → two distinct singletons → no bridge."""
    g1 = _source_graph([{"id": "n1", "label": "Billing Engine"}])
    g2 = _source_graph([{"id": "n2", "label": "Shipping Tracker"}])
    repo = ComposeRepo(
        diagrams=[
            _diagram_row("diagram:1", "source:1", g1),
            _diagram_row("diagram:2", "source:2", g2),
        ],
        sources=[
            _source_row("source:1", "notebook:1"),
            _source_row("source:2", "notebook:1"),
        ],
        entities=[],
    )
    result = await compose_notebook_hld(repo, P, notebook_id="notebook:1", chat=None)
    assert result.graph is not None
    assert _bridge_nodes(result.graph) == []
    assert result.bridge_count == 0


# =========================================================================== #
# Determinism / re-compose stability.
# =========================================================================== #
async def test_compose_is_deterministic_for_controlled_vocab() -> None:
    """Re-composing the same controlled-vocab inputs yields an identical graph (no LLM)."""
    g1 = _source_graph([{"id": "n1", "label": "Customer", "entity": "customer"}])
    g2 = _source_graph([{"id": "n2", "label": "Customer", "entity": "customer"}])

    def _repo() -> ComposeRepo:
        return ComposeRepo(
            diagrams=[
                _diagram_row("diagram:1", "source:1", g1),
                _diagram_row("diagram:2", "source:2", g2),
            ],
            sources=[
                _source_row("source:1", "notebook:1"),
                _source_row("source:2", "notebook:1"),
            ],
            entities=[
                {
                    "id": "notebook_entity:1", "owner": "u1", "scope": "private",
                    "notebook_id": "notebook:1", "entity_key": "customer",
                    "canonical_label": "Customer", "aliases": [],
                    "source_refs": ["source:1", "source:2"], "locked": False,
                }
            ],
        )

    r1 = await compose_notebook_hld(_repo(), P, notebook_id="notebook:1", chat=None)
    r2 = await compose_notebook_hld(_repo(), P, notebook_id="notebook:1", chat=None)
    assert r1.graph is not None and r2.graph is not None
    assert r1.graph.model_dump(by_alias=True) == r2.graph.model_dump(by_alias=True)


def test_min_sources_for_bridge_constant() -> None:
    """Sanity: the singleton-promotion rule is 'appears in >= 2 sources' (sub-design §7)."""
    assert MIN_SOURCES_FOR_BRIDGE == 2
