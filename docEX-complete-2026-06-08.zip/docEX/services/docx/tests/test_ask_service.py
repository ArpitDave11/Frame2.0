"""AskService — grounded synthesis with citations; no-results short-circuit."""

from docx_app.ask.service import AskService
from docx_app.retrieval.models import RetrievedChunk
from docx_app.tenancy import Principal


class FakeRetrieval:
    def __init__(self, chunks):
        self.chunks = chunks
        self.focus = None
        self.notebook = None

    async def search(
        self,
        query,
        principal,
        *,
        focus=False,
        limit=10,
        min_similarity=0.2,
        notebook=None,
    ):
        self.focus = focus
        self.notebook = notebook
        return self.chunks


class FakeChat:
    def __init__(self):
        self.called = False
        self.user = None

    async def complete(self, *, system, user, max_tokens=1000):
        self.called = True
        self.user = user
        return "answer [1]"


async def test_ask_synthesizes_with_citations_and_passes_focus():
    chunks = [
        RetrievedChunk(id="source_chunk:1", source="source:1", content="ctx", score=0.9)
    ]
    ret, chat = FakeRetrieval(chunks), FakeChat()
    res = await AskService(ret, chat).ask("q?", Principal(owner="u1"), focus=True)

    assert res.answer == "answer [1]"
    assert res.used_chunks == 1
    assert res.citations[0].source == "source:1"
    assert chat.called and "ctx" in chat.user  # the chunk content went into the prompt
    assert ret.focus is True  # focus propagated to retrieval


async def test_ask_with_no_results_skips_the_llm():
    ret, chat = FakeRetrieval([]), FakeChat()
    res = await AskService(ret, chat).ask("q?", Principal(owner="u1"))

    assert res.used_chunks == 0
    assert not chat.called  # don't hallucinate when nothing was retrieved
    assert "couldn't find" in res.answer.lower()


async def test_citation_numbering_matches_context_order():
    chunks = [
        RetrievedChunk(
            id="source_chunk:1", source="source:1", content="first", score=0.9
        ),
        RetrievedChunk(
            id="source_chunk:2", source="source:2", content="second", score=0.8
        ),
    ]
    ret, chat = FakeRetrieval(chunks), FakeChat()
    res = await AskService(ret, chat).ask("q?", Principal(owner="u1"))

    # context label [n] must line up with citations[n-1]
    assert "[1] first" in chat.user and "[2] second" in chat.user
    assert res.citations[0].source == "source:1"
    assert res.citations[1].source == "source:2"
