"""Notebook (workspace) — store + API, owner-private."""

import pytest
from fastapi.testclient import TestClient

from docx_app import deps
from docx_app.domain.notebook import Notebook, NotebookStore
from docx_app.main import app
from docx_app.tenancy import Principal, Scope


class FakeRepo:
    def __init__(self):
        self.created: list[dict] = []
        self.rows: list[dict] = []
        self.selects: list[dict] = []
        self.queries: list[dict] = []
        self.deletes: list[dict] = []
        # per-table seed; falls back to `rows` when a table isn't explicitly set.
        self.table_rows: dict[str, list[dict]] = {}
        self.query_rows: list[dict] = []

    async def create_scoped(self, table, data, *, owner, scope):
        self.created.append({"data": data, "owner": owner, "scope": scope})
        return {**data, "id": f"{table}:1", "owner": owner, "scope": scope.value}

    async def select_scoped(
        self,
        table,
        principal,
        *,
        focus=False,
        extra_where="",
        order_by="updated DESC",
        limit=None,
        vars=None,
        notebook=None,
    ):
        self.selects.append(
            {
                "table": table,
                "focus": focus,
                "extra_where": extra_where,
                "order_by": order_by,
                "notebook": notebook,
            }
        )
        return self.table_rows.get(table, self.rows)

    async def query(self, query_str, vars=None):
        self.queries.append({"query": query_str, "vars": vars})
        return self.query_rows

    async def delete_where(self, table, where, vars=None):
        self.deletes.append({"table": table, "where": where, "vars": vars})


async def test_create_stamps_owner_and_is_private():
    repo = FakeRepo()
    nb = await NotebookStore(repo).create(owner="u1", name="Research", description="d")
    assert isinstance(nb, Notebook) and nb.name == "Research" and nb.owner == "u1"
    assert repo.created[0]["owner"] == "u1"
    assert repo.created[0]["scope"] == Scope.PRIVATE  # workspaces are owner-private


async def test_list_and_get_are_owner_scoped():
    repo = FakeRepo()
    repo.rows = [{"id": "notebook:1", "name": "A", "owner": "u1"}]
    nbs = await NotebookStore(repo).list(Principal(owner="u1"))
    assert len(nbs) == 1 and nbs[0].name == "A"
    assert repo.selects[0]["focus"] is True  # only your own workspaces
    got = await NotebookStore(repo).get("notebook:1", Principal(owner="u1"))
    assert got is not None and got.name == "A"
    assert repo.selects[1]["extra_where"] == "id = $nid"
    assert repo.selects[1]["focus"] is True


@pytest.fixture
def client():
    repo = FakeRepo()
    app.dependency_overrides[deps.get_principal] = lambda: Principal(owner="u1")
    app.dependency_overrides[deps.get_repository] = lambda: repo
    c = TestClient(app)
    yield c, repo
    app.dependency_overrides.clear()


def test_api_create_notebook(client):
    c, repo = client
    resp = c.post("/notebooks", json={"name": "Strategy"})
    assert resp.status_code == 200 and resp.json()["name"] == "Strategy"
    assert repo.created[0]["scope"] == Scope.PRIVATE


def test_api_create_blank_name_returns_400(client):
    c, _ = client
    assert c.post("/notebooks", json={"name": "   "}).status_code == 400


def test_api_list_notebooks(client):
    c, repo = client
    repo.rows = [{"id": "notebook:1", "name": "A"}]
    resp = c.get("/notebooks")
    assert resp.status_code == 200 and len(resp.json()) == 1


def test_api_get_missing_notebook_404(client):
    c, repo = client
    repo.rows = []
    assert c.get("/notebooks/notebook:999").status_code == 404


# --- Open Notebook contract (lib/api/notebooks.ts) --------------------------


def test_api_notebook_response_shape_and_counts(client):
    c, repo = client
    repo.table_rows["notebook"] = [
        {
            "id": "notebook:1",
            "name": "A",
            "description": "d",
            "archived": False,
            "created": "2026-01-01",
            "updated": "2026-01-02",
        }
    ]
    # count_sources reads the `source` table (owner+notebook scoped)
    repo.table_rows["source"] = [{"id": "source:1"}, {"id": "source:2"}]
    nb = c.get("/notebooks/notebook:1").json()
    assert set(nb) == {
        "id",
        "name",
        "description",
        "archived",
        "created",
        "updated",
        "source_count",
        "note_count",
    }
    assert nb["source_count"] == 2  # scoped count of workspace sources
    assert nb["note_count"] == 0  # Docx has no notes table
    assert "owner" not in nb  # never leak the tenancy column


def test_api_create_returns_archived_false(client):
    c, repo = client
    resp = c.post("/notebooks", json={"name": "N"})
    assert resp.status_code == 200
    assert resp.json()["archived"] is False
    assert repo.created[0]["data"]["archived"] is False


def test_api_list_archived_filter(client):
    c, repo = client
    repo.table_rows["notebook"] = [
        {"id": "notebook:1", "name": "live", "archived": False},
        {"id": "notebook:2", "name": "old", "archived": True},
    ]
    names = {nb["name"] for nb in c.get("/notebooks", params={"archived": True}).json()}
    assert names == {"old"}
    names = {
        nb["name"] for nb in c.get("/notebooks", params={"archived": False}).json()
    }
    assert names == {"live"}


def test_api_list_order_by_passed_through_and_validated(client):
    c, repo = client
    repo.table_rows["notebook"] = [{"id": "notebook:1", "name": "A"}]
    c.get("/notebooks", params={"order_by": "name asc"})
    nb_select = next(s for s in repo.selects if s["table"] == "notebook")
    assert nb_select["order_by"] == "name asc"
    # injection / unknown field is rejected
    assert c.get("/notebooks", params={"order_by": "name; DROP"}).status_code == 400
    assert c.get("/notebooks", params={"order_by": "bogus"}).status_code == 400


def test_api_update_notebook(client):
    c, repo = client
    repo.table_rows["notebook"] = [{"id": "notebook:1", "name": "old", "owner": "u1"}]
    repo.query_rows = [
        {"id": "notebook:1", "name": "new", "archived": True, "owner": "u1"}
    ]
    resp = c.put("/notebooks/notebook:1", json={"name": "new", "archived": True})
    assert resp.status_code == 200
    body = resp.json()
    assert body["name"] == "new" and body["archived"] is True
    # owner-scoped UPDATE (tenancy guard on the write)
    assert "owner = $owner" in repo.queries[0]["query"]
    assert repo.queries[0]["vars"]["owner"] == "u1"


def test_api_update_missing_notebook_404(client):
    c, repo = client
    repo.table_rows["notebook"] = []
    assert c.put("/notebooks/notebook:9", json={"name": "x"}).status_code == 404


def test_api_delete_preview(client):
    c, repo = client
    repo.table_rows["notebook"] = [{"id": "notebook:1", "name": "A", "owner": "u1"}]
    repo.table_rows["source"] = [{"id": "source:1"}, {"id": "source:2"}]
    body = c.get("/notebooks/notebook:1/delete-preview").json()
    assert body["notebook_id"] == "notebook:1" and body["notebook_name"] == "A"
    assert body["exclusive_source_count"] == 2  # single-workspace → all exclusive
    assert body["shared_source_count"] == 0 and body["note_count"] == 0


def test_api_delete_preview_missing_404(client):
    c, repo = client
    repo.table_rows["notebook"] = []
    assert c.get("/notebooks/notebook:9/delete-preview").status_code == 404


def test_api_delete_notebook_unlinks_sources_by_default(client):
    c, repo = client
    repo.table_rows["notebook"] = [{"id": "notebook:1", "name": "A", "owner": "u1"}]
    repo.table_rows["source"] = [{"id": "source:1", "owner": "u1"}]
    body = c.delete("/notebooks/notebook:1").json()
    assert body["deleted_notes"] == 0
    assert body["deleted_sources"] == 0 and body["unlinked_sources"] == 1
    # default path clears the source's notebook (UPDATE), not a DELETE of the source
    assert any("notebook = $notebook" in q["query"] for q in repo.queries)


def test_api_delete_notebook_with_delete_exclusive_sources(client):
    c, repo = client
    repo.table_rows["notebook"] = [{"id": "notebook:1", "name": "A", "owner": "u1"}]
    repo.table_rows["source"] = [{"id": "source:1", "owner": "u1"}]
    body = c.delete(
        "/notebooks/notebook:1", params={"delete_exclusive_sources": True}
    ).json()
    assert body["deleted_sources"] == 1 and body["unlinked_sources"] == 0
    # the source + its chunks + the notebook are all deleted, owner-scoped
    tables = {d["table"] for d in repo.deletes}
    assert {"source", "source_chunk", "notebook"} <= tables
    assert all("owner = $owner" in d["where"] for d in repo.deletes)


def test_api_add_source_to_notebook(client):
    c, repo = client
    # both NotebookStore.get and SourceStore.get read their tables → present
    repo.table_rows["notebook"] = [{"id": "notebook:1", "owner": "u1"}]
    repo.table_rows["source"] = [{"id": "source:1", "owner": "u1"}]
    resp = c.post("/notebooks/notebook:1/sources/source:1")
    assert resp.status_code == 200
    # links via an owner-scoped UPDATE setting the source's notebook
    assert any(
        "notebook = $notebook" in q["query"] and q["vars"]["owner"] == "u1"
        for q in repo.queries
    )


def test_api_add_source_unknown_notebook_404(client):
    c, repo = client
    repo.table_rows["notebook"] = []
    assert c.post("/notebooks/notebook:9/sources/source:1").status_code == 404


def test_api_remove_source_from_notebook(client):
    c, repo = client
    repo.table_rows["notebook"] = [{"id": "notebook:1", "owner": "u1"}]
    repo.table_rows["source"] = [{"id": "source:1", "owner": "u1"}]
    resp = c.delete("/notebooks/notebook:1/sources/source:1")
    assert resp.status_code == 200


def test_api_cross_owner_cannot_read_notebook():
    """Leak guard through the API with a repo that really enforces the predicate:
    notebooks are owner-private, so u2 can never GET u1's notebook."""
    from tests.test_tenancy_isolation import InMemoryScopedRepo

    repo = InMemoryScopedRepo()

    async def seed():
        await NotebookStore(repo).create(owner="u1", name="u1-workspace")

    import asyncio

    asyncio.run(seed())

    app.dependency_overrides[deps.get_repository] = lambda: repo
    try:
        app.dependency_overrides[deps.get_principal] = lambda: Principal(owner="u2")
        assert TestClient(app).get("/notebooks/notebook:1").status_code == 404
        app.dependency_overrides[deps.get_principal] = lambda: Principal(owner="u1")
        assert TestClient(app).get("/notebooks/notebook:1").status_code == 200
    finally:
        app.dependency_overrides.clear()
