"""ChunkStore — idempotent replace, owner/scope stamped, order preserved."""

from docx_app.domain.chunk import ChunkStore
from docx_app.tenancy import Scope


class FakeRepo:
    def __init__(self):
        self.deleted: list = []
        self.inserted: list = []

    async def delete_where(self, table, where, vars=None):
        self.deleted.append((table, where, vars))

    async def insert_scoped(self, table, rows, *, owner, scope):
        self.inserted.append(
            {"table": table, "rows": rows, "owner": owner, "scope": scope}
        )
        return len(rows)


async def test_replace_for_source_deletes_then_inserts_scoped():
    repo = FakeRepo()
    n = await ChunkStore(repo).replace_for_source(
        "source:1", ["a", "b"], [[1.0], [2.0]], owner="u1", scope=Scope.ORG_COMMON
    )
    assert n == 2

    # idempotency: this owner's existing chunks for the source are dropped first
    assert repo.deleted and repo.deleted[0][0] == "source_chunk"
    assert (
        repo.deleted[0][1] == "source = $sid AND owner = $owner"
    )  # owner-scoped delete
    assert repo.deleted[0][2]["owner"] == "u1"

    ins = repo.inserted[0]
    assert ins["owner"] == "u1"
    assert ins["scope"] == Scope.ORG_COMMON
    assert [r["order"] for r in ins["rows"]] == [0, 1]
    assert ins["rows"][0]["content"] == "a" and ins["rows"][0]["embedding"] == [1.0]
    assert ins["rows"][0]["source"] is not None  # record<source> link


async def test_notebook_is_denormalised_onto_chunks():
    repo = FakeRepo()
    await ChunkStore(repo).replace_for_source(
        "source:1",
        ["a"],
        [[1.0]],
        owner="u1",
        scope=Scope.ORG_COMMON,
        notebook="notebook:1",
    )
    assert repo.inserted[0]["rows"][0]["notebook"] is not None
