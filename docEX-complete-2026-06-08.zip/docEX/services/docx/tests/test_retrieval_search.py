"""Scoped vector search query-building + the Retriever passing the query vector."""

from docx_app.retrieval.search import (
    Retriever,
    build_keyword_search,
    build_vector_search,
)
from docx_app.tenancy import Principal


def test_default_query_is_scoped_to_common_or_own():
    q, variables = build_vector_search(
        Principal(owner="u1"), focus=False, min_similarity=0.2, limit=5
    )
    assert "(scope = 'org-common' OR owner = $owner)" in q  # collective-brain default
    assert "vector::similarity::cosine(embedding, $q)" in q
    assert "array::len(embedding) = array::len($q)" in q  # dimension guard
    assert "LIMIT 5" in q
    assert variables == {"owner": "u1", "min": 0.2}


def test_focus_query_is_owner_only():
    q, _ = build_vector_search(
        Principal(owner="u1"), focus=True, min_similarity=0.1, limit=3
    )
    assert "owner = $owner" in q
    assert "org-common" not in q  # focus excludes the shared brain


def test_keyword_query_is_scoped_bm25():
    q, variables = build_keyword_search(Principal(owner="u1"), focus=False, limit=7)
    assert "content @1@ $kw" in q  # BM25 matches operator + bound term
    assert "search::score(1)" in q
    assert "(scope = 'org-common' OR owner = $owner)" in q  # same tenancy guard
    assert "LIMIT 7" in q
    assert variables == {"owner": "u1"}


def test_keyword_focus_is_owner_only():
    q, _ = build_keyword_search(Principal(owner="u1"), focus=True, limit=5)
    assert "owner = $owner" in q
    assert "org-common" not in q


def test_notebook_scopes_both_arms_to_the_workspace():
    qv, vv = build_vector_search(
        Principal(owner="u1"),
        focus=False,
        min_similarity=0.2,
        limit=5,
        notebook="notebook:1",
    )
    qk, vk = build_keyword_search(
        Principal(owner="u1"), focus=False, limit=5, notebook="notebook:1"
    )
    for q in (qv, qk):
        assert "owner = $owner AND notebook = $notebook" in q
        assert (
            "org-common" not in q
        )  # a workspace is the user's own, not the shared brain
    assert "notebook" in vv and "notebook" in vk  # $notebook is bound


class FakeRepo:
    def __init__(self):
        self.calls: list = []

    async def query(self, q, vars=None):
        self.calls.append((q, vars))
        return [{"id": "source_chunk:1", "content": "c", "score": 0.9}]


async def test_retriever_binds_query_vector_and_owner():
    repo = FakeRepo()
    rows = await Retriever(repo).vector_search(
        [0.1, 0.2, 0.3], Principal(owner="u1"), focus=False
    )
    assert rows
    _, sent_vars = repo.calls[0]
    assert sent_vars["q"] == [0.1, 0.2, 0.3]
    assert sent_vars["owner"] == "u1"
