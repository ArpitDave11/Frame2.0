"""RetrievalService — hybrid fusion (vector + BM25), graceful BM25 degrade."""

from surrealdb import SurrealError

from docx_app.retrieval.service import RetrievalService
from docx_app.tenancy import Principal


class FakeEmbedder:
    def __init__(self):
        self.seen = None

    async def embed(self, texts):
        self.seen = list(texts)
        return [[0.5, 0.5]]


class FakeHybridRepo:
    """Routes by SQL: the vector arm vs the BM25 arm. Optionally fails the BM25 arm."""

    def __init__(self, vec_rows, bm25_rows, *, bm25_raises=False):
        self.vec_rows = vec_rows
        self.bm25_rows = bm25_rows
        self.bm25_raises = bm25_raises
        self.vec_vars = None
        self.bm25_vars = None

    async def query(self, sql, vars=None):
        if "vector::similarity" in sql:
            self.vec_vars = vars
            return self.vec_rows
        if "search::score" in sql:
            self.bm25_vars = vars
            if self.bm25_raises:
                raise SurrealError(
                    "no SEARCH index"
                )  # the real index-absent error type
            return self.bm25_rows
        return []


C1 = {"id": "source_chunk:1", "source": "source:1", "content": "alpha", "score": 0.9}
C2 = {"id": "source_chunk:2", "source": "source:2", "content": "beta", "score": 0.8}
C3 = {"id": "source_chunk:3", "source": "source:3", "content": "gamma", "score": 0.7}


async def test_hybrid_fuses_vector_and_bm25_arms():
    repo = FakeHybridRepo(vec_rows=[C1, C2], bm25_rows=[C2, C3])
    emb = FakeEmbedder()
    out = await RetrievalService(repo, emb).search(
        "salary policy", Principal(owner="u1")
    )

    assert {c.content for c in out} == {"alpha", "beta", "gamma"}  # union of both arms
    assert out[0].content == "beta"  # C2 is in both arms → RRF lifts it to the top
    assert emb.seen == ["salary policy"]  # vector arm embedded the query
    assert repo.vec_vars["q"] == [0.5, 0.5]
    assert repo.bm25_vars["kw"] == "salary policy"  # BM25 arm got the raw term


async def test_bm25_failure_degrades_to_vector_only():
    repo = FakeHybridRepo(vec_rows=[C1, C2], bm25_rows=[], bm25_raises=True)
    out = await RetrievalService(repo, FakeEmbedder()).search(
        "q", Principal(owner="u1")
    )
    assert [c.content for c in out] == ["alpha", "beta"]  # vector arm only, no crash


async def test_hybrid_disabled_uses_vector_only():
    repo = FakeHybridRepo(vec_rows=[C1], bm25_rows=[C2, C3])
    out = await RetrievalService(repo, FakeEmbedder(), hybrid=False).search(
        "q", Principal(owner="u1")
    )
    assert [c.content for c in out] == ["alpha"]
    assert repo.bm25_vars is None  # BM25 arm never queried when hybrid is off


async def test_blank_query_returns_empty_without_embedding():
    repo = FakeHybridRepo(vec_rows=[], bm25_rows=[])
    emb = FakeEmbedder()
    assert await RetrievalService(repo, emb).search("   ", Principal(owner="u1")) == []
    assert emb.seen is None


async def test_fuse_with_empty_vector_arm_uses_bm25_results():
    # vector arm empty, BM25 non-empty → RRF over [[], [bm25 ids]] still returns bm25
    repo = FakeHybridRepo(vec_rows=[], bm25_rows=[C2, C3])
    out = await RetrievalService(repo, FakeEmbedder()).search(
        "q", Principal(owner="u1")
    )
    assert [c.content for c in out] == ["beta", "gamma"]


async def test_duplicate_id_tie_break_prefers_vector_row():
    # same chunk id from both arms → the vector arm's row wins the merge (tie-break only)
    vec = [
        {"id": "source_chunk:2", "source": "source:2", "content": "VEC", "score": 0.9}
    ]
    bm = [
        {"id": "source_chunk:2", "source": "source:2", "content": "BM25", "score": 0.5}
    ]
    repo = FakeHybridRepo(vec_rows=vec, bm25_rows=bm)
    out = await RetrievalService(repo, FakeEmbedder()).search(
        "q", Principal(owner="u1")
    )
    assert len(out) == 1 and out[0].content == "VEC"
