"""Chat (notebook chat + source chat) — store, API surface, and cross-owner isolation.

Three layers, all with fakes (no real Azure/DB):
  * InMemoryScopedRepo — a repo fake that REALLY applies the owner/scope predicate and the
    handful of UPDATE/DELETE statements ChatStore issues, so the leak test is meaningful
    (mirrors tests/test_tenancy_isolation.py).
  * TestClient API tests — drive both routers end to end with dependency overrides, a stub
    ChatClient (no network) and a stub RetrievalService.
  * The leak test — proves one owner can never read another owner's sessions/messages.
"""

from __future__ import annotations

import re
from typing import Any, cast

import pytest
from fastapi.testclient import TestClient
from surrealdb import RecordID

from docx_app import deps
from docx_app.api.chat import router as chat_router
from docx_app.api.chat import source_chat_router
from docx_app.db import SurrealRepository, parse_record_ids
from docx_app.domain.chat import ChatMessage, ChatStore
from docx_app.main import app
from docx_app.tenancy import Principal, Scope

# Mount the routers under test exactly as the orchestrator will in main.py. Done at import
# (the app is module-global) so the TestClient sees /chat/* and /sources/{id}/chat/*. This
# does NOT modify main.py; it only makes these tests self-contained.
if not any(getattr(r, "path", "").startswith("/chat") for r in app.routes):
    app.include_router(chat_router)
    app.include_router(source_chat_router)


def _store(repo: "InMemoryScopedRepo") -> ChatStore:
    """ChatStore over the fake repo (the fake is structurally compatible with the methods
    ChatStore uses; cast keeps mypy --strict happy without a Protocol indirection)."""
    return ChatStore(cast(SurrealRepository, repo))


def test_to_message_unwraps_surreal_list_result() -> None:
    # The real SurrealRepository.create_scoped returns a single-element LIST ([{...}]);
    # _to_message must unwrap it. Regression: ChatMessage(**list) raised TypeError → the
    # whole /chat/execute and source-chat send 500'd before the LLM was even called.
    row = {"id": "chat_message:1", "type": "ai", "content": "hello", "order": 1}
    msg = ChatStore._to_message([row])
    assert isinstance(msg, ChatMessage)
    assert msg.content == "hello" and msg.type == "ai"
    # plain dicts (the per-row read path) still pass through unchanged
    assert ChatStore._to_message(row).content == "hello"


class InMemoryScopedRepo:
    """A repo fake that genuinely enforces the tenancy predicate + ChatStore's writes.

    It stores rows per table and implements exactly the operations ChatStore relies on:
      - create_scoped: stamp owner/scope + a synthetic id, return the row
      - select_scoped: apply focus (owner-only) + the `extra_where` equality filters the
        store uses (id/session/notebook/source = $var), plus ordering
      - query: the owner-scoped UPDATE ... MERGE / SET (update_session, touch_session)
      - delete_where: owner-scoped deletes (delete_session)
    """

    def __init__(self) -> None:
        self.tables: dict[str, list[dict[str, Any]]] = {}
        self._counter = 0

    def _next_id(self, table: str) -> str:
        self._counter += 1
        return f"{table}:{self._counter}"

    @staticmethod
    def _norm(value: Any) -> Any:
        """Canonical `table:id` for either a RecordID or a `table:id` string.

        Idempotent (unlike RecordID.parse → str, which double-wraps the id), so a value can be
        normalised on write AND on compare without drifting — the property the equality checks
        below rely on. Mirrors how SurrealDB compares record links by (table, id) identity.
        """
        if isinstance(value, RecordID):
            return (
                f"{value.table_name}:{value.id!s}"  # !s: id is Any (str/int), force str
            )
        if isinstance(value, str) and ":" in value:
            table, _, ident = value.partition(":")
            return f"{table}:{ident}"
        return value

    async def create_scoped(
        self, table: str, data: dict[str, Any], *, owner: str, scope: Scope
    ) -> dict[str, Any]:
        row = {
            **{
                k: self._norm(v) if k in {"notebook", "source", "session"} else v
                for k, v in data.items()
            },
            "id": self._next_id(table),
            "owner": owner,
            "scope": scope.value,
            "created": "2026-01-01T00:00:00+00:00",
            "updated": "2026-01-01T00:00:00+00:00",
        }
        self.tables.setdefault(table, []).append(row)
        return row

    async def select_scoped(
        self,
        table: str,
        principal: Principal,
        *,
        focus: bool = False,
        extra_where: str = "",
        order_by: str = "updated DESC",
        limit: int | None = None,
        vars: dict[str, Any] | None = None,
        notebook: str | None = None,
    ) -> list[dict[str, Any]]:
        rows = list(self.tables.get(table, []))

        # scope predicate
        def visible(r: dict[str, Any]) -> bool:
            if focus:
                return r.get("owner") == principal.owner
            return r.get("scope") == "org-common" or r.get("owner") == principal.owner

        rows = [r for r in rows if visible(r)]

        # extra_where: "<field> = $<var>" equality filters used by ChatStore
        if extra_where and vars:
            m = re.match(r"(\w+)\s*=\s*\$(\w+)", extra_where)
            if m:
                field, var = m.group(1), m.group(2)
                target = self._norm(vars[var])
                rows = [r for r in rows if self._norm(r.get(field)) == target]

        # ordering (only the two ChatStore uses)
        if order_by.startswith("order"):
            rows.sort(key=lambda r: r.get("order", 0))
        else:
            rows.sort(key=lambda r: str(r.get("updated", "")), reverse=True)

        return rows[: limit or len(rows)]

    async def query(
        self, query_str: str, vars: dict[str, Any] | None = None
    ) -> list[dict[str, Any]]:
        v = vars or {}
        # UPDATE chat_session MERGE $patch WHERE id = $sid AND owner = $owner
        if query_str.startswith("UPDATE chat_session MERGE"):
            self._apply_update("chat_session", v, v.get("patch", {}))
        elif query_str.startswith("UPDATE chat_session SET updated"):
            self._apply_update("chat_session", v, {"updated": v.get("now")})
        return []

    def _apply_update(
        self, table: str, v: dict[str, Any], patch: dict[str, Any]
    ) -> None:
        sid = self._norm(v.get("sid"))
        owner = v.get("owner")
        # The real SurrealRepository.query runs parse_record_ids (datetime → ISO string)
        # before rows reach the domain; mirror that so `updated` round-trips as a str.
        clean_patch = parse_record_ids(patch)
        for r in self.tables.get(table, []):
            if self._norm(r.get("id")) == sid and r.get("owner") == owner:
                r.update(clean_patch)

    async def delete_where(
        self, table: str, where: str, vars: dict[str, Any] | None = None
    ) -> None:
        v = vars or {}
        owner = v.get("owner")
        rows = self.tables.get(table, [])
        if "session = $sid" in where:
            sid = self._norm(v.get("sid"))
            self.tables[table] = [
                r
                for r in rows
                if not (self._norm(r.get("session")) == sid and r.get("owner") == owner)
            ]
        elif "id = $sid" in where:
            sid = self._norm(v.get("sid"))
            self.tables[table] = [
                r
                for r in rows
                if not (self._norm(r.get("id")) == sid and r.get("owner") == owner)
            ]


# ---------------------------------------------------------------------------
# Store-level unit tests (no HTTP) — owner stamping + scoping
# ---------------------------------------------------------------------------


async def test_session_and_messages_are_owner_private() -> None:
    repo = InMemoryScopedRepo()
    store = _store(repo)
    alice = Principal(owner="alice")
    session = await store.create_session(
        owner="alice", title="T", notebook="notebook:1"
    )
    # stamped owner-private (sessions never enter the shared brain)
    assert repo.tables["chat_session"][0]["owner"] == "alice"
    assert repo.tables["chat_session"][0]["scope"] == Scope.PRIVATE.value

    await store.append_message(
        session_id=session.id or "", owner="alice", type="human", content="hi", order=0
    )
    msgs = await store.list_messages(session.id or "", alice)
    assert [m.content for m in msgs] == ["hi"]
    assert repo.tables["chat_message"][0]["scope"] == Scope.PRIVATE.value


async def test_update_session_is_owner_scoped_merge() -> None:
    repo = InMemoryScopedRepo()
    store = _store(repo)
    alice = Principal(owner="alice")
    s = await store.create_session(owner="alice", title="old", notebook="notebook:1")
    updated = await store.update_session(s.id or "", alice, title="new", set_title=True)
    assert updated is not None and updated.title == "new"


# ---------------------------------------------------------------------------
# THE LEAK TEST — cross-owner isolation (FINAL_DESIGN §11)
# ---------------------------------------------------------------------------


async def test_chat_sessions_and_messages_never_leak_across_owners() -> None:
    repo = InMemoryScopedRepo()
    store = _store(repo)
    alice, bob = Principal(owner="alice"), Principal(owner="bob")

    alice_session = await store.create_session(
        owner="alice", title="alice-secret-chat", notebook="notebook:1"
    )
    await store.append_message(
        session_id=alice_session.id or "",
        owner="alice",
        type="human",
        content="alice-secret-message",
        order=0,
    )

    # Bob cannot read Alice's session even with its exact id...
    assert await store.get_session(alice_session.id or "", bob) is None
    # ...nor enumerate her messages...
    assert await store.list_messages(alice_session.id or "", bob) == []
    # ...nor patch it (owner-scoped MERGE is a no-op for the wrong owner).
    assert (
        await store.update_session(
            alice_session.id or "", bob, title="hijacked", set_title=True
        )
        is None
    )
    # The data is unchanged and still Alice's.
    alice_view = await store.get_session(alice_session.id or "", alice)
    assert alice_view is not None and alice_view.title == "alice-secret-chat"
    assert [
        m.content for m in await store.list_messages(alice_session.id or "", alice)
    ] == ["alice-secret-message"]
    # Bob's own listing for the same notebook id is empty (it isn't his notebook/session).
    assert await store.list_sessions_for_notebook("notebook:1", bob) == []


# ---------------------------------------------------------------------------
# API surface — both routers, with stub AI + retrieval (no network)
# ---------------------------------------------------------------------------


class StubChatClient:
    def __init__(self) -> None:
        self.calls: list[dict[str, str]] = []

    async def complete(self, *, system: str, user: str, max_tokens: int = 1000) -> str:
        self.calls.append({"system": system, "user": user})
        return "stub answer"


class StubRetrieval:
    def __init__(self, chunks: list[Any] | None = None) -> None:
        self._chunks = chunks or []

    async def search(self, query: str, principal: Any, **kwargs: Any) -> list[Any]:
        return self._chunks


@pytest.fixture
def ctx() -> Any:
    repo = InMemoryScopedRepo()
    chat = StubChatClient()
    retrieval = StubRetrieval()
    app.dependency_overrides[deps.get_principal] = lambda: Principal(owner="u1")
    app.dependency_overrides[deps.get_repository] = lambda: repo
    app.dependency_overrides[deps.get_chat_client] = lambda: chat
    app.dependency_overrides[deps.get_retrieval_service] = lambda: retrieval
    client = TestClient(app)
    yield client, repo, chat
    app.dependency_overrides.clear()


def _seed_notebook(repo: InMemoryScopedRepo, owner: str = "u1") -> str:
    repo.tables.setdefault("notebook", []).append(
        {"id": "notebook:1", "name": "W", "owner": owner, "scope": "private"}
    )
    return "notebook:1"


def _seed_source(repo: InMemoryScopedRepo, owner: str = "u1") -> str:
    repo.tables.setdefault("source", []).append(
        {
            "id": "source:1",
            "title": "Doc",
            "full_text": "the answer is 42",
            "owner": owner,
            "scope": "org-common",
        }
    )
    return "source:1"


# --- notebook chat -----------------------------------------------------------


def test_create_list_get_session(ctx: Any) -> None:
    client, repo, _ = ctx
    _seed_notebook(repo)
    created = client.post(
        "/chat/sessions", json={"notebook_id": "notebook:1", "title": "Hi"}
    )
    assert created.status_code == 200
    body = created.json()
    assert body["title"] == "Hi"
    assert body["notebook_id"] == "notebook:1"
    assert body["message_count"] == 0
    sid = body["id"]

    listing = client.get("/chat/sessions", params={"notebook_id": "notebook:1"})
    assert listing.status_code == 200 and len(listing.json()) == 1

    got = client.get(f"/chat/sessions/{sid}")
    assert got.status_code == 200 and got.json()["messages"] == []


def test_create_session_unknown_notebook_404(ctx: Any) -> None:
    client, repo, _ = ctx
    resp = client.post("/chat/sessions", json={"notebook_id": "notebook:999"})
    assert resp.status_code == 404


def test_execute_persists_turn_and_returns_messages(ctx: Any) -> None:
    client, repo, chat = ctx
    _seed_notebook(repo)
    sid = client.post("/chat/sessions", json={"notebook_id": "notebook:1"}).json()["id"]
    resp = client.post(
        "/chat/execute",
        json={"session_id": sid, "message": "what is up?", "context": {}},
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["session_id"] == sid
    assert [m["type"] for m in data["messages"]] == ["human", "ai"]
    assert data["messages"][1]["content"] == "stub answer"
    # the AI was actually called once
    assert len(chat.calls) == 1
    # a second turn appends, preserving history (4 messages total)
    resp2 = client.post(
        "/chat/execute",
        json={"session_id": sid, "message": "again", "context": {}},
    )
    assert [m["type"] for m in resp2.json()["messages"]] == [
        "human",
        "ai",
        "human",
        "ai",
    ]


def test_execute_blank_message_400(ctx: Any) -> None:
    client, repo, _ = ctx
    _seed_notebook(repo)
    sid = client.post("/chat/sessions", json={"notebook_id": "notebook:1"}).json()["id"]
    assert (
        client.post(
            "/chat/execute", json={"session_id": sid, "message": "  ", "context": {}}
        ).status_code
        == 400
    )


def test_execute_missing_session_404(ctx: Any) -> None:
    client, _, _ = ctx
    resp = client.post(
        "/chat/execute",
        json={"session_id": "chat_session:999", "message": "hi", "context": {}},
    )
    assert resp.status_code == 404


def test_update_and_delete_session(ctx: Any) -> None:
    client, repo, _ = ctx
    _seed_notebook(repo)
    sid = client.post("/chat/sessions", json={"notebook_id": "notebook:1"}).json()["id"]
    upd = client.put(f"/chat/sessions/{sid}", json={"title": "Renamed"})
    assert upd.status_code == 200 and upd.json()["title"] == "Renamed"
    assert client.delete(f"/chat/sessions/{sid}").status_code == 200
    assert client.get(f"/chat/sessions/{sid}").status_code == 404


def test_build_context_returns_notebook_sources(ctx: Any) -> None:
    client, repo, _ = ctx
    _seed_notebook(repo)
    repo.tables.setdefault("source", []).append(
        {
            "id": "source:1",
            "title": "Doc",
            "full_text": "hello body",
            "owner": "u1",
            "scope": "org-common",
            "notebook": "notebook:1",
        }
    )
    resp = client.post(
        "/chat/context", json={"notebook_id": "notebook:1", "context_config": {}}
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["context"]["notes"] == []
    assert len(data["context"]["sources"]) == 1
    assert data["char_count"] > 0
    assert data["token_count"] == data["char_count"] // 4


# --- source chat -------------------------------------------------------------


def test_source_chat_session_lifecycle_and_message(ctx: Any) -> None:
    client, repo, chat = ctx
    _seed_source(repo)
    created = client.post(
        "/sources/source:1/chat/sessions",
        json={"source_id": "1", "title": "SrcChat"},
    )
    assert created.status_code == 200
    sid = created.json()["id"]
    assert created.json()["source_id"] == "source:1"

    listing = client.get("/sources/source:1/chat/sessions")
    assert listing.status_code == 200 and len(listing.json()) == 1

    got = client.get(f"/sources/source:1/chat/sessions/{sid}")
    assert got.status_code == 200
    assert got.json()["context_indicators"]["sources"] == ["source:1"]

    sent = client.post(
        f"/sources/source:1/chat/sessions/{sid}/messages",
        json={"message": "what is the answer?"},
    )
    assert sent.status_code == 200
    data = sent.json()
    assert [m["type"] for m in data["messages"]] == ["human", "ai"]
    assert data["messages"][1]["content"] == "stub answer"
    # the source's own text was put into the prompt (source chat grounds on the document)
    assert "the answer is 42" in chat.calls[-1]["user"]


def test_source_chat_unknown_source_404(ctx: Any) -> None:
    client, _, _ = ctx
    resp = client.post("/sources/source:999/chat/sessions", json={"source_id": "999"})
    assert resp.status_code == 404


def test_source_chat_session_must_match_source(ctx: Any) -> None:
    client, repo, _ = ctx
    _seed_source(repo)
    # a session attached to a DIFFERENT source must 404 under source:1's path
    repo.tables.setdefault("source", []).append(
        {"id": "source:2", "title": "Other", "owner": "u1", "scope": "org-common"}
    )
    other = client.post(
        "/sources/source:2/chat/sessions", json={"source_id": "2"}
    ).json()["id"]
    resp = client.get(f"/sources/source:1/chat/sessions/{other}")
    assert resp.status_code == 404
