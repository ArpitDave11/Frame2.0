"""Chunk-level cross-owner isolation — enforced in CI without a live DB.

The live integration test proves this against real SurrealDB but skips when no DB is
reachable. This double applies the SAME scope semantics the vector-search SQL encodes
(focus=False keeps the org-common arm; focus=True is own-only), so a regression in
`build_vector_search`'s predicate fails CI every run, not only when a DB happens to be up.
"""

from __future__ import annotations

from docx_app.retrieval.service import RetrievalService
from docx_app.tenancy import Principal

_CHUNKS = [
    {
        "id": "source_chunk:a",
        "source": "source:a",
        "owner": "alice",
        "scope": "private",
        "content": "alice secret",
    },
    {
        "id": "source_chunk:b",
        "source": "source:b",
        "owner": "bob",
        "scope": "private",
        "content": "bob secret",
    },
    {
        "id": "source_chunk:c",
        "source": "source:c",
        "owner": "alice",
        "scope": "org-common",
        "content": "shared",
    },
]


class _EnforcingChunkRepo:
    """Applies the scope rule the vector-search SQL would, by reading its WHERE clause."""

    def __init__(self, chunks):
        self._chunks = chunks

    async def query(self, sql, vars=None):
        owner = vars["owner"]
        keeps_common = "org-common" in sql  # focus=False retains the shared arm

        def visible(c):
            if keeps_common:
                return c["scope"] == "org-common" or c["owner"] == owner
            return c["owner"] == owner

        return [
            {
                "id": c["id"],
                "source": c["source"],
                "content": c["content"],
                "score": 1.0,
            }
            for c in self._chunks
            if visible(c)
        ]


class _Embedder:
    async def embed(self, texts):
        return [[1.0, 0.0]]


def _svc():
    return RetrievalService(_EnforcingChunkRepo(_CHUNKS), _Embedder())


async def test_default_search_excludes_other_owners_private():
    out = {
        c.content for c in await _svc().search("q", Principal(owner="bob"), focus=False)
    }
    assert "alice secret" not in out  # private never leaks across owners
    assert "shared" in out  # common brain visible
    assert "bob secret" in out  # own private visible in default view


async def test_focus_search_is_own_only():
    out = {
        c.content for c in await _svc().search("q", Principal(owner="bob"), focus=True)
    }
    assert out == {"bob secret"}
