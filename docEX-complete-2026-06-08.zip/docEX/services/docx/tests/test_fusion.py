"""Reciprocal Rank Fusion — pure."""

from docx_app.retrieval.fusion import reciprocal_rank_fusion


def test_empty_input_returns_empty():
    assert reciprocal_rank_fusion([]) == []
    assert reciprocal_rank_fusion([[], []]) == []


def test_fuses_two_lists_rewarding_agreement_and_rank():
    a = ["x", "y", "z"]  # x best
    b = ["y", "w", "x"]  # y best
    fused = reciprocal_rank_fusion([a, b], k=60)
    ids = [i for i, _ in fused]
    scores = dict(fused)

    assert set(ids) == {"x", "y", "z", "w"}  # union of candidates
    # items appearing in both lists outrank items in only one
    assert scores["x"] > scores["z"]
    assert scores["y"] > scores["w"]
    # y (rank0 + rank1) beats x (rank0 + rank2)
    assert scores["y"] > scores["x"]
    assert ids[0] == "y"
