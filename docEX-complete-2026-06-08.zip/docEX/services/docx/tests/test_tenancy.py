"""Tenancy + collective-brain scoping (the LOCKED defaults)."""

import pytest

from docx_app.tenancy import (
    Principal,
    Scope,
    default_write_scope,
    principal_from_claims,
    read_scopes,
    surreal_scope_predicate,
)


def test_principal_from_oid():
    p = principal_from_claims({"oid": "u1", "email": "a@b.com", "name": "A"})
    assert p.owner == "u1"
    assert p.email == "a@b.com"


def test_principal_from_sub_fallback():
    assert principal_from_claims({"sub": "u2"}).owner == "u2"


def test_principal_requires_identity():
    with pytest.raises(ValueError):
        principal_from_claims({"email": "x@y.com"})


def test_default_write_scope_is_common():
    # LOCKED: uploads enrich the common brain by default
    assert default_write_scope() == Scope.ORG_COMMON


def test_read_default_includes_common():
    scopes = read_scopes(focus=False)
    assert Scope.ORG_COMMON in scopes and Scope.PRIVATE in scopes


def test_read_focus_is_private_only():
    assert read_scopes(focus=True) == [Scope.PRIVATE]


def test_scope_predicate():
    p = Principal(owner="u1")
    assert "org-common" in surreal_scope_predicate(p, focus=False)
    assert surreal_scope_predicate(p, focus=True) == "owner = $owner"
