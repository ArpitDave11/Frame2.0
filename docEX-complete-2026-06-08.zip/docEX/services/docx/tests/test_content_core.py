"""ContentCoreEngine against the REAL content-core library (offline, text/markdown).

Proves the adapter matches content-core's actual contract (extract_content → .content),
so the light path (txt/md/url/audio/video + universal fallback) genuinely works now that
the dependency is installed — not just behind a fake.
"""

import os
import tempfile

import pytest

from docx_app.extraction.engines.base import EngineExtractionError
from docx_app.extraction.engines.content_core import ContentCoreEngine
from docx_app.extraction.models import EngineName, ExtractInput, ExtractStatus


async def test_extracts_local_markdown_file():
    fd, path = tempfile.mkstemp(suffix=".md")
    try:
        os.write(fd, b"# Q3 Report\n\nThe quarterly revenue grew by 12 percent.")
        os.close(fd)
        doc = await ContentCoreEngine().extract(
            ExtractInput(filename="q3.md", file_path=path)
        )
        assert "quarterly revenue grew" in doc.markdown
        assert doc.engine_used == EngineName.CONTENT_CORE
        assert doc.status == ExtractStatus.SUCCESS
    finally:
        if os.path.exists(path):
            os.unlink(path)


async def test_falls_back_to_raw_text_for_unsupported_textual_type():
    # content-core raises UnsupportedTypeException for application/json; the engine must
    # contain it and fall back to the raw UTF-8 text (else the API 500s). Regression guard.
    fd, path = tempfile.mkstemp(suffix=".json")
    try:
        os.write(fd, b'{"project":"Atlas","revenue_growth":"18 percent"}')
        os.close(fd)
        doc = await ContentCoreEngine().extract(
            ExtractInput(filename="d.json", file_path=path)
        )
        assert "Atlas" in doc.markdown and "18 percent" in doc.markdown
        assert doc.engine_used == EngineName.CONTENT_CORE
    finally:
        if os.path.exists(path):
            os.unlink(path)


async def test_binary_unsupported_raises_clean_engine_error():
    # A non-UTF-8 binary (no text fallback) must surface a clean EngineExtractionError so
    # the router converts it to a 422 — never an uncaught 500.
    fd, path = tempfile.mkstemp(suffix=".bin")
    try:
        os.write(
            fd, bytes([0x89, 0x50, 0x4E, 0x47, 0xFF, 0xFE, 0x00, 0x01, 0x9C, 0xA3])
        )
        os.close(fd)
        with pytest.raises(EngineExtractionError):
            await ContentCoreEngine().extract(
                ExtractInput(filename="x.bin", file_path=path)
            )
    finally:
        if os.path.exists(path):
            os.unlink(path)
