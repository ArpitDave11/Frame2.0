"""Supplementary Notebook-HLD compose tests — the two §9 matrix rows that need an
*explicit* assertion the primary suite leaves implicit (Surface 2).

Sub-design: ``docs/2026-06-07-entity-resolution-subdesign.md`` §9 test matrix. The primary
``test_compose.py`` exercises topology/tenancy/idempotency thoroughly, but two enumerated
matrix rows are only covered *implicitly* there:

  * **controlled-vocab → "used directly, no reconciliation"** — ``test_compose.py`` passes
    ``chat=None``, so a Path-C node that *leaked* into the Path-B cascade would still resolve
    deterministically (via normalize) and the assertions would pass anyway. That does NOT
    prove the reconciler was bypassed. Here we monkeypatch
    :func:`docx_app.diagram.compose.reconcile_node` to a tripwire and assert it is **never
    called** when every node is born with an ``entity`` key — the actual §9 "no reconciliation"
    guarantee. The complementary direction (a node *without* a key DOES reach the reconciler)
    is asserted too, so the tripwire can't pass vacuously.

  * **homonym (kind mismatch) at compose level** — ``test_entity_reconciler.py`` proves the
    kind guard for a single ``reconcile_node`` call, but the §9 homonym row's HLD consequence
    is "two same-label, different-kind nodes across two sources must NOT false-merge into one
    bridge." We assert that end-to-end through ``compose_notebook_hld`` (kind read from
    ``meta.kind``): two ``Manager`` nodes (actor vs service), no entity keys, empty registry →
    two distinct singleton entities → **no** bridge. This is the false-merge the whole
    sub-design exists to prevent, asserted at the surface the user sees.

All deterministic, no network, table-aware owner-scoped fake (mirrors ``test_compose.py`` /
``test_diagram.py``). ``asyncio_mode="auto"`` — no per-test marker.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any


import docx_app.diagram.compose as compose_mod
from docx_app.db import ensure_record_id
from docx_app.diagram.compose import compose_notebook_hld
from docx_app.diagram.model import DiagramGraph
from docx_app.diagram.reconciler import Assignment, NodeRef
from docx_app.tenancy import Principal

P = Principal(owner="u1")


def _id_eq(row_id: Any, want: Any) -> bool:
    """RecordID-aware id equality (the store binds ``ensure_record_id(...)`` as the var)."""
    a = ensure_record_id(str(row_id)) if not hasattr(row_id, "table_name") else row_id
    b = ensure_record_id(str(want)) if not hasattr(want, "table_name") else want
    return (a.table_name, str(a.id)) == (b.table_name, str(b.id))


def _source_graph(nodes: list[dict[str, Any]]) -> dict[str, Any]:
    """A stored graph_json dict with every required field set (edges empty)."""
    full_nodes = [
        {
            "id": n["id"],
            "label": n.get("label", n["id"].title()),
            "type": n.get("type", "service"),
            "description": n.get("description"),
            "groupId": None,
            "shape": n.get("shape"),
            "icon": None,
            "link": None,
            "drill": None,
            "entity": n.get("entity"),
            "meta": n.get("meta"),
        }
        for n in nodes
    ]
    return {"groups": [], "nodes": full_nodes, "edges": []}


def _diagram_row(
    diagram_id: str, source_ref: str, graph_json: dict[str, Any]
) -> dict[str, Any]:
    return {
        "id": diagram_id,
        "owner": "u1",
        "scope": "private",
        "surface": "source",
        "ref": source_ref,
        "status": "accepted",
        "graph_json": graph_json,
        "render_snapshot_svg": None,
        "version": 1,
    }


def _source_row(source_id: str, notebook_id: str) -> dict[str, Any]:
    return {
        "id": source_id,
        "owner": "u1",
        "scope": "private",
        "notebook": notebook_id,
        "title": source_id.split(":", 1)[-1].title(),
    }


class ComposeRepo:
    """Table-aware, owner-scoped, RecordID-aware fake for compose's three tables.

    Identical contract to ``test_compose.py``'s fake (diagram / source / notebook_entity);
    ``create_scoped`` returns a single-element LIST (exercises the unwrap), ``select_scoped``
    applies the owner filter on ``focus=True`` reads.
    """

    def __init__(
        self,
        *,
        diagrams: list[dict[str, Any]] | None = None,
        sources: list[dict[str, Any]] | None = None,
        entities: list[dict[str, Any]] | None = None,
    ) -> None:
        self.tables: dict[str, list[dict[str, Any]]] = {
            "diagram": list(diagrams or []),
            "source": list(sources or []),
            "notebook_entity": list(entities or []),
        }
        self.created: list[dict[str, Any]] = []
        self._counter = 0

    async def create_scoped(
        self, table: str, data: dict[str, Any], *, owner: str, scope: Any
    ) -> list[dict[str, Any]]:
        self._counter += 1
        row = {
            **data,
            "id": f"{table}:new{self._counter}",
            "owner": owner,
            "scope": scope.value,
        }
        self.created.append(row)
        self.tables.setdefault(table, []).append(row)
        return [row]

    async def select_scoped(
        self,
        table: str,
        principal: Principal,
        *,
        focus: bool = False,
        extra_where: str = "",
        order_by: str = "updated DESC",
        limit: int | None = None,
        vars: dict[str, Any] | None = None,
        notebook: Any = None,
    ) -> list[dict[str, Any]]:
        rows = list(self.tables.get(table, []))
        if focus:
            rows = [r for r in rows if r.get("owner") == principal.owner]
        v = vars or {}
        if "surface" in v:
            rows = [r for r in rows if r.get("surface") == v["surface"]]
        if "ref" in v:
            rows = [r for r in rows if r.get("ref") == v["ref"]]
        if "nb" in v:
            rows = [r for r in rows if r.get("notebook_id") == v["nb"]]
        if "key" in v:
            rows = [r for r in rows if r.get("entity_key") == v["key"]]
        for id_var in ("did", "eid", "sid", "nid"):
            if id_var in v:
                rows = [r for r in rows if _id_eq(r.get("id"), v[id_var])]
        if limit is not None:
            rows = rows[:limit]
        return rows

    async def query(
        self, query: str, vars: dict[str, Any] | None = None
    ) -> list[dict[str, Any]]:
        v = vars or {}
        for table_rows in self.tables.values():
            for row in table_rows:
                if _id_eq(row.get("id"), v.get("rid")) and row.get("owner") == v.get(
                    "owner"
                ):
                    for key, value in v.items():
                        if key in ("rid", "owner"):
                            continue
                        row[key] = (
                            value.isoformat()
                            if isinstance(value, datetime)
                            else value
                        )
                    return [dict(row)]
        return []

    async def delete_where(
        self, table: str, where: str, vars: dict[str, Any] | None = None
    ) -> None:
        v = vars or {}
        self.tables[table] = [
            r
            for r in self.tables.get(table, [])
            if not (
                _id_eq(r.get("id"), v.get("eid")) and r.get("owner") == v.get("owner")
            )
        ]


def _bridge_nodes(graph: DiagramGraph) -> list[Any]:
    return [n for n in graph.nodes if (n.meta or {}).get("shared")]


# =========================================================================== #
# §9 "controlled-vocab → used directly, no reconciliation" — proven by tripwire.
# =========================================================================== #
async def test_controlled_vocab_nodes_never_invoke_the_reconciler(
    monkeypatch: Any,
) -> None:
    """Every node born with an ``entity`` key resolves via Path C — ``reconcile_node`` is
    NEVER called (the §9 "used directly, no reconciliation" guarantee).

    A bare ``chat=None`` test can't prove this (a leaked Path-C node would still resolve via
    normalize and pass), so we replace ``compose.reconcile_node`` with a tripwire that fails
    the test if Path B is ever entered for a controlled-vocab node.
    """
    calls: list[NodeRef] = []

    async def _tripwire(node: NodeRef, *args: Any, **kwargs: Any) -> Assignment:
        calls.append(node)
        raise AssertionError(
            f"Path-B reconcile_node was called for a controlled-vocab node {node.label!r} "
            "— controlled-vocab nodes must be used directly (sub-design §9)."
        )

    monkeypatch.setattr(compose_mod, "reconcile_node", _tripwire)

    g1 = _source_graph([{"id": "n1", "label": "Customer", "entity": "customer"}])
    g2 = _source_graph([{"id": "n2", "label": "Client", "entity": "customer"}])  # diff label
    repo = ComposeRepo(
        diagrams=[
            _diagram_row("diagram:1", "source:1", g1),
            _diagram_row("diagram:2", "source:2", g2),
        ],
        sources=[
            _source_row("source:1", "notebook:1"),
            _source_row("source:2", "notebook:1"),
        ],
        entities=[
            {
                "id": "notebook_entity:1", "owner": "u1", "scope": "private",
                "notebook_id": "notebook:1", "entity_key": "customer",
                "canonical_label": "Customer", "aliases": [],
                "source_refs": ["source:1", "source:2"], "locked": False,
            }
        ],
    )
    result = await compose_notebook_hld(repo, P, notebook_id="notebook:1", chat=None)
    assert calls == []  # tripwire never fired → no reconciliation for Path C
    # Both nodes bridged via the SAME registry key even though labels differ ("Customer" vs
    # "Client") — proving the key, not the label, drove the merge (the Path-C contract).
    assert result.graph is not None
    bridges = _bridge_nodes(result.graph)
    assert len(bridges) == 1
    assert bridges[0].entity == "customer"
    # And: the assignment method is recorded as controlled_vocab (not exact/alias/llm).
    assert {a.method for a in result.assignments} == {"controlled_vocab"}


async def test_node_without_entity_key_does_reach_the_reconciler(
    monkeypatch: Any,
) -> None:
    """Complement to the tripwire test: a node lacking an ``entity`` key DOES enter Path B.

    Without this, the tripwire test could pass vacuously (e.g. if the entity branch were
    inverted). Here a single keyless node must call ``reconcile_node`` exactly once.
    """
    calls: list[NodeRef] = []

    async def _spy(node: NodeRef, *args: Any, **kwargs: Any) -> Assignment:
        calls.append(node)
        # Return a deterministic 'new' assignment so compose proceeds normally.
        return Assignment(
            entity_key="payment-gateway", method="new", confidence=1.0, is_new=True
        )

    monkeypatch.setattr(compose_mod, "reconcile_node", _spy)

    g1 = _source_graph([{"id": "n1", "label": "Payment Gateway"}])  # no entity key
    repo = ComposeRepo(
        diagrams=[_diagram_row("diagram:1", "source:1", g1)],
        sources=[_source_row("source:1", "notebook:1")],
        entities=[],
    )
    await compose_notebook_hld(repo, P, notebook_id="notebook:1", chat=None)
    assert len(calls) == 1
    assert calls[0].label == "Payment Gateway"


# =========================================================================== #
# §9 homonym row — the kind-split asserted END-TO-END through compose.
# =========================================================================== #
async def test_homonym_same_label_diff_kind_does_not_false_bridge() -> None:
    """Two ``Manager`` nodes (actor vs service), no entity keys, empty registry → NO bridge.

    This is the §9 homonym row at the surface the user sees: naive label-normalization would
    merge both ``Manager`` nodes into one shared entity (a wrong cross-source edge). Because
    the kind guard is universal (sub-design §5) and compose reads ``kind`` from ``meta.kind``,
    the two SHOULD register as DISTINCT entities → each a singleton → no bridge node emitted.
    ``chat=None`` so the ambiguous tail is never guessed (the fail-safe).

    The reconciler mints a DISTINCT key on the homonym slug collision (Step-4 guard), so the
    two register as separate entities → each a singleton → no bridge node emitted.
    """
    g1 = _source_graph(
        [{"id": "n1", "label": "Manager", "meta": {"kind": "actor"}}]
    )
    g2 = _source_graph(
        [{"id": "n2", "label": "Manager", "meta": {"kind": "service"}}]
    )
    repo = ComposeRepo(
        diagrams=[
            _diagram_row("diagram:1", "source:1", g1),
            _diagram_row("diagram:2", "source:2", g2),
        ],
        sources=[
            _source_row("source:1", "notebook:1"),
            _source_row("source:2", "notebook:1"),
        ],
        entities=[],  # empty — Path B must keep the homonyms apart
    )
    result = await compose_notebook_hld(repo, P, notebook_id="notebook:1", chat=None)
    assert result.graph is not None
    # No false bridge: the two same-label, different-kind nodes did NOT merge.
    assert _bridge_nodes(result.graph) == []
    assert result.bridge_count == 0
    # Two distinct entities were registered (one per kind), not one shared.
    created_keys = [r["entity_key"] for r in repo.created if r.get("entity_key")]
    assert len(created_keys) == 2  # the homonym split happened


async def test_homonym_same_label_same_kind_does_bridge() -> None:
    """Guard against over-blocking: two ``Manager`` nodes of the SAME kind DO bridge.

    The kind guard must not break the legitimate merge — two ``Manager`` service nodes across
    two sources are the same entity and must become one bridge (the positive control for the
    homonym test above).
    """
    g1 = _source_graph(
        [{"id": "n1", "label": "Manager", "meta": {"kind": "service"}}]
    )
    g2 = _source_graph(
        [{"id": "n2", "label": "Manager", "meta": {"kind": "service"}}]
    )
    repo = ComposeRepo(
        diagrams=[
            _diagram_row("diagram:1", "source:1", g1),
            _diagram_row("diagram:2", "source:2", g2),
        ],
        sources=[
            _source_row("source:1", "notebook:1"),
            _source_row("source:2", "notebook:1"),
        ],
        entities=[],
    )
    result = await compose_notebook_hld(repo, P, notebook_id="notebook:1", chat=None)
    assert result.graph is not None
    bridges = _bridge_nodes(result.graph)
    assert len(bridges) == 1  # same kind → converged to one shared entity
    assert result.bridge_count == 1
    # Exactly one entity registered (the second node matched the first via normalize).
    created_keys = [r["entity_key"] for r in repo.created if r.get("entity_key")]
    assert len(created_keys) == 1
