"""Cross-owner / cross-scope isolation — the locked collective-brain guarantee.

This is the test FINAL_DESIGN §11 mandates ("a test that fails on an unscoped query").
Unlike the endpoint fakes, InMemoryScopedRepo ACTUALLY applies the owner/scope predicate,
so a private doc leaking across owners would fail here. It mirrors build_scoped_select:
    default (focus=False): scope == 'org-common'  OR  owner == me   (common brain + own)
    focus=True           : owner == me                              (only my own)
"""

from __future__ import annotations

from docx_app.db import ensure_record_id
from docx_app.domain.source import Source, SourceStore
from docx_app.tenancy import Principal, Scope


class InMemoryScopedRepo:
    """A repo fake that really enforces the tenancy predicate."""

    def __init__(self) -> None:
        self._rows: list[dict] = []

    async def create_scoped(self, table, data, *, owner, scope):
        row = {
            **data,
            "id": f"{table}:{len(self._rows) + 1}",
            "owner": owner,
            "scope": scope.value,
        }
        self._rows.append(row)
        return row

    async def select_scoped(
        self,
        table,
        principal,
        *,
        focus=False,
        extra_where="",
        order_by="updated DESC",
        limit=None,
        vars=None,
        notebook=None,
    ):
        def visible(r: dict) -> bool:
            if focus:  # Private/Focus → only the user's own
                return r["owner"] == principal.owner
            return r["scope"] == "org-common" or r["owner"] == principal.owner

        rows = [r for r in self._rows if r["id"].startswith(f"{table}:") and visible(r)]
        if vars and "sid" in vars:  # SourceStore.get → extra_where "id = $sid"
            # Real SurrealDB compares RecordIDs; normalise both sides identically.
            target = str(ensure_record_id(vars["sid"]))
            rows = [r for r in rows if str(ensure_record_id(r["id"])) == target]
        return rows[: limit or len(rows)]


async def _seed(store: SourceStore) -> Source:
    alice_private = await store.create(
        owner="alice", scope=Scope.PRIVATE, title="alice-secret"
    )
    await store.create(owner="bob", scope=Scope.PRIVATE, title="bob-secret")
    await store.create(owner="alice", scope=Scope.ORG_COMMON, title="shared-doc")
    return alice_private


async def test_private_docs_never_leak_across_owners():
    store = SourceStore(InMemoryScopedRepo())
    await _seed(store)
    bob = Principal(owner="bob")

    # Default (collective-brain) read for bob: org-common ∪ bob's own — never alice's private
    titles = {s.title for s in await store.list(bob, focus=False)}
    assert "shared-doc" in titles  # the common brain is shared
    assert "bob-secret" in titles  # own private surfaces in the default view
    assert "alice-secret" not in titles  # alice's PRIVATE must never leak to bob


async def test_focus_narrows_to_own_only():
    store = SourceStore(InMemoryScopedRepo())
    await _seed(store)

    bob_focus = {s.title for s in await store.list(Principal(owner="bob"), focus=True)}
    assert bob_focus == {"bob-secret"}  # not the shared common doc, not alice's private

    alice_focus = {
        s.title for s in await store.list(Principal(owner="alice"), focus=True)
    }
    assert alice_focus == {"alice-secret", "shared-doc"}  # both owned by alice


async def test_get_by_id_cannot_fetch_other_owners_private():
    store = SourceStore(InMemoryScopedRepo())
    alice_private = await _seed(store)

    # Even with the exact id, bob cannot read alice's private doc...
    assert (
        await store.get(alice_private.id, Principal(owner="bob"), focus=False) is None
    )
    # ...but alice can.
    got = await store.get(alice_private.id, Principal(owner="alice"), focus=False)
    assert got is not None and got.title == "alice-secret"
