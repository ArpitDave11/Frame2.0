"""LIVE SurrealDB integration — proves scoped vector search isolates private chunks.

Runs against a real SurrealDB in an ISOLATED namespace/database (`docx_it`), so it never
touches other data, and drops its table afterwards. Auto-skips if no DB is reachable.
This is the live proof behind the app-layer tenancy guarantee (FINAL_DESIGN §5/§11).
"""

from __future__ import annotations

import pytest

from docx_app.config import DocxConfig
from docx_app.db import SurrealRepository
from docx_app.domain.chunk import ChunkStore
from docx_app.migrate import apply_migrations
from docx_app.retrieval.search import Retriever
from docx_app.retrieval.service import RetrievalService
from docx_app.tenancy import Principal, Scope


class _FixedEmbedder:
    """Returns a fixed query vector (no Azure call) so the vector arm runs offline."""

    def __init__(self, vec):
        self._vec = vec

    async def embed(self, texts):
        return [self._vec for _ in texts]


async def _connect_or_skip() -> SurrealRepository:
    repo = SurrealRepository(_it_config())
    try:
        await repo.query("DEFINE NAMESPACE IF NOT EXISTS docx_it")
    except Exception as e:  # noqa: BLE001 - any connect/auth failure → skip
        pytest.skip(f"no reachable SurrealDB on localhost:8000 ({type(e).__name__})")
    await repo.query("DEFINE DATABASE IF NOT EXISTS docx_it")
    await repo.query("REMOVE TABLE IF EXISTS source_chunk")
    await repo.query(
        "REMOVE TABLE IF EXISTS docx_migration"
    )  # let migrations re-run fresh
    return repo


def _it_config() -> DocxConfig:
    return DocxConfig(
        service_name="docx-it",
        surreal_url="ws://localhost:8000/rpc",
        surreal_user="root",
        surreal_password="root",
        surreal_namespace="docx_it",  # isolated from any other namespace
        surreal_database="docx_it",
    )


async def test_live_scoped_vector_search_isolates_private_chunks():
    repo = SurrealRepository(_it_config())
    try:
        await repo.query("DEFINE NAMESPACE IF NOT EXISTS docx_it")
    except Exception as e:  # noqa: BLE001 - any connect/auth failure → skip, don't fail CI
        pytest.skip(f"no reachable SurrealDB on localhost:8000 ({type(e).__name__})")

    await repo.query("DEFINE DATABASE IF NOT EXISTS docx_it")
    await repo.query("REMOVE TABLE IF EXISTS source_chunk")  # clean slate
    try:
        store = ChunkStore(repo)
        # alice's PRIVATE chunk sits exactly on the query vector (the closest match).
        await store.replace_for_source(
            "source:a",
            ["alice secret"],
            [[1.0, 0.0, 0.0]],
            owner="alice",
            scope=Scope.PRIVATE,
        )
        await store.replace_for_source(
            "source:b",
            ["bob secret"],
            [[0.0, 1.0, 0.0]],
            owner="bob",
            scope=Scope.PRIVATE,
        )
        await store.replace_for_source(
            "source:c",
            ["shared handbook"],
            [[0.9, 0.1, 0.0]],
            owner="alice",
            scope=Scope.ORG_COMMON,
        )

        retriever = Retriever(repo)
        query_vec = [1.0, 0.0, 0.0]  # identical to alice's private chunk

        # Default (collective-brain) read for BOB.
        rows = await retriever.vector_search(
            query_vec,
            Principal(owner="bob"),
            focus=False,
            min_similarity=-1.0,
            limit=10,
        )
        contents = {r.get("content") for r in rows}
        assert (
            "alice secret" not in contents
        )  # PRIVATE never leaks — even as top vector hit
        assert "shared handbook" in contents  # the common brain is visible
        assert "bob secret" in contents  # own private surfaces in the default view

        # Focus read for BOB → only his own.
        own = await retriever.vector_search(
            query_vec, Principal(owner="bob"), focus=True, min_similarity=-1.0, limit=10
        )
        assert {r.get("content") for r in own} == {"bob secret"}

        # Sanity: ALICE, querying the same vector, does get her private chunk back.
        alice_rows = await retriever.vector_search(
            query_vec,
            Principal(owner="alice"),
            focus=True,
            min_similarity=-1.0,
            limit=10,
        )
        assert "alice secret" in {r.get("content") for r in alice_rows}
    finally:
        await repo.query("REMOVE TABLE IF EXISTS source_chunk")


async def test_live_bm25_keyword_search_is_scoped():
    repo = await _connect_or_skip()
    try:
        store = ChunkStore(repo)
        await store.replace_for_source(
            "source:a",
            ["alice confidential salary report"],
            [[1.0, 0.0, 0.0]],
            owner="alice",
            scope=Scope.PRIVATE,
        )
        await store.replace_for_source(
            "source:c",
            ["the company salary policy handbook"],
            [[0.0, 1.0, 0.0]],
            owner="alice",
            scope=Scope.ORG_COMMON,
        )
        await apply_migrations(
            repo
        )  # applies the real migrations/*.surql (schema + BM25 index)

        # bob keyword-searches "salary": gets the common doc, never alice's private
        rows = await Retriever(repo).keyword_search(
            "salary", Principal(owner="bob"), focus=False, limit=10
        )
        contents = {r.get("content") for r in rows}
        assert "the company salary policy handbook" in contents  # BM25 matched + common
        assert (
            "alice confidential salary report" not in contents
        )  # BM25 arm is scoped too
    finally:
        await repo.query("REMOVE TABLE IF EXISTS source_chunk")


async def test_live_hybrid_fuses_vector_and_bm25():
    repo = await _connect_or_skip()
    try:
        store = ChunkStore(repo)
        await store.replace_for_source(
            "source:c",
            ["the company salary policy handbook"],
            [[0.0, 1.0, 0.0]],
            owner="alice",
            scope=Scope.ORG_COMMON,
        )
        await store.replace_for_source(
            "source:b",
            ["bob private notes about vacation"],
            [[1.0, 0.0, 0.0]],
            owner="bob",
            scope=Scope.PRIVATE,
        )
        await apply_migrations(
            repo
        )  # applies the real migrations/*.surql (schema + BM25 index)

        # Query vector matches bob's own chunk; the term "salary" matches the common doc.
        svc = RetrievalService(repo, _FixedEmbedder([1.0, 0.0, 0.0]))
        out = await svc.search(
            "salary", Principal(owner="bob"), focus=False, min_similarity=-1.0
        )
        contents = {c.content for c in out}
        assert "bob private notes about vacation" in contents  # vector arm (own)
        assert "the company salary policy handbook" in contents  # BM25 arm (common)
    finally:
        await repo.query("REMOVE TABLE IF EXISTS source_chunk")
