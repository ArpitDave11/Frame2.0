"""Models + credentials slice — wire contract, secret masking, and a cross-owner LEAK test.

Two layers, mirroring tests/test_settings_system.py + tests/test_tenancy_isolation.py:
  - API tests (TestClient + dependency_overrides with a light fake repo) prove the wire
    contract matches the Open Notebook frontend (lib/api/models.ts + credentials.ts),
    including the SECURITY guarantee that an api_key is never echoed back.
  - The LEAK tests use InMemoryScopedRepo, which ACTUALLY applies the owner/scope predicate,
    proving one owner can never read/delete another owner's credentials, models, or
    default-model assignments — the locked tenancy guarantee for this slice.
"""

from __future__ import annotations

import re
from collections.abc import Iterator
from typing import Any, cast

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from docx_app import deps
from docx_app.api.credentials import router as credentials_router
from docx_app.api.models import router as models_router
from docx_app.db import SurrealRepository, ensure_record_id, parse_record_ids
from docx_app.domain.credential import (
    CredentialStore,
    ModelDefaultsStore,
    ModelDefaultsUpdate,
    ModelStore,
)
from docx_app.tenancy import Principal, Scope

# =============================================================================
# Fakes
# =============================================================================

# `<field> = $<key>` equality predicates used in extra_where (e.g. "id = $cid",
# "credential = $cid"). The InMemoryScopedRepo applies these the way the real DB binds them.
_RECORD_ID_PREDICATES = re.compile(r"(\w+)\s*=\s*\$(\w+)")


class FakeRepo:
    """API-level fake: records writes, returns canned rows. Does NOT enforce scoping
    (InMemoryScopedRepo below does that — this one just exercises the router/store path).
    """

    def __init__(self) -> None:
        self.created: list[dict[str, Any]] = []
        self.deletes: list[dict[str, Any]] = []
        self.queries: list[dict[str, Any]] = []
        self.selects: list[dict[str, Any]] = []
        # rows per table for scoped selects; falls back to `rows` when a table isn't seeded.
        self.table_rows: dict[str, list[dict[str, Any]]] = {}
        self.rows: list[dict[str, Any]] = []
        self.query_rows: list[dict[str, Any]] = []

    async def create_scoped(
        self, table: str, data: dict[str, Any], *, owner: str, scope: Scope
    ) -> dict[str, Any]:
        self.created.append(
            {"table": table, "data": data, "owner": owner, "scope": scope}
        )
        return parse_record_ids(
            {**data, "id": f"{table}:1", "owner": owner, "scope": scope.value}
        )

    async def select_scoped(
        self,
        table: str,
        principal: Principal,
        *,
        focus: bool = False,
        extra_where: str = "",
        order_by: str = "updated DESC",
        limit: int | None = None,
        vars: dict[str, Any] | None = None,
        notebook: str | None = None,
    ) -> list[dict[str, Any]]:
        self.selects.append(
            {"table": table, "focus": focus, "extra_where": extra_where, "vars": vars}
        )
        return parse_record_ids(self.table_rows.get(table, self.rows))

    async def query(
        self, query_str: str, vars: dict[str, Any] | None = None
    ) -> list[dict[str, Any]]:
        self.queries.append({"query": query_str, "vars": vars})
        return parse_record_ids(self.query_rows)

    async def delete_where(
        self, table: str, where: str, vars: dict[str, Any] | None = None
    ) -> None:
        self.deletes.append({"table": table, "where": where, "vars": vars})


class InMemoryScopedRepo:
    """A repo fake that REALLY enforces the tenancy predicate (mirrors test_tenancy_isolation).

    select_scoped(focus=True) → owner-only; delete_where(... owner = $owner) and the scoped
    UPDATE in `query` only touch the bound owner's rows. A leak would fail the assertions.
    """

    def __init__(self) -> None:
        self._rows: list[dict[str, Any]] = []
        self._seq = 0

    async def create_scoped(
        self, table: str, data: dict[str, Any], *, owner: str, scope: Scope
    ) -> dict[str, Any]:
        self._seq += 1
        row = {
            **data,
            "id": f"{table}:{self._seq}",
            "owner": owner,
            "scope": scope.value,
        }
        self._rows.append(row)
        # Mirror the real repo: RecordID/datetime values are normalised to primitives on
        # the way out (so e.g. a `credential` RecordID comes back as a str, like SurrealDB).
        return parse_record_ids(dict(row))

    async def select_scoped(
        self,
        table: str,
        principal: Principal,
        *,
        focus: bool = False,
        extra_where: str = "",
        order_by: str = "updated DESC",
        limit: int | None = None,
        vars: dict[str, Any] | None = None,
        notebook: str | None = None,
    ) -> list[dict[str, Any]]:
        def visible(r: dict[str, Any]) -> bool:
            if focus:  # Private/Focus → only the user's own
                return r["owner"] == principal.owner
            return r["scope"] == "org-common" or r["owner"] == principal.owner

        rows = [r for r in self._rows if r["id"].startswith(f"{table}:") and visible(r)]
        # Honour the equality filters the stores use, faithfully: parse `<field> = $<key>`
        # predicates out of extra_where and match each against its bound var (record-id
        # aware). This mirrors the real repo, where the SAME bound key (`$cid`) means
        # different fields depending on the clause (`id = $cid` vs `credential = $cid`).
        for field, key in _RECORD_ID_PREDICATES.findall(extra_where):
            if vars and key in vars:
                target = str(ensure_record_id(vars[key]))
                rows = [
                    r
                    for r in rows
                    if r.get(field) is not None
                    and str(ensure_record_id(r[field])) == target
                ]
        return [parse_record_ids(dict(r)) for r in rows[: limit or len(rows)]]

    async def query(
        self, query_str: str, vars: dict[str, Any] | None = None
    ) -> list[dict[str, Any]]:
        # The two `query` paths in this slice are both owner-scoped UPDATEs:
        #   CredentialStore.update          → "UPDATE credential SET ... WHERE id = $cid AND owner = $owner"
        #   CredentialStore.delete(migrate) → "UPDATE model SET credential = $target WHERE credential = $cid AND owner = $owner"
        # Match the right WHERE field, apply the SET, return the affected rows (RETURN AFTER).
        vars = vars or {}
        owner = vars.get("owner")
        cid = str(ensure_record_id(vars["cid"])) if "cid" in vars else None
        match_field = "credential" if "credential = $cid" in query_str else "id"
        # Parse the SET clause's "<column> = $<var>" pairs — the column name and the bound
        # var name DIFFER for the migrate UPDATE ("credential = $target"), so we must map them
        # (a naive col==var assumption silently writes the wrong field).
        set_clause = query_str.split(" SET ", 1)[1].split(" WHERE ", 1)[0]
        assignments = {
            col: var
            for col, var in _RECORD_ID_PREDICATES.findall(set_clause)
            if var in vars
        }
        updated: list[dict[str, Any]] = []
        for r in self._rows:
            if owner is not None and r.get("owner") != owner:
                continue
            current = r.get(match_field)
            if cid is not None and (
                current is None or str(ensure_record_id(current)) != cid
            ):
                continue
            for col, var in assignments.items():
                r[col] = vars[var]
            updated.append(r)
        return [parse_record_ids(dict(r)) for r in updated]

    async def delete_where(
        self, table: str, where: str, vars: dict[str, Any] | None = None
    ) -> None:
        vars = vars or {}
        owner = vars.get("owner")
        cid = str(ensure_record_id(vars["cid"])) if "cid" in vars else None

        def matches(r: dict[str, Any]) -> bool:
            if not r["id"].startswith(f"{table}:"):
                return False
            if owner is not None and r.get("owner") != owner:
                return False
            if "id = $cid" in where and cid is not None:
                return str(ensure_record_id(r["id"])) == cid
            if "credential = $cid" in where and cid is not None:
                return r.get("credential") is not None and (
                    str(ensure_record_id(r["credential"])) == cid
                )
            return True

        self._rows = [r for r in self._rows if not matches(r)]


# =============================================================================
# API fixtures
# =============================================================================


@pytest.fixture
def ctx() -> Iterator[tuple[TestClient, FakeRepo]]:
    # Build a self-contained app mounting only this slice's routers, so the tests don't
    # depend on main.py being wired yet (the orchestrator adds the include_router lines).
    # Behaviour is identical once they are wired — the routers + DI keys are the same.
    test_app = FastAPI()
    test_app.include_router(models_router)
    test_app.include_router(credentials_router)
    repo = FakeRepo()
    test_app.dependency_overrides[deps.get_principal] = lambda: Principal(owner="u1")
    test_app.dependency_overrides[deps.get_repository] = lambda: repo
    client = TestClient(test_app)
    yield client, repo
    test_app.dependency_overrides.clear()


# =============================================================================
# API: /models
# =============================================================================


def test_list_models_uses_owner_only_predicate(
    ctx: tuple[TestClient, FakeRepo],
) -> None:
    client, repo = ctx
    repo.table_rows["model"] = [
        {
            "id": "model:1",
            "name": "gpt-4o",
            "provider": "openai",
            "type": "language",
            "owner": "u1",
            "scope": "private",
            "created": "c",
            "updated": "u",
        }
    ]
    resp = client.get("/models")
    assert resp.status_code == 200
    body = resp.json()
    assert body[0]["name"] == "gpt-4o"
    assert body[0]["provider"] == "openai"
    assert body[0]["type"] == "language"
    # The read used the owner-only predicate (focus=True).
    assert repo.selects[0]["focus"] is True


def test_create_model_stamps_owner_and_normalises_provider(
    ctx: tuple[TestClient, FakeRepo],
) -> None:
    client, repo = ctx
    repo.table_rows["model"] = []  # no duplicate
    resp = client.post(
        "/models", json={"name": "GPT-4o", "provider": "OpenAI", "type": "language"}
    )
    assert resp.status_code == 200
    # Written PRIVATE, stamped to the caller, provider normalised to lower-case.
    created = repo.created[-1]
    assert created["owner"] == "u1"
    assert created["scope"] == Scope.PRIVATE
    assert created["data"]["provider"] == "openai"
    assert (
        "owner" not in created["data"]
    )  # framework columns added by the repo, not the body


def test_create_model_rejects_unsupported_provider(
    ctx: tuple[TestClient, FakeRepo],
) -> None:
    client, _ = ctx
    resp = client.post(
        "/models", json={"name": "claude", "provider": "anthropic", "type": "language"}
    )
    assert resp.status_code == 400
    assert "unsupported provider" in resp.json()["detail"]


def test_create_model_rejects_invalid_type(ctx: tuple[TestClient, FakeRepo]) -> None:
    client, _ = ctx
    resp = client.post(
        "/models", json={"name": "gpt-4o", "provider": "openai", "type": "vision"}
    )
    assert resp.status_code == 400
    assert "invalid model type" in resp.json()["detail"]


def test_create_model_rejects_duplicate(ctx: tuple[TestClient, FakeRepo]) -> None:
    client, repo = ctx
    # find_duplicate's scoped select returns an existing row → 400.
    repo.table_rows["model"] = [
        {"id": "model:1", "name": "gpt-4o", "provider": "openai", "type": "language"}
    ]
    resp = client.post(
        "/models", json={"name": "gpt-4o", "provider": "openai", "type": "language"}
    )
    assert resp.status_code == 400
    assert "already exists" in resp.json()["detail"]


def test_get_model_404_when_absent(ctx: tuple[TestClient, FakeRepo]) -> None:
    client, repo = ctx
    repo.table_rows["model"] = []
    resp = client.get("/models/model:doesnotexist")
    assert resp.status_code == 404


def test_delete_model_owner_scoped(ctx: tuple[TestClient, FakeRepo]) -> None:
    client, repo = ctx
    repo.table_rows["model"] = [
        {"id": "model:1", "name": "x", "provider": "openai", "type": "language"}
    ]
    resp = client.delete("/models/model:1")
    assert resp.status_code == 200
    # The delete carried the owner predicate + bound owner.
    deleted = repo.deletes[-1]
    assert deleted["table"] == "model"
    assert deleted["where"] == "id = $mid AND owner = $owner"
    assert deleted["vars"]["owner"] == "u1"


def test_model_defaults_get_returns_empty_when_none(
    ctx: tuple[TestClient, FakeRepo],
) -> None:
    client, repo = ctx
    repo.table_rows["model_defaults"] = []
    resp = client.get("/models/defaults")
    assert resp.status_code == 200
    body = resp.json()
    # All ON default-slot keys present, all null.
    assert body["default_chat_model"] is None
    assert "default_embedding_model" in body
    assert "default_tools_model" in body
    assert repo.selects[0]["focus"] is True  # owner-only read


def test_model_defaults_put_merges_and_stamps_private(
    ctx: tuple[TestClient, FakeRepo],
) -> None:
    client, repo = ctx
    repo.table_rows["model_defaults"] = []  # merge over empty defaults
    resp = client.put("/models/defaults", json={"default_chat_model": "model:abc"})
    assert resp.status_code == 200
    assert resp.json()["default_chat_model"] == "model:abc"
    created = repo.created[-1]
    assert created["table"] == "model_defaults"
    assert created["owner"] == "u1"
    assert created["scope"] == Scope.PRIVATE
    # Upsert deletes the owner's existing row first (owner-scoped).
    assert repo.deletes[-1]["where"] == "owner = $owner"
    assert repo.deletes[-1]["vars"] == {"owner": "u1"}


def test_model_providers_static_openai_azure(ctx: tuple[TestClient, FakeRepo]) -> None:
    client, _ = ctx
    resp = client.get("/models/providers")
    assert resp.status_code == 200
    body = resp.json()
    assert set(body["available"]) == {"openai", "azure"}
    assert body["unavailable"] == []
    assert "language" in body["supported_types"]["openai"]


def test_model_test_endpoint_validates_shape(ctx: tuple[TestClient, FakeRepo]) -> None:
    client, repo = ctx
    repo.table_rows["model"] = [
        {"id": "model:1", "name": "gpt-4o", "provider": "openai", "type": "language"}
    ]
    resp = client.post("/models/model:1/test")
    assert resp.status_code == 200
    body = resp.json()
    assert body["success"] is True
    assert "valid" in body["message"].lower()


# =============================================================================
# API: /credentials
# =============================================================================


def _seed_credential_row(owner: str = "u1", *, with_key: bool = True) -> dict[str, Any]:
    return {
        "id": "credential:1",
        "name": "My OpenAI",
        "provider": "openai",
        "modalities": ["language", "embedding"],
        "api_key": "sk-super-secret-DO-NOT-LEAK" if with_key else None,
        "base_url": None,
        "owner": owner,
        "scope": "private",
        "created": "c",
        "updated": "u",
    }


def test_create_credential_never_echoes_api_key(
    ctx: tuple[TestClient, FakeRepo],
) -> None:
    client, repo = ctx
    resp = client.post(
        "/credentials",
        json={
            "name": "My OpenAI",
            "provider": "openai",
            "modalities": ["language"],
            "api_key": "sk-super-secret-DO-NOT-LEAK",
        },
    )
    assert resp.status_code == 201
    body = resp.json()
    # SECURITY: response carries has_api_key but NEVER the key itself (or any field with it).
    assert body["has_api_key"] is True
    assert "api_key" not in body
    assert "sk-super-secret-DO-NOT-LEAK" not in resp.text
    # The secret was persisted (so it can be used), stamped owner + PRIVATE.
    created = repo.created[-1]
    assert created["data"]["api_key"] == "sk-super-secret-DO-NOT-LEAK"
    assert created["owner"] == "u1"
    assert created["scope"] == Scope.PRIVATE


def test_create_credential_defaults_modalities(
    ctx: tuple[TestClient, FakeRepo],
) -> None:
    client, repo = ctx
    resp = client.post(
        "/credentials", json={"name": "K", "provider": "azure", "api_key": "k"}
    )
    assert resp.status_code == 201
    # Empty modalities → provider defaults (azure → all four).
    assert set(repo.created[-1]["data"]["modalities"]) == {
        "language",
        "embedding",
        "speech_to_text",
        "text_to_speech",
    }


def test_create_credential_rejects_unsupported_provider(
    ctx: tuple[TestClient, FakeRepo],
) -> None:
    client, _ = ctx
    resp = client.post(
        "/credentials", json={"name": "K", "provider": "anthropic", "api_key": "k"}
    )
    assert resp.status_code == 400
    assert "unsupported provider" in resp.json()["detail"]


def test_create_credential_rejects_link_local_url(
    ctx: tuple[TestClient, FakeRepo],
) -> None:
    client, _ = ctx
    resp = client.post(
        "/credentials",
        json={
            "name": "K",
            "provider": "azure",
            "api_key": "k",
            "endpoint": "http://169.254.169.254/metadata",
        },
    )
    assert resp.status_code == 400
    assert "link-local" in resp.json()["detail"].lower()


def test_list_credentials_masks_keys_and_counts_models(
    ctx: tuple[TestClient, FakeRepo],
) -> None:
    client, repo = ctx
    repo.table_rows["credential"] = [_seed_credential_row()]
    # linked_model_count reads the model table; two linked models.
    repo.table_rows["model"] = [
        {"id": "model:1", "credential": "credential:1"},
        {"id": "model:2", "credential": "credential:1"},
    ]
    resp = client.get("/credentials")
    assert resp.status_code == 200
    body = resp.json()
    assert len(body) == 1
    assert body[0]["has_api_key"] is True
    assert body[0]["model_count"] == 2
    assert "api_key" not in body[0]
    assert "sk-super-secret-DO-NOT-LEAK" not in resp.text
    # Reads are owner-only.
    assert all(s["focus"] is True for s in repo.selects)


def test_get_credential_404(ctx: tuple[TestClient, FakeRepo]) -> None:
    client, repo = ctx
    repo.table_rows["credential"] = []
    resp = client.get("/credentials/credential:missing")
    assert resp.status_code == 404


def test_update_credential_only_sends_allowlisted_columns(
    ctx: tuple[TestClient, FakeRepo],
) -> None:
    client, repo = ctx
    repo.table_rows["credential"] = [_seed_credential_row()]
    # The scoped UPDATE returns the updated row.
    repo.query_rows = [{**_seed_credential_row(), "name": "Renamed"}]
    resp = client.put("/credentials/credential:1", json={"name": "Renamed"})
    assert resp.status_code == 200
    assert resp.json()["name"] == "Renamed"
    assert "api_key" not in resp.json()
    # The UPDATE statement is owner-scoped and only set the `name` column.
    upd = repo.queries[-1]
    assert "owner = $owner" in upd["query"]
    assert upd["vars"]["owner"] == "u1"
    assert upd["vars"]["name"] == "Renamed"


def test_update_credential_can_rotate_key_without_echo(
    ctx: tuple[TestClient, FakeRepo],
) -> None:
    client, repo = ctx
    repo.table_rows["credential"] = [_seed_credential_row()]
    repo.query_rows = [{**_seed_credential_row(), "api_key": "sk-rotated-secret"}]
    resp = client.put(
        "/credentials/credential:1", json={"api_key": "sk-rotated-secret"}
    )
    assert resp.status_code == 200
    # New key persisted via the bound UPDATE var, never returned in the response.
    assert repo.queries[-1]["vars"]["api_key"] == "sk-rotated-secret"
    assert "sk-rotated-secret" not in resp.text
    assert resp.json()["has_api_key"] is True


def test_delete_credential_cascades_models_owner_scoped(
    ctx: tuple[TestClient, FakeRepo],
) -> None:
    client, repo = ctx
    repo.table_rows["credential"] = [_seed_credential_row()]
    repo.table_rows["model"] = [{"id": "model:1", "credential": "credential:1"}]
    resp = client.delete("/credentials/credential:1")
    assert resp.status_code == 200
    assert resp.json()["deleted_models"] == 1
    # Both the model-cascade delete and the credential delete are owner-scoped.
    where_clauses = {d["where"] for d in repo.deletes}
    assert "credential = $cid AND owner = $owner" in where_clauses
    assert "id = $cid AND owner = $owner" in where_clauses
    assert all(d["vars"]["owner"] == "u1" for d in repo.deletes)


def test_delete_credential_404(ctx: tuple[TestClient, FakeRepo]) -> None:
    client, repo = ctx
    repo.table_rows["credential"] = []
    resp = client.delete("/credentials/credential:missing")
    assert resp.status_code == 404


def test_credentials_status_reports_db_source(ctx: tuple[TestClient, FakeRepo]) -> None:
    client, repo = ctx
    # openai has a DB credential; azure has none and no env.
    repo.table_rows["credential"] = [_seed_credential_row()]
    resp = client.get("/credentials/status")
    assert resp.status_code == 200
    body = resp.json()
    assert body["configured"]["openai"] is True
    assert body["source"]["openai"] == "database"
    assert body["encryption_configured"] is False


def test_credentials_discover_returns_curated_list(
    ctx: tuple[TestClient, FakeRepo],
) -> None:
    client, repo = ctx
    repo.table_rows["credential"] = [_seed_credential_row()]
    resp = client.post("/credentials/credential:1/discover")
    assert resp.status_code == 200
    body = resp.json()
    assert body["provider"] == "openai"
    names = {m["name"] for m in body["discovered"]}
    assert "gpt-4o" in names
    assert "text-embedding-3-small" in names


# =============================================================================
# Cross-owner LEAK tests (real predicate enforcement)
# =============================================================================


async def test_credentials_never_leak_across_owners() -> None:
    """Owner A's credential (incl. its key) must be invisible to owner B, and B cannot
    read, update, or delete A's credential even with the exact id."""
    repo = InMemoryScopedRepo()
    store = CredentialStore(cast("SurrealRepository", repo))
    alice = Principal(owner="alice")
    bob = Principal(owner="bob")

    alice_cred = await store.create(
        owner="alice",
        name="alice-openai",
        provider="openai",
        modalities=["language"],
        api_key="sk-ALICE-SECRET",
    )
    assert alice_cred.id is not None

    # Bob lists → sees nothing of alice's (credentials are owner-private).
    assert await store.list(bob) == []
    # Bob cannot fetch alice's credential by its exact id...
    assert await store.get(alice_cred.id, bob) is None
    # ...but alice can, and the key is present in-process (for outbound use only).
    got = await store.get(alice_cred.id, alice)
    assert got is not None
    assert got.api_key is not None
    assert got.api_key.get_secret_value() == "sk-ALICE-SECRET"

    # Bob's UPDATE/DELETE on alice's id are no-ops (return None) and leave her row intact.
    assert await store.update(alice_cred.id, bob, fields={"name": "hacked"}) is None
    assert await store.delete(alice_cred.id, bob) is None
    still = await store.get(alice_cred.id, alice)
    assert still is not None and still.name == "alice-openai"


async def test_credential_secret_masked_in_repr() -> None:
    """Defence in depth: the SecretStr key must not appear in the model's repr / str."""
    repo = InMemoryScopedRepo()
    store = CredentialStore(cast("SurrealRepository", repo))
    cred = await store.create(
        owner="alice",
        name="k",
        provider="openai",
        modalities=["language"],
        api_key="sk-LEAK-ME",
    )
    got = await store.get(cred.id or "", Principal(owner="alice"))
    assert got is not None
    assert "sk-LEAK-ME" not in repr(got)
    assert "sk-LEAK-ME" not in str(got)


async def test_models_never_leak_across_owners() -> None:
    """Owner A's models must be invisible to owner B; B cannot delete A's model by id."""
    repo = InMemoryScopedRepo()
    store = ModelStore(cast("SurrealRepository", repo))
    alice = Principal(owner="alice")
    bob = Principal(owner="bob")

    alice_model = await store.create(
        owner="alice", name="gpt-4o", provider="openai", type="language"
    )
    await store.create(
        owner="bob", name="gpt-4o-mini", provider="openai", type="language"
    )

    assert {m.name for m in await store.list(alice)} == {"gpt-4o"}
    assert {m.name for m in await store.list(bob)} == {"gpt-4o-mini"}
    # Bob cannot see or delete alice's model.
    assert alice_model.id is not None
    assert await store.get(alice_model.id, bob) is None
    assert await store.delete(alice_model.id, bob) is False
    # Alice's model survives.
    assert await store.get(alice_model.id, alice) is not None


async def test_model_defaults_never_leak_across_owners() -> None:
    """Owner A's default-model row must be invisible to owner B, and B's PUT must not
    disturb A's row (one row per owner, upsert in place)."""
    repo = InMemoryScopedRepo()
    store = ModelDefaultsStore(cast("SurrealRepository", repo))
    alice = Principal(owner="alice")
    bob = Principal(owner="bob")

    await store.upsert(alice, ModelDefaultsUpdate(default_chat_model="model:alice"))

    # Bob, who set nothing, sees empty defaults — never alice's value.
    bob_defaults = await store.get(bob)
    assert bob_defaults.default_chat_model is None

    await store.upsert(bob, ModelDefaultsUpdate(default_chat_model="model:bob"))
    alice_defaults = await store.get(alice)
    assert alice_defaults.default_chat_model == "model:alice"  # untouched

    # Each owner has exactly one row.
    assert len([r for r in repo._rows if r["owner"] == "alice"]) == 1
    assert len([r for r in repo._rows if r["owner"] == "bob"]) == 1


async def test_delete_credential_migrate_reassigns_only_own_models() -> None:
    """delete(migrate_to=...) reassigns the OWNER's linked models to another credential."""
    repo = InMemoryScopedRepo()
    cred_store = CredentialStore(cast("SurrealRepository", repo))
    model_store = ModelStore(cast("SurrealRepository", repo))
    alice = Principal(owner="alice")

    src = await cred_store.create(
        owner="alice",
        name="src",
        provider="openai",
        modalities=["language"],
        api_key="a",
    )
    dst = await cred_store.create(
        owner="alice",
        name="dst",
        provider="openai",
        modalities=["language"],
        api_key="b",
    )
    assert src.id is not None and dst.id is not None
    await model_store.create(
        owner="alice",
        name="gpt-4o",
        provider="openai",
        type="language",
        credential=src.id,
    )

    deleted = await cred_store.delete(src.id, alice, migrate_to=dst.id)
    assert deleted == 0  # migrated, not cascade-deleted
    # The model now points at dst, and src is gone.
    models = await model_store.list(alice)
    assert len(models) == 1
    assert models[0].credential is not None
    # The model's credential (str, post parse_record_ids) now equals dst's record id.
    assert models[0].credential == str(ensure_record_id(dst.id))
    assert await cred_store.get(src.id, alice) is None


# Reference the imported routers so ruff(unused-import) sees them as used; they are also what
# main.py will include (asserts the routers import cleanly under the test environment).
def test_routers_importable() -> None:
    assert models_router.prefix == "/models"
    assert credentials_router.prefix == "/credentials"
