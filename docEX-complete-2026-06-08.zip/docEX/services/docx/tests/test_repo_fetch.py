"""RepoGraph reads BOTH GitHub and GitLab — provider dispatch + GitHub fetch tests.

Deterministic + offline: the GitHub service is exercised via a subclass that overrides the
single HTTP seam (``_get_json``); the dispatcher's routing + error normalisation are tested
with a stubbed service. No network, no real DB. ``asyncio_mode="auto"`` — no per-test marker.
"""

from __future__ import annotations

import base64
from typing import Any

import pytest

from docx_app.config import DocxConfig
from docx_app.diagram.github_service import (
    GitHubData,
    GitHubNotFoundError,
    GitHubService,
    parse_github_url,
)
from docx_app.diagram.repo_fetch import (
    RepoConfigError,
    RepoFetcher,
    detect_provider,
)


def _cfg(**over: Any) -> DocxConfig:
    base: dict[str, Any] = {
        "gitlab_base_url": "",
        "github_api_url": "https://api.github.com",
        "github_token": "",
        "gitlab_timeout_s": 30.0,
        "repograph_max_file_tree_chars": 780_000,
    }
    base.update(over)
    return DocxConfig.model_construct(**base)


# --------------------------------------------------------------------------- #
# parse_github_url
# --------------------------------------------------------------------------- #
def test_parse_github_url_basic() -> None:
    assert parse_github_url("https://github.com/owner/repo") == ("owner", "repo")


def test_parse_github_url_strips_git_suffix_and_extra_path() -> None:
    assert parse_github_url("https://github.com/owner/repo.git/tree/main") == (
        "owner",
        "repo",
    )


def test_parse_github_url_rejects_non_github() -> None:
    with pytest.raises(ValueError):
        parse_github_url("https://gitlab.com/group/project")


# --------------------------------------------------------------------------- #
# detect_provider — host-based routing
# --------------------------------------------------------------------------- #
def test_detect_github() -> None:
    assert detect_provider("https://github.com/a/b", _cfg()) == "github"


def test_detect_gitlab_by_configured_host() -> None:
    cfg = _cfg(gitlab_base_url="https://gitlab.ubs.net")
    assert detect_provider("https://gitlab.ubs.net/a/b", cfg) == "gitlab"


def test_detect_gitlab_by_name_heuristic() -> None:
    # No base configured, but the host clearly says gitlab.
    assert detect_provider("https://gitlab.com/a/b", _cfg()) == "gitlab"


def test_detect_unsupported_host_raises() -> None:
    with pytest.raises(ValueError):
        detect_provider("https://bitbucket.org/a/b", _cfg())


# --------------------------------------------------------------------------- #
# GitHubService — via a subclass overriding the HTTP seam
# --------------------------------------------------------------------------- #
class _StubGitHub(GitHubService):
    """Overrides ``_get_json`` so the 3-call fetch runs with canned responses (no network)."""

    def __init__(self, cfg: DocxConfig, *, meta: Any, tree: Any, readme: Any) -> None:
        super().__init__(cfg)
        self._meta = meta
        self._tree = tree
        self._readme = readme

    async def _get_json(self, url: str, params: Any = None) -> Any:
        if "/readme" in url:
            if isinstance(self._readme, Exception):
                raise self._readme
            return self._readme
        if "git/trees" in url:
            return self._tree
        return self._meta


async def test_github_get_data_builds_repodata_and_filters_tree() -> None:
    svc = _StubGitHub(
        _cfg(),
        meta={"default_branch": "main"},
        tree={
            "truncated": False,
            "tree": [
                {"type": "blob", "path": "api/main.py"},
                {"type": "blob", "path": "node_modules/x.js"},  # excluded
                {"type": "tree", "path": "api"},  # directory — skipped
                {"type": "blob", "path": "README.md"},
            ],
        },
        readme={"content": base64.b64encode(b"# Hello").decode(), "encoding": "base64"},
    )
    data = await svc.get_github_data("https://github.com/o/r")
    assert isinstance(data, GitHubData)
    assert data.default_branch == "main"
    assert "api/main.py" in data.file_tree
    assert "README.md" in data.file_tree
    assert "node_modules" not in data.file_tree  # EXCLUDED_PATTERNS applied
    assert "api\n" not in (data.file_tree + "\n")  # the bare dir entry was dropped
    assert data.namespace == "o/r"
    assert "Hello" in data.readme


async def test_github_tree_truncated_raises_too_large() -> None:
    svc = _StubGitHub(
        _cfg(),
        meta={"default_branch": "main"},
        tree={"truncated": True, "tree": []},
        readme={},
    )
    with pytest.raises(ValueError):
        await svc.get_github_data("https://github.com/o/r")


async def test_github_missing_readme_is_empty_string() -> None:
    svc = _StubGitHub(
        _cfg(),
        meta={"default_branch": "main"},
        tree={"truncated": False, "tree": [{"type": "blob", "path": "x.py"}]},
        readme=GitHubNotFoundError("404"),
    )
    data = await svc.get_github_data("https://github.com/o/r")
    assert data.readme == ""


# --------------------------------------------------------------------------- #
# RepoFetcher — routing + error normalisation
# --------------------------------------------------------------------------- #
async def test_fetcher_routes_github(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, str] = {}

    class _FakeGH:
        def __init__(self, _cfg: DocxConfig) -> None:
            pass

        async def get_github_data(self, repo_url: str) -> GitHubData:
            captured["url"] = repo_url
            return GitHubData(
                default_branch="main", file_tree="x.py", readme="# R", namespace="o/r"
            )

    monkeypatch.setattr("docx_app.diagram.repo_fetch.GitHubService", _FakeGH)
    out = await RepoFetcher(_cfg()).fetch("https://github.com/o/r")
    assert out.provider == "github"
    assert out.namespace == "o/r"
    assert captured["url"].endswith("o/r")


async def test_fetcher_gitlab_unconfigured_maps_to_config_error() -> None:
    # A gitlab host with no base configured → GitLabConfigError → normalised to RepoConfigError.
    with pytest.raises(RepoConfigError):
        await RepoFetcher(_cfg(gitlab_base_url="")).fetch("https://gitlab.com/a/b")
