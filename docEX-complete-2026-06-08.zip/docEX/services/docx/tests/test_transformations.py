"""Transformations — store (owner-scoped) + API + a cross-owner LEAK test.

The store-level tests use a recording FakeRepo to assert every write is owner-stamped
(scope=PRIVATE) and every read/update/delete is owner-scoped (focus=True). The leak test
uses InMemoryScopedRepo, which ACTUALLY applies the owner predicate (mirroring
tests/test_tenancy_isolation.py), so a transformation leaking across owners fails here.
The API tests drive the router with fakes via dependency_overrides (no DB / no Azure).
"""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from docx_app import deps
from docx_app.api.transformations import router as transformations_router
from docx_app.db import ensure_record_id
from docx_app.domain.default_transformations import (
    DEFAULT_TRANSFORMATION_INSTRUCTIONS,
    DEFAULT_TRANSFORMATIONS,
)
from docx_app.domain.transformation import (
    DefaultPromptStore,
    Transformation,
    TransformationStore,
)
from docx_app.main import app
from docx_app.tenancy import Principal, Scope

# The orchestrator wires this router into main.py; until then, register it here so these
# API tests exercise the real routes (idempotent — guarded against a double-include).
if not any(getattr(r, "path", "").startswith("/transformations") for r in app.routes):
    app.include_router(transformations_router)


# --- Recording fake: asserts the scoping ARGUMENTS the store passes down ----


class RecordingRepo:
    def __init__(self) -> None:
        self.created: list[dict] = []
        self.selects: list[dict] = []
        self.queries: list[tuple[str, dict]] = []
        self.deletes: list[tuple[str, dict]] = []
        self.rows: list[dict] = []
        self.query_rows: list[dict] = []

    async def create_scoped(self, table, data, *, owner, scope):
        self.created.append(
            {"table": table, "data": data, "owner": owner, "scope": scope}
        )
        return {**data, "id": f"{table}:1", "owner": owner, "scope": scope.value}

    async def select_scoped(
        self,
        table,
        principal,
        *,
        focus=False,
        extra_where="",
        order_by="updated DESC",
        limit=None,
        vars=None,
        notebook=None,
    ):
        self.selects.append(
            {"table": table, "focus": focus, "extra_where": extra_where, "vars": vars}
        )
        return self.rows

    async def query(self, query_str, vars=None):
        self.queries.append((query_str, vars or {}))
        return self.query_rows

    async def delete_where(self, table, where, vars=None):
        self.deletes.append((f"{table}::{where}", vars or {}))


# --- Store-level scoping tests ---------------------------------------------


async def test_create_stamps_owner_and_is_private():
    repo = RecordingRepo()
    t = await TransformationStore(repo).create(
        owner="u1",
        name="Summarize",
        title="Summary",
        description="Make a summary",
        prompt="Summarize the following",
        apply_default=True,
    )
    assert isinstance(t, Transformation)
    assert t.name == "Summarize" and t.owner == "u1"
    assert repo.created[0]["owner"] == "u1"
    assert (
        repo.created[0]["scope"] == Scope.PRIVATE
    )  # a user's prompt library is private
    assert repo.created[0]["data"]["apply_default"] is True


async def test_list_and_get_are_owner_scoped():
    repo = RecordingRepo()
    repo.rows = [
        {"id": "transformation:1", "name": "A", "title": "", "prompt": "p"},
    ]
    items = await TransformationStore(repo).list(Principal(owner="u1"))
    assert len(items) == 1 and items[0].name == "A"
    assert repo.selects[0]["focus"] is True  # only your own
    got = await TransformationStore(repo).get("transformation:1", Principal(owner="u1"))
    assert got is not None and got.name == "A"
    assert repo.selects[1]["extra_where"] == "id = $tid"
    assert repo.selects[1]["focus"] is True


async def test_update_binds_owner_in_where_and_returns_after():
    repo = RecordingRepo()
    repo.rows = [
        {"id": "transformation:1", "name": "old", "prompt": "p"}
    ]  # get() check
    repo.query_rows = [{"id": "transformation:1", "name": "new", "prompt": "p"}]
    out = await TransformationStore(repo).update(
        "transformation:1", Principal(owner="u1"), fields={"name": "new"}
    )
    assert out is not None and out.name == "new"
    q, qvars = repo.queries[0]
    assert q.startswith("UPDATE transformation SET")
    assert "owner = $owner" in q and "RETURN AFTER" in q  # owner-scoped patch
    assert qvars["owner"] == "u1"
    assert qvars["set_name"] == "new"


async def test_update_missing_returns_none():
    repo = RecordingRepo()
    repo.query_rows = []  # owner-scoped UPDATE matched no row (absent / not theirs)
    out = await TransformationStore(repo).update(
        "transformation:1", Principal(owner="u1"), fields={"name": "x"}
    )
    assert out is None
    # the UPDATE is owner-scoped in its WHERE, so it's safe to issue unconditionally —
    # a non-owned / absent row simply updates nothing (RETURN AFTER → []).
    assert "owner = $owner" in repo.queries[0][0]


async def test_delete_is_owner_scoped():
    repo = RecordingRepo()
    repo.rows = [{"id": "transformation:1", "name": "A", "prompt": "p"}]
    ok = await TransformationStore(repo).delete(
        "transformation:1", Principal(owner="u1")
    )
    assert ok is True
    where, dvars = repo.deletes[0]
    assert "owner = $owner" in where and "id = $tid" in where
    assert dvars["owner"] == "u1"


async def test_default_prompt_get_empty_when_no_row():
    repo = RecordingRepo()
    repo.rows = []
    dp = await DefaultPromptStore(repo).get(Principal(owner="u1"))
    assert dp.transformation_instructions == ""
    assert repo.selects[0]["focus"] is True  # owner-only


async def test_default_prompt_set_upserts_via_owner_scoped_update_then_create():
    # First write: UPDATE returns nothing → falls through to a scoped create.
    repo = RecordingRepo()
    repo.query_rows = []  # no existing row for this owner
    dp = await DefaultPromptStore(repo).set(
        Principal(owner="u1"), transformation_instructions="be terse"
    )
    assert dp.transformation_instructions == "be terse"
    q, qvars = repo.queries[0]
    assert "owner = $owner" in q and qvars["owner"] == "u1"  # scoped upsert
    assert repo.created[0]["owner"] == "u1"
    assert repo.created[0]["scope"] == Scope.PRIVATE


# --- Cross-owner LEAK test (the predicate is REALLY applied) ----------------


class InMemoryScopedRepo:
    """A repo fake that actually enforces owner scoping (mirrors test_tenancy_isolation)."""

    def __init__(self) -> None:
        self._rows: list[dict] = []

    async def create_scoped(self, table, data, *, owner, scope):
        row = {
            **data,
            "id": f"{table}:{len(self._rows) + 1}",
            "owner": owner,
            "scope": scope.value,
        }
        self._rows.append(row)
        return row

    async def select_scoped(
        self,
        table,
        principal,
        *,
        focus=False,
        extra_where="",
        order_by="updated DESC",
        limit=None,
        vars=None,
        notebook=None,
    ):
        # Transformations are always read with focus=True → owner-only.
        rows = [
            r
            for r in self._rows
            if r["id"].startswith(f"{table}:") and r["owner"] == principal.owner
        ]
        if vars and "tid" in vars:  # get() → extra_where "id = $tid"
            target = str(ensure_record_id(vars["tid"]))
            rows = [r for r in rows if str(ensure_record_id(r["id"])) == target]
        return rows[: limit or len(rows)]

    async def query(self, query_str, vars=None):
        # Only used for UPDATE <table> ... WHERE owner = $owner [AND id = $tid] RETURN AFTER.
        vars = vars or {}
        owner = vars.get("owner")
        # Real Surreal UPDATEs are table-scoped; honour the target table so a default-prompt
        # UPDATE can't spuriously match this owner's transformation rows (and vice versa).
        parts = query_str.split()
        table = parts[1] if len(parts) > 1 and parts[0].upper() == "UPDATE" else None
        rows = [
            r
            for r in self._rows
            if r.get("owner") == owner
            and (table is None or r["id"].startswith(f"{table}:"))
        ]
        if "tid" in vars:
            target = str(ensure_record_id(vars["tid"]))
            rows = [r for r in rows if str(ensure_record_id(r["id"])) == target]
        for r in rows:
            for k, v in vars.items():
                if k.startswith("set_"):
                    r[k[len("set_") :]] = v
                if k == "ti":  # DefaultPromptStore.set
                    r["transformation_instructions"] = v
        return rows

    async def delete_where(self, table, where, vars=None):
        vars = vars or {}
        owner = vars.get("owner")
        target = str(ensure_record_id(vars["tid"])) if "tid" in vars else None
        self._rows = [
            r
            for r in self._rows
            if not (
                r["id"].startswith(f"{table}:")
                and r.get("owner") == owner
                and (target is None or str(ensure_record_id(r["id"])) == target)
            )
        ]


async def _seed_two_owners(store: TransformationStore) -> Transformation:
    alice = await store.create(
        owner="alice",
        name="alice-prompt",
        title="A",
        description="",
        prompt="secret prompt",
    )
    await store.create(
        owner="bob", name="bob-prompt", title="B", description="", prompt="bobs prompt"
    )
    return alice


async def test_transformations_never_leak_across_owners():
    repo = InMemoryScopedRepo()
    store = TransformationStore(repo)
    alice = await _seed_two_owners(store)

    # bob lists → sees only his own (transformations are owner-private, never shared)
    bob_names = {t.name for t in await store.list(Principal(owner="bob"))}
    assert bob_names == {"bob-prompt"}
    assert "alice-prompt" not in bob_names

    # bob cannot read alice's transformation even with the exact id...
    assert await store.get(alice.id, Principal(owner="bob")) is None
    # ...but alice can.
    got = await store.get(alice.id, Principal(owner="alice"))
    assert got is not None and got.name == "alice-prompt"


async def test_update_and_delete_cannot_touch_other_owners_rows():
    repo = InMemoryScopedRepo()
    store = TransformationStore(repo)
    alice = await _seed_two_owners(store)

    # bob's UPDATE on alice's row is a no-op (scoped out) and alice's prompt is untouched
    assert (
        await store.update(
            alice.id, Principal(owner="bob"), fields={"prompt": "hacked"}
        )
        is None
    )
    still = await store.get(alice.id, Principal(owner="alice"))
    assert still is not None and still.prompt == "secret prompt"

    # bob's DELETE on alice's row is a no-op; alice's row survives
    assert await store.delete(alice.id, Principal(owner="bob")) is False
    assert await store.get(alice.id, Principal(owner="alice")) is not None


async def test_default_prompt_does_not_leak_across_owners():
    repo = InMemoryScopedRepo()
    store = DefaultPromptStore(repo)
    await store.set(Principal(owner="alice"), transformation_instructions="alice-pre")

    # bob has no preamble even though alice set one
    assert (await store.get(Principal(owner="bob"))).transformation_instructions == ""
    assert (
        await store.get(Principal(owner="alice"))
    ).transformation_instructions == "alice-pre"


# --- Per-owner default-library seed (ON migration 5, made per-owner) --------


async def test_ensure_seeded_populates_builtins_for_a_fresh_owner():
    repo = InMemoryScopedRepo()
    store = TransformationStore(repo)
    prompts = DefaultPromptStore(repo)
    p = Principal(owner="fresh")

    assert await store.ensure_seeded(p) is True
    items = await store.list(p)
    # the full built-in library lands, owner-private, with the ON instructions preamble
    assert {t.name for t in items} == {t["name"] for t in DEFAULT_TRANSFORMATIONS}
    assert len(items) == len(DEFAULT_TRANSFORMATIONS)
    assert all(t.owner == "fresh" and t.scope == Scope.PRIVATE.value for t in items)
    assert (
        await prompts.get(p)
    ).transformation_instructions == DEFAULT_TRANSFORMATION_INSTRUCTIONS


async def test_ensure_seeded_is_idempotent():
    repo = InMemoryScopedRepo()
    store = TransformationStore(repo)
    p = Principal(owner="fresh")
    assert await store.ensure_seeded(p) is True
    # a second call seeds nothing (the owner already has the library) — no duplicates
    assert await store.ensure_seeded(p) is False
    assert len(await store.list(p)) == len(DEFAULT_TRANSFORMATIONS)


async def test_ensure_seeded_respects_a_deliberately_emptied_library():
    repo = InMemoryScopedRepo()
    store = TransformationStore(repo)
    p = Principal(owner="fresh")
    assert await store.ensure_seeded(p) is True
    for t in await store.list(p):  # the user deletes every built-in
        assert t.id is not None
        await store.delete(t.id, p)
    assert await store.list(p) == []
    # the default-prompt row remains as the seeded marker → no surprise re-seed
    assert await store.ensure_seeded(p) is False
    assert await store.list(p) == []


async def test_ensure_seeded_does_not_seed_other_owners():
    repo = InMemoryScopedRepo()
    store = TransformationStore(repo)
    await store.ensure_seeded(Principal(owner="alice"))
    # bob stays empty until HE first uses transformations (seeding is strictly per-owner)
    assert await store.list(Principal(owner="bob")) == []
    assert await store.ensure_seeded(Principal(owner="bob")) is True
    assert len(await store.list(Principal(owner="bob"))) == len(DEFAULT_TRANSFORMATIONS)


# --- API tests (router wired with fakes) -----------------------------------


class ApiFakeRepo:
    """Minimal in-memory repo for the API layer: enough for CRUD + default-prompt."""

    def __init__(self) -> None:
        self._rows: list[dict] = []

    async def create_scoped(self, table, data, *, owner, scope):
        row = {
            **data,
            "id": f"{table}:{len(self._rows) + 1}",
            "owner": owner,
            "scope": scope.value,
            "created": "2026-01-01T00:00:00+00:00",
            "updated": "2026-01-01T00:00:00+00:00",
        }
        self._rows.append(row)
        return row

    async def select_scoped(
        self,
        table,
        principal,
        *,
        focus=False,
        extra_where="",
        order_by="updated DESC",
        limit=None,
        vars=None,
        notebook=None,
    ):
        rows = [
            r
            for r in self._rows
            if r["id"].startswith(f"{table}:") and r["owner"] == principal.owner
        ]
        if vars and "tid" in vars:
            target = str(ensure_record_id(vars["tid"]))
            rows = [r for r in rows if str(ensure_record_id(r["id"])) == target]
        return rows[: limit or len(rows)]

    async def query(self, query_str, vars=None):
        vars = vars or {}
        owner = vars.get("owner")
        parts = query_str.split()
        table = parts[1] if len(parts) > 1 and parts[0].upper() == "UPDATE" else None
        rows = [
            r
            for r in self._rows
            if r.get("owner") == owner
            and (table is None or r["id"].startswith(f"{table}:"))
        ]
        if "tid" in vars:
            target = str(ensure_record_id(vars["tid"]))
            rows = [r for r in rows if str(ensure_record_id(r["id"])) == target]
        for r in rows:
            for k, v in vars.items():
                if k.startswith("set_"):
                    r[k[len("set_") :]] = v
                if k == "ti":
                    r["transformation_instructions"] = v
        return rows

    async def delete_where(self, table, where, vars=None):
        vars = vars or {}
        owner = vars.get("owner")
        target = str(ensure_record_id(vars["tid"])) if "tid" in vars else None
        self._rows = [
            r
            for r in self._rows
            if not (
                r["id"].startswith(f"{table}:")
                and r.get("owner") == owner
                and (target is None or str(ensure_record_id(r["id"])) == target)
            )
        ]


class FakeChat:
    def __init__(self) -> None:
        self.system: str | None = None
        self.user: str | None = None

    async def complete(self, *, system, user, max_tokens=1000):
        self.system = system
        self.user = user
        return f"OUT::{user}"


@pytest.fixture
def client():
    repo = ApiFakeRepo()
    chat = FakeChat()
    app.dependency_overrides[deps.get_principal] = lambda: Principal(owner="u1")
    app.dependency_overrides[deps.get_repository] = lambda: repo
    app.dependency_overrides[deps.get_chat_client] = lambda: chat
    c = TestClient(app)
    yield c, repo, chat
    app.dependency_overrides.clear()


def _make(c: TestClient, **over) -> dict:
    body = {
        "name": "Summarize",
        "title": "Summary",
        "description": "d",
        "prompt": "Summarize this",
        **over,
    }
    resp = c.post("/transformations", json=body)
    assert resp.status_code == 200, resp.text
    return resp.json()


def test_api_create_and_list(client):
    c, _, _ = client
    created = _make(c)
    assert created["name"] == "Summarize" and created["apply_default"] is False
    assert "owner" not in created  # response shape matches the ON contract exactly
    resp = c.get("/transformations")
    assert resp.status_code == 200
    names = [t["name"] for t in resp.json()]
    assert names == ["Summarize"]


def test_api_first_list_seeds_builtin_library(client):
    c, _, _ = client
    # a brand-new owner opening Transformations gets the built-in library, not a blank page
    resp = c.get("/transformations")
    assert resp.status_code == 200
    assert {t["name"] for t in resp.json()} == {
        t["name"] for t in DEFAULT_TRANSFORMATIONS
    }
    # the ON default-instructions preamble is seeded alongside it
    dp = c.get("/transformations/default-prompt").json()
    assert dp["transformation_instructions"] == DEFAULT_TRANSFORMATION_INSTRUCTIONS
    # idempotent: listing again neither duplicates nor errors
    again = c.get("/transformations").json()
    assert len({t["id"] for t in again}) == len(DEFAULT_TRANSFORMATIONS)


def test_api_create_blank_name_400(client):
    c, _, _ = client
    assert (
        c.post(
            "/transformations",
            json={"name": "  ", "title": "", "description": "", "prompt": "p"},
        ).status_code
        == 400
    )


def test_api_create_blank_prompt_400(client):
    c, _, _ = client
    assert (
        c.post(
            "/transformations",
            json={"name": "X", "title": "", "description": "", "prompt": "   "},
        ).status_code
        == 400
    )


def test_api_get_and_404(client):
    c, _, _ = client
    created = _make(c)
    got = c.get(f"/transformations/{created['id']}")
    assert got.status_code == 200 and got.json()["id"] == created["id"]
    assert c.get("/transformations/transformation:999").status_code == 404


def test_api_update(client):
    c, _, _ = client
    created = _make(c)
    resp = c.put(
        f"/transformations/{created['id']}",
        json={"title": "New title", "apply_default": True},
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["title"] == "New title" and body["apply_default"] is True
    assert body["name"] == "Summarize"  # untouched fields preserved


def test_api_update_missing_404(client):
    c, _, _ = client
    assert (
        c.put("/transformations/transformation:999", json={"title": "x"}).status_code
        == 404
    )


def test_api_delete(client):
    c, _, _ = client
    created = _make(c)
    resp = c.delete(f"/transformations/{created['id']}")
    assert resp.status_code == 200 and "deleted" in resp.json()["message"].lower()
    assert c.get(f"/transformations/{created['id']}").status_code == 404


def test_api_delete_missing_404(client):
    c, _, _ = client
    assert c.delete("/transformations/transformation:999").status_code == 404


def test_api_execute_runs_prompt_over_text(client):
    c, _, chat = client
    created = _make(c, prompt="Summarize this")
    resp = c.post(
        "/transformations/execute",
        json={
            "transformation_id": created["id"],
            "input_text": "the quick brown fox",
            "model_id": "gpt-x",
        },
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["output"] == "OUT::the quick brown fox"
    assert body["transformation_id"] == created["id"]
    assert body["model_id"] == "gpt-x"  # echoed back for contract parity
    # the prompt is built into the system message, input into the user message
    assert chat.system is not None and "Summarize this" in chat.system
    assert chat.system.rstrip().endswith("# INPUT")
    assert chat.user == "the quick brown fox"


def test_api_execute_prepends_default_prompt(client):
    c, _, chat = client
    c.put(
        "/transformations/default-prompt",
        json={"transformation_instructions": "ALWAYS be concise."},
    )
    created = _make(c, prompt="Summarize this")
    resp = c.post(
        "/transformations/execute",
        json={"transformation_id": created["id"], "input_text": "hi", "model_id": ""},
    )
    assert resp.status_code == 200
    # default-instructions preamble comes before the transformation prompt
    assert chat.system is not None
    assert chat.system.index("ALWAYS be concise.") < chat.system.index("Summarize this")


def test_api_execute_unknown_transformation_404(client):
    c, _, _ = client
    resp = c.post(
        "/transformations/execute",
        json={
            "transformation_id": "transformation:999",
            "input_text": "x",
            "model_id": "",
        },
    )
    assert resp.status_code == 404


def test_api_execute_blank_input_400(client):
    c, _, _ = client
    created = _make(c)
    resp = c.post(
        "/transformations/execute",
        json={"transformation_id": created["id"], "input_text": "   ", "model_id": ""},
    )
    assert resp.status_code == 400


def test_api_default_prompt_get_set_roundtrip(client):
    c, _, _ = client
    # default is empty
    assert (
        c.get("/transformations/default-prompt").json()["transformation_instructions"]
        == ""
    )
    put = c.put(
        "/transformations/default-prompt",
        json={"transformation_instructions": "be terse"},
    )
    assert put.status_code == 200
    assert put.json()["transformation_instructions"] == "be terse"
    # persisted
    assert (
        c.get("/transformations/default-prompt").json()["transformation_instructions"]
        == "be terse"
    )


def test_static_routes_not_shadowed_by_id_route(client):
    """`/execute` and `/default-prompt` must not be captured as `/{transformation_id}`."""
    c, _, _ = client
    # default-prompt resolves to the literal route (200), not a 404 "not found" lookup
    assert c.get("/transformations/default-prompt").status_code == 200
