"""Search API — ON's /api/search contract on docx's hybrid retrieval.

Three layers of coverage:
1. POST /search wiring + ON SearchResponse shape (mocked RetrievalService).
2. POST /search/ask streaming in ON's SSE event shape (mocked AskService).
3. A cross-owner LEAK test that drives the endpoint through the REAL RetrievalService
   over an enforcing in-memory repo (the repo actually applies the scope predicate),
   proving one owner's POST /search can never surface another owner's private chunk.
"""

from __future__ import annotations

import json
from collections.abc import Iterator
from typing import Any, cast

import pytest
from fastapi.testclient import TestClient

from docx_app import deps
from docx_app.api.search import router as search_router
from docx_app.ask.models import AskResult, Citation
from docx_app.main import app
from docx_app.retrieval.models import RetrievedChunk
from docx_app.retrieval.service import RetrievalService
from docx_app.tenancy import Principal

# The orchestrator wires `search_router` into main.py (see the slice manifest). Until then
# — and idempotently after — register it here so this test suite is self-contained. Guarded
# so we never double-register the routes once main.py includes it.
if not any(getattr(r, "path", None) == "/search" for r in app.routes):
    app.include_router(search_router)


class FakeRetrieval:
    """Records the scoping args it was called with and returns canned chunks."""

    def __init__(self, chunks: list[RetrievedChunk]) -> None:
        self.chunks = chunks
        self.calls: list[dict[str, Any]] = []

    async def search(
        self,
        query: str,
        principal: Principal,
        *,
        focus: bool = False,
        limit: int = 10,
        min_similarity: float = 0.2,
        notebook: str | None = None,
    ) -> list[RetrievedChunk]:
        self.calls.append(
            {
                "query": query,
                "owner": principal.owner,
                "focus": focus,
                "limit": limit,
                "min_similarity": min_similarity,
                "notebook": notebook,
            }
        )
        return self.chunks


class FakeAsk:
    def __init__(self) -> None:
        self.calls: list[dict[str, Any]] = []

    async def ask(
        self,
        question: str,
        principal: Principal,
        *,
        focus: bool = False,
        limit: int = 10,
        notebook: str | None = None,
    ) -> AskResult:
        self.calls.append(
            {"question": question, "owner": principal.owner, "focus": focus}
        )
        return AskResult(
            answer=f"A: {question}",
            citations=[Citation(source="source:1", chunk="source_chunk:1", score=0.9)],
            used_chunks=1,
        )


def _parse_sse(body: str) -> list[dict[str, Any]]:
    """Parse `data: {...}\\n\\n` SSE frames into a list of event dicts."""
    events: list[dict[str, Any]] = []
    for raw in body.splitlines():
        line = raw.strip()
        if line.startswith("data:"):
            events.append(json.loads(line[len("data:") :].strip()))
    return events


def _titles(resp_json: dict[str, Any]) -> set[str]:
    return {cast(str, r["title"]) for r in resp_json["results"]}


# --- POST /search ----------------------------------------------------------------------


@pytest.fixture
def search_ctx() -> Iterator[tuple[TestClient, FakeRetrieval]]:
    chunks = [
        RetrievedChunk(
            id="source_chunk:1",
            source="source:1",
            content="the quick brown fox",
            score=0.87,
        ),
        RetrievedChunk(
            id="source_chunk:2", source="source:2", content="lazy dog", score=0.5
        ),
    ]
    ret = FakeRetrieval(chunks)
    app.dependency_overrides[deps.get_principal] = lambda: Principal(owner="u1")
    app.dependency_overrides[deps.get_retrieval_service] = lambda: ret
    client = TestClient(app)
    yield client, ret
    app.dependency_overrides.clear()


def test_search_returns_on_shape(search_ctx: tuple[TestClient, FakeRetrieval]) -> None:
    client, ret = search_ctx
    resp = client.post("/search", json={"query": "fox", "type": "vector", "limit": 5})
    assert resp.status_code == 200
    body = resp.json()
    # SearchResponse envelope
    assert body["search_type"] == "vector"
    assert body["total_count"] == 2
    assert len(body["results"]) == 2
    # SearchResult shape (ON field names)
    first = body["results"][0]
    assert first["id"] == "source_chunk:1"
    assert first["parent_id"] == "source:1"  # chunk → its source
    assert first["final_score"] == pytest.approx(0.87)
    assert first["score"] == pytest.approx(0.87)
    assert first["title"] == "the quick brown fox"  # snippet-derived label
    assert first["source_type"] == "source"
    # query + limit forwarded to the (scoped) retrieval service
    assert ret.calls[0]["query"] == "fox" and ret.calls[0]["limit"] == 5


def test_search_passes_minimum_score_and_focus(
    search_ctx: tuple[TestClient, FakeRetrieval],
) -> None:
    client, ret = search_ctx
    resp = client.post(
        "/search",
        json={"query": "fox", "minimum_score": 0.55, "focus": True},
    )
    assert resp.status_code == 200
    assert ret.calls[0]["min_similarity"] == pytest.approx(0.55)
    assert ret.calls[0]["focus"] is True
    assert ret.calls[0]["owner"] == "u1"  # scoped to the caller


def test_search_blank_query_returns_400(
    search_ctx: tuple[TestClient, FakeRetrieval],
) -> None:
    client, _ = search_ctx
    assert client.post("/search", json={"query": "   "}).status_code == 400


def test_search_empty_results(search_ctx: tuple[TestClient, FakeRetrieval]) -> None:
    client, ret = search_ctx
    ret.chunks = []
    resp = client.post("/search", json={"query": "nothing"})
    assert resp.status_code == 200
    body = resp.json()
    assert body["results"] == [] and body["total_count"] == 0


def test_search_ignores_unknown_on_fields(
    search_ctx: tuple[TestClient, FakeRetrieval],
) -> None:
    # ON sends search_sources/search_notes; docx accepts and ignores extras (no 422).
    client, _ = search_ctx
    resp = client.post(
        "/search",
        json={
            "query": "fox",
            "search_sources": True,
            "search_notes": True,
            "some_future_field": "x",
        },
    )
    assert resp.status_code == 200


# --- POST /search/ask (streaming) ------------------------------------------------------


@pytest.fixture
def ask_ctx() -> Iterator[tuple[TestClient, FakeAsk]]:
    ask = FakeAsk()
    app.dependency_overrides[deps.get_principal] = lambda: Principal(owner="u1")
    app.dependency_overrides[deps.get_ask_service] = lambda: ask
    client = TestClient(app)
    yield client, ask
    app.dependency_overrides.clear()


def test_ask_streams_on_sse_events(ask_ctx: tuple[TestClient, FakeAsk]) -> None:
    client, ask = ask_ctx
    resp = client.post(
        "/search/ask",
        json={
            "question": "what is the fox?",
            "strategy_model": "m1",
            "answer_model": "m2",
            "final_answer_model": "m3",
        },
    )
    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("text/event-stream")
    events = _parse_sse(resp.text)
    types = [e["type"] for e in events]
    assert types == ["final_answer", "complete"]  # ON-shaped subset
    assert events[0]["content"] == "A: what is the fox?"
    assert events[1]["final_answer"] == "A: what is the fox?"
    # ON's three model roles are accepted but ignored (single-pass); question is scoped.
    assert ask.calls[0]["question"] == "what is the fox?"
    assert ask.calls[0]["owner"] == "u1"


def test_ask_propagates_focus(ask_ctx: tuple[TestClient, FakeAsk]) -> None:
    client, ask = ask_ctx
    resp = client.post("/search/ask", json={"question": "q?", "focus": True})
    assert resp.status_code == 200
    _parse_sse(resp.text)  # drain
    assert ask.calls[0]["focus"] is True


def test_ask_blank_question_returns_400(ask_ctx: tuple[TestClient, FakeAsk]) -> None:
    client, _ = ask_ctx
    assert client.post("/search/ask", json={"question": "  "}).status_code == 400


def test_ask_stream_emits_error_event_on_failure() -> None:
    class BoomAsk:
        async def ask(self, *a: Any, **k: Any) -> AskResult:
            raise RuntimeError("azure down")

    app.dependency_overrides[deps.get_principal] = lambda: Principal(owner="u1")
    app.dependency_overrides[deps.get_ask_service] = lambda: BoomAsk()
    client = TestClient(app)
    try:
        resp = client.post("/search/ask", json={"question": "q?"})
        # The HTTP envelope still succeeds; the failure is an in-stream error event,
        # never a 500 mid-stream (the frontend reader expects this).
        assert resp.status_code == 200
        events = _parse_sse(resp.text)
        assert events and events[-1]["type"] == "error"
    finally:
        app.dependency_overrides.clear()


# --- Cross-owner LEAK test (real RetrievalService over an enforcing repo) ---------------

_CHUNKS: list[dict[str, Any]] = [
    {
        "id": "source_chunk:a",
        "source": "source:a",
        "owner": "alice",
        "scope": "private",
        "content": "alice secret",
    },
    {
        "id": "source_chunk:b",
        "source": "source:b",
        "owner": "bob",
        "scope": "private",
        "content": "bob secret",
    },
    {
        "id": "source_chunk:c",
        "source": "source:c",
        "owner": "alice",
        "scope": "org-common",
        "content": "shared",
    },
]


class _EnforcingChunkRepo:
    """Really applies the scope rule the retrieval SQL encodes (reads its WHERE clause).

    Mirrors tests/test_retrieval_isolation.py so a regression in the scope predicate
    fails here too — but exercised end-to-end through the /search HTTP endpoint.
    """

    def __init__(self, chunks: list[dict[str, Any]]) -> None:
        self._chunks = chunks

    async def query(
        self, sql: str, vars: dict[str, Any] | None = None
    ) -> list[dict[str, Any]]:
        assert vars is not None
        owner = vars["owner"]
        keeps_common = "org-common" in sql  # focus=False retains the shared arm

        def visible(c: dict[str, Any]) -> bool:
            if keeps_common:
                return bool(c["scope"] == "org-common" or c["owner"] == owner)
            return bool(c["owner"] == owner)

        return [
            {
                "id": c["id"],
                "source": c["source"],
                "content": c["content"],
                "score": 1.0,
            }
            for c in self._chunks
            if visible(c)
        ]


class _Embedder:
    async def embed(self, texts: list[str]) -> list[list[float]]:
        return [[1.0, 0.0]]


@pytest.fixture
def leak_client() -> Iterator[None]:
    # Real RetrievalService (BM25 arm degrades on this fake → vector-only path) so the
    # endpoint's scoping is genuinely exercised, not stubbed. The fakes satisfy the
    # SurrealRepository / Embedder protocols used by RetrievalService at runtime.
    service = RetrievalService(
        cast(Any, _EnforcingChunkRepo(_CHUNKS)), cast(Any, _Embedder())
    )
    app.dependency_overrides[deps.get_retrieval_service] = lambda: service
    yield
    app.dependency_overrides.clear()


def test_search_default_excludes_other_owners_private(leak_client: None) -> None:
    app.dependency_overrides[deps.get_principal] = lambda: Principal(owner="bob")
    client = TestClient(app)
    resp = client.post("/search", json={"query": "secret", "focus": False})
    assert resp.status_code == 200
    titles = _titles(resp.json())
    assert "alice secret" not in titles  # alice's PRIVATE must never leak to bob
    assert "shared" in titles  # the common brain is shared
    assert "bob secret" in titles  # own private surfaces in the default view


def test_search_focus_is_own_only(leak_client: None) -> None:
    app.dependency_overrides[deps.get_principal] = lambda: Principal(owner="bob")
    client = TestClient(app)
    resp = client.post("/search", json={"query": "secret", "focus": True})
    assert resp.status_code == 200
    assert _titles(resp.json()) == {"bob secret"}  # not shared, not alice's private
