"""Proves the LOCKED extraction routing + bidirectional fallback (FINAL_DESIGN §3.5)."""

import pytest

from docx_app.extraction.engines.base import (
    EngineAvailabilityError,
    EngineExtractionError,
)
from docx_app.extraction.models import (
    DocType,
    EngineName,
    ExtractedDoc,
    ExtractInput,
    ExtractStatus,
)
from docx_app.extraction.probe import PdfProbe
from docx_app.extraction.router import ExtractionError, ExtractionRouter, detect_type


class FakeEngine:
    def __init__(self, name, result=None, error=None):
        self.name = name
        self._result = result
        self._error = error
        self.calls = 0

    async def extract(self, inp):
        self.calls += 1
        if self._error:
            raise self._error
        return self._result.model_copy(deep=True)


def _doc(md: str = "x" * 100, pages: int = 1) -> ExtractedDoc:
    return ExtractedDoc(markdown=md, page_count=pages)


def test_detect_type():
    assert detect_type(ExtractInput(filename="a.pdf")) == DocType.PDF
    assert detect_type(ExtractInput(filename="a.docx")) == DocType.DOCX
    assert detect_type(ExtractInput(filename="a.mp3")) == DocType.AUDIO
    assert detect_type(ExtractInput(url="https://x.com")) == DocType.URL
    assert detect_type(ExtractInput(filename="a.xyz")) == DocType.UNKNOWN


@pytest.mark.asyncio
async def test_docx_routes_to_docling():
    cc, dl = FakeEngine("cc", _doc()), FakeEngine("dl", _doc())
    out = await ExtractionRouter(cc, dl).extract(
        ExtractInput(filename="r.docx", file_path="/x/r.docx")
    )
    assert out.engine_used == EngineName.DOCLING
    assert dl.calls == 1 and cc.calls == 0


@pytest.mark.asyncio
async def test_url_routes_to_content_core():
    cc, dl = FakeEngine("cc", _doc()), FakeEngine("dl", _doc())
    out = await ExtractionRouter(cc, dl).extract(ExtractInput(url="https://x.com"))
    assert out.engine_used == EngineName.CONTENT_CORE
    assert cc.calls == 1 and dl.calls == 0


@pytest.mark.asyncio
async def test_pdf_clean_uses_content_core():
    cc, dl = FakeEngine("cc", _doc()), FakeEngine("dl", _doc())
    r = ExtractionRouter(
        cc, dl, probe=lambda p: PdfProbe(scanned=False, table_heavy=False)
    )
    out = await r.extract(ExtractInput(filename="a.pdf", file_path="/x/a.pdf"))
    assert out.engine_used == EngineName.CONTENT_CORE


@pytest.mark.asyncio
async def test_pdf_scanned_or_tableheavy_uses_docling():
    cc, dl = FakeEngine("cc", _doc()), FakeEngine("dl", _doc())
    r = ExtractionRouter(cc, dl, probe=lambda p: PdfProbe(scanned=True))
    out = await r.extract(ExtractInput(filename="a.pdf", file_path="/x/a.pdf"))
    assert out.engine_used == EngineName.DOCLING


@pytest.mark.asyncio
async def test_docling_unavailable_degrades_to_content_core():
    cc = FakeEngine("cc", _doc())
    dl = FakeEngine("dl", error=EngineAvailabilityError("DocMining down"))
    out = await ExtractionRouter(cc, dl).extract(
        ExtractInput(filename="a.docx", file_path="/x/a.docx")
    )
    assert out.engine_used == EngineName.CONTENT_CORE
    assert out.status == ExtractStatus.DEGRADED


@pytest.mark.asyncio
async def test_docling_docfailure_falls_back_to_content_core():
    cc = FakeEngine("cc", _doc())
    dl = FakeEngine("dl", error=EngineExtractionError("corrupt"))
    out = await ExtractionRouter(cc, dl).extract(
        ExtractInput(filename="a.docx", file_path="/x/a.docx")
    )
    assert out.engine_used == EngineName.CONTENT_CORE
    assert out.status == ExtractStatus.SUCCESS


@pytest.mark.asyncio
async def test_content_core_low_quality_escalates_to_docling():
    cc = FakeEngine("cc", _doc(md="short", pages=10))  # low quality
    dl = FakeEngine("dl", _doc(md="y" * 5000, pages=10))
    r = ExtractionRouter(cc, dl, probe=lambda p: PdfProbe())  # clean → cc first
    out = await r.extract(ExtractInput(filename="a.pdf", file_path="/x/a.pdf"))
    assert out.engine_used == EngineName.DOCLING


@pytest.mark.asyncio
async def test_both_engines_fail_raises_clean_error():
    cc = FakeEngine("cc", error=EngineExtractionError("cc bad"))
    dl = FakeEngine("dl", error=EngineExtractionError("dl bad"))
    with pytest.raises(ExtractionError):
        await ExtractionRouter(cc, dl).extract(
            ExtractInput(filename="a.docx", file_path="/x/a.docx")
        )
