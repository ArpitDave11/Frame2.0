from fastapi.testclient import TestClient
from shared.factory import FastAPIFactory


def test_factory_creates_app_with_health():
    app = FastAPIFactory.create_app(title="test")
    client = TestClient(app)
    assert client.get("/health/live").status_code == 200
    assert client.get("/health/ready").status_code == 200
    assert client.get("/health/live").json() == {"status": "alive"}
