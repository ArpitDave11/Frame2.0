import pytest
from shared.auth.jwt import create_local_jwt, decode_local_jwt


def test_create_and_decode():
    token = create_local_jwt("secret", "user-123", claims={"role": "editor"})
    decoded = decode_local_jwt(token, "secret")
    assert decoded["sub"] == "user-123"
    assert decoded["role"] == "editor"
    assert decoded["iss"] == "frame-gateway"


def test_decode_wrong_secret():
    token = create_local_jwt("secret", "user-123")
    with pytest.raises(Exception):
        decode_local_jwt(token, "wrong-secret")
