import pytest
from unittest.mock import AsyncMock
from shared.events.publisher import publish_event, CHANNEL
from shared.models.events import PipelineEvent


@pytest.mark.asyncio
async def test_publish_event_calls_notify():
    conn = AsyncMock()
    event = PipelineEvent(
        run_id="run-1",
        project_id="proj-1",
        stage="comprehension",
        status="completed",
    )
    await publish_event(conn, event)

    conn.execute.assert_called_once()
    call_args = conn.execute.call_args
    assert CHANNEL in call_args[0][0]
    # Payload is the second positional arg
    payload = call_args[0][1]
    assert "run-1" in payload
    assert "comprehension" in payload
