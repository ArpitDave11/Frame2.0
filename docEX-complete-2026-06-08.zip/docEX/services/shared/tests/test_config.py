from shared.config.base import BaseConfig


def test_base_config_defaults():
    cfg = BaseConfig()
    assert cfg.jwt_algorithm == "HS256"
    assert cfg.api_port == 8000
    assert cfg.service_name == "frame4"


def test_base_config_env_override(monkeypatch):
    monkeypatch.setenv("DATABASE_URL", "postgresql://test")
    cfg = BaseConfig()
    assert cfg.database_url == "postgresql://test"
