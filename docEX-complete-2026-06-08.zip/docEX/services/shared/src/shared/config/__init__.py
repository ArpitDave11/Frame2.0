from shared.config.base import BaseConfig

__all__ = ["BaseConfig"]
