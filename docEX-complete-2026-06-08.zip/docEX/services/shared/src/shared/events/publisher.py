"""Publish PipelineEvent via Postgres NOTIFY.

Core service calls publish_event() after each stage transition.
Gateway subscribes via LISTEN in the SSE module.
"""

import json

import structlog

from shared.models.events import PipelineEvent

log = structlog.get_logger()

CHANNEL = "pipeline_events"


async def publish_event(conn, event: PipelineEvent) -> None:
    """Send a PipelineEvent as a Postgres NOTIFY payload.

    Args:
        conn: An asyncpg connection (or any object with .execute).
        event: The PipelineEvent to publish.
    """
    payload = event.model_dump_json()
    await conn.execute(f"NOTIFY {CHANNEL}, $1", payload)
    log.debug(
        "event.published", run_id=event.run_id, stage=event.stage, status=event.status
    )
