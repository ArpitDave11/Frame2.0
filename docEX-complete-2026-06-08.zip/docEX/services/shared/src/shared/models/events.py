from datetime import datetime, timezone
from typing import Literal
from pydantic import BaseModel, Field


class PipelineEvent(BaseModel):
    run_id: str
    project_id: str
    stage: str
    status: str
    iteration: int | None = None
    score: float | None = None
    timestamp: str = Field(
        default_factory=lambda: datetime.now(tz=timezone.utc).isoformat()
    )
    payload: dict | None = None


class EvalInput(BaseModel):
    stage: str
    output: dict
    iteration: int
    criteria_source: str
    previous_feedback: list[str] | None = None


class EvalOutput(BaseModel):
    passed: bool
    score: float
    feedback: list[str]
    iteration: int
    route: Literal["pass", "retry", "give_up"]
