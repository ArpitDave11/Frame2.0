from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from asgi_correlation_id import CorrelationIdMiddleware
from shared.config.base import BaseConfig
from shared.logging.setup import configure_logging


class FastAPIFactory:
    @staticmethod
    def create_app(
        title: str,
        version: str = "0.1.0",
        config: BaseConfig | None = None,
        lifespan=None,
    ) -> FastAPI:
        cfg = config or BaseConfig()
        configure_logging(cfg.log_level, cfg.log_json_format)

        app = FastAPI(title=title, version=version, lifespan=lifespan)
        app.add_middleware(CorrelationIdMiddleware)
        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_methods=["*"],
            allow_headers=["*"],
        )
        app.state.config = cfg

        @app.get("/health/live")
        async def liveness():
            return {"status": "alive"}

        @app.get("/health/ready")
        async def readiness():
            return {"status": "ready"}

        return app
