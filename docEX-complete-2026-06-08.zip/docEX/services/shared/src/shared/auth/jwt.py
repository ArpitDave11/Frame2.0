import time
import jwt
from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer


_bearer = HTTPBearer()


def create_local_jwt(
    secret: str,
    subject: str,
    claims: dict | None = None,
    ttl: int = 3600,
    algorithm: str = "HS256",
) -> str:
    now = int(time.time())
    payload = {
        "sub": subject,
        "iat": now,
        "exp": now + ttl,
        "iss": "frame-gateway",
        **(claims or {}),
    }
    return jwt.encode(payload, secret, algorithm=algorithm)


def decode_local_jwt(token: str, secret: str, algorithm: str = "HS256") -> dict:
    try:
        return jwt.decode(token, secret, algorithms=[algorithm], issuer="frame-gateway")
    except jwt.ExpiredSignatureError:
        raise HTTPException(401, "Token expired")
    except jwt.InvalidTokenError as e:
        raise HTTPException(401, f"Invalid token: {e}")


class LocalJWTBearer:
    def __init__(self, secret: str, algorithm: str = "HS256"):
        self.secret = secret
        self.algorithm = algorithm

    async def __call__(
        self,
        credentials: HTTPAuthorizationCredentials = Depends(_bearer),
    ) -> dict:
        return decode_local_jwt(credentials.credentials, self.secret, self.algorithm)
