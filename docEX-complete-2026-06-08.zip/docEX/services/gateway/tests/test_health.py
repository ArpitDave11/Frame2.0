from fastapi.testclient import TestClient
from gateway.main import app


def test_gateway_health():
    client = TestClient(app)
    assert client.get("/health/live").json() == {"status": "alive"}


def test_gateway_root():
    client = TestClient(app)
    resp = client.get("/")
    assert resp.json()["service"] == "gateway"
