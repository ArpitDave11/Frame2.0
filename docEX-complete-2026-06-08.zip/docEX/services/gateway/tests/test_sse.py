import asyncio

from fastapi.testclient import TestClient

from gateway.main import app
from gateway.sse import dispatch_event, _subscribers
from shared.models.events import PipelineEvent


def test_sse_route_registered():
    """SSE route is registered in the app."""
    client = TestClient(app)
    routes = [r.path for r in app.routes]
    assert "/sse/pipeline/{run_id}" in routes


def test_dispatch_event_delivers_to_subscriber():
    """dispatch_event pushes to subscriber queues for matching run_id."""
    queue: asyncio.Queue = asyncio.Queue()
    _subscribers["run-abc"].add(queue)

    event = PipelineEvent(
        run_id="run-abc",
        project_id="proj-1",
        stage="comprehension",
        status="completed",
    )
    dispatch_event(event)

    assert not queue.empty()
    received = queue.get_nowait()
    assert received.run_id == "run-abc"
    assert received.stage == "comprehension"

    # Cleanup
    _subscribers["run-abc"].discard(queue)
    del _subscribers["run-abc"]


def test_dispatch_event_ignores_unrelated_run_id():
    """Events for a different run_id are not dispatched."""
    queue: asyncio.Queue = asyncio.Queue()
    _subscribers["run-xyz"].add(queue)

    event = PipelineEvent(
        run_id="run-other",
        project_id="proj-1",
        stage="classification",
        status="started",
    )
    dispatch_event(event)

    assert queue.empty()

    # Cleanup
    _subscribers["run-xyz"].discard(queue)
    del _subscribers["run-xyz"]
