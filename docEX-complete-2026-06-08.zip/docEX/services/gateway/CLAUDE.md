# gateway — Service Memory

The only service the SPA talks to. Single entry point for all browser requests.

## This service owns
- MSAL confidential client flow (Azure AD token validation)
- LOCAL JWT minting (HS256, 1hr TTL)
- S2S JWT generation (HS256, 5min TTL, per-backend-call)
- SSE streaming to browser (subscribes to Postgres LISTEN/NOTIFY)
- Request fan-out to core/ and delivery/
- Session management (JWT-based, no Redis)

## This service does NOT
- Run LLM calls (that's core/)
- Touch Neo4j (that's core/)
- Write to GitLab (that's delivery/)
- Run Procrastinate workers (that's core/ with FRAME_ROLE=worker)

## Dependencies
- shared/ (BaseConfig, FastAPIFactory, structlog, JWT utils)
- Postgres (for LISTEN/NOTIFY SSE channel)
- Azure AD (MSAL token validation via JWKS)

## Key env vars
- `AZURE_TENANT_ID`, `AZURE_CLIENT_ID`, `AZURE_CLIENT_SECRET`
- `LOCAL_JWT_SECRET` (shared with core/ and delivery/)
- `DATABASE_URL` (for LISTEN/NOTIFY)
