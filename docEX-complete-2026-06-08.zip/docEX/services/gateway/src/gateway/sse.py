"""SSE streaming endpoint — fans out PipelineEvents to connected browsers.

Subscribes to Postgres LISTEN on the pipeline_events channel.
Each connected client receives events filtered by run_id query param.
"""

import asyncio
import json
from collections import defaultdict
from collections.abc import AsyncGenerator

import structlog
from fastapi import APIRouter, Query, Request
from sse_starlette.sse import EventSourceResponse

from shared.models.events import PipelineEvent

log = structlog.get_logger()

router = APIRouter(prefix="/sse", tags=["sse"])

# In-memory subscriber registry: run_id -> set of asyncio.Queue
_subscribers: dict[str, set[asyncio.Queue]] = defaultdict(set)


def _dispatch(event: PipelineEvent) -> None:
    """Push event to all subscribers watching this run_id."""
    queues = _subscribers.get(event.run_id, set())
    for q in queues:
        q.put_nowait(event)


async def _listen_postgres(database_url: str) -> None:
    """Background task: LISTEN on Postgres channel, dispatch to subscribers.

    STUB: In production, this connects via asyncpg and listens.
    For now, it's a no-op that keeps the coroutine alive.
    """
    log.info("sse.listen_postgres.start", channel="pipeline_events")
    # Production implementation:
    # import asyncpg
    # conn = await asyncpg.connect(database_url)
    # await conn.add_listener("pipeline_events", lambda *args: ...)
    while True:
        await asyncio.sleep(3600)  # Keep alive; real impl uses asyncpg listener


async def _event_stream(run_id: str, request: Request) -> AsyncGenerator[dict, None]:
    """Yield SSE events for a specific run_id until client disconnects."""
    queue: asyncio.Queue[PipelineEvent] = asyncio.Queue()
    _subscribers[run_id].add(queue)
    log.info("sse.client_connected", run_id=run_id)

    try:
        while True:
            if await request.is_disconnected():
                break
            try:
                event = await asyncio.wait_for(queue.get(), timeout=30.0)
                yield {
                    "event": "pipeline",
                    "data": event.model_dump_json(),
                }
            except asyncio.TimeoutError:
                # Send keepalive comment
                yield {"comment": "keepalive"}
    finally:
        _subscribers[run_id].discard(queue)
        if not _subscribers[run_id]:
            del _subscribers[run_id]
        log.info("sse.client_disconnected", run_id=run_id)


@router.get("/pipeline/{run_id}")
async def stream_pipeline_events(run_id: str, request: Request):
    """SSE endpoint: stream PipelineEvents for a specific run_id."""
    return EventSourceResponse(_event_stream(run_id, request))


# Expose dispatch for testing
dispatch_event = _dispatch
