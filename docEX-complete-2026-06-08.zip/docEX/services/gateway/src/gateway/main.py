from shared.factory import FastAPIFactory
from shared.config.base import BaseConfig
from gateway.sse import router as sse_router

config = BaseConfig(service_name="gateway")
app = FastAPIFactory.create_app(title="Frame4 Gateway", config=config)
app.include_router(sse_router)


@app.get("/")
async def root():
    return {"service": "gateway", "status": "running"}
