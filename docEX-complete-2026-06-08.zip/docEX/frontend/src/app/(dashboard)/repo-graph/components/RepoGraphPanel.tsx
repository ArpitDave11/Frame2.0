'use client'

import { useCallback, useMemo, useState } from 'react'
import { isAxiosError } from 'axios'
import {
  GitBranch,
  Sparkles,
  RefreshCw,
  AlertCircle,
  Loader2,
  ExternalLink,
} from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { LoadingSpinner } from '@/components/common/LoadingSpinner'
import { DiagramRenderer } from '@/components/diagram/DiagramRenderer'
import { useGenerateRepoGraph } from '@/lib/hooks/use-repo-graph'
import { useTheme } from '@/lib/stores/theme-store'
import { useTranslation } from '@/lib/hooks/use-translation'

/**
 * RepoGraphPanel — the body of the top-level "RepoGraph" panel (Surface 3).
 *
 * The GitDiagram experience re-pointed at GitLab (design §7): a URL field → Generate → the
 * same custom `DiagramRenderer` used by the source/notebook surfaces, with drill-down
 * (breadcrumb, handled inside the renderer) and click-to-open-in-GitLab on link nodes (the
 * renderer's default `onLink` opens the node's GitLab `link` in a new tab).
 *
 * The chrome (Card / CardHeader / CardContent, the empty-state icon idiom, the generating
 * spinner, the Alert error idiom, the fixed-height renderer container) is lifted from the
 * frozen `DiagramTab.tsx` so this panel is visually indistinguishable from its sibling
 * surfaces. State is driven by a single generate mutation (`use-repo-graph`): the typed URL is
 * the input and the returned diagram is the result, so there is no persisted "current" diagram
 * to load — the panel starts on the input screen and shows the result inline after Generate.
 *
 * Token-only (UBS): backgrounds/text/borders use the project's design tokens (`bg-card`,
 * `text-muted-foreground`, `border`, …) exactly as the diagram surfaces do — no hardcoded hex.
 */
export function RepoGraphPanel(): React.ReactElement {
  const { t } = useTranslation()
  const { effectiveTheme } = useTheme()

  const [repoUrl, setRepoUrl] = useState('')
  const generate = useGenerateRepoGraph()

  const result = generate.data ?? null
  const isAccepted = result?.status === 'accepted'
  const graph = result?.graph ?? null
  const snapshot = isAccepted ? result?.render_snapshot_svg ?? null : null

  const trimmedUrl = repoUrl.trim()
  const canSubmit = trimmedUrl.length > 0 && !generate.isPending

  /** Surface a generate failure precisely: 503 (GitLab off) / 404 (no repo) / 502 (LLM/upstream). */
  const explainError = useCallback(
    (err: unknown): string => {
      if (isAxiosError(err)) {
        if (err.response?.status === 503) return t('repoGraph.notConfigured')
        if (err.response?.status === 404) return t('repoGraph.repoNotFound')
        if (err.response?.status === 422) return t('repoGraph.invalidUrl')
        if (err.response?.status === 502) return t('repoGraph.generateFailed')
      }
      return t('repoGraph.generateFailed')
    },
    [t],
  )

  const handleGenerate = useCallback(() => {
    // On the input screen the typed URL drives it; once a result is on screen, Regenerate /
    // retry re-run against that result's repo_url (the input box is no longer shown).
    const url = trimmedUrl.length > 0 ? trimmedUrl : result?.repo_url ?? ''
    if (url.length === 0) return
    generate.mutate(
      { repoUrl: url },
      { onError: (err) => toast.error(explainError(err)) },
    )
  }, [generate, trimmedUrl, result, explainError])

  const handleSubmit = useCallback(
    (event: React.FormEvent) => {
      event.preventDefault()
      handleGenerate()
    },
    [handleGenerate],
  )

  const repoLabel = useMemo(() => {
    if (!result) return null
    return result.repo_name || result.repo_url
  }, [result])

  /* ------------------------------- header ------------------------------- */

  const header = (
    <CardHeader>
      <CardTitle className="flex items-center justify-between gap-2">
        <span className="flex items-center gap-2">
          <GitBranch className="h-5 w-5" />
          {t('repoGraph.title')}
        </span>
        {result && (
          <div className="flex items-center gap-2">
            {result.default_branch && (
              <Badge variant="secondary" className="gap-1">
                <GitBranch className="h-3 w-3" />
                {result.default_branch}
              </Badge>
            )}
            <Button
              size="sm"
              variant="outline"
              onClick={handleGenerate}
              disabled={generate.isPending}
            >
              {generate.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {t('repoGraph.regenerating')}
                </>
              ) : (
                <>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  {t('repoGraph.regenerate')}
                </>
              )}
            </Button>
            <Button size="sm" variant="ghost" asChild>
              <a
                href={result.repo_url}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={t('repoGraph.openInGitlab')}
              >
                <ExternalLink className="mr-2 h-4 w-4" />
                {t('repoGraph.openInGitlab')}
              </a>
            </Button>
          </div>
        )}
      </CardTitle>
      <CardDescription>
        {result ? repoLabel : t('repoGraph.description')}
      </CardDescription>
    </CardHeader>
  )

  /* --------------------------- input / generating ----------------------- */

  if (!result) {
    return (
      <Card>
        {header}
        <CardContent>
          {generate.isPending ? (
            <div className="flex flex-col items-center justify-center gap-3 py-16 text-center text-muted-foreground">
              <LoadingSpinner size="lg" />
              <p className="text-sm font-medium text-foreground">{t('repoGraph.generating')}</p>
              <p className="max-w-sm text-xs">{t('repoGraph.generatingHint')}</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="mx-auto max-w-xl py-8">
              <div className="flex flex-col items-center gap-3 pb-6 text-center text-muted-foreground">
                <GitBranch className="h-12 w-12 opacity-50" />
                <p className="text-sm text-foreground">{t('repoGraph.empty')}</p>
                <p className="max-w-sm text-xs">{t('repoGraph.emptyHint')}</p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="repo-graph-url">{t('repoGraph.urlLabel')}</Label>
                <div className="flex flex-col gap-2 sm:flex-row">
                  <Input
                    id="repo-graph-url"
                    type="url"
                    inputMode="url"
                    autoComplete="off"
                    spellCheck={false}
                    placeholder={t('repoGraph.urlPlaceholder')}
                    value={repoUrl}
                    onChange={(event) => setRepoUrl(event.target.value)}
                    disabled={generate.isPending}
                    className="flex-1"
                  />
                  <Button type="submit" disabled={!canSubmit}>
                    <Sparkles className="mr-2 h-4 w-4" />
                    {t('repoGraph.generate')}
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">{t('repoGraph.urlHint')}</p>
              </div>
            </form>
          )}
        </CardContent>
      </Card>
    )
  }

  /* ------------------------------- result ------------------------------- */

  return (
    <Card>
      {header}
      <CardContent>
        <p className="mb-3 text-xs text-muted-foreground">{t('repoGraph.drillHint')}</p>
        <div className="relative h-[520px] w-full">
          {graph ? (
            <DiagramRenderer
              graph={graph}
              snapshot={snapshot}
              theme={effectiveTheme}
              animated={!generate.isPending}
              ariaLabel={t('repoGraph.title')}
            />
          ) : (
            <div className="flex h-full items-center justify-center rounded-lg border bg-card text-sm text-muted-foreground">
              {t('repoGraph.empty')}
            </div>
          )}
          {/* Dim + spinner overlay while a regenerate runs in place (same idiom as the source tab). */}
          {generate.isPending && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 rounded-lg bg-background/70 backdrop-blur-sm">
              <LoadingSpinner size="lg" />
              <p className="text-xs text-muted-foreground">{t('repoGraph.regenerating')}</p>
            </div>
          )}
        </div>

        {/* A failed regenerate (we still have the prior result on screen) — inline, dismissible by retry. */}
        {generate.isError && !generate.isPending && (
          <Alert className="mt-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>{t('repoGraph.generateFailedTitle')}</AlertTitle>
            <AlertDescription>
              <div className="mt-1 text-sm">{explainError(generate.error)}</div>
              <div className="mt-3">
                <Button size="sm" variant="outline" onClick={handleGenerate}>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  {t('common.retry')}
                </Button>
              </div>
            </AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  )
}
