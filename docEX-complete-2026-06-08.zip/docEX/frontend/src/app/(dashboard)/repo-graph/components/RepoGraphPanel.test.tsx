import { render, screen, fireEvent } from '@testing-library/react'
import { describe, it, expect, vi, beforeEach } from 'vitest'
import { RepoGraphPanel } from './RepoGraphPanel'
import { useGenerateRepoGraph } from '@/lib/hooks/use-repo-graph'
import type { RepoGraphResponse } from '@/lib/api/repo-graph'
import type { DiagramGraph } from '@/components/diagram/DiagramRenderer.types'

/**
 * RepoGraphPanel unit tests.
 *
 * The panel is a pure shell over the single `useGenerateRepoGraph` mutation, so the data hook
 * is mocked (mirrors `NotebookDiagramPanel.test.tsx`). The heavy SVG renderer is stubbed to a
 * lightweight marker (its layout uses elkjs, unavailable/slow in jsdom). `react-i18next` and
 * `react-router-dom` are stubbed globally in `src/test/setup.ts` (so `t(key)` returns the
 * key — assertions match on the key strings).
 */

// ---- mock the data hook (the panel is a pure shell over it) ----------------- //
vi.mock('@/lib/hooks/use-repo-graph')

// theme-store's getSystemTheme calls window.matchMedia (absent in jsdom); stub the
// hook so the panel gets a deterministic theme without a matchMedia polyfill.
vi.mock('@/lib/stores/theme-store', () => ({
  useTheme: () => ({
    theme: 'light' as const,
    setTheme: vi.fn(),
    effectiveTheme: 'light' as const,
    isDark: false,
  }),
}))

// ---- stub the heavy SVG renderer; expose props as data-attrs for assertions - //
vi.mock('@/components/diagram/DiagramRenderer', () => ({
  DiagramRenderer: ({
    ariaLabel,
    snapshot,
  }: {
    ariaLabel?: string
    snapshot?: string | null
  }) => (
    <div
      data-testid="diagram-renderer"
      data-aria={ariaLabel}
      data-snapshot={snapshot ? 'yes' : 'no'}
    />
  ),
}))

const REPO_GRAPH: DiagramGraph = {
  groups: [],
  nodes: [
    {
      id: 'svc_api',
      label: 'API',
      type: 'service',
      shape: 'box',
      link: 'https://gitlab.example.com/group/project/-/tree/main/api',
    },
  ],
  edges: [],
}

function repoRow(over: Partial<RepoGraphResponse> = {}): RepoGraphResponse {
  return {
    id: 'repograph:1',
    surface: 'repograph',
    repo_url: 'https://gitlab.example.com/group/project',
    status: 'draft',
    version: 1,
    graph: REPO_GRAPH,
    render_snapshot_svg: null,
    repo_name: 'group/project',
    default_branch: 'main',
    created: '',
    updated: '',
    ...over,
  }
}

/** Build a mocked `useGenerateRepoGraph` return value (the mutation result object). */
function genMock(
  over: Partial<{
    data: RepoGraphResponse | null
    isPending: boolean
    isError: boolean
    error: unknown
    mutate: ReturnType<typeof vi.fn>
  }> = {},
) {
  return {
    data: over.data ?? undefined,
    isPending: over.isPending ?? false,
    isError: over.isError ?? false,
    error: over.error ?? null,
    mutate: over.mutate ?? vi.fn(),
    reset: vi.fn(),
  } as unknown as ReturnType<typeof useGenerateRepoGraph>
}

describe('RepoGraphPanel', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    vi.mocked(useGenerateRepoGraph).mockReturnValue(genMock())
  })

  it('renders the URL input and an (initially disabled) generate button', () => {
    render(<RepoGraphPanel />)
    expect(screen.getByLabelText('repoGraph.urlLabel')).toBeInTheDocument()
    expect(screen.getByText('repoGraph.empty')).toBeInTheDocument()
    // Nothing typed yet → the submit button is disabled.
    const button = screen.getByRole('button', { name: 'repoGraph.generate' })
    expect(button).toBeDisabled()
  })

  it('enables generate once a URL is typed and fires the mutation on submit', () => {
    const mutate = vi.fn()
    vi.mocked(useGenerateRepoGraph).mockReturnValue(genMock({ mutate }))
    render(<RepoGraphPanel />)

    const input = screen.getByLabelText('repoGraph.urlLabel')
    fireEvent.change(input, {
      target: { value: 'https://gitlab.example.com/group/project' },
    })
    const button = screen.getByRole('button', { name: 'repoGraph.generate' })
    expect(button).toBeEnabled()

    fireEvent.click(button)
    expect(mutate).toHaveBeenCalledTimes(1)
    expect(mutate).toHaveBeenCalledWith(
      { repoUrl: 'https://gitlab.example.com/group/project' },
      expect.objectContaining({ onError: expect.any(Function) }),
    )
  })

  it('does not submit a blank/whitespace-only URL', () => {
    const mutate = vi.fn()
    vi.mocked(useGenerateRepoGraph).mockReturnValue(genMock({ mutate }))
    render(<RepoGraphPanel />)

    const input = screen.getByLabelText('repoGraph.urlLabel')
    fireEvent.change(input, { target: { value: '   ' } })
    expect(screen.getByRole('button', { name: 'repoGraph.generate' })).toBeDisabled()
  })

  it('shows the generating state while the pipeline runs', () => {
    vi.mocked(useGenerateRepoGraph).mockReturnValue(genMock({ isPending: true }))
    render(<RepoGraphPanel />)
    expect(screen.getByTestId('loading-spinner')).toBeInTheDocument()
    expect(screen.getByText('repoGraph.generating')).toBeInTheDocument()
  })

  it('renders the diagram + open-in-GitLab link once a result arrives', () => {
    vi.mocked(useGenerateRepoGraph).mockReturnValue(genMock({ data: repoRow() }))
    render(<RepoGraphPanel />)

    expect(screen.getByTestId('diagram-renderer')).toBeInTheDocument()
    // The open-in-GitLab affordance links to the repo URL in a new tab.
    const link = screen.getByRole('link', { name: 'repoGraph.openInGitlab' })
    expect(link).toHaveAttribute('href', 'https://gitlab.example.com/group/project')
    expect(link).toHaveAttribute('target', '_blank')
    expect(link).toHaveAttribute('rel', 'noopener noreferrer')
    // The default-branch badge and the drill hint are shown on the result.
    expect(screen.getByText('main')).toBeInTheDocument()
    expect(screen.getByText('repoGraph.drillHint')).toBeInTheDocument()
  })

  it('passes the frozen snapshot to the renderer for an accepted result', () => {
    vi.mocked(useGenerateRepoGraph).mockReturnValue(
      genMock({
        data: repoRow({ status: 'accepted', render_snapshot_svg: '<svg></svg>' }),
      }),
    )
    render(<RepoGraphPanel />)
    expect(screen.getByTestId('diagram-renderer')).toHaveAttribute('data-snapshot', 'yes')
  })

  it('surfaces an inline error + retry when a (re)generate fails with a result on screen', () => {
    const mutate = vi.fn()
    vi.mocked(useGenerateRepoGraph).mockReturnValue(
      genMock({
        data: repoRow(),
        isError: true,
        error: { isAxiosError: true, response: { status: 502 } },
        mutate,
      }),
    )
    render(<RepoGraphPanel />)

    expect(screen.getByText('repoGraph.generateFailedTitle')).toBeInTheDocument()
    expect(screen.getByText('repoGraph.generateFailed')).toBeInTheDocument()

    fireEvent.click(screen.getByText('common.retry'))
    expect(mutate).toHaveBeenCalledTimes(1)
  })
})
