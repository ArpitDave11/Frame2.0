'use client'

import { AppShell } from '@/components/layout/AppShell'
import { RepoGraphPanel } from './components/RepoGraphPanel'
import { useTranslation } from '@/lib/hooks/use-translation'

/**
 * RepoGraphPage — the top-level "RepoGraph" route (Surface 3, design §7).
 *
 * A GitDiagram-style panel: paste a GitLab repo URL → architecture diagram (the same custom
 * renderer the source/notebook surfaces use). Page chrome mirrors `TransformationsPage`
 * (`AppShell` + a scrollable padded column with a title/description), so it sits among the
 * other top-level panels with no visual seam. All diagram state lives in `RepoGraphPanel`.
 */
export default function RepoGraphPage() {
  const { t } = useTranslation()

  return (
    <AppShell>
      <div className="flex-1 overflow-y-auto">
        <div className="space-y-6 p-6">
          <div>
            <h1 className="text-2xl font-bold">{t('repoGraph.pageTitle')}</h1>
            <p className="mt-1 max-w-3xl text-muted-foreground">{t('repoGraph.pageDesc')}</p>
          </div>
          <RepoGraphPanel />
        </div>
      </div>
    </AppShell>
  )
}
