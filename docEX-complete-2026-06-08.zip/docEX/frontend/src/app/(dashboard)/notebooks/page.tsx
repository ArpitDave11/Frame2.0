'use client'

import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { formatDistanceToNow } from 'date-fns'

import { AppShell } from '@/components/layout/AppShell'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Plus, RefreshCw, Search, Archive, ArchiveRestore, Trash2, ArrowRight,
  FileText, StickyNote, Bot, Send, Book,
} from 'lucide-react'
import { useNotebooks, useUpdateNotebook } from '@/lib/hooks/use-notebooks'
import { useSources } from '@/lib/hooks/use-sources'
import { useNotes } from '@/lib/hooks/use-notes'
import { CreateNotebookDialog } from '@/components/notebooks/CreateNotebookDialog'
import { NotebookDeleteDialog } from './components/NotebookDeleteDialog'
import type { NotebookResponse } from '@/lib/types/api'
import { cn } from '@/lib/utils'

const ago = (d: string) => formatDistanceToNow(new Date(d), { addSuffix: true })

/**
 * Notebooks — "Studio Split" master-detail (Refined Instrument redesign).
 * Left: searchable list + Active/Archived tabs. Right: live preview of the selected
 * notebook (stat cards, sources/notes preview, open + continue-conversation).
 */
export default function NotebooksPage() {
  const navigate = useNavigate()
  const [createOpen, setCreateOpen] = useState(false)
  const [deleteOpen, setDeleteOpen] = useState(false)
  const [search, setSearch] = useState('')
  const [tab, setTab] = useState<'active' | 'archived'>('active')
  const [selectedId, setSelectedId] = useState<string | null>(null)

  const { data: active, isLoading, refetch } = useNotebooks(false)
  const { data: archived } = useNotebooks(true)
  const updateNotebook = useUpdateNotebook()

  const list = tab === 'active' ? active : archived
  const q = search.trim().toLowerCase()
  const filtered = useMemo(
    () => (list ?? []).filter((n) => !q || n.name.toLowerCase().includes(q)),
    [list, q],
  )

  useEffect(() => {
    if (filtered.length && (!selectedId || !filtered.some((n) => n.id === selectedId))) {
      setSelectedId(filtered[0].id)
    } else if (!filtered.length) {
      setSelectedId(null)
    }
  }, [filtered, selectedId])

  const selected = filtered.find((n) => n.id === selectedId) ?? null
  const open = (id: string) => navigate(`/notebooks/${encodeURIComponent(id)}`)

  return (
    <AppShell>
      <div className="flex flex-1 overflow-hidden">
        {/* ── Left: list panel ───────────────────────────── */}
        <aside className="flex w-[340px] min-w-[340px] flex-col border-r bg-card">
          <div className="flex items-center justify-between border-b px-4 py-3">
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-semibold">Notebooks</h1>
              <span className="rounded-full bg-muted px-2 py-0.5 text-xs text-muted-foreground">
                {filtered.length}
              </span>
            </div>
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="icon" onClick={() => refetch()} aria-label="Refresh">
                <RefreshCw className="h-4 w-4" />
              </Button>
              <Button size="sm" onClick={() => setCreateOpen(true)}>
                <Plus className="mr-1 h-4 w-4" />New
              </Button>
            </div>
          </div>

          <div className="space-y-3 border-b p-3">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search notebooks..."
                className="pl-8"
                aria-label="Search notebooks"
              />
            </div>
            <div className="grid grid-cols-2 gap-1 rounded-md bg-muted p-1">
              {(['active', 'archived'] as const).map((tk) => (
                <button
                  key={tk}
                  onClick={() => setTab(tk)}
                  className={cn(
                    'rounded px-3 py-1.5 text-sm capitalize transition-colors',
                    tab === tk
                      ? 'bg-card font-medium text-foreground shadow-sm'
                      : 'text-muted-foreground hover:text-foreground',
                  )}
                >
                  {tk}
                </button>
              ))}
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-2">
            {filtered.map((n) => (
              <button
                key={n.id}
                onClick={() => setSelectedId(n.id)}
                className={cn(
                  'mb-1 w-full rounded-lg border-l-2 px-3 py-3 text-left transition-colors',
                  n.id === selectedId
                    ? 'border-primary bg-sidebar-accent'
                    : 'border-transparent hover:bg-muted',
                )}
              >
                <div className={cn('truncate font-medium', n.id === selectedId && 'text-primary')}>
                  {n.name}
                </div>
                <div className="mt-1 text-xs text-muted-foreground">
                  {n.source_count} sources · {n.note_count} notes · {ago(n.updated)}
                </div>
              </button>
            ))}
            {!isLoading && filtered.length === 0 && (
              <div className="py-12 text-center text-sm text-muted-foreground">
                {q ? 'No matches' : 'No notebooks yet'}
              </div>
            )}
          </div>
        </aside>

        {/* ── Right: preview ─────────────────────────────── */}
        <main className="flex-1 overflow-y-auto">
          {selected ? (
            <NotebookPreview
              notebook={selected}
              onOpen={() => open(selected.id)}
              onArchiveToggle={() =>
                updateNotebook.mutate({ id: selected.id, data: { archived: !selected.archived } })
              }
              onDelete={() => setDeleteOpen(true)}
            />
          ) : (
            <div className="flex h-full flex-col items-center justify-center text-center">
              <Book className="mb-3 h-10 w-10 text-muted-foreground/50" />
              <div className="text-lg font-medium">No notebook selected</div>
              <p className="mt-1 max-w-sm text-sm text-muted-foreground">
                Create your first notebook to organize your research.
              </p>
              <Button className="mt-4" onClick={() => setCreateOpen(true)}>
                <Plus className="mr-1.5 h-4 w-4" />New Notebook
              </Button>
            </div>
          )}
        </main>
      </div>

      <CreateNotebookDialog open={createOpen} onOpenChange={setCreateOpen} />
      {selected && (
        <NotebookDeleteDialog
          open={deleteOpen}
          onOpenChange={setDeleteOpen}
          notebookId={selected.id}
          notebookName={selected.name}
        />
      )}
    </AppShell>
  )
}

// ─── Preview pane ──────────────────────────────────────────

function NotebookPreview({
  notebook, onOpen, onArchiveToggle, onDelete,
}: {
  notebook: NotebookResponse
  onOpen: () => void
  onArchiveToggle: () => void
  onDelete: () => void
}) {
  const { data: sources } = useSources(notebook.id)
  const { data: notes } = useNotes(notebook.id)

  return (
    <div className="mx-auto max-w-5xl space-y-6 p-8">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <h2 className="text-2xl font-bold">{notebook.name}</h2>
          <p className="mt-1 text-muted-foreground">{notebook.description || 'No description'}</p>
          <p className="mt-1 text-xs text-muted-foreground">
            Created {ago(notebook.created)} · Updated {ago(notebook.updated)}
          </p>
        </div>
        <div className="flex flex-shrink-0 items-center gap-2">
          <Button variant="outline" size="sm" onClick={onArchiveToggle}>
            {notebook.archived ? <ArchiveRestore className="mr-1.5 h-4 w-4" /> : <Archive className="mr-1.5 h-4 w-4" />}
            {notebook.archived ? 'Unarchive' : 'Archive'}
          </Button>
          <Button variant="outline" size="sm" className="text-destructive" onClick={onDelete}>
            <Trash2 className="mr-1.5 h-4 w-4" />Delete
          </Button>
          <Button size="sm" onClick={onOpen}>
            Open notebook<ArrowRight className="ml-1.5 h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-3 gap-3">
        <Stat icon={FileText} label="Sources" value={String(notebook.source_count)} />
        <Stat icon={StickyNote} label="Notes" value={String(notebook.note_count)} />
        <button
          onClick={onOpen}
          className="flex items-center gap-3 rounded-xl border p-4 text-left transition-colors hover:bg-muted"
        >
          <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
            <Bot className="h-5 w-5 text-primary" />
          </span>
          <span>
            <span className="block text-sm font-semibold">Chat</span>
            <span className="block text-xs text-muted-foreground">Open conversation</span>
          </span>
        </button>
      </div>

      {/* Sources + Notes preview */}
      <div className="grid grid-cols-2 gap-4">
        <PreviewCard title="Sources" count={notebook.source_count} onViewAll={onOpen} empty="No sources yet">
          {(sources ?? []).slice(0, 4).map((s) => (
            <PreviewRow key={(s as { id: string }).id} icon={FileText}
              title={(s as { title?: string }).title || 'Untitled source'} />
          ))}
        </PreviewCard>
        <PreviewCard title="Notes" count={notebook.note_count} onViewAll={onOpen} empty="No notes yet">
          {(notes ?? []).slice(0, 4).map((nt) => (
            <PreviewRow key={(nt as { id: string }).id} icon={StickyNote}
              title={(nt as { title?: string | null }).title || 'Untitled note'} />
          ))}
        </PreviewCard>
      </div>

      {/* Continue the conversation */}
      <button
        onClick={onOpen}
        className="flex w-full items-center gap-3 rounded-xl border p-4 text-left transition-colors hover:bg-muted"
      >
        <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10">
          <Bot className="h-5 w-5 text-primary" />
        </span>
        <span className="flex-1">
          <span className="block text-sm font-medium">Continue the conversation</span>
          <span className="block text-xs text-muted-foreground">Ask anything about this notebook</span>
        </span>
        <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
          <Send className="h-4 w-4 text-primary-foreground" />
        </span>
      </button>
    </div>
  )
}

function Stat({ icon: Icon, label, value }: { icon: typeof FileText; label: string; value: string }) {
  return (
    <div className="flex items-center gap-3 rounded-xl border p-4">
      <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
        <Icon className="h-5 w-5 text-muted-foreground" />
      </span>
      <span>
        <span className="block text-xl font-semibold leading-none">{value}</span>
        <span className="mt-1 block text-xs text-muted-foreground">{label}</span>
      </span>
    </div>
  )
}

function PreviewCard({
  title, count, onViewAll, empty, children,
}: {
  title: string; count: number; onViewAll: () => void; empty: string; children: React.ReactNode
}) {
  const hasItems = Array.isArray(children) ? children.length > 0 : Boolean(children)
  return (
    <div className="rounded-xl border p-4">
      <div className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-sm font-semibold">{title}</span>
          <span className="rounded-full bg-muted px-1.5 py-0.5 text-xs text-muted-foreground">{count}</span>
        </div>
        <button onClick={onViewAll} className="flex items-center gap-1 text-xs font-medium text-primary hover:underline">
          View all<ArrowRight className="h-3 w-3" />
        </button>
      </div>
      <div className="space-y-1">
        {hasItems ? children : <div className="py-6 text-center text-xs text-muted-foreground">{empty}</div>}
      </div>
    </div>
  )
}

function PreviewRow({ icon: Icon, title }: { icon: typeof FileText; title: string }) {
  return (
    <div className="flex items-center gap-2 rounded-md px-2 py-2 text-sm hover:bg-muted">
      <Icon className="h-4 w-4 flex-shrink-0 text-muted-foreground" />
      <span className="truncate">{title}</span>
    </div>
  )
}
