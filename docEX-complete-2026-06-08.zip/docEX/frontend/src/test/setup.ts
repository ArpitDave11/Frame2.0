/**
 * Vitest global setup — runs before every test file.
 *
 * Provides:
 *  - @testing-library/jest-dom matchers (toBeInTheDocument, toBeDisabled, etc.)
 *  - A stable stub for react-i18next so tests don't need to configure i18n;
 *    `t(key)` returns the key string, making assertions deterministic.
 *  - A stub for react-router-dom hooks (useLocation, useNavigate) so components
 *    that import them don't need a Router wrapper in unit tests.
 */

import '@testing-library/jest-dom'
import { vi } from 'vitest'

// ------------------------------------------------------------------
// react-i18next stub
// ------------------------------------------------------------------
// Every component calls `useTranslation()` and uses `t(key)`.
// Return the key so assertions can match e.g. 'navigation.repoGraph'.
vi.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key,
    i18n: { changeLanguage: vi.fn(), language: 'en' },
  }),
  Trans: ({ i18nKey }: { i18nKey: string }) => i18nKey,
  initReactI18next: { type: '3rdParty', init: vi.fn() },
}))

// ------------------------------------------------------------------
// react-router-dom stub — provides no-op hooks so unit tests don't
// need a <MemoryRouter> wrapper unless they explicitly test routing.
// ------------------------------------------------------------------
vi.mock('react-router-dom', async (importOriginal) => {
  const actual = await importOriginal<typeof import('react-router-dom')>()
  return {
    ...actual,
    useNavigate: () => vi.fn(),
    useLocation: () => ({ pathname: '/', search: '', hash: '', state: null, key: 'default' }),
    useParams: () => ({}),
  }
})
