// DocxPanel — the federated remote FRAME mounts (and the standalone app's root).
//
// This is Open Notebook's full UI, ported into a self-contained SPA: the same providers ON
// wires in its root + dashboard layouts (ErrorBoundary → Theme → Query → I18n →
// ConnectionGuard → CreateDialogs), an internal MemoryRouter (so the panel never fights
// FRAME's URL/router), AppShell (sidebar + content), and ON's screens as routes. The host
// (FRAME) injects the caller's identity via `getAuthHeaders`, bridged into the API layer.
import { useEffect } from 'react'
import { MemoryRouter, Navigate, Route, Routes } from 'react-router-dom'

import '@/globals.css'

import { ErrorBoundary } from '@/components/common/ErrorBoundary'
import { ThemeProvider } from '@/components/providers/ThemeProvider'
import { QueryProvider } from '@/components/providers/QueryProvider'
import { I18nProvider } from '@/components/providers/I18nProvider'
import { ConnectionGuard } from '@/components/common/ConnectionGuard'
import { ModalProvider } from '@/components/providers/ModalProvider'
import { CommandPalette } from '@/components/common/CommandPalette'
import { CreateDialogsProvider } from '@/lib/hooks/use-create-dialogs'
import { Toaster } from '@/components/ui/sonner'
import { setAuthHeaderProvider, type AuthHeaderProvider } from '@/lib/host-auth'

// Screens (Open Notebook's app-router pages, mounted as react-router routes).
import NotebooksPage from '@/app/(dashboard)/notebooks/page'
import NotebookDetailPage from '@/app/(dashboard)/notebooks/[id]/page'
import SourcesPage from '@/app/(dashboard)/sources/page'
import SourceDetailPage from '@/app/(dashboard)/sources/[id]/page'
import SearchPage from '@/app/(dashboard)/search/page'
import RepoGraphPage from '@/app/(dashboard)/repo-graph/page'
import TransformationsPage from '@/app/(dashboard)/transformations/page'
import SettingsPage from '@/app/(dashboard)/settings/page'
import ApiKeysPage from '@/app/(dashboard)/settings/api-keys/page'
import AdvancedPage from '@/app/(dashboard)/advanced/page'

export interface DocxPanelProps {
  // Host (FRAME) injects the caller's auth headers (MSAL bearer / X-Docx-User dev header).
  // Omitted standalone → the backend's dev-auth fallback applies.
  getAuthHeaders?: AuthHeaderProvider
}

export default function DocxPanel({ getAuthHeaders }: DocxPanelProps) {
  // Bridge the host's auth into the API layer for the panel's lifetime.
  useEffect(() => {
    setAuthHeaderProvider(getAuthHeaders)
    return () => setAuthHeaderProvider(null)
  }, [getAuthHeaders])

  return (
    <ErrorBoundary>
      <ThemeProvider>
        <QueryProvider>
          <I18nProvider>
            <ConnectionGuard>
              <CreateDialogsProvider>
                <MemoryRouter initialEntries={['/notebooks']}>
                  {/* Each ON page renders its own <AppShell> (sidebar + content); the source
                      detail view is intentionally full-screen — so DocxPanel does NOT wrap. */}
                  <Routes>
                    <Route path="/" element={<Navigate to="/notebooks" replace />} />
                    <Route path="/notebooks" element={<NotebooksPage />} />
                    <Route path="/notebooks/:id" element={<NotebookDetailPage />} />
                    <Route path="/sources" element={<SourcesPage />} />
                    <Route path="/sources/:id" element={<SourceDetailPage />} />
                    <Route path="/search" element={<SearchPage />} />
                    <Route path="/repo-graph" element={<RepoGraphPage />} />
                    <Route path="/transformations" element={<TransformationsPage />} />
                    <Route path="/settings" element={<SettingsPage />} />
                    <Route path="/settings/api-keys" element={<ApiKeysPage />} />
                    <Route path="/advanced" element={<AdvancedPage />} />
                    <Route path="*" element={<Navigate to="/notebooks" replace />} />
                  </Routes>
                  {/* URL-driven modals + ⌘K palette, rendered alongside the routed content. */}
                  <ModalProvider />
                  <CommandPalette />
                </MemoryRouter>
              </CreateDialogsProvider>
              <Toaster />
            </ConnectionGuard>
          </I18nProvider>
        </QueryProvider>
      </ThemeProvider>
    </ErrorBoundary>
  )
}
