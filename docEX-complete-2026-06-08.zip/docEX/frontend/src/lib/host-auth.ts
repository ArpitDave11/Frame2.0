/**
 * Host-auth bridge — lets FRAME (the host app) inject the caller's identity into the panel's
 * API layer.
 *
 * FRAME mounts `<DocxPanel getAuthHeaders={...} />` and passes a function returning the auth
 * headers for the current user: a `{ Authorization: 'Bearer <MSAL JWT>' }` in production, or
 * the `{ 'X-Docx-User': '<id>' }` dev header locally. The axios interceptor and the SSE fetch
 * helpers read the provider here, so every request to the Docx backend carries the host's
 * identity — without each call site knowing how auth works.
 *
 * Standalone (no host) → no provider registered → empty headers, and the backend's dev-auth
 * fallback (config.dev_owner) applies. This is the one seam between FRAME's auth and the panel.
 */

export type AuthHeaderProvider = () =>
  | Record<string, string>
  | Promise<Record<string, string>>

let provider: AuthHeaderProvider | null = null

/** Register (or clear) the host's auth-header provider. Called by DocxPanel on mount. */
export function setAuthHeaderProvider(fn: AuthHeaderProvider | null | undefined): void {
  provider = fn ?? null
}

/** Resolve the host's auth headers for one request. Never throws — falls back to `{}`. */
export async function getHostAuthHeaders(): Promise<Record<string, string>> {
  if (!provider) {
    return {}
  }
  try {
    return (await provider()) ?? {}
  } catch {
    return {}
  }
}
