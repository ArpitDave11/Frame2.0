/**
 * Runtime configuration for the Docx panel.
 *
 * Standalone Open Notebook discovers its API URL at runtime (env var + a Next.js `/config`
 * endpoint). The Docx panel doesn't need that: it always reaches the backend through one
 * fixed, relative ingress prefix — `/api/docx`. In standalone dev the Vite proxy maps
 * `/api/docx` → the FastAPI service; inside FRAME the gateway routes the same prefix. So the
 * base is a constant, not something to discover.
 *
 * We keep `getApiUrl()` / `getConfig()` / `AppConfig` so the ported components that depend on
 * them (ConnectionGuard, the Advanced screen's version + DB status) work unchanged against the
 * backend's `/config` endpoint.
 */

import { AppConfig, BackendConfigResponse } from '@/lib/types/config'

// The single ingress prefix the panel calls through (proxied to the Docx FastAPI service).
export const API_BASE = '/api/docx'

// Build timestamp for debugging — stamped at module load.
const BUILD_TIME = new Date().toISOString()

let config: AppConfig | null = null
let configPromise: Promise<AppConfig> | null = null

/**
 * The (fixed) API base the panel calls through. Kept async to preserve Open Notebook's
 * call sites, which `await getApiUrl()` before composing a URL.
 */
export async function getApiUrl(): Promise<string> {
  return API_BASE
}

/** Full backend config (version, DB status). Cached after the first successful fetch. */
export async function getConfig(): Promise<AppConfig> {
  if (config) {
    return config
  }
  if (configPromise) {
    return await configPromise
  }
  configPromise = fetchConfig()
  return await configPromise
}

async function fetchConfig(): Promise<AppConfig> {
  // Single source of truth: the backend's /config behind the /api/docx prefix.
  const response = await fetch(`${API_BASE}/config`, { cache: 'no-store' })
  if (!response.ok) {
    // ConnectionGuard renders the proper error UI from this throw.
    throw new Error(`API config endpoint returned status ${response.status}`)
  }
  const data: BackendConfigResponse = await response.json()
  config = {
    apiUrl: API_BASE,
    version: data.version || 'unknown',
    buildTime: BUILD_TIME,
    latestVersion: data.latestVersion || null,
    hasUpdate: data.hasUpdate || false,
    dbStatus: data.dbStatus,
  }
  return config
}

/** Reset the configuration cache (used by ConnectionGuard's retry + tests). */
export function resetConfig(): void {
  config = null
  configPromise = null
}
