import { useSearchParams } from 'react-router-dom'

export type ModalType = 'source' | 'note' | 'insight'

/**
 * Drives detail modals (source / note / insight) off the URL's query string, so a modal is
 * shareable and survives back/forward within the panel. Ported from Open Notebook's
 * next/navigation version to react-router's useSearchParams (the panel runs its own router).
 */
export function useModalManager() {
  const [searchParams, setSearchParams] = useSearchParams()

  // Read current modal state from URL params.
  const modalType = searchParams.get('modal') as ModalType | null
  const modalId = searchParams.get('id')

  /** Open a modal by setting URL params (no navigation away from the current screen). */
  const openModal = (type: ModalType, id: string) => {
    setSearchParams((prev) => {
      const params = new URLSearchParams(prev)
      params.set('modal', type)
      params.set('id', id)
      return params
    })
  }

  /** Close the open modal by removing its params. */
  const closeModal = () => {
    setSearchParams((prev) => {
      const params = new URLSearchParams(prev)
      params.delete('modal')
      params.delete('id')
      return params
    })
  }

  return {
    modalType,
    modalId,
    openModal,
    closeModal,
    isOpen: !!modalType && !!modalId,
  }
}
