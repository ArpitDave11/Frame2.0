import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { isAxiosError } from 'axios'
import {
  notebookDiagramsApi,
  type NotebookDiagramResponse,
} from '@/lib/api/notebook-diagrams'
import { QUERY_KEYS } from '@/lib/api/query-client'

/**
 * Data hooks for the Notebook-HLD view (Surface 2).
 *
 * Mirrors `use-diagram.ts` (the source surface): a thin `useQuery` over the api client plus
 * mutations that seed the keyed query with the fresh result so the canvas updates without a
 * refetch round-trip. The query for a notebook's current HLD tolerates a 404 — that *is* the
 * empty state (no HLD built yet, e.g. no accepted source diagrams), not an error — so it
 * resolves to `null` rather than throwing, and the panel renders its "Build notebook diagram"
 * call-to-action.
 */

/** Load the notebook's current HLD, or `null` if it has none yet (404). */
export function useNotebookDiagram(
  notebookId: string,
  options?: { enabled?: boolean },
) {
  return useQuery<NotebookDiagramResponse | null>({
    queryKey: QUERY_KEYS.notebookDiagram(notebookId),
    queryFn: async () => {
      try {
        return await notebookDiagramsApi.get(notebookId)
      } catch (err) {
        // 404 = "no HLD yet" → the empty state, not a failure.
        if (isAxiosError(err) && err.response?.status === 404) {
          return null
        }
        throw err
      }
    },
    enabled: options?.enabled !== false && !!notebookId,
    staleTime: 30 * 1000, // 30 seconds (matches useDiagram)
    retry: false, // a 404 must not be retried; real errors surface immediately
  })
}

/**
 * (Re)build the notebook's HLD from its accepted source diagrams. Used by the "Build notebook
 * diagram" CTA and by "Rebuild". Seeds the diagram query with the fresh result so the canvas
 * appears without a refetch round-trip.
 */
export function useRebuildNotebookDiagram(notebookId: string) {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: () => notebookDiagramsApi.rebuild(notebookId),
    onSuccess: (diagram) => {
      queryClient.setQueryData(QUERY_KEYS.notebookDiagram(notebookId), diagram)
    },
  })
}

/** Accept (freeze) the notebook's HLD — data + server-rendered SVG snapshot. */
export function useAcceptNotebookDiagram(notebookId: string) {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: () => notebookDiagramsApi.accept(notebookId),
    onSuccess: (diagram) => {
      queryClient.setQueryData(QUERY_KEYS.notebookDiagram(notebookId), diagram)
    },
  })
}
