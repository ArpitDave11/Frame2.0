import { useMutation } from '@tanstack/react-query'
import { repoGraphApi, type RepoGraphResponse } from '@/lib/api/repo-graph'

/**
 * Data hook for the top-level "RepoGraph" panel (Surface 3).
 *
 * Unlike the source/notebook surfaces — which load a *persisted current* diagram by id and
 * therefore key a `useQuery` (with the 404 → `null` empty state) — RepoGraph is driven by a
 * URL the user types and submits. There is nothing to load until they hit Generate, so the
 * panel models the flow as a single `useMutation`: the URL is the input, the generated diagram
 * is the result, and the mutation's own `isPending` / `isError` / `data` drive every screen
 * (input → generating → result → error). This mirrors the `useGenerateDiagram` mutation shape
 * (the imperative half of `use-diagram.ts`) rather than its query half.
 *
 * `generate` resolves to a `RepoGraphResponse` (synchronous server-side pipeline — see
 * `repo-graph.ts`); the panel reads `data.graph` for the live canvas and, once a result is
 * accepted, `data.render_snapshot_svg` for the frozen picture.
 */
export function useGenerateRepoGraph() {
  return useMutation<RepoGraphResponse, unknown, { repoUrl: string; includeAzureShapes?: boolean }>(
    {
      mutationFn: ({ repoUrl, includeAzureShapes }) =>
        repoGraphApi.generate(repoUrl, { include_azure_shapes: includeAzureShapes }),
    },
  )
}
