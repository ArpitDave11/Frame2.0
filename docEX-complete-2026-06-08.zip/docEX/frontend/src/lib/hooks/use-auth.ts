/**
 * Auth, adapted for the embedded panel.
 *
 * In standalone Open Notebook this hook drove a password login and router redirects to
 * `/login` / `/notebooks`. Inside FRAME the host owns identity — it injects the caller's auth
 * headers via `setAuthHeaderProvider` (see lib/host-auth) — so the panel is always
 * "authenticated" from its own perspective and never navigates to a login route. The hook is
 * kept (with the same shape) so ported components can call `useAuth()` unchanged.
 */
export function useAuth() {
  return {
    isAuthenticated: true,
    isLoading: false,
    error: null as string | null,
    // No-ops: the host performs the real authentication.
    login: async (_password: string): Promise<boolean> => true,
    logout: (): void => {},
  }
}
