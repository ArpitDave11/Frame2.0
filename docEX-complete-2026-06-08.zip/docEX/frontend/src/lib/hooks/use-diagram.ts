import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { isAxiosError } from 'axios'
import { diagramsApi, type DiagramResponse } from '@/lib/api/diagrams'
import { QUERY_KEYS } from '@/lib/api/query-client'
import type { DiagramGraph } from '@/components/diagram/DiagramRenderer.types'

/**
 * Data hooks for the source "Diagram" tab.
 *
 * Mirrors `use-insights.ts` (a thin `useQuery` over the api client) and the
 * mutation pattern used elsewhere (invalidate the keyed query on success). The
 * query for a source's current diagram tolerates a 404 — that *is* the empty
 * state (no diagram yet), not an error — so it resolves to `null` rather than
 * throwing, and the tab renders its "Diagram this document" call-to-action.
 */

/** Load the source's current diagram, or `null` if it has none yet (404). */
export function useDiagram(
  sourceId: string,
  options?: { enabled?: boolean },
) {
  return useQuery<DiagramResponse | null>({
    queryKey: QUERY_KEYS.diagram(sourceId),
    queryFn: async () => {
      try {
        return await diagramsApi.get(sourceId)
      } catch (err) {
        // 404 = "no diagram yet" → the empty state, not a failure.
        if (isAxiosError(err) && err.response?.status === 404) {
          return null
        }
        throw err
      }
    },
    enabled: options?.enabled !== false && !!sourceId,
    staleTime: 30 * 1000, // 30 seconds (matches useInsight)
    retry: false, // a 404 must not be retried; real errors surface immediately
  })
}

/**
 * Generate (or re-generate) the source's diagram from its document text. Used by
 * the "Diagram this document" CTA and by "Rebuild". Seeds the diagram query with
 * the fresh result so the canvas appears without a refetch round-trip.
 */
export function useGenerateDiagram(sourceId: string) {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (vars?: { include_azure_shapes?: boolean }) =>
      diagramsApi.generate(sourceId, vars),
    onSuccess: (diagram) => {
      queryClient.setQueryData(QUERY_KEYS.diagram(sourceId), diagram)
    },
  })
}

/** Refine the diagram with a natural-language instruction (the refine chat). */
export function useRefineDiagram(sourceId: string) {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (vars: { instruction: string; include_azure_shapes?: boolean }) =>
      diagramsApi.chat(sourceId, vars.instruction, {
        include_azure_shapes: vars.include_azure_shapes,
      }),
    onSuccess: (diagram) => {
      queryClient.setQueryData(QUERY_KEYS.diagram(sourceId), diagram)
    },
  })
}

/** Persist a hand-edited graph onto the draft. */
export function useSaveDiagram(sourceId: string) {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (graph: DiagramGraph) => diagramsApi.save(sourceId, graph),
    onSuccess: (diagram) => {
      queryClient.setQueryData(QUERY_KEYS.diagram(sourceId), diagram)
    },
  })
}

/** Accept (freeze) the diagram — data + server-rendered SVG snapshot. */
export function useAcceptDiagram(sourceId: string) {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (graph?: DiagramGraph) => diagramsApi.accept(sourceId, graph),
    onSuccess: (diagram) => {
      queryClient.setQueryData(QUERY_KEYS.diagram(sourceId), diagram)
    },
  })
}
