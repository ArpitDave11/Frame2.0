import axios, { AxiosResponse } from 'axios'
import { API_BASE } from '@/lib/config'
import { getHostAuthHeaders } from '@/lib/host-auth'

// API client for the Docx backend. Every call is relative to /api/docx (the ingress prefix):
// the Vite dev proxy (standalone) and the FRAME gateway (embedded) both route it to FastAPI.
// The long timeout accommodates slow LLM operations (ask, transformations, chat) — the
// frontend uses milliseconds, the backend uses seconds.
export const apiClient = axios.create({
  baseURL: API_BASE,
  timeout: 600000, // 600 seconds = 10 minutes
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: false,
})

// Request interceptor: attach the host's auth headers (MSAL bearer / X-Docx-User dev header)
// and pick the right Content-Type for FormData vs JSON.
apiClient.interceptors.request.use(async (config) => {
  const authHeaders = await getHostAuthHeaders()
  for (const [key, value] of Object.entries(authHeaders)) {
    config.headers.set(key, value)
  }

  if (config.data instanceof FormData) {
    // Let the browser set the multipart boundary.
    config.headers.delete('Content-Type')
  } else if (config.method && ['post', 'put', 'patch'].includes(config.method.toLowerCase())) {
    config.headers.set('Content-Type', 'application/json')
  }

  return config
})

// Response interceptor: surface errors to React Query. Auth is owned by the host (FRAME),
// so a 401 is reported — not redirected — because the panel has no login route of its own.
apiClient.interceptors.response.use(
  (response: AxiosResponse) => response,
  (error) => Promise.reject(error)
)

export default apiClient
