import apiClient from './client'
import type { DiagramGraph } from '@/components/diagram/DiagramRenderer.types'

/**
 * Diagrams API — the Surface-1 "Diagram" tab on a source.
 *
 * Mirrors the `insightsApi` shape (see `./insights.ts`): a flat object of thin
 * `apiClient` wrappers, request/response types co-located. Every path is nested
 * under `/sources/{id}/diagram` to match the backend router
 * (`services/docx/src/docx_app/api/diagrams.py`).
 *
 * Wire contract notes:
 *   • `graph` is the canonical `DiagramGraph` JSON with edges keyed by `"from"`
 *     (the Pydantic alias) — the renderer reads it as-is, so it is typed as
 *     `DiagramGraph` end-to-end.
 *   • `render_snapshot_svg` is present only once `status === 'accepted'` (the
 *     frozen, server-rendered static picture — design §2 "data + picture").
 *   • generate/refine is **synchronous** server-side (the pipeline runs inside the
 *     request), so `generate`/`chat`/`save` resolve directly to the new diagram —
 *     there is no command-job to poll here (unlike insights).
 */

/** A source's diagram (draft or accepted). Mirrors the backend `DiagramResponse`. */
export interface DiagramResponse {
  id: string
  source_id: string
  surface: string
  status: 'draft' | 'accepted'
  version: number
  graph: DiagramGraph | null
  render_snapshot_svg: string | null
  created: string
  updated: string
}

/** Generate/refine the diagram from the source's own `full_text`. */
export interface DiagramChatRequest {
  /** Reserved refine-by-prompt instruction (accepted but inert this pass). */
  instruction?: string
  /** Inject the Azure icon catalog into the pipeline (default on). */
  include_azure_shapes?: boolean
}

/** Save a hand-edited graph onto the source's draft. */
export interface DiagramSaveRequest {
  graph: DiagramGraph
}

/** Accept (freeze) the source's diagram — optionally with a final graph. */
export interface DiagramAcceptRequest {
  graph?: DiagramGraph
}

/** Drawio (mxGraph XML) / Mermaid text exports — pure string emission. */
export interface DiagramExportResponse {
  content: string
}

export const diagramsApi = {
  /** Load the source's current diagram (latest). Throws 404 when none yet. */
  get: async (sourceId: string): Promise<DiagramResponse> => {
    const response = await apiClient.get<DiagramResponse>(
      `/sources/${sourceId}/diagram`,
    )
    return response.data
  },

  /**
   * Generate the source's diagram from its document text (first build, or a new
   * draft version when the current one is accepted). Runs the pipeline
   * server-side and resolves to the resulting diagram.
   */
  generate: async (
    sourceId: string,
    data?: DiagramChatRequest,
  ): Promise<DiagramResponse> => {
    const response = await apiClient.post<DiagramResponse>(
      `/sources/${sourceId}/diagram/chat`,
      data ?? {},
    )
    return response.data
  },

  /**
   * Refine the diagram via a natural-language instruction. Same endpoint as
   * `generate` (the backend re-runs the pipeline over the source); the
   * `instruction` rides along for a future refine-by-prompt and is harmless now.
   */
  chat: async (
    sourceId: string,
    instruction: string,
    options?: { include_azure_shapes?: boolean },
  ): Promise<DiagramResponse> => {
    const response = await apiClient.post<DiagramResponse>(
      `/sources/${sourceId}/diagram/chat`,
      { instruction, include_azure_shapes: options?.include_azure_shapes },
    )
    return response.data
  },

  /** Save a hand-edited `DiagramGraph` onto the source's draft (validated 422). */
  save: async (
    sourceId: string,
    graph: DiagramGraph,
  ): Promise<DiagramResponse> => {
    const response = await apiClient.put<DiagramResponse>(
      `/sources/${sourceId}/diagram`,
      { graph } satisfies DiagramSaveRequest,
    )
    return response.data
  },

  /**
   * Accept (freeze) the diagram: stamps `accepted`, freezes `graph_json`, and
   * stores a server-rendered static SVG snapshot. Optionally freeze a final
   * `graph` atomically (e.g. straight after a hand-edit).
   */
  accept: async (
    sourceId: string,
    graph?: DiagramGraph,
  ): Promise<DiagramResponse> => {
    const response = await apiClient.post<DiagramResponse>(
      `/sources/${sourceId}/diagram/accept`,
      graph ? ({ graph } satisfies DiagramAcceptRequest) : {},
    )
    return response.data
  },
}
