import apiClient from './client'
import type { DiagramGraph } from '@/components/diagram/DiagramRenderer.types'

/**
 * RepoGraph API — Surface 3 (the top-level "RepoGraph" panel).
 *
 * The GitDiagram experience, re-pointed at GitLab (design
 * `docs/2026-06-06-diagram-platform-design.md` §7): paste a self-hosted GitLab repo URL →
 * the same 2-step pipeline + the same custom renderer produce an architecture
 * `DiagramGraph`, with each node optionally carrying a `link` back to the GitLab file/dir and
 * a `drill` into a subsystem sub-graph.
 *
 * Mirrors the Surface-1 `diagramsApi` / Surface-2 `notebookDiagramsApi` shape one-to-one: a
 * flat object of thin `apiClient` wrappers with the request/response types co-located. Every
 * path is under the backend router prefix `/repograph`
 * (`services/docx/src/docx_app/api/repograph.py`). The generate path is **synchronous**
 * server-side (the pipeline runs inside the request — design §8: `POST /repograph {repo_url}`
 * → return graph), so `generate` resolves directly to the resulting diagram; there is no
 * command-job to poll here (unlike insights).
 *
 * Wire contract notes:
 *   • `graph` is the canonical `DiagramGraph` JSON with edges keyed by `"from"` (the Pydantic
 *     alias) — the renderer reads it as-is, so it is typed as `DiagramGraph` end-to-end. Repo
 *     nodes carry an absolute GitLab `link` (opened in a new tab on click) and may carry a
 *     `drill` into a subsystem sub-graph.
 *   • `render_snapshot_svg` is present only once `status === 'accepted'` (the frozen,
 *     server-rendered static picture — design §2 "data + picture"). The panel renders the live
 *     canvas for a draft and the snapshot once accepted, mirroring the source surface.
 *   • GitLab target/auth are supplied by the platform (FRAME 2.0 gateway) — there is no
 *     BYO-token in DocEX, so the request body carries only the repo URL.
 *   • `repo_name` / `default_branch` are optional convenience labels for the result header.
 *     The backend may omit them (the persisted diagram row only stores the canonical graph),
 *     so the panel degrades gracefully — falling back to `repo_url` for the label and hiding
 *     the branch badge when absent.
 */

/** A generated repository diagram (draft or accepted). Mirrors the backend response. */
export interface RepoGraphResponse {
  id: string
  /** The owning surface — always `"repograph"` for this panel. */
  surface: string
  /** The GitLab repo URL this diagram was generated from (the diagram's `ref`). */
  repo_url: string
  status: 'draft' | 'accepted'
  version: number
  graph: DiagramGraph | null
  /** Present only once `status === 'accepted'` (the frozen static picture). */
  render_snapshot_svg: string | null
  /** Convenience label for the result header, e.g. `"group/subgroup/project"`. */
  repo_name?: string | null
  /** The repo's default branch the graph was built from, e.g. `"main"`. */
  default_branch?: string | null
  created: string
  updated: string
}

/** Generate a repository diagram from a GitLab repo URL. */
export interface RepoGraphGenerateRequest {
  /** A self-hosted GitLab repo URL, e.g. `https://gitlab.example.com/group/project`. */
  repo_url: string
  /** Inject the Azure icon catalog into the pipeline (default on, server-side). */
  include_azure_shapes?: boolean
}

export const repoGraphApi = {
  /**
   * Generate the architecture diagram for a GitLab repository. Runs the fetch (project
   * lookup → recursive tree → README) and the 2-step pipeline server-side and resolves to the
   * resulting diagram.
   *
   * Surfaces the backend's mapped errors verbatim so the panel can explain them precisely
   * (503 = GitLab not configured · 404 = repo not found · 502 = upstream/LLM failure).
   */
  generate: async (
    repoUrl: string,
    options?: { include_azure_shapes?: boolean },
  ): Promise<RepoGraphResponse> => {
    const response = await apiClient.post<RepoGraphResponse>('/repograph', {
      repo_url: repoUrl,
      include_azure_shapes: options?.include_azure_shapes,
    } satisfies RepoGraphGenerateRequest)
    return response.data
  },
}
