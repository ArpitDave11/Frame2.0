import apiClient from './client'
import { API_BASE } from '@/lib/config'
import { getHostAuthHeaders } from '@/lib/host-auth'
import { SearchRequest, SearchResponse, AskRequest } from '@/lib/types/search'

export const searchApi = {
  // Standard search (non-streaming)
  search: async (params: SearchRequest) => {
    const response = await apiClient.post<SearchResponse>('/search', params)
    return response.data
  },

  // Ask with streaming. Relative to the /api/docx ingress prefix so it works standalone
  // (Vite proxy) and embedded (FRAME gateway); auth comes from the host.
  askKnowledgeBase: async (params: AskRequest) => {
    const url = `${API_BASE}/search/ask`

    // Use fetch with ReadableStream for SSE.
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(await getHostAuthHeaders()),
      },
      body: JSON.stringify(params)
    })

    if (!response.ok) {
      // Try to extract error message from response
      let errorMessage = `HTTP error! status: ${response.status}`
      try {
        const errorData = await response.json()
        errorMessage = errorData.detail || errorData.message || errorMessage
      } catch {
        // If response isn't JSON, use status text
        errorMessage = response.statusText || errorMessage
      }
      throw new Error(errorMessage)
    }

    if (!response.body) {
      throw new Error('No response body received')
    }

    return response.body
  }
}
