import apiClient from './client'
import type { DiagramGraph } from '@/components/diagram/DiagramRenderer.types'

/**
 * Notebook-HLD API — Surface 2 (the notebook "Diagram"/HLD view).
 *
 * Mirrors the Surface-1 `diagramsApi` shape (see `./diagrams.ts`) one-to-one: a flat
 * object of thin `apiClient` wrappers with request/response types co-located. Every path
 * is nested under `/notebooks/{id}/diagram` to match the backend router
 * (`services/docx/src/docx_app/api/notebook_diagrams.py`).
 *
 * The HLD is a **derived view**: it deterministically composes the notebook's *accepted
 * source diagrams* into one entity-bridged parent `DiagramGraph` (each source = a drillable
 * node; entities shared across >= 2 sources = cross-source bridge nodes — see
 * `docs/2026-06-07-entity-resolution-subdesign.md` §7). Unlike the source surface there is no
 * free-text "chat"/refine; the HLD is (re)built deterministically from the accepted sources
 * via `rebuild`, then optionally frozen via `accept`.
 *
 * Wire contract notes:
 *   • `graph` is the entity-bridged parent `DiagramGraph` JSON with edges keyed by `"from"`
 *     (the Pydantic alias) — the renderer reads it as-is, so it is typed as `DiagramGraph`
 *     end-to-end. HLD source nodes carry `meta.source_id` (the source ref) and `drill`
 *     (the accepted child-diagram id); bridge nodes carry `meta.source_refs`.
 *   • `render_snapshot_svg` is present only once `status === 'accepted'` (the frozen,
 *     server-rendered static picture — design §2 "data + picture").
 *   • `rebuild` is **synchronous** server-side (compose runs inside the request, with the LLM
 *     reaching only the reconciler's ambiguous tail), so it resolves directly to the new HLD;
 *     `low_confidence` then lists heuristic merges surfaced for human review (sub-design §6).
 */

/** A low-confidence merge surfaced for human review. Mirrors backend `AssignmentResponse`. */
export interface DiagramAssignment {
  /** The registry entity key the heuristic merged into. */
  entity_key: string
  /** How it was resolved — `embedding` | `llm` (only heuristic merges are surfaced). */
  method: string
  /** Resolver confidence in [0, 1]. */
  confidence: number
}

/**
 * A notebook's HLD diagram (draft or accepted). Mirrors the backend
 * `NotebookDiagramResponse`.
 */
export interface NotebookDiagramResponse {
  id: string
  notebook_id: string
  surface: string
  status: 'draft' | 'accepted'
  version: number
  graph: DiagramGraph | null
  render_snapshot_svg: string | null
  /** Count of accepted source diagrams composed into this HLD (rebuild summary). */
  source_count: number
  /** Count of cross-source bridge nodes (shared entities) (rebuild summary). */
  bridge_count: number
  /** Heuristic merges to flag for human review — populated by `rebuild` only. */
  low_confidence: DiagramAssignment[]
  created: string
  updated: string
}

export const notebookDiagramsApi = {
  /**
   * Load the notebook's current HLD (latest — draft or accepted). Throws 404 when none has
   * been built yet — the caller maps that to the "Build notebook diagram" empty state.
   */
  get: async (notebookId: string): Promise<NotebookDiagramResponse> => {
    const response = await apiClient.get<NotebookDiagramResponse>(
      `/notebooks/${notebookId}/diagram`,
    )
    return response.data
  },

  /**
   * (Re)build the notebook's HLD from its accepted source diagrams. Runs the deterministic
   * entity-bridged composition server-side and resolves to the resulting HLD (a new draft, or
   * a new version when the prior HLD was accepted — immutability). Throws 404 when the
   * notebook has no accepted source diagrams to compose.
   */
  rebuild: async (notebookId: string): Promise<NotebookDiagramResponse> => {
    const response = await apiClient.post<NotebookDiagramResponse>(
      `/notebooks/${notebookId}/diagram/rebuild`,
      {},
    )
    return response.data
  },

  /**
   * Accept (freeze) the notebook's HLD: stamps `accepted`, freezes `graph_json`, and stores a
   * server-rendered static SVG snapshot. A later rebuild then opens a new version rather than
   * mutating the frozen one.
   */
  accept: async (notebookId: string): Promise<NotebookDiagramResponse> => {
    const response = await apiClient.post<NotebookDiagramResponse>(
      `/notebooks/${notebookId}/diagram/accept`,
      {},
    )
    return response.data
  },
}
