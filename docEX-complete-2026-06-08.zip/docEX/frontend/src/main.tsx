// Standalone entry — mounts the same component FRAME consumes via federation (./DocxPanel),
// so the panel is developed/tested standalone and embedded identically.
import React from "react";
import { createRoot } from "react-dom/client";

import DocxPanel from "./DocxPanel";

const root = document.getElementById("root");
if (!root) throw new Error("root element not found");

createRoot(root).render(
  <React.StrictMode>
    <DocxPanel />
  </React.StrictMode>,
);
