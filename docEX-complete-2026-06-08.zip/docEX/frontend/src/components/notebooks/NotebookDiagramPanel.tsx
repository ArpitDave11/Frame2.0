'use client'

import { useCallback, useMemo, useState } from 'react'
import { isAxiosError } from 'axios'
import {
  Network,
  Sparkles,
  RefreshCw,
  CheckCircle2,
  Lock,
  AlertCircle,
  AlertTriangle,
  Loader2,
} from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { LoadingSpinner } from '@/components/common/LoadingSpinner'
import { DiagramRenderer } from '@/components/diagram/DiagramRenderer'
import { BreadcrumbBar } from '@/components/diagram/BreadcrumbBar'
import type {
  DiagramGraph,
  DiagramGraphNode,
} from '@/components/diagram/DiagramRenderer.types'
import {
  useNotebookDiagram,
  useRebuildNotebookDiagram,
  useAcceptNotebookDiagram,
} from '@/lib/hooks/use-notebook-diagram'
import { useDiagram } from '@/lib/hooks/use-diagram'
import { useSource } from '@/lib/hooks/use-sources'
import { useTheme } from '@/lib/stores/theme-store'
import { useTranslation } from '@/lib/hooks/use-translation'

/**
 * NotebookDiagramPanel — Surface 2 (the notebook HLD / "Build notebook diagram" view).
 *
 * The HLD is a derived, entity-bridged parent graph: each accepted source diagram becomes a
 * drillable hexagon node and each entity shared across >= 2 sources becomes a cross-source
 * bridge node (see `docs/2026-06-07-entity-resolution-subdesign.md` §7). This panel reuses the
 * frozen Surface-1 chrome — Card / CardHeader / CardContent, the empty-CTA idiom, the Alert
 * error idiom, and the same three-state guard (empty CTA / live canvas / frozen snapshot) — so
 * it reads as a sibling of the source Diagram tab.
 *
 * The HLD adds one capability over the source surface: **drill from a source bridge node into
 * that source's LLD via a breadcrumb.** Clicking a source node loads that source's accepted
 * diagram (`useDiagram` against the node's `meta.source_id`, NOT its `drill` id — `drill` is the
 * child *diagram* id, while `useDiagram` keys on the *source* id) and swaps it onto the same
 * renderer; the BreadcrumbBar (Overview › <source title>) pops back to the HLD. Because this is
 * a cross-diagram hop rather than an intra-graph sub-graph zoom, the renderer's own breadcrumb
 * push is suppressed (`onDrill` returns `false`) and this panel owns the trail.
 *
 * Flow (design §6; sub-design §8):
 *   • no HLD            → "Build notebook diagram" CTA → `rebuild`
 *   • draft             → live DiagramRenderer + Accept / Rebuild (+ low-confidence review hint)
 *   • accepted (frozen) → the static SVG snapshot + Rebuild (starts a new version)
 */

interface NotebookDiagramPanelProps {
  notebookId: string
  /** Notebook name — the implicit root of the drill breadcrumb. */
  notebookName?: string
}

const EMPTY_GRAPH: DiagramGraph = { groups: [], nodes: [], edges: [] }

export function NotebookDiagramPanel({
  notebookId,
  notebookName,
}: NotebookDiagramPanelProps): React.ReactElement {
  const { t } = useTranslation()
  const { effectiveTheme } = useTheme()

  const { data: diagram, isLoading, isError, refetch } = useNotebookDiagram(notebookId)
  const rebuild = useRebuildNotebookDiagram(notebookId)
  const accept = useAcceptNotebookDiagram(notebookId)

  // Cross-source drill: the source whose LLD is currently shown (null = HLD overview).
  // `label` is captured from the clicked HLD node so the breadcrumb reads sensibly even
  // before the real source title resolves.
  const [drilled, setDrilled] = useState<{ sourceId: string; label: string } | null>(null)
  const drilledSourceId = drilled?.sourceId ?? null

  // The drilled source's accepted LLD + its real title (compose only labels nodes with a
  // stable handle; the real title makes the breadcrumb legible). Both fetch only while drilled.
  const { data: sourceDiagram, isLoading: sourceLoading } = useDiagram(
    drilledSourceId ?? '',
    { enabled: !!drilledSourceId },
  )
  const { data: source } = useSource(drilledSourceId ?? '')

  const isAccepted = diagram?.status === 'accepted'
  const hldGraph = diagram?.graph ?? null
  const snapshot = isAccepted ? (diagram?.render_snapshot_svg ?? null) : null

  // A composition run is in flight (first build or rebuild).
  const pipelineBusy = rebuild.isPending
  const lowConfidenceCount = diagram?.low_confidence.length ?? 0

  /** Resolve a source node id from a clicked HLD node: prefer `meta.source_id`. */
  const sourceIdForNode = useCallback(
    (node: DiagramGraphNode | undefined): string | null => {
      const metaSourceId = node?.meta?.source_id
      return typeof metaSourceId === 'string' && metaSourceId ? metaSourceId : null
    },
    [],
  )

  const hldNodeIndex = useMemo(() => {
    const map = new Map<string, DiagramGraphNode>()
    for (const node of hldGraph?.nodes ?? []) map.set(node.id, node)
    return map
  }, [hldGraph])

  /**
   * Drill handler for the HLD canvas. Returns `false` to suppress the renderer's internal
   * breadcrumb (this is a cross-diagram hop, not an intra-graph zoom). Only source nodes —
   * those carrying `meta.source_id` — are drillable; bridge nodes have no source id and do
   * nothing here (their "used in" set is already visible as the bridge's edges).
   */
  const handleDrill = useCallback(
    (nodeId: string): boolean => {
      const node = hldNodeIndex.get(nodeId)
      const sourceId = sourceIdForNode(node)
      if (!sourceId) return false
      setDrilled({ sourceId, label: node?.label ?? t('notebookDiagram.sourceFallback') })
      return false
    },
    [hldNodeIndex, sourceIdForNode, t],
  )

  /** Breadcrumb navigation: -1 (root) pops back to the HLD overview. */
  const handleBreadcrumb = useCallback((depth: number) => {
    if (depth < 0) setDrilled(null)
  }, [])

  const handleRebuild = useCallback(() => {
    // Returning to the overview keeps the breadcrumb honest after a rebuild swaps the graph.
    setDrilled(null)
    rebuild.mutate(undefined, {
      onError: (err) => {
        // 404 = no accepted source diagrams to compose (the actionable empty case).
        if (isAxiosError(err) && err.response?.status === 404) {
          toast.error(t('notebookDiagram.noSources'))
          return
        }
        toast.error(t('notebookDiagram.buildFailed'))
      },
    })
  }, [rebuild, t])

  const handleAccept = useCallback(() => {
    accept.mutate(undefined, {
      onSuccess: () => toast.success(t('notebookDiagram.acceptSuccess')),
      onError: () => toast.error(t('notebookDiagram.acceptFailed')),
    })
  }, [accept, t])

  const statusBadge = useMemo(() => {
    if (!diagram) return null
    return isAccepted ? (
      <Badge variant="default" className="gap-1">
        <Lock className="h-3 w-3" />
        {t('notebookDiagram.accepted')}
      </Badge>
    ) : (
      <Badge variant="secondary" className="gap-1">
        {t('notebookDiagram.draft')} ·{' '}
        {t('notebookDiagram.version').replace('{version}', String(diagram.version))}
      </Badge>
    )
  }, [diagram, isAccepted, t])

  /* ------------------------------ loading ------------------------------- */

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Network className="h-5 w-5" />
            {t('notebookDiagram.title')}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <LoadingSpinner />
          </div>
        </CardContent>
      </Card>
    )
  }

  /* ------------------------------- error -------------------------------- */

  if (isError) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Network className="h-5 w-5" />
            {t('notebookDiagram.title')}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>{t('notebookDiagram.loadFailed')}</AlertTitle>
            <AlertDescription>
              <div className="mt-3">
                <Button size="sm" variant="outline" onClick={() => void refetch()}>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  {t('common.retry')}
                </Button>
              </div>
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    )
  }

  /* ------------------------------- header ------------------------------- */

  const header = (
    <CardHeader>
      <CardTitle className="flex items-center justify-between">
        <span className="flex items-center gap-2">
          <Network className="h-5 w-5" />
          {t('notebookDiagram.title')}
        </span>
        <div className="flex items-center gap-2">
          {statusBadge}
          {diagram && !isAccepted && (
            <Button
              size="sm"
              onClick={handleAccept}
              disabled={accept.isPending || pipelineBusy}
            >
              {accept.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {t('notebookDiagram.accepting')}
                </>
              ) : (
                <>
                  <CheckCircle2 className="mr-2 h-4 w-4" />
                  {t('notebookDiagram.accept')}
                </>
              )}
            </Button>
          )}
          {diagram && (
            <Button
              size="sm"
              variant="outline"
              onClick={handleRebuild}
              disabled={pipelineBusy || accept.isPending}
            >
              {rebuild.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {t('notebookDiagram.rebuilding')}
                </>
              ) : (
                <>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  {t('notebookDiagram.rebuild')}
                </>
              )}
            </Button>
          )}
        </div>
      </CardTitle>
      <CardDescription>
        {isAccepted ? t('notebookDiagram.acceptedHint') : t('notebookDiagram.description')}
      </CardDescription>
    </CardHeader>
  )

  /* ------------------------- empty / building --------------------------- */

  if (!diagram) {
    return (
      <Card>
        {header}
        <CardContent>
          {rebuild.isPending ? (
            <div className="flex flex-col items-center justify-center gap-3 py-16 text-center text-muted-foreground">
              <LoadingSpinner size="lg" />
              <p className="text-sm font-medium text-foreground">
                {t('notebookDiagram.building')}
              </p>
              <p className="max-w-sm text-xs">{t('notebookDiagram.buildingHint')}</p>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center text-muted-foreground">
              <Network className="mx-auto mb-3 h-12 w-12 opacity-50" />
              <p className="text-sm">{t('notebookDiagram.empty')}</p>
              <p className="mt-1 max-w-md text-xs">{t('notebookDiagram.emptyHint')}</p>
              <Button className="mt-5" onClick={handleRebuild}>
                <Sparkles className="mr-2 h-4 w-4" />
                {t('notebookDiagram.buildThis')}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    )
  }

  /* ----------------------- drill trail (shared) ------------------------- */

  const drilling = !!drilled
  // Prefer the real source title (fetched), falling back to the label captured at click time.
  const sourceLabel =
    source?.title?.trim() || drilled?.label || t('notebookDiagram.sourceFallback')

  const breadcrumb = drilled ? (
    <BreadcrumbBar
      className="mb-3"
      rootLabel={notebookName?.trim() || t('notebookDiagram.overview')}
      trail={[{ nodeId: drilled.sourceId, label: sourceLabel }]}
      onNavigate={handleBreadcrumb}
    />
  ) : null

  /* ----------------------- drilled into a source LLD -------------------- */

  if (drilling) {
    return (
      <Card>
        {header}
        <CardContent>
          {breadcrumb}
          <div className="relative h-[520px] w-full">
            {sourceLoading ? (
              <div className="flex h-full items-center justify-center rounded-lg border bg-card">
                <LoadingSpinner size="lg" />
              </div>
            ) : sourceDiagram?.graph ? (
              <DiagramRenderer
                graph={sourceDiagram.graph}
                snapshot={
                  sourceDiagram.status === 'accepted'
                    ? sourceDiagram.render_snapshot_svg
                    : null
                }
                theme={effectiveTheme}
                ariaLabel={t('notebookDiagram.sourceDiagramAria').replace(
                  '{source}',
                  sourceLabel,
                )}
              />
            ) : (
              <div className="flex h-full flex-col items-center justify-center gap-2 rounded-lg border bg-card p-8 text-center text-muted-foreground">
                <AlertCircle className="h-6 w-6 opacity-50" />
                <p className="text-sm">{t('notebookDiagram.sourceUnavailable')}</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    )
  }

  /* --------------------------- accepted (frozen) ------------------------ */

  if (isAccepted && snapshot) {
    return (
      <Card>
        {header}
        <CardContent>
          <div className="h-[520px] w-full">
            <DiagramRenderer
              graph={hldGraph ?? EMPTY_GRAPH}
              snapshot={snapshot}
              theme={effectiveTheme}
              ariaLabel={t('notebookDiagram.title')}
            />
          </div>
        </CardContent>
      </Card>
    )
  }

  /* ------------------------------- draft -------------------------------- */

  return (
    <Card>
      {header}
      <CardContent className="space-y-3">
        {lowConfidenceCount > 0 && (
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>{t('notebookDiagram.reviewTitle')}</AlertTitle>
            <AlertDescription>
              {t('notebookDiagram.reviewHint').replace(
                '{count}',
                String(lowConfidenceCount),
              )}
            </AlertDescription>
          </Alert>
        )}
        <div className="relative h-[520px] w-full">
          {hldGraph && hldGraph.nodes.length > 0 ? (
            <DiagramRenderer
              graph={hldGraph}
              theme={effectiveTheme}
              animated={!pipelineBusy}
              onDrill={handleDrill}
              ariaLabel={t('notebookDiagram.title')}
            />
          ) : (
            <div className="flex h-full items-center justify-center rounded-lg border bg-card text-sm text-muted-foreground">
              {t('notebookDiagram.empty')}
            </div>
          )}
          {/* Dim + spinner overlay while a rebuild regenerates in place. */}
          {pipelineBusy && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 rounded-lg bg-background/70 backdrop-blur-sm">
              <LoadingSpinner size="lg" />
              <p className="text-xs text-muted-foreground">
                {t('notebookDiagram.building')}
              </p>
            </div>
          )}
        </div>
        <p className="text-xs text-muted-foreground">{t('notebookDiagram.drillHint')}</p>
      </CardContent>
    </Card>
  )
}
