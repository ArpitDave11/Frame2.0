import { render, screen, fireEvent } from '@testing-library/react'
import { describe, it, expect, vi, beforeEach } from 'vitest'
import { NotebookDiagramPanel } from './NotebookDiagramPanel'
import {
  useNotebookDiagram,
  useRebuildNotebookDiagram,
  useAcceptNotebookDiagram,
} from '@/lib/hooks/use-notebook-diagram'
import { useDiagram } from '@/lib/hooks/use-diagram'
import { useSource } from '@/lib/hooks/use-sources'
import type { NotebookDiagramResponse } from '@/lib/api/notebook-diagrams'
import type { DiagramResponse } from '@/lib/api/diagrams'
import type { DiagramGraph } from '@/components/diagram/DiagramRenderer.types'

// ---- mock the data hooks (the panel is a pure shell over them) -------------- //
vi.mock('@/lib/hooks/use-notebook-diagram')
vi.mock('@/lib/hooks/use-diagram')
vi.mock('@/lib/hooks/use-sources')

// theme-store's getSystemTheme calls window.matchMedia (absent in jsdom); stub the
// hook so the panel gets a deterministic theme without a matchMedia polyfill.
vi.mock('@/lib/stores/theme-store', () => ({
  useTheme: () => ({
    theme: 'light' as const,
    setTheme: vi.fn(),
    effectiveTheme: 'light' as const,
    isDark: false,
  }),
}))

// ---- stub the heavy SVG renderer; expose onDrill via a button so the drill -- //
//      wiring (read meta.source_id → swap graph) is testable without elkjs.    //
const drillSpy = vi.fn()
vi.mock('@/components/diagram/DiagramRenderer', () => ({
  DiagramRenderer: ({
    ariaLabel,
    snapshot,
    onDrill,
  }: {
    ariaLabel?: string
    snapshot?: string | null
    onDrill?: (nodeId: string, drillTarget: string) => void | boolean
  }) => (
    <div
      data-testid="diagram-renderer"
      data-aria={ariaLabel}
      data-snapshot={snapshot ? 'yes' : 'no'}
    >
      <button
        type="button"
        data-testid="drill-source-node"
        onClick={() => {
          drillSpy()
          onDrill?.('src_abc', 'diagram:1')
        }}
      >
        drill
      </button>
    </div>
  ),
}))

// theme store is a plain zustand hook; the real one is fine in jsdom.

const SOURCE_GRAPH: DiagramGraph = {
  groups: [],
  nodes: [{ id: 'a', label: 'A', type: 'box' }],
  edges: [],
}

const HLD_GRAPH: DiagramGraph = {
  groups: [],
  nodes: [
    {
      id: 'src_abc',
      label: 'Source abc',
      type: 'source',
      shape: 'hexagon',
      drill: 'diagram:1',
      meta: { source_id: 'source:abc' },
    },
    {
      id: 'ent_customer',
      label: 'Customer',
      type: 'actor',
      shape: 'circle',
      entity: 'customer',
      meta: { source_refs: ['source:abc', 'source:def'], shared: true },
    },
  ],
  edges: [],
}

function hldMock(
  overrides: Partial<{
    data: NotebookDiagramResponse | null
    isLoading: boolean
    isError: boolean
  }> = {},
) {
  return {
    data: overrides.data ?? null,
    isLoading: overrides.isLoading ?? false,
    isError: overrides.isError ?? false,
    refetch: vi.fn(),
  } as unknown as ReturnType<typeof useNotebookDiagram>
}

function mutationMock(isPending = false) {
  return {
    mutate: vi.fn(),
    isPending,
  } as unknown as ReturnType<typeof useRebuildNotebookDiagram>
}

function diagramRow(over: Partial<NotebookDiagramResponse>): NotebookDiagramResponse {
  return {
    id: 'nbdiag:1',
    notebook_id: 'nb:1',
    surface: 'notebook',
    status: 'draft',
    version: 1,
    graph: HLD_GRAPH,
    render_snapshot_svg: null,
    source_count: 1,
    bridge_count: 1,
    low_confidence: [],
    created: '',
    updated: '',
    ...over,
  }
}

function sourceDiagramMock(
  data: DiagramResponse | null,
  isLoading = false,
) {
  return {
    data,
    isLoading,
    isError: false,
    refetch: vi.fn(),
  } as unknown as ReturnType<typeof useDiagram>
}

describe('NotebookDiagramPanel', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    // Sensible defaults; individual tests override the HLD hook.
    vi.mocked(useRebuildNotebookDiagram).mockReturnValue(mutationMock())
    vi.mocked(useAcceptNotebookDiagram).mockReturnValue(
      mutationMock() as unknown as ReturnType<typeof useAcceptNotebookDiagram>,
    )
    vi.mocked(useDiagram).mockReturnValue(sourceDiagramMock(null))
    vi.mocked(useSource).mockReturnValue({
      data: undefined,
    } as unknown as ReturnType<typeof useSource>)
  })

  const props = { notebookId: 'nb:1', notebookName: 'My Notebook' }

  it('shows the loading spinner while fetching the HLD', () => {
    vi.mocked(useNotebookDiagram).mockReturnValue(hldMock({ isLoading: true }))
    render(<NotebookDiagramPanel {...props} />)
    expect(screen.getByTestId('loading-spinner')).toBeInTheDocument()
  })

  it('renders the build CTA in the empty state (no HLD yet)', () => {
    vi.mocked(useNotebookDiagram).mockReturnValue(hldMock({ data: null }))
    render(<NotebookDiagramPanel {...props} />)
    expect(screen.getByText('notebookDiagram.empty')).toBeInTheDocument()
    expect(screen.getByText('notebookDiagram.buildThis')).toBeInTheDocument()
  })

  it('fires rebuild when the build CTA is clicked', () => {
    const rebuild = mutationMock()
    vi.mocked(useRebuildNotebookDiagram).mockReturnValue(rebuild)
    vi.mocked(useNotebookDiagram).mockReturnValue(hldMock({ data: null }))
    render(<NotebookDiagramPanel {...props} />)
    fireEvent.click(screen.getByText('notebookDiagram.buildThis'))
    expect(rebuild.mutate).toHaveBeenCalledTimes(1)
  })

  it('renders the error state with a retry button', () => {
    vi.mocked(useNotebookDiagram).mockReturnValue(hldMock({ isError: true }))
    render(<NotebookDiagramPanel {...props} />)
    expect(screen.getByText('notebookDiagram.loadFailed')).toBeInTheDocument()
    expect(screen.getByText('common.retry')).toBeInTheDocument()
  })

  it('renders the live canvas + accept/rebuild for a draft HLD', () => {
    vi.mocked(useNotebookDiagram).mockReturnValue(
      hldMock({ data: diagramRow({ status: 'draft' }) }),
    )
    render(<NotebookDiagramPanel {...props} />)
    expect(screen.getByTestId('diagram-renderer')).toBeInTheDocument()
    expect(screen.getByText('notebookDiagram.accept')).toBeInTheDocument()
    expect(screen.getByText('notebookDiagram.rebuild')).toBeInTheDocument()
    // Drill affordance hint is shown on the draft.
    expect(screen.getByText('notebookDiagram.drillHint')).toBeInTheDocument()
  })

  it('surfaces a review hint when there are low-confidence merges', () => {
    vi.mocked(useNotebookDiagram).mockReturnValue(
      hldMock({
        data: diagramRow({
          low_confidence: [{ entity_key: 'customer', method: 'llm', confidence: 0.6 }],
        }),
      }),
    )
    render(<NotebookDiagramPanel {...props} />)
    expect(screen.getByText('notebookDiagram.reviewTitle')).toBeInTheDocument()
  })

  it('drills into a source LLD (reads meta.source_id) and shows a breadcrumb', () => {
    vi.mocked(useNotebookDiagram).mockReturnValue(
      hldMock({ data: diagramRow({ status: 'draft' }) }),
    )
    // After drilling, the source's accepted LLD resolves.
    vi.mocked(useDiagram).mockReturnValue(
      sourceDiagramMock({
        id: 'd1',
        source_id: 'source:abc',
        surface: 'source',
        status: 'draft',
        version: 1,
        graph: SOURCE_GRAPH,
        render_snapshot_svg: null,
        created: '',
        updated: '',
      }),
    )
    render(<NotebookDiagramPanel {...props} />)

    fireEvent.click(screen.getByTestId('drill-source-node'))

    // onDrill was wired through to the renderer stub.
    expect(drillSpy).toHaveBeenCalledTimes(1)
    // The breadcrumb root (notebook name) appears once drilled.
    expect(screen.getByText('My Notebook')).toBeInTheDocument()
    // The drilled source node's label is the active breadcrumb hop.
    expect(screen.getByText('Source abc')).toBeInTheDocument()
  })

  it('renders the frozen snapshot for an accepted HLD', () => {
    vi.mocked(useNotebookDiagram).mockReturnValue(
      hldMock({
        data: diagramRow({
          status: 'accepted',
          render_snapshot_svg: '<svg></svg>',
        }),
      }),
    )
    render(<NotebookDiagramPanel {...props} />)
    const renderer = screen.getByTestId('diagram-renderer')
    expect(renderer).toHaveAttribute('data-snapshot', 'yes')
    expect(screen.getByText('notebookDiagram.accepted')).toBeInTheDocument()
    // Accepted HLD does not offer Accept again.
    expect(screen.queryByText('notebookDiagram.accept')).not.toBeInTheDocument()
  })
})
