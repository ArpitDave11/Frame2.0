/**
 * EdgePath — renders one DiagramGraphEdge: its (animated or static) route via
 * the `renderFlow` seam, plus an optional midpoint label on a token-tinted
 * backdrop so it stays legible over crossing edges.
 */

import type { DiagramGraphEdge } from './DiagramRenderer.types'
import {
  renderFlow,
  pointsToPath,
  routeLength,
  durationForLength,
  type FlowPoint,
} from './renderFlow'
import { flowColor } from './diagramTheme'

export interface EdgePathProps {
  edge: DiagramGraphEdge
  /** Route points (canvas coords) from the ELK layout. */
  points: FlowPoint[]
  /** DOM-safe unique id for this edge's path/gradient/marker references. */
  pathId: string
  /** Live canvas (true) vs static export (false). */
  animated: boolean
  /** Arrowhead marker id (one per colour, defined once by the renderer). */
  markerId: string
}

/** Midpoint of a polyline, for label placement. */
function midpoint(points: FlowPoint[]): FlowPoint {
  if (points.length === 0) return { x: 0, y: 0 }
  const mid = Math.floor(points.length / 2)
  if (points.length % 2 === 1) return points[mid]
  const a = points[mid - 1]
  const b = points[mid]
  return { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }
}

export function EdgePath({
  edge,
  points,
  pathId,
  animated,
  markerId,
}: EdgePathProps): React.ReactElement | null {
  if (points.length < 2) return null

  const color = flowColor(edge.flow)
  const pathD = pointsToPath(points)
  const isAnimated = animated && edge.animated === true
  const dashed = edge.style === 'dashed'
  const duration = durationForLength(routeLength(points))

  const label = edge.label?.trim()
  const labelPos = label ? midpoint(points) : null
  const labelWidth = label ? Math.min(label.length * 6 + 12, 160) : 0

  return (
    <g aria-hidden="true">
      {renderFlow({
        pathId,
        pathD,
        color,
        animated: isAnimated,
        dashed,
        durationSec: duration,
        markerId,
      })}
      {label && labelPos && (
        <g transform={`translate(${labelPos.x}, ${labelPos.y})`}>
          <rect
            x={-labelWidth / 2}
            y={-9}
            width={labelWidth}
            height={18}
            rx={6}
            fill="var(--card)"
            stroke="var(--border)"
            strokeWidth={0.75}
            opacity={0.95}
          />
          <text
            x={0}
            y={3.5}
            textAnchor="middle"
            fontSize={9.5}
            fill="var(--muted-foreground)"
          >
            {label.length > 24 ? `${label.slice(0, 23)}…` : label}
          </text>
        </g>
      )}
    </g>
  )
}
