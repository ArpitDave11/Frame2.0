/**
 * Shared type definitions for the custom SVG DiagramRenderer.
 *
 * These mirror the backend `DiagramGraph` Pydantic models 1:1 (see
 * `services/docx/src/docx_app/diagram/model.py`, itself extended from
 * gitdiagram's `graph_service.py`). The canonical artifact is JSON: every
 * renderer in this package is a pure, deterministic function of a
 * `DiagramGraph`.
 *
 * NOTE on the `entity` field: it is present in the model for forward
 * compatibility with the Notebook-HLD entity registry (see
 * `docs/2026-06-07-entity-resolution-subdesign.md`), but NOTHING in this
 * Surface-1 renderer consumes it. It is carried through untouched.
 */

/** Geometric primitives the renderer knows how to draw when no icon is set. */
export type DiagramNodeShape =
  | 'box'
  | 'database'
  | 'queue'
  | 'document'
  | 'circle'
  | 'hexagon'
  | 'diamond'
  | 'cloud'
  | 'person'

/** A logical grouping container (single-level only, per the model). */
export interface DiagramGraphGroup {
  id: string
  label: string
  description?: string | null
  /** Repeated-stack annotation, e.g. "Nx" / "6x" — rendered as a badge on the group. */
  repeat?: string | null
}

/** A single architecture node. */
export interface DiagramGraphNode {
  id: string
  label: string
  /** Freeform, repo/document-specific kind; shown as a secondary sub-label. */
  type: string
  description?: string | null
  groupId?: string | null
  /** Rendering hint when no icon is supplied. */
  shape?: DiagramNodeShape | null
  /**
   * Catalog icon id, e.g. `"azure/compute/Virtual_Machine"`. Resolved against
   * the `azureIconRegistry`; falls back to the generic `shape` when missing.
   */
  icon?: string | null
  /** Optional URL / file path; clicking opens it in a new tab. */
  link?: string | null
  /** Id of a deeper sub-graph node to zoom into (breadcrumb drill-down). */
  drill?: string | null
  /** Canonical shared-entity key — NOT consumed in Surface 1 (see header). */
  entity?: string | null
  /** Per-node metadata (oh-my-mermaid style). */
  meta?: DiagramNodeMeta | null
}

export interface DiagramNodeMeta {
  description?: string | null
  constraint?: string | null
  concern?: string | null
  context?: string | null
  /** Tolerate forward-compatible keys without losing type-safety on the known ones. */
  [key: string]: unknown
}

/** A directed connection between two nodes. */
export interface DiagramGraphEdge {
  /** Source node id. Serialized as `from` on the wire (Pydantic alias). */
  from: string
  /** Target node id. */
  to: string
  label?: string | null
  description?: string | null
  style?: 'solid' | 'dashed' | null
  /** When true, the live canvas rides a glowing particle along the path. */
  animated?: boolean | null
  /** Semantic flow key → mapped to a chart-N token colour. */
  flow?: string | null
}

/** The complete, validated graph. */
export interface DiagramGraph {
  groups: DiagramGraphGroup[]
  nodes: DiagramGraphNode[]
  edges: DiagramGraphEdge[]
}

/** Active colour scheme; drives token resolution for static SVG export. */
export type DiagramTheme = 'light' | 'dark'

/** One breadcrumb hop in the drill-down stack. */
export interface BreadcrumbEntry {
  nodeId: string
  label: string
}
