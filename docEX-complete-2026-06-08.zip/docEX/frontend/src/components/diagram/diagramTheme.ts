/**
 * Token resolution for the DiagramRenderer.
 *
 * Every colour the renderer uses is a CSS custom property defined in
 * `globals.css` (UBS theme). No hardcoded hex anywhere — this module is the one
 * place that maps semantic intent → token reference.
 */

import type { DiagramTheme } from './DiagramRenderer.types'

/** Chart token cycle used to colour distinct `edge.flow` semantics. */
const FLOW_TOKENS = [
  'var(--chart-1)',
  'var(--chart-2)',
  'var(--chart-3)',
  'var(--chart-4)',
  'var(--chart-5)',
] as const

/**
 * Resolve an edge's stroke colour. A `flow` key is hashed to a stable
 * chart-token so the same flow reads in the same colour across the canvas;
 * edges with no flow use the primary accent.
 */
export function flowColor(flow: string | null | undefined): string {
  if (!flow) return 'var(--primary)'
  let hash = 0
  for (let i = 0; i < flow.length; i++) {
    hash = (hash * 31 + flow.charCodeAt(i)) | 0
  }
  const index = Math.abs(hash) % FLOW_TOKENS.length
  return FLOW_TOKENS[index]
}

/**
 * A stable chart-token colour for a group by its position, so each compound container (and
 * the nodes inside it) reads in a distinct hue — the colour-coded look of a layered
 * architecture diagram (e.g. encoder vs decoder). Cycles the 5 chart tokens.
 */
export function groupColor(index: number): string {
  const len = FLOW_TOKENS.length
  return FLOW_TOKENS[((index % len) + len) % len]
}

/**
 * For static SVG export the file must be self-contained, so CSS variables get
 * replaced with concrete values from the active theme. These mirror the
 * `:root` / `.dark` blocks in `globals.css` exactly.
 */
const TOKEN_VALUES: Record<DiagramTheme, Record<string, string>> = {
  light: {
    '--background': '#ffffff',
    '--foreground': '#030213',
    '--card': '#ffffff',
    '--card-foreground': '#030213',
    '--primary': '#e60000',
    '--primary-foreground': '#ffffff',
    '--muted': '#ececf0',
    '--muted-foreground': '#717182',
    '--border': '#e5e7eb',
    '--ring': '#e60000',
    '--chart-1': '#e60000',
    '--chart-2': '#030213',
    '--chart-3': '#717182',
    '--chart-4': '#b30000',
    '--chart-5': '#9ca3af',
  },
  dark: {
    '--background': '#1a1a1c',
    '--foreground': '#fafafa',
    '--card': '#232326',
    '--card-foreground': '#fafafa',
    '--primary': '#f23030',
    '--primary-foreground': '#ffffff',
    '--muted': '#2a2a2e',
    '--muted-foreground': '#a1a1ab',
    '--border': 'rgba(255,255,255,0.10)',
    '--ring': '#f23030',
    '--chart-1': '#f23030',
    '--chart-2': '#fafafa',
    '--chart-3': '#a1a1ab',
    '--chart-4': '#b30000',
    '--chart-5': '#717182',
  },
}

/**
 * Replace every `var(--token)` occurrence in a string with its concrete value
 * for the given theme (used when serialising a self-contained export SVG).
 */
export function inlineTokens(svg: string, theme: DiagramTheme): string {
  const values = TOKEN_VALUES[theme]
  return svg.replace(/var\((--[a-z0-9-]+)\)/gi, (match, token: string) => {
    return values[token] ?? match
  })
}
