/**
 * BreadcrumbBar — the drill-down trail (Root › Group › SubNode).
 *
 * Each hop is a real <button> (keyboard reachable, focus-visible). Clicking a
 * hop pops the stack back to that level. Tokens only.
 */

import { ChevronRight } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { BreadcrumbEntry } from './DiagramRenderer.types'

export interface BreadcrumbBarProps {
  /** The drill stack, root first. Empty when at the top level. */
  trail: BreadcrumbEntry[]
  /** Label for the implicit root hop. */
  rootLabel: string
  /** Pop to a given depth: -1 = root, 0..n = a trail index. */
  onNavigate: (depth: number) => void
  className?: string
}

export function BreadcrumbBar({
  trail,
  rootLabel,
  onNavigate,
  className,
}: BreadcrumbBarProps): React.ReactElement | null {
  if (trail.length === 0) return null

  return (
    <nav
      aria-label="Diagram drill-down trail"
      className={cn('flex items-center gap-1 text-sm', className)}
    >
      <button
        type="button"
        onClick={() => onNavigate(-1)}
        className="rounded px-1.5 py-0.5 text-muted-foreground transition-colors hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        {rootLabel}
      </button>
      {trail.map((entry, index) => {
        const isLast = index === trail.length - 1
        return (
          <span key={entry.nodeId} className="flex items-center gap-1">
            <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" aria-hidden="true" />
            <button
              type="button"
              onClick={() => onNavigate(index)}
              aria-current={isLast ? 'page' : undefined}
              disabled={isLast}
              className={cn(
                'rounded px-1.5 py-0.5 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
                isLast
                  ? 'font-medium text-foreground'
                  : 'text-muted-foreground hover:text-primary',
              )}
            >
              {entry.label}
            </button>
          </span>
        )
      })}
    </nav>
  )
}
