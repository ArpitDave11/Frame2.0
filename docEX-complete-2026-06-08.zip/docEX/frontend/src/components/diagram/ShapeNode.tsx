/**
 * ShapeNode — renders one DiagramGraphNode as SVG at a laid-out box.
 *
 * Two visual modes:
 *   • icon node  — when `node.icon` resolves: a card rect + embedded inline
 *                  glyph chip + label + type sub-label.
 *   • shape node — otherwise: a themed geometric primitive by `node.shape`
 *                  (box | database | queue | document | circle | hexagon |
 *                  diamond | cloud | person).
 *
 * Affordances: a "drill" chevron badge (`node.drill`), an "open ↗" badge
 * (`node.link`), hover + selected states, and full keyboard a11y on
 * interactive nodes. Every colour is a CSS token — no hardcoded hex.
 */

import { useId, useState, type KeyboardEvent } from 'react'
import type { DiagramGraphNode } from './DiagramRenderer.types'
import { resolveIcon, useAzureIcon } from './azure-icons'

export interface ShapeNodeProps {
  node: DiagramGraphNode
  x: number
  y: number
  width: number
  height: number
  selected: boolean
  /** Chart-token colour of the node's group, used to tint its outline (colour-coding). */
  groupColor?: string
  onActivate: (node: DiagramGraphNode) => void
}

/** Truncate a label to fit roughly within the node width. */
function clampText(text: string, max: number): string {
  if (text.length <= max) return text
  return `${text.slice(0, max - 1)}…`
}

export function ShapeNode({
  node,
  x,
  y,
  width,
  height,
  selected,
  groupColor,
  onActivate,
}: ShapeNodeProps): React.ReactElement {
  const [hovered, setHovered] = useState(false)
  const reactId = useId().replace(/:/g, '')
  // Real Microsoft Azure icon once it loads (full-colour, branded); the themed glyph shows
  // instantly and until then (and for any non-Azure / missing id).
  const realIcon = useAzureIcon(node.icon)
  const iconSvg = realIcon ?? resolveIcon(node.icon)
  const interactive = Boolean(node.drill || node.link)
  const active = hovered || selected

  const handleKeyDown = (event: KeyboardEvent<SVGGElement>): void => {
    if (!interactive) return
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault()
      onActivate(node)
    }
  }

  const strokeColor = active ? 'var(--primary)' : (groupColor ?? 'var(--border)')
  const strokeWidth = active ? 2 : 1.25
  const filter = active ? `url(#node-shadow-${reactId})` : undefined

  // Shared <g> wrapper: positions the node, carries a11y + interaction.
  const groupProps = {
    transform: `translate(${x}, ${y})`,
    role: interactive ? 'button' : 'img',
    'aria-label': interactive
      ? `${node.label}, ${node.type}${node.drill ? ', drill in' : ''}${node.link ? ', opens link' : ''}`
      : `${node.label}, ${node.type}`,
    tabIndex: interactive ? 0 : -1,
    style: {
      cursor: interactive ? 'pointer' : 'default',
      outline: 'none',
      transition: 'transform 120ms ease',
    } as React.CSSProperties,
    onMouseEnter: () => setHovered(true),
    onMouseLeave: () => setHovered(false),
    onClick: interactive ? () => onActivate(node) : undefined,
    onKeyDown: handleKeyDown,
  }

  return (
    <g {...groupProps}>
      <defs>
        <filter
          id={`node-shadow-${reactId}`}
          x="-20%"
          y="-20%"
          width="140%"
          height="140%"
        >
          <feDropShadow
            dx="0"
            dy="2"
            stdDeviation="4"
            floodColor="var(--primary)"
            floodOpacity="0.18"
          />
        </filter>
      </defs>

      {iconSvg
        ? renderIconNode({ node, width, height, iconSvg, strokeColor, strokeWidth, filter, focusRing: selected })
        : renderShapeNode({ node, width, height, strokeColor, strokeWidth, filter, focusRing: selected })}

      {/* Drill affordance */}
      {node.drill && (
        <g transform={`translate(${width - 18}, ${height - 14})`} aria-hidden="true">
          <rect x={-26} y={-9} width={44} height={18} rx={9} fill="var(--primary)" opacity={active ? 1 : 0.82} />
          <text x={-15} y={3} fontSize={8} fontWeight={600} fill="var(--primary-foreground)" letterSpacing="0.04em">
            DRILL
          </text>
          <path d="M9 -2 L13 -2 L11 2 Z" fill="var(--primary-foreground)" />
        </g>
      )}

      {/* Link affordance */}
      {node.link && (
        <g transform={`translate(${width - 14}, 12)`} aria-hidden="true">
          <circle r={9} fill="var(--card)" stroke="var(--border)" strokeWidth={1} />
          <path
            d="M-2.5 2.5 L2.5 -2.5 M0 -2.5 L2.5 -2.5 L2.5 0"
            stroke="var(--primary)"
            strokeWidth={1.4}
            strokeLinecap="round"
            strokeLinejoin="round"
            fill="none"
          />
        </g>
      )}
    </g>
  )
}

interface RenderArgs {
  node: DiagramGraphNode
  width: number
  height: number
  strokeColor: string
  strokeWidth: number
  filter: string | undefined
  focusRing: boolean
}

function renderIconNode({
  node,
  width,
  height,
  iconSvg,
  strokeColor,
  strokeWidth,
  filter,
  focusRing,
}: RenderArgs & { iconSvg: string }): React.ReactElement {
  const iconSize = 32
  const iconX = width / 2 - iconSize / 2
  return (
    <>
      {focusRing && (
        <rect x={-3} y={-3} width={width + 6} height={height + 6} rx={12} fill="none" stroke="var(--ring)" strokeWidth={1.5} strokeDasharray="3 3" />
      )}
      <rect
        x={0}
        y={0}
        width={width}
        height={height}
        rx={10}
        fill="var(--card)"
        stroke={strokeColor}
        strokeWidth={strokeWidth}
        filter={filter}
      />
      {/* Icon chip background */}
      <rect x={iconX - 6} y={10} width={iconSize + 12} height={iconSize + 12} rx={9} fill="var(--muted)" />
      {/* Embedded glyph as a NATIVE nested <svg> (NOT <foreignObject>): an SVG
          containing <foreignObject> taints the 2D canvas, so PNG export throws,
          and the HTML is dropped when the standalone .svg is viewed as an <img>.
          A nested <svg> keeps the glyph's own viewBox and rasterises cleanly.
          currentColor → primary via the `color` attribute. */}
      <svg
        x={iconX}
        y={16}
        width={iconSize}
        height={iconSize}
        color="var(--primary)"
        dangerouslySetInnerHTML={{ __html: iconSvg }}
      />
      <text
        x={width / 2}
        y={height - 22}
        textAnchor="middle"
        fontSize={12}
        fontWeight={600}
        fill="var(--card-foreground)"
      >
        {clampText(node.label, 18)}
      </text>
      <text
        x={width / 2}
        y={height - 9}
        textAnchor="middle"
        fontSize={9.5}
        fill="var(--muted-foreground)"
      >
        {clampText(node.type, 22)}
      </text>
    </>
  )
}

function renderShapeNode({
  node,
  width,
  height,
  strokeColor,
  strokeWidth,
  filter,
  focusRing,
}: RenderArgs): React.ReactElement {
  const label = (
    <>
      <text x={width / 2} y={height / 2 - 3} textAnchor="middle" fontSize={12} fontWeight={600} fill="var(--card-foreground)">
        {clampText(node.label, 18)}
      </text>
      <text x={width / 2} y={height / 2 + 12} textAnchor="middle" fontSize={9} fill="var(--muted-foreground)">
        {clampText(node.type, 24)}
      </text>
    </>
  )

  const fill = 'var(--card)'
  const common = { fill, stroke: strokeColor, strokeWidth, filter }
  const ring = focusRing ? (
    <rect x={-3} y={-3} width={width + 6} height={height + 6} rx={12} fill="none" stroke="var(--ring)" strokeWidth={1.5} strokeDasharray="3 3" />
  ) : null

  switch (node.shape) {
    case 'database': {
      const ry = 7
      return (
        <>
          {ring}
          <path
            d={`M0 ${ry} a ${width / 2} ${ry} 0 0 1 ${width} 0 v ${height - ry * 2} a ${width / 2} ${ry} 0 0 1 ${-width} 0 Z`}
            {...common}
          />
          <ellipse cx={width / 2} cy={ry} rx={width / 2} ry={ry} fill="var(--muted)" stroke={strokeColor} strokeWidth={strokeWidth} />
          {label}
        </>
      )
    }
    case 'queue': {
      return (
        <>
          {ring}
          <rect x={0} y={0} width={width} height={height} rx={8} {...common} />
          <line x1={width - 22} y1={6} x2={width - 22} y2={height - 6} stroke="var(--border)" strokeWidth={1} />
          <line x1={width - 12} y1={6} x2={width - 12} y2={height - 6} stroke="var(--border)" strokeWidth={1} />
          {label}
        </>
      )
    }
    case 'document': {
      const wave = 8
      return (
        <>
          {ring}
          <path
            d={`M0 0 H${width} V${height - wave} q ${-width / 4} ${wave * 1.6} ${-width / 2} 0 q ${-width / 4} ${-wave * 1.6} ${-width / 2} 0 Z`}
            {...common}
          />
          {label}
        </>
      )
    }
    case 'circle': {
      const r = Math.min(width, height) / 2
      return (
        <>
          {ring}
          <circle cx={width / 2} cy={height / 2} r={r} {...common} />
          {label}
        </>
      )
    }
    case 'hexagon': {
      const inset = height / 2
      const pts = [
        `${inset},0`,
        `${width - inset},0`,
        `${width},${height / 2}`,
        `${width - inset},${height}`,
        `${inset},${height}`,
        `0,${height / 2}`,
      ].join(' ')
      return (
        <>
          {ring}
          <polygon points={pts} {...common} />
          {label}
        </>
      )
    }
    case 'diamond': {
      const pts = [
        `${width / 2},0`,
        `${width},${height / 2}`,
        `${width / 2},${height}`,
        `0,${height / 2}`,
      ].join(' ')
      return (
        <>
          {ring}
          <polygon points={pts} {...common} />
          {label}
        </>
      )
    }
    case 'cloud': {
      // A soft, fully-rounded boundary reads as "external cloud / internet" without a
      // fragile multi-arc path; clean at any size.
      return (
        <>
          {ring}
          <rect x={0} y={0} width={width} height={height} rx={height / 2} {...common} />
          {label}
        </>
      )
    }
    case 'person': {
      // A small actor avatar on the left, label to its right (box stays the hit target).
      const cx = 22
      const cy = height / 2
      return (
        <>
          {ring}
          <rect x={0} y={0} width={width} height={height} rx={10} {...common} />
          <circle cx={cx} cy={cy - 7} r={6} fill="none" stroke={strokeColor} strokeWidth={strokeWidth} />
          <path
            d={`M ${cx - 9} ${cy + 9} a 9 9 0 0 1 18 0`}
            fill="none"
            stroke={strokeColor}
            strokeWidth={strokeWidth}
          />
          {label}
        </>
      )
    }
    case 'box':
    default:
      return (
        <>
          {ring}
          <rect x={0} y={0} width={width} height={height} rx={10} {...common} />
          {label}
        </>
      )
  }
}
