/**
 * renderFlow — the animation seam for edges.
 *
 * All motion lives behind this boundary so SMIL (`<animateMotion>` +
 * `<animate>`) can later be swapped for requestAnimationFrame / CSS
 * `offset-path` WITHOUT touching `EdgePath` or `DiagramRenderer`. SMIL is the
 * simplest cross-browser SVG animation today; it is, however, the least
 * React-native option and has been periodically rumoured for deprecation —
 * hence the seam (design §4).
 *
 * Exports are STATIC by definition: a PNG can't animate, and a standalone
 * SVG's SMIL usually won't run when embedded as an `<img>` elsewhere. So the
 * `static` path (used by `exportDiagram` and the accepted SVG snapshot) emits a
 * directional gradient + arrowhead and NO `<animateMotion>`.
 */

import type { ReactNode } from 'react'
import { createElement, Fragment } from 'react'

/** A point in canvas coordinates. */
export interface FlowPoint {
  x: number
  y: number
}

/**
 * Turn a list of route points into an SVG path `d`. Uses a light Catmull-Rom →
 * cubic smoothing so spline routes from ELK read as gentle curves rather than
 * polylines. Two-point routes stay straight.
 */
export function pointsToPath(points: FlowPoint[]): string {
  if (points.length === 0) return ''
  if (points.length === 1) return `M ${points[0].x} ${points[0].y}`
  if (points.length === 2) {
    return `M ${points[0].x} ${points[0].y} L ${points[1].x} ${points[1].y}`
  }

  const d: string[] = [`M ${points[0].x} ${points[0].y}`]
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[i - 1] ?? points[i]
    const p1 = points[i]
    const p2 = points[i + 1]
    const p3 = points[i + 2] ?? p2
    const t = 1 / 6
    const c1x = p1.x + (p2.x - p0.x) * t
    const c1y = p1.y + (p2.y - p0.y) * t
    const c2x = p2.x - (p3.x - p1.x) * t
    const c2y = p2.y - (p3.y - p1.y) * t
    d.push(`C ${c1x} ${c1y} ${c2x} ${c2y} ${p2.x} ${p2.y}`)
  }
  return d.join(' ')
}

export interface RenderFlowArgs {
  /** Unique, DOM-safe id for this edge's path + gradient + marker references. */
  pathId: string
  /** The SVG path `d` for the edge route. */
  pathD: string
  /** CSS variable reference for the stroke colour, e.g. `var(--primary)`. */
  color: string
  /** `true` → live canvas (SMIL); `false` → static export path. */
  animated: boolean
  /** Dashed vs solid. */
  dashed: boolean
  /** Animation duration in seconds (live only). Derived from path length. */
  durationSec: number
  /** Marker id to terminate the path with an arrowhead. */
  markerId: string
}

/**
 * Render a single edge's path + (optionally) its riding particle + animated
 * gradient. Returns plain React nodes built with `createElement` so this stays
 * a `.ts` module (the renderer composes them into the SVG tree).
 */
export function renderFlow(args: RenderFlowArgs): ReactNode {
  const { pathId, pathD, color, animated, dashed, durationSec, markerId } = args
  const gradientId = `${pathId}-grad`
  const dash = dashed ? '6 4' : undefined

  if (!animated) {
    // Static: a single themed stroke with an arrowhead. No SMIL.
    return createElement('path', {
      d: pathD,
      fill: 'none',
      stroke: color,
      strokeWidth: 1.75,
      strokeDasharray: dash,
      strokeLinecap: 'round',
      markerEnd: `url(#${markerId})`,
    })
  }

  // Live canvas: animated gradient stroke + a glowing particle on the route.
  const defs = createElement(
    'defs',
    { key: 'defs' },
    createElement(
      'linearGradient',
      {
        // Default gradientUnits (objectBoundingBox) makes the 0%–100% coords
        // valid; with userSpaceOnUse those percentages are meaningless and the
        // gradient collapses to a near-degenerate fill.
        id: gradientId,
        x1: '0%',
        y1: '0%',
        x2: '100%',
        y2: '0%',
      },
      createElement(
        'stop',
        { offset: '0%', stopColor: color, stopOpacity: 0.25 },
        createElement('animate', {
          attributeName: 'stop-opacity',
          values: '0.25;0.9;0.25',
          dur: '2.4s',
          repeatCount: 'indefinite',
        }),
      ),
      createElement('stop', { offset: '100%', stopColor: color, stopOpacity: 0.9 }),
    ),
  )

  const flowDash = dashed ? '6 6' : '10 8'
  const path = createElement(
    'path',
    {
      key: 'path',
      id: pathId,
      d: pathD,
      fill: 'none',
      stroke: `url(#${gradientId})`,
      strokeWidth: 2,
      strokeDasharray: flowDash,
      strokeLinecap: 'round',
      markerEnd: `url(#${markerId})`,
    },
    // Marching-ants flow: travel the dash pattern along the route (on top of the riding
    // particle) for an unmistakably "live" connector. The SMIL stroke-dashoffset animation
    // stays behind the renderFlow seam, so it can later move to CSS offset-path without
    // touching EdgePath / DiagramRenderer.
    createElement('animate', {
      attributeName: 'stroke-dashoffset',
      from: dashed ? '12' : '18',
      to: '0',
      dur: `${Math.max(0.8, durationSec / 4).toFixed(2)}s`,
      repeatCount: 'indefinite',
    }),
  )

  const particle = createElement(
    'circle',
    { key: 'particle', r: 3.5, fill: color, opacity: 0.9 },
    createElement(
      'animateMotion',
      {
        dur: `${durationSec}s`,
        repeatCount: 'indefinite',
        rotate: 'auto',
        keyPoints: '0;1',
        keyTimes: '0;1',
        calcMode: 'linear',
      },
      createElement('mpath', { href: `#${pathId}` }),
    ),
  )

  return createElement(Fragment, null, defs, path, particle)
}

/** Rough pixel length of a polyline route (drives particle speed). */
export function routeLength(points: FlowPoint[]): number {
  let total = 0
  for (let i = 1; i < points.length; i++) {
    total += Math.hypot(points[i].x - points[i - 1].x, points[i].y - points[i - 1].y)
  }
  return total
}

/** Map a route length to a pleasant traversal duration (clamped 2.5–7s). */
export function durationForLength(length: number): number {
  const seconds = length / 90
  return Math.min(7, Math.max(2.5, seconds))
}
