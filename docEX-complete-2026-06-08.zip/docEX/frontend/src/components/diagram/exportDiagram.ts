/**
 * exportDiagram — PNG / SVG export, both STATIC.
 *
 * A PNG can't animate and a standalone SVG's SMIL usually won't run when
 * embedded as an `<img>` elsewhere, so both paths strip `<animateMotion>` /
 * `<animate>` and inline CSS-variable colours into concrete values (the file
 * must be self-contained — design §4). The same static-serialisation is the
 * basis for the backend `render_snapshot_svg` accepted snapshot.
 */

import type { DiagramTheme } from './DiagramRenderer.types'
import { inlineTokens } from './diagramTheme'

const SVG_NS = 'http://www.w3.org/2000/svg'

function triggerDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = filename
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  URL.revokeObjectURL(url)
}

/**
 * Produce a self-contained, static SVG string from a live `<svg>` element:
 *   1. deep-clone so we never mutate the on-screen canvas,
 *   2. reset pan/zoom transform on the viewport group so the export is framed,
 *   3. strip all SMIL animation nodes,
 *   4. inline CSS-variable colours for the active theme,
 *   5. stamp width/height/xmlns so it renders standalone.
 *
 * The caller passes the bounding box to frame (from the layout result).
 */
export function serializeStaticSvg(
  svgEl: SVGSVGElement,
  bounds: { width: number; height: number },
  theme: DiagramTheme,
): string {
  const clone = svgEl.cloneNode(true) as SVGSVGElement

  // Frame the export to the graph bounds at 1:1 (drop interactive pan/zoom).
  const padding = 24
  const w = Math.ceil(bounds.width + padding * 2)
  const h = Math.ceil(bounds.height + padding * 2)
  clone.setAttribute('xmlns', SVG_NS)
  clone.setAttribute('width', String(w))
  clone.setAttribute('height', String(h))
  clone.setAttribute('viewBox', `0 0 ${w} ${h}`)
  clone.removeAttribute('style')

  // Neutralise the live pan/zoom: reset the viewport group's transform so the
  // content sits at the padding offset.
  const viewport = clone.querySelector('[data-diagram-viewport]')
  if (viewport) {
    viewport.setAttribute('transform', `translate(${padding}, ${padding}) scale(1)`)
  }

  // Strip SMIL — exports are static by definition.
  clone
    .querySelectorAll('animate, animateMotion, animateTransform, mpath, set')
    .forEach((node) => node.parentNode?.removeChild(node))

  // Any element that pointed its stroke at an animated gradient now references a
  // removed-animation gradient; the gradient stops remain, so it still paints a
  // valid static linear fill. Nothing further required.

  // Solid card background so the file isn't transparent.
  const bg = clone.ownerDocument.createElementNS(SVG_NS, 'rect')
  bg.setAttribute('x', '0')
  bg.setAttribute('y', '0')
  bg.setAttribute('width', String(w))
  bg.setAttribute('height', String(h))
  bg.setAttribute('fill', 'var(--background)')
  clone.insertBefore(bg, clone.firstChild)

  const raw = new XMLSerializer().serializeToString(clone)
  return inlineTokens(`<?xml version="1.0" encoding="UTF-8"?>\n${raw}`, theme)
}

/** Export the current canvas as a static SVG file. */
export function exportToSvg(
  svgEl: SVGSVGElement,
  bounds: { width: number; height: number },
  theme: DiagramTheme,
  filename: string,
): void {
  const svg = serializeStaticSvg(svgEl, bounds, theme)
  triggerDownload(new Blob([svg], { type: 'image/svg+xml;charset=utf-8' }), filename)
}

/**
 * Export the current canvas as a PNG. Rasterises the static SVG via an
 * offscreen canvas at 2× for crispness, then downloads the blob.
 */
export async function exportToPng(
  svgEl: SVGSVGElement,
  bounds: { width: number; height: number },
  theme: DiagramTheme,
  filename: string,
): Promise<void> {
  const svg = serializeStaticSvg(svgEl, bounds, theme)
  const scale = 2
  const padding = 24
  const w = Math.ceil(bounds.width + padding * 2)
  const h = Math.ceil(bounds.height + padding * 2)

  const blob = new Blob([svg], { type: 'image/svg+xml;charset=utf-8' })
  const url = URL.createObjectURL(blob)

  try {
    const image = await loadImage(url)
    const canvas = document.createElement('canvas')
    canvas.width = w * scale
    canvas.height = h * scale
    const ctx = canvas.getContext('2d')
    if (!ctx) throw new Error('Canvas 2D context unavailable')
    ctx.scale(scale, scale)
    ctx.drawImage(image, 0, 0, w, h)

    const pngBlob = await new Promise<Blob | null>((resolve) =>
      canvas.toBlob(resolve, 'image/png'),
    )
    if (!pngBlob) throw new Error('PNG encoding failed')
    triggerDownload(pngBlob, filename)
  } finally {
    URL.revokeObjectURL(url)
  }
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image()
    image.onload = () => resolve(image)
    image.onerror = () => reject(new Error('Failed to rasterise SVG'))
    image.src = src
  })
}
