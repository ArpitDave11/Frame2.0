/**
 * renderFlow — unit tests.
 *
 * Covered:
 *  - Static branch (animated=false): returns a plain <path> with arrowhead;
 *    NO <animate>, NO <animateMotion>, NO <linearGradient>.
 *  - Animated branch (animated=true): returns Fragment with defs (linearGradient
 *    + stop-opacity animate), a <path>, and a <circle> riding particle
 *    (<animateMotion>). Gradient id is derived from pathId.
 *  - pointsToPath: two-point → straight line, multi-point → cubic curves.
 *  - routeLength and durationForLength clamps.
 */

import { describe, it, expect } from 'vitest'
import { createElement, isValidElement } from 'react'
import {
  renderFlow,
  pointsToPath,
  routeLength,
  durationForLength,
  type RenderFlowArgs,
} from './renderFlow'

// Stringify a React element tree so we can do string-based assertions without
// @testing-library/react (these are pure-function tests, no DOM needed).
function stringify(node: unknown): string {
  if (node == null || typeof node === 'boolean') return ''
  if (typeof node === 'string' || typeof node === 'number') return String(node)
  if (!isValidElement(node)) {
    // Fragment or array
    if (Array.isArray(node)) return node.map(stringify).join('')
    return ''
  }
  const el = node as React.ReactElement
  const type = typeof el.type === 'string' ? el.type : ''
  const props = el.props as Record<string, unknown>
  const childStr = stringify(props.children)
  // Quick serialiser: just produce a tag string for the assertions we need.
  const attrPairs = Object.entries(props)
    .filter(([k]) => k !== 'children')
    .map(([k, v]) => `${k}="${String(v)}"`)
    .join(' ')
  return `<${type}${attrPairs ? ' ' + attrPairs : ''}>${childStr}</${type}>`
}

// Helper: collect all element type strings from a React tree.
function collectTypes(node: unknown): string[] {
  if (node == null || typeof node === 'boolean') return []
  if (!isValidElement(node)) {
    if (Array.isArray(node)) return node.flatMap(collectTypes)
    return []
  }
  const el = node as React.ReactElement
  const type = typeof el.type === 'string' ? el.type : 'Fragment'
  const props = el.props as Record<string, unknown>
  const children = props.children
  return [type, ...collectTypes(children)]
}

const BASE_ARGS: RenderFlowArgs = {
  pathId: 'edge-path-0',
  pathD: 'M 0 0 L 100 100',
  color: 'var(--primary)',
  animated: false,
  dashed: false,
  durationSec: 3,
  markerId: 'arrow-primary',
}

// -------------------------------------------------------------------------
// Static branch
// -------------------------------------------------------------------------

describe('renderFlow — static branch (animated=false)', () => {
  it('returns a single <path> element', () => {
    const result = renderFlow({ ...BASE_ARGS, animated: false })
    expect(isValidElement(result)).toBe(true)
    const el = result as React.ReactElement
    expect(el.type).toBe('path')
  })

  it('sets markerEnd to the provided markerId', () => {
    const result = renderFlow({ ...BASE_ARGS, animated: false, markerId: 'arrow-primary' })
    const el = result as React.ReactElement
    const props = el.props as Record<string, unknown>
    expect(props.markerEnd).toBe('url(#arrow-primary)')
  })

  it('has fill="none" and the provided stroke color', () => {
    const result = renderFlow({ ...BASE_ARGS, animated: false, color: 'var(--primary)' })
    const el = result as React.ReactElement
    const props = el.props as Record<string, unknown>
    expect(props.fill).toBe('none')
    expect(props.stroke).toBe('var(--primary)')
  })

  it('sets strokeDasharray when dashed=true', () => {
    const result = renderFlow({ ...BASE_ARGS, animated: false, dashed: true })
    const el = result as React.ReactElement
    const props = el.props as Record<string, unknown>
    expect(props.strokeDasharray).toBe('6 4')
  })

  it('does NOT include any SMIL animation elements', () => {
    const result = renderFlow({ ...BASE_ARGS, animated: false })
    const types = collectTypes(result)
    expect(types).not.toContain('animate')
    expect(types).not.toContain('animateMotion')
    expect(types).not.toContain('linearGradient')
  })
})

// -------------------------------------------------------------------------
// Animated branch
// -------------------------------------------------------------------------

describe('renderFlow — animated branch (animated=true)', () => {
  it('returns a React Fragment containing defs, path, and circle', () => {
    const result = renderFlow({ ...BASE_ARGS, animated: true })
    // Fragment children: defs, path, circle
    const types = collectTypes(result)
    expect(types).toContain('defs')
    expect(types).toContain('path')
    expect(types).toContain('circle')
  })

  it('includes a linearGradient inside defs', () => {
    const result = renderFlow({ ...BASE_ARGS, animated: true })
    const types = collectTypes(result)
    expect(types).toContain('linearGradient')
  })

  it('includes a stop-opacity <animate> element for the gradient', () => {
    const result = renderFlow({ ...BASE_ARGS, animated: true })
    const types = collectTypes(result)
    expect(types).toContain('animate')
  })

  it('includes an <animateMotion> riding the particle', () => {
    const result = renderFlow({ ...BASE_ARGS, animated: true })
    const types = collectTypes(result)
    expect(types).toContain('animateMotion')
  })

  it('gradient id is derived from pathId', () => {
    const result = renderFlow({ ...BASE_ARGS, animated: true, pathId: 'edge-path-42' })
    const serialised = stringify(result)
    expect(serialised).toContain('edge-path-42-grad')
  })

  it('animated path stroke references the gradient, not the raw color', () => {
    const result = renderFlow({ ...BASE_ARGS, animated: true, pathId: 'ep1' })
    const serialised = stringify(result)
    // The animated path should use url(#ep1-grad), not var(--primary) directly.
    expect(serialised).toContain('url(#ep1-grad)')
  })
})

// -------------------------------------------------------------------------
// pointsToPath
// -------------------------------------------------------------------------

describe('pointsToPath', () => {
  it('returns empty string for zero points', () => {
    expect(pointsToPath([])).toBe('')
  })

  it('returns a single M for one point', () => {
    expect(pointsToPath([{ x: 10, y: 20 }])).toBe('M 10 20')
  })

  it('returns M...L for two points (straight line)', () => {
    const result = pointsToPath([{ x: 0, y: 0 }, { x: 100, y: 200 }])
    expect(result).toBe('M 0 0 L 100 200')
  })

  it('returns a cubic-bezier path (C) for three or more points', () => {
    const result = pointsToPath([
      { x: 0, y: 0 },
      { x: 50, y: 50 },
      { x: 100, y: 0 },
    ])
    expect(result.startsWith('M 0 0')).toBe(true)
    expect(result).toContain('C ')
  })
})

// -------------------------------------------------------------------------
// routeLength and durationForLength
// -------------------------------------------------------------------------

describe('routeLength', () => {
  it('returns 0 for fewer than 2 points', () => {
    expect(routeLength([])).toBe(0)
    expect(routeLength([{ x: 0, y: 0 }])).toBe(0)
  })

  it('returns the correct length for a simple horizontal line', () => {
    const len = routeLength([{ x: 0, y: 0 }, { x: 90, y: 0 }])
    expect(len).toBeCloseTo(90)
  })

  it('accumulates segment lengths for a multi-point polyline', () => {
    const len = routeLength([{ x: 0, y: 0 }, { x: 30, y: 40 }, { x: 60, y: 0 }])
    // Each leg = 50 (3-4-5 triple scaled ×10)
    expect(len).toBeCloseTo(100)
  })
})

describe('durationForLength', () => {
  it('clamps at 2.5s for very short routes', () => {
    expect(durationForLength(0)).toBe(2.5)
    expect(durationForLength(10)).toBe(2.5)
  })

  it('clamps at 7s for very long routes', () => {
    expect(durationForLength(10000)).toBe(7)
  })

  it('returns a proportional value in range for medium routes', () => {
    const d = durationForLength(450) // 450 / 90 = 5s
    expect(d).toBeCloseTo(5)
  })
})
