/**
 * exportDiagram.serializeStaticSvg — unit tests.
 *
 * Covered:
 *  - Strips all SMIL animation nodes (<animate>, <animateMotion>,
 *    <animateTransform>, <mpath>, <set>).
 *  - Inlines CSS tokens from the active theme (--ring resolves to the
 *    theme-correct hex value; --primary, --background, --card, etc.).
 *  - Does NOT contain <foreignObject> in the output.
 *  - Resets viewport transform to padding offset (pan/zoom neutralised).
 *  - Stamps correct width/height/viewBox derived from bounds.
 *  - No raw `var(--*)` left over after inlining (every token replaced).
 */

import { describe, it, expect, beforeEach } from 'vitest'
import { serializeStaticSvg } from './exportDiagram'

// -------------------------------------------------------------------------
// jsdom SVG builder helpers
// -------------------------------------------------------------------------

/** Build a minimal live SVG element that mimics what DiagramRenderer produces. */
function buildLiveSvg(opts: {
  withAnimation?: boolean
  withViewportGroup?: boolean
}): SVGSVGElement {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg')
  svg.setAttribute('role', 'img')
  svg.setAttribute('width', '100%')
  svg.setAttribute('height', '100%')
  svg.setAttribute('viewBox', '0 0 800 600')

  if (opts.withViewportGroup) {
    const g = document.createElementNS('http://www.w3.org/2000/svg', 'g')
    g.setAttribute('data-diagram-viewport', '')
    // Simulate a pan/zoom transform that should be neutralised on export.
    g.setAttribute('transform', 'translate(123, 456) scale(1.5)')
    svg.appendChild(g)
  }

  if (opts.withAnimation) {
    // Animated gradient path (what renderFlow produces in animated mode).
    const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs')
    const grad = document.createElementNS('http://www.w3.org/2000/svg', 'linearGradient')
    grad.setAttribute('id', 'ep0-grad')
    const stop = document.createElementNS('http://www.w3.org/2000/svg', 'stop')
    stop.setAttribute('offset', '0%')
    stop.setAttribute('stopColor', 'var(--primary)')
    const animate = document.createElementNS('http://www.w3.org/2000/svg', 'animate')
    animate.setAttribute('attributeName', 'stop-opacity')
    animate.setAttribute('values', '0.25;0.9;0.25')
    stop.appendChild(animate)
    grad.appendChild(stop)
    defs.appendChild(grad)
    svg.appendChild(defs)

    // Particle circle with animateMotion
    const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle')
    circle.setAttribute('r', '3.5')
    const animateMotion = document.createElementNS('http://www.w3.org/2000/svg', 'animateMotion')
    animateMotion.setAttribute('dur', '3s')
    const mpath = document.createElementNS('http://www.w3.org/2000/svg', 'mpath')
    animateMotion.appendChild(mpath)
    circle.appendChild(animateMotion)
    svg.appendChild(circle)
  }

  // A node rect using CSS tokens — verifies inlining.
  const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect')
  rect.setAttribute('x', '10')
  rect.setAttribute('y', '10')
  rect.setAttribute('width', '120')
  rect.setAttribute('height', '80')
  rect.setAttribute('fill', 'var(--card)')
  rect.setAttribute('stroke', 'var(--ring)')
  svg.appendChild(rect)

  // Add to jsdom document so cloneNode works with proper owner.
  document.body.appendChild(svg)
  return svg
}

// -------------------------------------------------------------------------
// Tests
// -------------------------------------------------------------------------

describe('serializeStaticSvg', () => {
  let svg: SVGSVGElement

  beforeEach(() => {
    // Clean up between tests.
    document.body.innerHTML = ''
  })

  it('strips <animate> elements (SMIL)', () => {
    svg = buildLiveSvg({ withAnimation: true })
    const result = serializeStaticSvg(svg, { width: 400, height: 300 }, 'light')
    expect(result).not.toContain('<animate ')
    expect(result).not.toContain('animateMotion')
    expect(result).not.toContain('mpath')
  })

  it('strips <animateMotion> and <mpath> (SMIL particle)', () => {
    svg = buildLiveSvg({ withAnimation: true })
    const result = serializeStaticSvg(svg, { width: 400, height: 300 }, 'light')
    expect(result).not.toMatch(/<animateMotion/)
    expect(result).not.toMatch(/<mpath/)
  })

  it('does NOT introduce <foreignObject> elements of its own', () => {
    // serializeStaticSvg must not inject any <foreignObject> nodes itself.
    // (The renderer never emits one — see ShapeNode.test.tsx for that contract.)
    // Build a clean SVG with no foreignObject to confirm the serialiser is clean.
    svg = buildLiveSvg({})
    const result = serializeStaticSvg(svg, { width: 400, height: 300 }, 'light')
    expect(result).not.toContain('foreignObject')
  })

  it('inlines --ring token for light theme (no raw var(--ring) left)', () => {
    svg = buildLiveSvg({})
    const result = serializeStaticSvg(svg, { width: 400, height: 300 }, 'light')
    // var(--ring) should be replaced; the light value is '#e60000'.
    expect(result).not.toContain('var(--ring)')
    expect(result).toContain('#e60000')
  })

  it('inlines --ring token for dark theme', () => {
    svg = buildLiveSvg({})
    const result = serializeStaticSvg(svg, { width: 400, height: 300 }, 'dark')
    expect(result).not.toContain('var(--ring)')
    expect(result).toContain('#f23030')
  })

  it('inlines --card token for light theme', () => {
    svg = buildLiveSvg({})
    const result = serializeStaticSvg(svg, { width: 400, height: 300 }, 'light')
    expect(result).not.toContain('var(--card)')
  })

  it('no raw var(--*) references remain after inlining', () => {
    svg = buildLiveSvg({ withAnimation: true })
    const result = serializeStaticSvg(svg, { width: 400, height: 300 }, 'light')
    // The only var(...) still present might be inside a removed <animate> —
    // but those were stripped. Confirm no unresolved CSS vars remain.
    const unresolved = result.match(/var\(--[a-z0-9-]+\)/g)
    expect(unresolved).toBeNull()
  })

  it('stamps width and height from bounds + padding (24px each side)', () => {
    svg = buildLiveSvg({})
    const result = serializeStaticSvg(svg, { width: 400, height: 300 }, 'light')
    // Expected: width=448 (400 + 24*2), height=348 (300 + 24*2)
    expect(result).toContain('width="448"')
    expect(result).toContain('height="348"')
  })

  it('viewBox matches the stamped width/height', () => {
    svg = buildLiveSvg({})
    const result = serializeStaticSvg(svg, { width: 400, height: 300 }, 'light')
    expect(result).toContain('viewBox="0 0 448 348"')
  })

  it('resets viewport transform to padding offset (strips live pan/zoom)', () => {
    svg = buildLiveSvg({ withViewportGroup: true })
    const result = serializeStaticSvg(svg, { width: 400, height: 300 }, 'light')
    // The pan/zoom transform 'translate(123, 456) scale(1.5)' should be replaced
    // by 'translate(24, 24) scale(1)'.
    expect(result).toContain('translate(24, 24) scale(1)')
    expect(result).not.toContain('translate(123, 456) scale(1.5)')
  })

  it('includes an XML declaration', () => {
    svg = buildLiveSvg({})
    const result = serializeStaticSvg(svg, { width: 400, height: 300 }, 'light')
    expect(result.startsWith('<?xml version="1.0"')).toBe(true)
  })
})
