/**
 * ShapeNode — component tests.
 *
 * Covered:
 *  - Icon node: when node.icon resolves, the renderer emits a native <svg> chip
 *    (NOT <foreignObject>). Validated by querying the rendered SVG subtree.
 *  - Shape node: when no icon, the node's shape primitive is drawn.
 *  - Drill affordance: "DRILL" badge visible when node.drill is set.
 *  - Link affordance: external-link badge visible when node.link is set.
 *  - Keyboard a11y: interactive nodes receive tabIndex=0, role="button";
 *    non-interactive nodes get role="img".
 *  - onActivate called on click (interactive only).
 *  - Focus ring: a dashed ring is rendered on selected nodes.
 */

import { render, screen, fireEvent } from '@testing-library/react'
import { describe, it, expect, vi } from 'vitest'
import type { DiagramGraphNode } from './DiagramRenderer.types'
import { ShapeNode } from './ShapeNode'

// ShapeNode renders into an SVG canvas — wrap with a minimal host SVG so the
// browser (jsdom) resolves the SVG element correctly.
function renderInSvg(ui: React.ReactElement) {
  const { container } = render(
    <svg xmlns="http://www.w3.org/2000/svg" width="400" height="400">
      {ui}
    </svg>,
  )
  return container
}

const baseNode: DiagramGraphNode = {
  id: 'n1',
  label: 'API Gateway',
  type: 'service',
  shape: 'box',
}

describe('ShapeNode — shape (no icon)', () => {
  it('renders the node label', () => {
    const container = renderInSvg(
      <ShapeNode
        node={baseNode}
        x={10}
        y={10}
        width={120}
        height={80}
        selected={false}
        onActivate={vi.fn()}
      />,
    )
    const label = container.querySelector('text')
    expect(label?.textContent).toContain('API Gateway')
  })

  it('non-interactive node has role="img"', () => {
    const container = renderInSvg(
      <ShapeNode
        node={baseNode}
        x={0}
        y={0}
        width={120}
        height={80}
        selected={false}
        onActivate={vi.fn()}
      />,
    )
    const group = container.querySelector('[role="img"]')
    expect(group).not.toBeNull()
  })

  it('does NOT render <foreignObject> for any node', () => {
    const container = renderInSvg(
      <ShapeNode
        node={{ ...baseNode, icon: 'azure/compute/Virtual_Machine' }}
        x={0}
        y={0}
        width={120}
        height={80}
        selected={false}
        onActivate={vi.fn()}
      />,
    )
    const fo = container.querySelector('foreignObject')
    expect(fo).toBeNull()
  })
})

describe('ShapeNode — icon node', () => {
  const iconNode: DiagramGraphNode = {
    id: 'n2',
    label: 'Virtual Machine',
    type: 'compute',
    icon: 'azure/compute/Virtual_Machine',
  }

  it('renders a native <svg> element (not <foreignObject>) for the icon glyph', () => {
    const container = renderInSvg(
      <ShapeNode
        node={iconNode}
        x={0}
        y={0}
        width={120}
        height={100}
        selected={false}
        onActivate={vi.fn()}
      />,
    )
    // The icon chip is a nested <svg> with x/y attributes (positioned glyph).
    // There must be at least one <svg> inside the host <svg>.
    const svgs = container.querySelectorAll('svg svg')
    expect(svgs.length).toBeGreaterThanOrEqual(1)
  })

  it('does NOT render <foreignObject> for icon node', () => {
    const container = renderInSvg(
      <ShapeNode
        node={iconNode}
        x={0}
        y={0}
        width={120}
        height={100}
        selected={false}
        onActivate={vi.fn()}
      />,
    )
    expect(container.querySelector('foreignObject')).toBeNull()
  })
})

describe('ShapeNode — drill affordance', () => {
  const drillNode: DiagramGraphNode = {
    ...baseNode,
    drill: 'sub-graph-1',
  }

  it('shows "DRILL" text badge when node.drill is set', () => {
    const container = renderInSvg(
      <ShapeNode
        node={drillNode}
        x={0}
        y={0}
        width={120}
        height={80}
        selected={false}
        onActivate={vi.fn()}
      />,
    )
    const texts = Array.from(container.querySelectorAll('text')).map((t) => t.textContent)
    expect(texts.some((t) => t?.includes('DRILL'))).toBe(true)
  })

  it('has role="button" and tabIndex=0 for drill node', () => {
    const container = renderInSvg(
      <ShapeNode
        node={drillNode}
        x={0}
        y={0}
        width={120}
        height={80}
        selected={false}
        onActivate={vi.fn()}
      />,
    )
    const btn = container.querySelector('[role="button"]')
    expect(btn).not.toBeNull()
    expect(btn?.getAttribute('tabindex')).toBe('0')
  })

  it('calls onActivate on click', () => {
    const onActivate = vi.fn()
    const container = renderInSvg(
      <ShapeNode
        node={drillNode}
        x={0}
        y={0}
        width={120}
        height={80}
        selected={false}
        onActivate={onActivate}
      />,
    )
    const btn = container.querySelector('[role="button"]') as Element
    fireEvent.click(btn)
    expect(onActivate).toHaveBeenCalledTimes(1)
    expect(onActivate).toHaveBeenCalledWith(drillNode)
  })
})

describe('ShapeNode — link affordance', () => {
  const linkNode: DiagramGraphNode = {
    ...baseNode,
    link: 'https://example.com',
  }

  it('has role="button" for link node', () => {
    const container = renderInSvg(
      <ShapeNode
        node={linkNode}
        x={0}
        y={0}
        width={120}
        height={80}
        selected={false}
        onActivate={vi.fn()}
      />,
    )
    expect(container.querySelector('[role="button"]')).not.toBeNull()
  })

  it('does NOT show "DRILL" text for link-only node', () => {
    const container = renderInSvg(
      <ShapeNode
        node={linkNode}
        x={0}
        y={0}
        width={120}
        height={80}
        selected={false}
        onActivate={vi.fn()}
      />,
    )
    const texts = Array.from(container.querySelectorAll('text')).map((t) => t.textContent)
    expect(texts.some((t) => t?.includes('DRILL'))).toBe(false)
  })
})

describe('ShapeNode — selected / focus ring', () => {
  it('renders a focus-ring rect with var(--ring) stroke when selected=true', () => {
    const container = renderInSvg(
      <ShapeNode
        node={baseNode}
        x={0}
        y={0}
        width={120}
        height={80}
        selected={true}
        onActivate={vi.fn()}
      />,
    )
    const rects = Array.from(container.querySelectorAll('rect'))
    // One of the rects should carry the --ring stroke (the focus ring).
    const ringRect = rects.find((r) => r.getAttribute('stroke') === 'var(--ring)')
    expect(ringRect).not.toBeUndefined()
  })

  it('does NOT render the focus-ring rect when selected=false', () => {
    const container = renderInSvg(
      <ShapeNode
        node={baseNode}
        x={0}
        y={0}
        width={120}
        height={80}
        selected={false}
        onActivate={vi.fn()}
      />,
    )
    const rects = Array.from(container.querySelectorAll('rect'))
    const ringRect = rects.find((r) => r.getAttribute('stroke') === 'var(--ring)')
    expect(ringRect).toBeUndefined()
  })
})
