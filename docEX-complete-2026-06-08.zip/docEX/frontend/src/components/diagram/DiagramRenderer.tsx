/**
 * DiagramRenderer — the one custom SVG renderer used by every diagram surface.
 *
 * Pure display component over a validated `DiagramGraph`:
 *   • elkjs layout → coordinates (via `useDiagramLayout`)
 *   • SVG nodes with embedded Azure glyphs + generic shapes (`ShapeNode`)
 *   • animated data-flow edges behind the `renderFlow` seam (`EdgePath`)
 *   • drill-down (sub-graph + breadcrumb) and link (open in new tab)
 *   • pan / zoom (plain DOM handlers — no external lib)
 *   • static PNG / SVG export (`exportDiagram`)
 *
 * No runtime draw.io dependency on any path. All colours are CSS tokens. The
 * outer <svg> is `role="img"` with an aria-label; interactive nodes are
 * keyboard reachable (see `ShapeNode`).
 */

import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type PointerEvent as ReactPointerEvent,
  type WheelEvent as ReactWheelEvent,
} from 'react'
import { toast } from 'sonner'
import { LoadingSpinner } from '@/components/common/LoadingSpinner'
import { cn } from '@/lib/utils'
import type {
  BreadcrumbEntry,
  DiagramGraph,
  DiagramGraphNode,
  DiagramTheme,
} from './DiagramRenderer.types'
import { useDiagramLayout, edgeKey } from './useDiagramLayout'
import { ShapeNode } from './ShapeNode'
import { EdgePath } from './EdgePath'
import { BreadcrumbBar } from './BreadcrumbBar'
import { DiagramToolbar } from './DiagramToolbar'
import { flowColor, groupColor } from './diagramTheme'
import { exportToPng, exportToSvg } from './exportDiagram'

export interface DiagramRendererProps {
  /** The validated DiagramGraph JSON. */
  graph: DiagramGraph
  /**
   * Frozen, static SVG snapshot (an accepted diagram). When provided the
   * renderer shows the immutable picture instead of the live canvas — the
   * "data + picture" immutability contract (design §2).
   */
  snapshot?: string | null
  /**
   * Called when a drillable node is activated. The parent decides whether to
   * load a sub-graph (swap the `graph` prop) or navigate. Return `false` to
   * suppress the renderer's breadcrumb push.
   */
  onDrill?: (nodeId: string, drillTarget: string) => void | boolean
  /**
   * Called when a link node is activated. Defaults to
   * `window.open(link, '_blank', 'noopener,noreferrer')`.
   */
  onLink?: (nodeId: string, link: string) => void
  /** Live animations (true) vs a still canvas (false). Default true. */
  animated?: boolean
  /** Fit to view on first layout. Default true. */
  fitOnMount?: boolean
  /** Show the zoom / export toolbar. Default true. */
  showToolbar?: boolean
  /** When set, the toolbar shows a full-screen toggle (⤢) that calls this. */
  onToggleFullscreen?: () => void
  /** Reflects current full-screen state (toggles the toolbar icon ⤢ ↔ ⤡). */
  isFullscreen?: boolean
  /** When set, the toolbar shows a canvas light/dark toggle that calls this. */
  onToggleTheme?: () => void
  /** Active theme — drives token inlining for export. Default 'light'. */
  theme?: DiagramTheme
  /** aria-label for the canvas. */
  ariaLabel?: string
  className?: string
}

const ZOOM_MIN = 0.25
const ZOOM_MAX = 4
const ZOOM_STEP = 1.2

interface ViewTransform {
  x: number
  y: number
  zoom: number
}

export function DiagramRenderer({
  graph,
  snapshot,
  onDrill,
  onLink,
  animated = true,
  fitOnMount = true,
  showToolbar = true,
  theme = 'light',
  ariaLabel = 'Architecture diagram',
  onToggleFullscreen,
  isFullscreen = false,
  onToggleTheme,
  className,
}: DiagramRendererProps): React.ReactElement {
  const containerRef = useRef<HTMLDivElement>(null)
  const svgRef = useRef<SVGSVGElement>(null)
  const { layout, loading, error } = useDiagramLayout(snapshot ? null : graph)

  const [view, setView] = useState<ViewTransform>({ x: 24, y: 24, zoom: 1 })
  const [trail, setTrail] = useState<BreadcrumbEntry[]>([])
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [exporting, setExporting] = useState(false)
  const didFitRef = useRef(false)
  const [containerSize, setContainerSize] = useState({ w: 0, h: 0 })

  /* ----------------------------- fit-to-view ----------------------------- */

  const fitToView = useCallback(() => {
    const w = containerSize.w || containerRef.current?.clientWidth || 0
    const h = containerSize.h || containerRef.current?.clientHeight || 0
    if (!layout || layout.width === 0 || w === 0 || h === 0) return
    const padding = 32
    const availW = w - padding * 2
    const availH = h - padding * 2
    if (availW <= 0 || availH <= 0) return
    const scale = Math.min(availW / layout.width, availH / layout.height, ZOOM_MAX)
    const zoom = Math.max(ZOOM_MIN, scale)
    const x = (w - layout.width * zoom) / 2
    const y = (h - layout.height * zoom) / 2
    setView({ x, y, zoom })
  }, [layout, containerSize])

  useEffect(() => {
    if (!fitOnMount || didFitRef.current) return
    if (layout && layout.width > 0) {
      fitToView()
      didFitRef.current = true
    }
  }, [layout, fitOnMount, fitToView])

  // Re-fit when a brand-new graph arrives (e.g. after drill swaps the prop).
  useEffect(() => {
    didFitRef.current = false
  }, [graph])

  // Track the container's real pixel size (ResizeObserver) so the viewBox + fit math always
  // use current dimensions. A bare `containerRef.current?.clientWidth` read during render is
  // null on first paint (the ref attaches in commit), which left fit/zoom computing against a
  // stale size. Re-runs when `layout` flips non-null (the interactive container first mounts).
  useEffect(() => {
    const el = containerRef.current
    if (!el) return
    const measure = () => setContainerSize({ w: el.clientWidth, h: el.clientHeight })
    measure()
    const observer = new ResizeObserver(measure)
    observer.observe(el)
    return () => observer.disconnect()
  }, [layout])

  /* ------------------------------- zoom ---------------------------------- */

  const zoomBy = useCallback((factor: number, originX?: number, originY?: number) => {
    setView((prev) => {
      const next = Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, prev.zoom * factor))
      if (next === prev.zoom) return prev
      const container = containerRef.current
      // Zoom about the cursor (or the container centre).
      const cx = originX ?? (container ? container.clientWidth / 2 : 0)
      const cy = originY ?? (container ? container.clientHeight / 2 : 0)
      const ratio = next / prev.zoom
      return {
        zoom: next,
        x: cx - (cx - prev.x) * ratio,
        y: cy - (cy - prev.y) * ratio,
      }
    })
  }, [])

  const handleWheel = useCallback(
    (event: ReactWheelEvent<HTMLDivElement>) => {
      event.preventDefault()
      const rect = containerRef.current?.getBoundingClientRect()
      const ox = rect ? event.clientX - rect.left : undefined
      const oy = rect ? event.clientY - rect.top : undefined
      const factor = event.deltaY < 0 ? 1.08 : 1 / 1.08
      zoomBy(factor, ox, oy)
    },
    [zoomBy],
  )

  /* ------------------------------- pan ----------------------------------- */

  const panStateRef = useRef<{
    pointerId: number
    startX: number
    startY: number
    originX: number
    originY: number
  } | null>(null)
  const [panning, setPanning] = useState(false)

  const handlePointerDown = useCallback(
    (event: ReactPointerEvent<HTMLDivElement>) => {
      // Only start a pan on background drags — never when the press lands on an
      // interactive control. This must include native <button>s (the toolbar + the
      // breadcrumb) and links/inputs, not just nodes (which set role="button"):
      // otherwise the setPointerCapture below swallows the control's click, leaving the
      // zoom / fit / export buttons dead.
      const target = event.target as Element
      if (target.closest('button, a, input, [role="button"], [data-no-pan]')) return
      panStateRef.current = {
        pointerId: event.pointerId,
        startX: event.clientX,
        startY: event.clientY,
        originX: view.x,
        originY: view.y,
      }
      ;(event.currentTarget as HTMLElement).setPointerCapture(event.pointerId)
      setPanning(true)
    },
    [view.x, view.y],
  )

  const handlePointerMove = useCallback((event: ReactPointerEvent<HTMLDivElement>) => {
    const state = panStateRef.current
    if (!state || state.pointerId !== event.pointerId) return
    setView((prev) => ({
      ...prev,
      x: state.originX + (event.clientX - state.startX),
      y: state.originY + (event.clientY - state.startY),
    }))
  }, [])

  const endPan = useCallback((event: ReactPointerEvent<HTMLDivElement>) => {
    if (panStateRef.current?.pointerId === event.pointerId) {
      panStateRef.current = null
      setPanning(false)
    }
  }, [])

  /* --------------------------- node activation --------------------------- */

  const nodeIndex = useMemo(() => {
    const map = new Map<string, DiagramGraphNode>()
    for (const node of graph.nodes) map.set(node.id, node)
    return map
  }, [graph.nodes])

  const handleActivate = useCallback(
    (node: DiagramGraphNode) => {
      setSelectedId(node.id)
      if (node.drill) {
        const result = onDrill?.(node.id, node.drill)
        if (result === false) return
        setTrail((prev) => [...prev, { nodeId: node.id, label: node.label }])
      } else if (node.link) {
        if (onLink) {
          onLink(node.id, node.link)
        } else {
          window.open(node.link, '_blank', 'noopener,noreferrer')
        }
      }
    },
    [onDrill, onLink],
  )

  const handleBreadcrumb = useCallback((depth: number) => {
    // depth -1 = root; pop the trail back to that level.
    setTrail((prev) => (depth < 0 ? [] : prev.slice(0, depth + 1)))
    setSelectedId(null)
  }, [])

  /* ------------------------------ export --------------------------------- */

  const runExport = useCallback(
    async (kind: 'png' | 'svg') => {
      const svgEl = svgRef.current
      if (!svgEl || !layout) return
      setExporting(true)
      try {
        const bounds = { width: layout.width, height: layout.height }
        const stamp = new Date().toISOString().slice(0, 10)
        if (kind === 'png') {
          await exportToPng(svgEl, bounds, theme, `diagram-${stamp}.png`)
        } else {
          exportToSvg(svgEl, bounds, theme, `diagram-${stamp}.svg`)
        }
      } catch (err) {
        console.error('Diagram export failed:', err)
        toast.error('Export failed')
      } finally {
        setExporting(false)
      }
    },
    [layout, theme],
  )

  /* ------------------------- arrowhead markers --------------------------- */

  // One marker per distinct flow colour referenced by an edge (plus primary).
  const markerColors = useMemo(() => {
    const set = new Map<string, string>()
    set.set('primary', 'var(--primary)')
    for (const edge of graph.edges) {
      const color = flowColor(edge.flow)
      set.set(markerIdFor(edge.flow), color)
    }
    return set
  }, [graph.edges])

  // Colour-coding: each group gets a stable chart hue; its container + member nodes use it.
  const groupColorById = useMemo(() => {
    const map = new Map<string, string>()
    graph.groups.forEach((group, index) => map.set(group.id, groupColor(index)))
    return map
  }, [graph.groups])

  /* ------------------------------ snapshot ------------------------------- */

  if (snapshot) {
    return (
      <div
        ref={containerRef}
        className={cn(
          'relative h-full w-full overflow-auto rounded-lg border bg-card',
          className,
        )}
      >
        <div
          className="min-h-full w-full p-4 [&_svg]:h-auto [&_svg]:max-w-full"
          role="img"
          aria-label={`${ariaLabel} (accepted snapshot)`}
          // Snapshot is our own serialised, sanitised SVG (no scripts).
          dangerouslySetInnerHTML={{ __html: snapshot }}
        />
      </div>
    )
  }

  /* --------------------------- loading / error --------------------------- */

  if (loading) {
    return (
      <div
        className={cn(
          'flex h-full w-full items-center justify-center rounded-lg border bg-card',
          className,
        )}
      >
        <LoadingSpinner />
      </div>
    )
  }

  if (error || !layout) {
    return (
      <div
        className={cn(
          'flex h-full w-full flex-col items-center justify-center gap-2 rounded-lg border bg-card p-8 text-center',
          className,
        )}
      >
        <p className="text-sm font-medium text-foreground">Could not lay out the diagram</p>
        <p className="text-xs text-muted-foreground">{error ?? 'No layout result'}</p>
      </div>
    )
  }

  /* ------------------------------- render -------------------------------- */

  const viewBoxW = containerSize.w || layout.width + 48
  const viewBoxH = containerSize.h || layout.height + 48

  return (
    <div
      ref={containerRef}
      className={cn(
        'relative h-full w-full overflow-hidden rounded-lg border bg-card',
        theme === 'dark' && 'dark',
        className,
      )}
      style={{ cursor: panning ? 'grabbing' : 'grab', touchAction: 'none' }}
      onWheel={handleWheel}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={endPan}
      onPointerLeave={endPan}
      onPointerCancel={endPan}
    >
      {/* Breadcrumb (top-left) */}
      {trail.length > 0 && (
        <div className="absolute left-3 top-3 z-10 rounded-lg border bg-card/90 px-2 py-1 shadow-sm backdrop-blur">
          <BreadcrumbBar trail={trail} rootLabel="Overview" onNavigate={handleBreadcrumb} />
        </div>
      )}

      {/* Toolbar (top-right) */}
      {showToolbar && (
        <DiagramToolbar
          className="absolute right-3 top-3 z-10"
          zoom={view.zoom}
          onZoomIn={() => zoomBy(ZOOM_STEP)}
          onZoomOut={() => zoomBy(1 / ZOOM_STEP)}
          onFit={fitToView}
          onExportPng={() => void runExport('png')}
          onExportSvg={() => void runExport('svg')}
          exporting={exporting}
          onToggleFullscreen={onToggleFullscreen}
          isFullscreen={isFullscreen}
          onToggleTheme={onToggleTheme}
          isDark={theme === 'dark'}
        />
      )}

      <svg
        ref={svgRef}
        role="img"
        aria-label={ariaLabel}
        width="100%"
        height="100%"
        viewBox={`0 0 ${viewBoxW} ${viewBoxH}`}
        className="block select-none"
      >
        <defs>
          {Array.from(markerColors.entries()).map(([id, color]) => (
            <marker
              key={id}
              id={`arrow-${id}`}
              viewBox="0 0 10 10"
              refX="9"
              refY="5"
              markerWidth="7"
              markerHeight="7"
              orient="auto-start-reverse"
            >
              <path d="M 0 0 L 10 5 L 0 10 z" fill={color} />
            </marker>
          ))}
        </defs>

        <g
          data-diagram-viewport
          transform={`translate(${view.x}, ${view.y}) scale(${view.zoom})`}
        >
          {/* Group containers (behind nodes) */}
          {graph.groups.map((group) => {
            const box = layout.groups.get(group.id)
            if (!box) return null
            const color = groupColorById.get(group.id) ?? 'var(--border)'
            return (
              <g key={`group-${group.id}`} aria-hidden="true">
                <rect
                  x={box.x}
                  y={box.y}
                  width={box.width}
                  height={box.height}
                  rx={12}
                  fill={color}
                  fillOpacity={0.06}
                  stroke={color}
                  strokeWidth={1.25}
                  strokeOpacity={0.6}
                  strokeDasharray="5 4"
                />
                <text
                  x={box.x + 12}
                  y={box.y + 19}
                  fontSize={11}
                  fontWeight={700}
                  fill={color}
                  letterSpacing="0.02em"
                >
                  {group.label}
                </text>
                {group.repeat && (
                  <g transform={`translate(${box.x + box.width - 38}, ${box.y + 8})`}>
                    <rect
                      width={30}
                      height={18}
                      rx={9}
                      fill={color}
                      fillOpacity={0.18}
                      stroke={color}
                      strokeWidth={1}
                    />
                    <text
                      x={15}
                      y={13}
                      textAnchor="middle"
                      fontSize={10}
                      fontWeight={700}
                      fill={color}
                    >
                      {group.repeat}
                    </text>
                  </g>
                )}
              </g>
            )
          })}

          {/* Edges (above groups, behind nodes) */}
          {graph.edges.map((edge, index) => {
            const route = layout.edges.find(
              (r) => r.key === edgeKey(edge.from, edge.to, index),
            )
            if (!route) return null
            return (
              <EdgePath
                key={`edge-${index}`}
                edge={edge}
                points={route.points}
                pathId={`edge-path-${index}`}
                animated={animated}
                markerId={`arrow-${markerIdFor(edge.flow)}`}
              />
            )
          })}

          {/* Nodes (top) */}
          {graph.nodes.map((node) => {
            const box = layout.nodes.get(node.id)
            if (!box) return null
            return (
              <ShapeNode
                key={`node-${node.id}`}
                node={node}
                x={box.x}
                y={box.y}
                width={box.width}
                height={box.height}
                selected={selectedId === node.id}
                groupColor={node.groupId ? groupColorById.get(node.groupId) : undefined}
                onActivate={handleActivate}
              />
            )
          })}
        </g>
      </svg>

      {/* Hidden live region announcing the selected node for screen readers. */}
      <span className="sr-only" aria-live="polite">
        {selectedId ? nodeIndex.get(selectedId)?.label ?? '' : ''}
      </span>
    </div>
  )
}

/** Stable, DOM-safe marker id key for an edge's flow colour. */
function markerIdFor(flow: string | null | undefined): string {
  if (!flow) return 'primary'
  return `flow-${flow.replace(/[^a-z0-9]/gi, '').toLowerCase() || 'x'}`
}
