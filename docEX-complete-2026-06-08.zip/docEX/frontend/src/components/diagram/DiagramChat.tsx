'use client'

import { useState, useRef, useEffect, useId } from 'react'
import { Bot, User, Send, Loader2, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useTranslation } from '@/lib/hooks/use-translation'

/**
 * DiagramChat — the compact "refine" panel for the source Diagram tab.
 *
 * Mirrors the chrome of `components/source/ChatPanel.tsx` (bot/user bubbles, a
 * `ScrollArea` transcript, a `Textarea` + Send affordance with ⌘/Ctrl+Enter),
 * but specialised for diagram refinement: every user turn is an instruction that
 * re-runs the pipeline, and each assistant turn is a short status line. It is a
 * controlled component — the parent owns the message log and the submit handler
 * (which drives `useRefineDiagram`).
 *
 * Tokens only (UBS theme): `bg-primary`/`text-primary-foreground` for the user
 * bubble, `bg-muted` for the assistant, `bg-primary/10` for the avatar — exactly
 * as ChatPanel does.
 */

/** One refine turn. `human` = an instruction; `ai` = a status line. */
export interface DiagramChatMessage {
  id: string
  type: 'human' | 'ai'
  content: string
}

interface DiagramChatProps {
  messages: DiagramChatMessage[]
  /** A refine request is in flight (disables the input + shows the typing dot). */
  busy: boolean
  /** Disable the whole panel (e.g. no diagram to refine yet). */
  disabled?: boolean
  onSend: (instruction: string) => void
  className?: string
}

export function DiagramChat({
  messages,
  busy,
  disabled = false,
  onSend,
  className,
}: DiagramChatProps): React.ReactElement {
  const { t } = useTranslation()
  const inputId = useId()
  const [input, setInput] = useState('')
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, busy])

  const canSend = input.trim().length > 0 && !busy && !disabled

  const handleSend = () => {
    if (!canSend) return
    onSend(input.trim())
    setInput('')
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    const isMac =
      typeof navigator !== 'undefined' &&
      navigator.userAgent.toUpperCase().indexOf('MAC') >= 0
    const modifier = isMac ? e.metaKey : e.ctrlKey
    if (e.key === 'Enter' && modifier) {
      e.preventDefault()
      handleSend()
    }
  }

  const isMac =
    typeof navigator !== 'undefined' &&
    navigator.userAgent.toUpperCase().indexOf('MAC') >= 0
  const keyHint = isMac ? '⌘+Enter' : 'Ctrl+Enter'

  return (
    <div className={className}>
      <div className="flex h-full flex-col">
        <div className="flex items-center gap-2 border-b px-4 py-3">
          <Sparkles className="h-4 w-4 text-primary" />
          <span className="text-sm font-semibold">{t('diagram.refineTitle')}</span>
        </div>

        <ScrollArea className="min-h-0 flex-1 px-4">
          <div className="space-y-4 py-4">
            {messages.length === 0 ? (
              <div className="py-8 text-center text-muted-foreground">
                <Bot className="mx-auto mb-4 h-12 w-12 opacity-50" />
                <p className="text-sm">{t('diagram.startRefine')}</p>
                <p className="mt-2 text-xs">{t('diagram.refineHint')}</p>
              </div>
            ) : (
              messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex gap-3 ${
                    message.type === 'human' ? 'justify-end' : 'justify-start'
                  }`}
                >
                  {message.type === 'ai' && (
                    <div className="flex-shrink-0">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                        <Bot className="h-4 w-4" />
                      </div>
                    </div>
                  )}
                  <div
                    className={`max-w-[80%] rounded-lg px-4 py-2 ${
                      message.type === 'human'
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted'
                    }`}
                  >
                    <p className="break-words text-sm">{message.content}</p>
                  </div>
                  {message.type === 'human' && (
                    <div className="flex-shrink-0">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary">
                        <User className="h-4 w-4 text-primary-foreground" />
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
            {busy && (
              <div className="flex justify-start gap-3">
                <div className="flex-shrink-0">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                    <Bot className="h-4 w-4" />
                  </div>
                </div>
                <div className="rounded-lg bg-muted px-4 py-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        <div className="flex-shrink-0 border-t p-4">
          <div className="flex min-w-0 items-end gap-2">
            <Textarea
              id={inputId}
              name="diagram-refine"
              autoComplete="off"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={`${t('diagram.refinePlaceholder')} (${t('chat.pressToSend').replace('{key}', keyHint)})`}
              disabled={busy || disabled}
              className="max-h-[100px] min-h-[40px] min-w-0 flex-1 resize-none px-3 py-2"
              rows={1}
            />
            <Button
              onClick={handleSend}
              disabled={!canSend}
              size="icon"
              className="h-[40px] w-[40px] flex-shrink-0"
              aria-label={t('diagram.refine')}
            >
              {busy ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
