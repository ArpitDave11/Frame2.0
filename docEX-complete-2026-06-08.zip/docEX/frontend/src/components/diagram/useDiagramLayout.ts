/**
 * useDiagramLayout — runs the Eclipse Layout Kernel (elkjs) over a
 * `DiagramGraph` and returns pixel positions + edge routes.
 *
 * This is NEW work: gitdiagram does not drive elkjs directly (it emits Mermaid
 * and flips Mermaid's `elk` flag). We drive elkjs ourselves so the custom SVG
 * renderer gets concrete coordinates and full control.
 *
 * `elk.layout()` is async, so this is a hook (useEffect + useState). A
 * cancellation flag guards against a stale layout resolving after the graph
 * prop changed (gotcha #11).
 */

import { useEffect, useState } from 'react'
import ELK, {
  type ElkNode,
  type ElkExtendedEdge,
  type LayoutOptions,
} from 'elkjs/lib/elk.bundled.js'
import type { DiagramGraph } from './DiagramRenderer.types'

/** A laid-out box in canvas pixel coordinates. */
export interface NodeBox {
  x: number
  y: number
  width: number
  height: number
}

/** A laid-out edge: the points the SVG path threads through. */
export interface EdgeRoute {
  /** `"<from>__<to>"` — matches the key produced for each edge below. */
  key: string
  points: Array<{ x: number; y: number }>
}

export interface LayoutResult {
  /** node id → box (icon/shape nodes). */
  nodes: Map<string, NodeBox>
  /** group id → box (compound containers). */
  groups: Map<string, NodeBox>
  edges: EdgeRoute[]
  width: number
  height: number
}

export interface LayoutState {
  layout: LayoutResult | null
  loading: boolean
  error: string | null
}

/* Sizing — kept in one place so ShapeNode and layout agree exactly. */
export const ICON_NODE_WIDTH = 132
export const ICON_NODE_HEIGHT = 96
export const SHAPE_NODE_WIDTH = 148
export const SHAPE_NODE_HEIGHT = 64
/** Padding reserved inside a group box for its header label. */
export const GROUP_PADDING_TOP = 30
export const GROUP_PADDING = 16

const elk = new ELK()

const BASE_OPTIONS: LayoutOptions = {
  'elk.algorithm': 'layered',
  'elk.direction': 'DOWN',
  'elk.layered.spacing.nodeNodeBetweenLayers': '64',
  'elk.spacing.nodeNode': '44',
  'elk.spacing.edgeNode': '28',
  'elk.layered.spacing.edgeNodeBetweenLayers': '28',
  'elk.edgeRouting': 'SPLINES',
  'elk.layered.considerModelOrder.strategy': 'NODES_AND_EDGES',
  'elk.padding': '[top=24,left=24,bottom=24,right=24]',
}

/** Hierarchical variant — used when the graph has groups (compound layout). */
const HIERARCHICAL_OPTIONS: LayoutOptions = {
  ...BASE_OPTIONS,
  'elk.hierarchyHandling': 'INCLUDE_CHILDREN',
  'elk.layered.spacing.nodeNodeBetweenLayers': '80',
  'elk.spacing.nodeNode': '50',
}

/** Stable composite key for an edge (also used by EdgePath / renderFlow ids). */
export function edgeKey(from: string, to: string, index: number): string {
  return `${from}__${to}__${index}`
}

function nodeSize(node: DiagramGraph['nodes'][number]): {
  width: number
  height: number
} {
  if (node.icon) return { width: ICON_NODE_WIDTH, height: ICON_NODE_HEIGHT }
  return { width: SHAPE_NODE_WIDTH, height: SHAPE_NODE_HEIGHT }
}

/**
 * Least-common-ancestor container id for an edge's two endpoints.
 *
 * Why this matters (the routing bug this fixes): elkjs reports an edge's section
 * coordinates *relative to the container the edge is declared on*, and — unlike
 * full ELK's JSON import — elkjs 0.11 does NOT re-home an edge to its true LCA on
 * import; it lays the edge out and reports its coordinates **as if** it belonged
 * to its real LCA, while leaving it parked wherever the author put it. So an
 * intra-group edge declared on `root` comes back with *group-relative* numbers
 * but a *root* (zero) offset in `mapResult`'s edge walk, landing the route off by
 * the group's position. Declaring every edge on its actual LCA makes the declared
 * container match the container ELK measures against, so the offset is right.
 *
 * Groups are single-level (see `model.py` — `node.groupId` points straight at a
 * group, groups have no parent), so the LCA reduces to: the shared group when
 * both endpoints are nodes in the *same* group, otherwise `root`. Endpoints that
 * aren't grouped nodes (ungrouped nodes, or — defensively — an id that names a
 * group for a future hierarchical/drill edge) resolve to `root`.
 */
function edgeContainerId(
  from: string,
  to: string,
  nodeGroup: Map<string, string>,
): string {
  const fromGroup = nodeGroup.get(from)
  const toGroup = nodeGroup.get(to)
  if (fromGroup && fromGroup === toGroup) return fromGroup
  return 'root'
}

/** Build the ELK input tree from a DiagramGraph (groups → compound children). */
function toElkGraph(graph: DiagramGraph): ElkNode {
  const hasGroups = graph.groups.length > 0
  const groupIds = new Set(graph.groups.map((g) => g.id))

  // Index nodes by their group so we can nest them, and keep a node→group lookup
  // for routing edges to their least-common-ancestor container below.
  const childrenByGroup = new Map<string, ElkNode[]>()
  const topLevel: ElkNode[] = []
  const nodeGroup = new Map<string, string>()

  for (const node of graph.nodes) {
    const { width, height } = nodeSize(node)
    const elkNode: ElkNode = { id: node.id, width, height }
    if (node.groupId && groupIds.has(node.groupId)) {
      const bucket = childrenByGroup.get(node.groupId) ?? []
      bucket.push(elkNode)
      childrenByGroup.set(node.groupId, bucket)
      nodeGroup.set(node.id, node.groupId)
    } else {
      topLevel.push(elkNode)
    }
  }

  // Bucket each edge onto its LCA container (a group, or root). ELK reports edge
  // coordinates relative to the container the edge is declared on, so this is what
  // makes compound/grouped routes land correctly (see `edgeContainerId`).
  const edgesByContainer = new Map<string, ElkExtendedEdge[]>()
  graph.edges.forEach((edge, index) => {
    const container = edgeContainerId(edge.from, edge.to, nodeGroup)
    const elkEdge: ElkExtendedEdge = {
      id: edgeKey(edge.from, edge.to, index),
      sources: [edge.from],
      targets: [edge.to],
    }
    const bucket = edgesByContainer.get(container) ?? []
    bucket.push(elkEdge)
    edgesByContainer.set(container, bucket)
  })

  const groupNodes: ElkNode[] = graph.groups.map((group) => ({
    id: group.id,
    children: childrenByGroup.get(group.id) ?? [],
    edges: edgesByContainer.get(group.id) ?? [],
    layoutOptions: {
      'elk.padding': `[top=${GROUP_PADDING_TOP},left=${GROUP_PADDING},bottom=${GROUP_PADDING},right=${GROUP_PADDING}]`,
    },
  }))

  return {
    id: 'root',
    layoutOptions: hasGroups ? HIERARCHICAL_OPTIONS : BASE_OPTIONS,
    children: [...groupNodes, ...topLevel],
    edges: edgesByContainer.get('root') ?? [],
  }
}

/**
 * Walk the laid-out ELK tree, accumulating absolute pixel coords. Children of a
 * compound (group) node have coordinates relative to that group, so we carry an
 * offset down the recursion.
 */
function collect(
  node: ElkNode,
  offsetX: number,
  offsetY: number,
  groupIds: Set<string>,
  nodes: Map<string, NodeBox>,
  groups: Map<string, NodeBox>,
): void {
  const absX = offsetX + (node.x ?? 0)
  const absY = offsetY + (node.y ?? 0)
  const box: NodeBox = {
    x: absX,
    y: absY,
    width: node.width ?? 0,
    height: node.height ?? 0,
  }

  if (node.id !== 'root') {
    if (groupIds.has(node.id)) {
      groups.set(node.id, box)
    } else {
      nodes.set(node.id, box)
    }
  }

  for (const child of node.children ?? []) {
    collect(child, absX, absY, groupIds, nodes, groups)
  }
}

function mapResult(laidOut: ElkNode, groupIds: Set<string>): LayoutResult {
  const nodes = new Map<string, NodeBox>()
  const groups = new Map<string, NodeBox>()
  collect(laidOut, 0, 0, groupIds, nodes, groups)

  // Edge routes. ELK places edges on the node that owns them; for hierarchical
  // graphs that can be a group, so we resolve each section point against the
  // container the edge was reported on. Simplest robust approach: gather every
  // edge across the whole tree with the container offset that hosts it.
  const edges: EdgeRoute[] = []
  const visitEdges = (node: ElkNode, ox: number, oy: number): void => {
    const baseX = ox + (node.id === 'root' ? 0 : node.x ?? 0)
    const baseY = oy + (node.id === 'root' ? 0 : node.y ?? 0)
    for (const edge of node.edges ?? []) {
      const points: Array<{ x: number; y: number }> = []
      for (const section of edge.sections ?? []) {
        points.push({
          x: baseX + section.startPoint.x,
          y: baseY + section.startPoint.y,
        })
        for (const bend of section.bendPoints ?? []) {
          points.push({ x: baseX + bend.x, y: baseY + bend.y })
        }
        points.push({
          x: baseX + section.endPoint.x,
          y: baseY + section.endPoint.y,
        })
      }
      if (points.length >= 2) {
        edges.push({ key: edge.id ?? '', points })
      }
    }
    for (const child of node.children ?? []) {
      visitEdges(child, baseX, baseY)
    }
  }
  visitEdges(laidOut, 0, 0)

  return {
    nodes,
    groups,
    edges,
    width: laidOut.width ?? 0,
    height: laidOut.height ?? 0,
  }
}

/**
 * Compute layout for a graph. Re-runs whenever the graph reference changes.
 * Cancels a pending layout if the graph changes mid-flight.
 */
export function useDiagramLayout(graph: DiagramGraph | null): LayoutState {
  const [state, setState] = useState<LayoutState>({
    layout: null,
    loading: !!graph,
    error: null,
  })

  useEffect(() => {
    if (!graph) {
      setState({ layout: null, loading: false, error: null })
      return
    }

    let cancelled = false
    setState((prev) => ({ ...prev, loading: true, error: null }))

    const groupIds = new Set(graph.groups.map((g) => g.id))
    const input = toElkGraph(graph)

    elk
      .layout(input)
      .then((laidOut) => {
        if (cancelled) return
        setState({ layout: mapResult(laidOut, groupIds), loading: false, error: null })
      })
      .catch((err: unknown) => {
        if (cancelled) return
        const message = err instanceof Error ? err.message : 'Layout failed'
        setState({ layout: null, loading: false, error: message })
      })

    return () => {
      cancelled = true
    }
  }, [graph])

  return state
}
