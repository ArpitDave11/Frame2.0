/**
 * DiagramToolbar — fit / zoom / full-screen / export controls for the canvas.
 *
 * Built on the project's shadcn `Button` + Radix `Tooltip`. Icon buttons carry
 * aria-labels; the zoom read-out is a live region. Tokens only.
 *
 * Icon mapping: ⤢ `Maximize2` = **Full screen** (the headline action); `Frame` =
 * **Fit to view** (zoom-to-fit). When `onToggleFullscreen` is omitted the
 * full-screen button is hidden (e.g. when the renderer is already full screen-less).
 */

import {
  Frame,
  ZoomIn,
  ZoomOut,
  ImageDown,
  FileDown,
  Maximize2,
  Minimize2,
  Sun,
  Moon,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import { cn } from '@/lib/utils'

export interface DiagramToolbarProps {
  zoom: number
  onZoomIn: () => void
  onZoomOut: () => void
  onFit: () => void
  onExportPng: () => void
  onExportSvg: () => void
  exporting: boolean
  /** When set, show a full-screen toggle (⤢ / ⤡) reflecting `isFullscreen`. */
  onToggleFullscreen?: () => void
  isFullscreen?: boolean
  /** When set, show a canvas light/dark toggle (☀/☾) reflecting `isDark`. */
  onToggleTheme?: () => void
  isDark?: boolean
  className?: string
}

interface IconActionProps {
  label: string
  onClick: () => void
  disabled?: boolean
  children: React.ReactNode
}

function IconAction({ label, onClick, disabled, children }: IconActionProps): React.ReactElement {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Button
          type="button"
          variant="ghost"
          size="icon"
          onClick={onClick}
          disabled={disabled}
          aria-label={label}
          className="h-8 w-8"
        >
          {children}
        </Button>
      </TooltipTrigger>
      <TooltipContent side="bottom">{label}</TooltipContent>
    </Tooltip>
  )
}

export function DiagramToolbar({
  zoom,
  onZoomIn,
  onZoomOut,
  onFit,
  onExportPng,
  onExportSvg,
  exporting,
  onToggleFullscreen,
  isFullscreen = false,
  onToggleTheme,
  isDark = false,
  className,
}: DiagramToolbarProps): React.ReactElement {
  return (
    <div
      className={cn(
        'flex items-center gap-0.5 rounded-lg border bg-card/90 p-1 shadow-sm backdrop-blur',
        className,
      )}
    >
      <IconAction label="Zoom out" onClick={onZoomOut}>
        <ZoomOut className="h-4 w-4" />
      </IconAction>
      <span
        className="min-w-[3.25rem] select-none text-center text-xs tabular-nums text-muted-foreground"
        aria-live="polite"
      >
        {Math.round(zoom * 100)}%
      </span>
      <IconAction label="Zoom in" onClick={onZoomIn}>
        <ZoomIn className="h-4 w-4" />
      </IconAction>
      <span className="mx-1 h-5 w-px bg-border" aria-hidden="true" />
      <IconAction label="Fit to view" onClick={onFit}>
        <Frame className="h-4 w-4" />
      </IconAction>
      {onToggleTheme && (
        <IconAction
          label={isDark ? 'Light canvas' : 'Dark canvas'}
          onClick={onToggleTheme}
        >
          {isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
        </IconAction>
      )}
      {onToggleFullscreen && (
        <IconAction
          label={isFullscreen ? 'Exit full screen' : 'Full screen'}
          onClick={onToggleFullscreen}
        >
          {isFullscreen ? (
            <Minimize2 className="h-4 w-4" />
          ) : (
            <Maximize2 className="h-4 w-4" />
          )}
        </IconAction>
      )}
      <span className="mx-1 h-5 w-px bg-border" aria-hidden="true" />
      <IconAction label="Export PNG" onClick={onExportPng} disabled={exporting}>
        <ImageDown className="h-4 w-4" />
      </IconAction>
      <IconAction label="Export SVG" onClick={onExportSvg} disabled={exporting}>
        <FileDown className="h-4 w-4" />
      </IconAction>
    </div>
  )
}
