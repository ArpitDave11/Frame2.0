# Azure icon assets — provenance & licensing (READ BEFORE ADDING SVG BYTES)

This directory is the **icon seam** for the DiagramRenderer. Today it ships only
**clean-room, first-party category glyphs** (authored in `index.ts`, no
third-party bytes). The renderer resolves `node.icon` ids of the shape
`azure/{category}/{ShapeName}` against `azureIconRegistry`; anything not found
falls back to the node's generic geometric `shape`, so the canvas never crashes.

## Governance gate (design §12 — HARD requirement)

The official Microsoft **Azure Architecture Icons** set and the draw.io `azure2`
stencils are **different artifacts with different terms**. Before committing any
real Azure SVG *bytes* into this UBS-internal product you MUST:

1. Pin the **exact source URL** the bytes came from.
2. Pin the **version / download date**.
3. Pin the **applicable license** and confirm the use is in-scope
   (MS Azure Architecture Icons Terms of Use permit architecture-diagram use
   within an organisation's own tools/docs; no altering the icons; no implying
   Microsoft endorsement).
4. Get a quick **third-party-asset / licensing nod** before bundling the set.

Record 1–3 in this file (a table: `id | source URL | version | license`) at the
moment the bytes land.

## How to drop in real bytes later (no renderer change required)

1. Place each raw SVG at `./<category>/<ShapeName>.svg`.
2. Import it with Vite's `?raw` suffix (returns the file contents as a string):

   ```ts
   import virtualMachine from './compute/Virtual_Machine.svg?raw'
   ```

3. Register it in `index.ts`:

   ```ts
   azureIconRegistry['azure/compute/Virtual_Machine'] = virtualMachine
   ```

The `?raw` import inlines the bytes at build time (no runtime fetch — works
air-gapped). Test with **one** icon first, then expand.
