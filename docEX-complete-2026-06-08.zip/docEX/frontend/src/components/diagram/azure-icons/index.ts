/**
 * Azure icon seam for the DiagramRenderer.
 *
 * `node.icon` carries ids of the form `azure/{category}/{ShapeName}` (the
 * catalog format from next-ai-draw-io's `azure2.md`, re-spelled with a leading
 * `azure/`). `resolveIcon()` maps an id to an inline SVG **string** that the
 * renderer embeds. Resolution order:
 *
 *   1. exact id          → `azureIconRegistry[id]`            (real bytes, when present)
 *   2. category glyph    → `CATEGORY_GLYPHS[category]`        (first-party, always present)
 *   3. null              → caller draws the node's generic `shape`
 *
 * The glyphs below are **clean-room, first-party line icons** drawn with
 * `stroke="currentColor"` so they inherit the node's themed colour (no
 * hardcoded hex). They are NOT Microsoft assets — see `NOTICE.md` for the
 * governance gate that must clear before real Azure bytes are bundled.
 *
 * To add real bytes later, drop them under `./<category>/<Shape>.svg`, import
 * with Vite `?raw`, and assign into `azureIconRegistry` (see NOTICE.md). No
 * change to the renderer is required.
 */

import { useEffect, useState } from 'react'

/** The Azure catalog categories we recognise (from azure2.md). */
export type AzureCategory =
  | 'ai_machine_learning'
  | 'analytics'
  | 'app_services'
  | 'compute'
  | 'containers'
  | 'databases'
  | 'devops'
  | 'identity'
  | 'integration'
  | 'networking'
  | 'security'
  | 'storage'
  | 'general'

/**
 * A representative slice (~40) of catalog ids across every key category. This
 * is the set the LLM prompt advertises and the set we can confidently render.
 * Unknown ids still resolve via the category-glyph fallback, so this list is a
 * curated default, not an exhaustive gate.
 */
export const AZURE_CATALOG: readonly string[] = [
  // compute
  'azure/compute/Virtual_Machine',
  'azure/compute/Kubernetes_Services',
  'azure/compute/Function_Apps',
  'azure/compute/Container_Instances',
  'azure/compute/VM_Scale_Sets',
  'azure/compute/App_Services',
  // ai_machine_learning
  'azure/ai_machine_learning/Azure_OpenAI',
  'azure/ai_machine_learning/Machine_Learning',
  'azure/ai_machine_learning/Cognitive_Services',
  'azure/ai_machine_learning/Bot_Services',
  'azure/ai_machine_learning/Speech_Services',
  'azure/ai_machine_learning/Language_Services',
  // databases
  'azure/databases/Azure_SQL',
  'azure/databases/Azure_Cosmos_DB',
  'azure/databases/Cache_Redis',
  'azure/databases/SQL_Database',
  'azure/databases/Azure_Database_PostgreSQL_Server',
  'azure/databases/Data_Factory',
  // integration
  'azure/integration/Service_Bus',
  'azure/integration/Event_Grid_Topics',
  'azure/integration/Logic_Apps',
  'azure/integration/API_Management_Services',
  'azure/integration/App_Configuration',
  // security
  'azure/security/Key_Vaults',
  'azure/security/Azure_Defender',
  'azure/security/Azure_Sentinel',
  'azure/security/Conditional_Access',
  // storage
  'azure/storage/Storage_Accounts',
  'azure/storage/Azure_NetApp_Files',
  'azure/storage/Data_Lake_Storage_Gen1',
  'azure/storage/Recovery_Services_Vaults',
  // networking
  'azure/networking/Virtual_Networks',
  'azure/networking/Application_Gateways',
  'azure/networking/Load_Balancers',
  'azure/networking/Firewalls',
  'azure/networking/Private_Link',
  'azure/networking/DNS_Zones',
  // analytics
  'azure/analytics/Azure_Synapse_Analytics',
  'azure/analytics/Event_Hubs',
  'azure/analytics/Log_Analytics_Workspaces',
  // devops
  'azure/devops/Azure_DevOps',
  'azure/devops/Application_Insights',
]

/**
 * Real-byte registry. Empty until the governance gate (NOTICE.md) clears and
 * official SVGs are imported via `?raw`. Keyed by full id.
 */
export const azureIconRegistry: Record<string, string> = {}

/* --------------------------------------------------------------------------
 * First-party clean-room category glyphs.
 * 24x24 viewBox, fill="none", stroke="currentColor". Drawn to read as the
 * *kind* of service, not as the official brand mark.
 * ------------------------------------------------------------------------ */

const G = (body: string): string =>
  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${body}</svg>`

const CATEGORY_GLYPHS: Record<AzureCategory, string> = {
  // CPU chip
  compute: G(
    '<rect x="6" y="6" width="12" height="12" rx="1.5"/><rect x="9.5" y="9.5" width="5" height="5" rx="0.5"/>' +
      '<path d="M9 3v3M15 3v3M9 18v3M15 18v3M3 9h3M3 15h3M18 9h3M18 15h3"/>'
  ),
  // Neural nodes
  ai_machine_learning: G(
    '<circle cx="6" cy="7" r="1.6"/><circle cx="6" cy="17" r="1.6"/><circle cx="13" cy="12" r="1.6"/>' +
      '<circle cx="19" cy="8" r="1.6"/><circle cx="19" cy="16" r="1.6"/>' +
      '<path d="M7.5 7.6 11.5 11.4M7.5 16.4 11.5 12.6M14.5 11.2 17.6 8.6M14.5 12.8 17.6 15.4"/>'
  ),
  // Bar chart
  analytics: G('<path d="M4 20V4"/><path d="M4 20h16"/><rect x="7" y="12" width="3" height="5"/><rect x="12" y="8" width="3" height="9"/><rect x="17" y="5" width="3" height="12"/>'),
  // Browser window
  app_services: G('<rect x="3.5" y="5" width="17" height="14" rx="1.5"/><path d="M3.5 9h17"/><circle cx="6.5" cy="7" r="0.4"/><circle cx="8.5" cy="7" r="0.4"/>'),
  // Hexagon container
  containers: G('<path d="M12 3 20 7.5v9L12 21 4 16.5v-9z"/><path d="M12 3v9M12 12 20 7.5M12 12 4 7.5"/>'),
  // Cylinder
  databases: G('<ellipse cx="12" cy="6" rx="7" ry="2.6"/><path d="M5 6v12c0 1.4 3.1 2.6 7 2.6s7-1.2 7-2.6V6"/><path d="M5 12c0 1.4 3.1 2.6 7 2.6s7-1.2 7-2.6"/>'),
  // Branch / pipeline
  devops: G('<circle cx="6" cy="6" r="2"/><circle cx="6" cy="18" r="2"/><circle cx="18" cy="12" r="2"/><path d="M6 8v8M8 6h6a2 2 0 0 1 2 2v2M8 18h6a2 2 0 0 0 2-2v-2"/>'),
  // Key / badge
  identity: G('<circle cx="9" cy="9" r="4"/><path d="M11.8 11.8 20 20M16 16l2-2M18 18l1.5-1.5"/>'),
  // Plug / connector
  integration: G('<path d="M9 3v5M15 3v5"/><rect x="7" y="8" width="10" height="6" rx="1.5"/><path d="M12 14v3a4 4 0 0 1-4 4H7"/>'),
  // Network nodes
  networking: G('<circle cx="12" cy="5" r="2"/><circle cx="5" cy="18" r="2"/><circle cx="19" cy="18" r="2"/><path d="M12 7v5M12 12 6.5 16.5M12 12l5.5 4.5M7 18h10"/>'),
  // Shield
  security: G('<path d="M12 3 5 6v6c0 4.2 3 7.4 7 9 4-1.6 7-4.8 7-9V6z"/><path d="m9 12 2 2 4-4"/>'),
  // Stacked drums
  storage: G('<ellipse cx="12" cy="6" rx="7" ry="2.4"/><path d="M5 6v5c0 1.3 3.1 2.4 7 2.4s7-1.1 7-2.4V6"/><path d="M5 11v5c0 1.3 3.1 2.4 7 2.4s7-1.1 7-2.4v-5"/>'),
  // Cloud (generic Azure fallback)
  general: G('<path d="M7.5 18a4 4 0 0 1-.6-7.96A5 5 0 0 1 16.5 9.2 3.8 3.8 0 0 1 17 18z"/>'),
}

/** The cloud glyph is the ultimate fallback for an `azure/...` id we cannot place. */
const CLOUD_GLYPH = CATEGORY_GLYPHS.general

/** Extract the `{category}` segment from `azure/{category}/{Shape}`. */
function categoryOf(iconId: string): AzureCategory | null {
  const parts = iconId.split('/')
  if (parts.length < 2 || parts[0] !== 'azure') return null
  const cat = parts[1] as AzureCategory
  return cat in CATEGORY_GLYPHS ? cat : null
}

/**
 * Resolve a node icon id to an inline SVG string, or `null` if the id is not an
 * `azure/...` id at all (so the caller draws the generic geometric shape).
 *
 * Order: exact real-byte registry → category glyph → cloud fallback.
 */
export function resolveIcon(iconId: string | null | undefined): string | null {
  if (!iconId) return null
  const exact = azureIconRegistry[iconId]
  if (exact) return exact
  const cat = categoryOf(iconId)
  if (cat) return CATEGORY_GLYPHS[cat]
  // It looked like an azure id but the category is unknown → cloud, never crash.
  if (iconId.startsWith('azure/')) return CLOUD_GLYPH
  return null
}

/* --------------------------------------------------------------------------
 * Real Microsoft Azure icons — bundled under public/icons/azure2 (the draw.io
 * azure2 set, the exact artwork the next-ai-draw-io catalog references). Fetched
 * on demand by URL and inlined as NATIVE SVG (export-safe; no canvas taint),
 * with the first-party glyph above as the instant / loading / miss fallback.
 * ------------------------------------------------------------------------ */

const REAL_ICON_BASE = '/icons/azure2'
const realIconCache = new Map<string, string | null>()
const realIconInFlight = new Map<string, Promise<string | null>>()

/** `azure/{category}/{Shape}` → `/icons/azure2/{category}/{Shape}.svg`, else null. */
export function azureIconUrl(iconId: string | null | undefined): string | null {
  if (!iconId) return null
  const parts = iconId.split('/')
  if (parts.length !== 3 || parts[0] !== 'azure' || !parts[1] || !parts[2]) return null
  return `${REAL_ICON_BASE}/${encodeURIComponent(parts[1])}/${encodeURIComponent(parts[2])}.svg`
}

/** Strip the root <svg>'s fixed width/height so the icon scales to its wrapper (keeps viewBox). */
function fluidSvg(markup: string): string {
  return markup.replace(
    /<svg\b([^>]*)>/i,
    (_m, attrs: string) => `<svg${attrs.replace(/\s(?:width|height)="[^"]*"/gi, '')}>`,
  )
}

/** Fetch + cache the real Azure SVG markup for an id; null if missing / not an azure id. */
export async function loadAzureIcon(iconId: string | null | undefined): Promise<string | null> {
  if (!iconId) return null
  const cached = realIconCache.get(iconId)
  if (cached !== undefined) return cached
  const url = azureIconUrl(iconId)
  if (!url) {
    realIconCache.set(iconId, null)
    return null
  }
  let pending = realIconInFlight.get(iconId)
  if (!pending) {
    pending = fetch(url)
      .then(async (resp) => {
        const svg = resp.ok ? fluidSvg(await resp.text()) : null
        realIconCache.set(iconId, svg)
        return svg
      })
      .catch(() => {
        realIconCache.set(iconId, null)
        return null
      })
      .finally(() => realIconInFlight.delete(iconId))
    realIconInFlight.set(iconId, pending)
  }
  return pending
}

/**
 * Hook → the real bundled Azure SVG for `iconId` once fetched, else null. Nodes paint the
 * themed `resolveIcon` glyph instantly and upgrade to the branded Microsoft icon when this
 * resolves. Inlined as native SVG by the caller, so it stays export-safe.
 */
export function useAzureIcon(iconId: string | null | undefined): string | null {
  const [svg, setSvg] = useState<string | null>(() => realIconCache.get(iconId ?? '') ?? null)
  useEffect(() => {
    let active = true
    const cached = realIconCache.get(iconId ?? '')
    if (cached !== undefined) {
      setSvg(cached)
      return
    }
    void loadAzureIcon(iconId).then((result) => {
      if (active) setSvg(result)
    })
    return () => {
      active = false
    }
  }, [iconId])
  return svg
}
