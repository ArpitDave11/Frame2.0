import { forwardRef, lazy, Suspense } from 'react'

// @uiw/react-md-editor touches `window` on import, so load it lazily (browser-only) — the
// React.lazy equivalent of Open Notebook's next/dynamic(..., { ssr: false }).
const MDEditor = lazy(() => import('@uiw/react-md-editor'))

export interface MarkdownEditorProps {
  value?: string
  onChange?: (value?: string) => void
  placeholder?: string
  height?: number
  preview?: 'live' | 'edit' | 'preview'
  hideToolbar?: boolean
  textareaId?: string
  name?: string
  className?: string
}

export const MarkdownEditor = forwardRef<HTMLDivElement, MarkdownEditorProps>(
  (
    {
      value = '',
      onChange,
      placeholder,
      height = 300,
      preview = 'live',
      hideToolbar = false,
      className,
      textareaId,
      name,
    },
    ref
  ) => {
    return (
      <div className={className} ref={ref} data-color-mode="light">
        <Suspense fallback={<div style={{ height }} aria-busy="true" />}>
          <MDEditor
            value={value}
            onChange={onChange}
            preview={preview}
            height={height}
            hideToolbar={hideToolbar}
            textareaProps={{
              placeholder: placeholder || 'Enter markdown...',
              id: textareaId,
              name: name,
            }}
          />
        </Suspense>
      </div>
    )
  }
)

MarkdownEditor.displayName = 'MarkdownEditor'
