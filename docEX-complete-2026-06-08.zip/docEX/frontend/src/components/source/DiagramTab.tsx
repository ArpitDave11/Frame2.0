'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { isAxiosError } from 'axios'
import {
  Network,
  Sparkles,
  RefreshCw,
  CheckCircle2,
  Lock,
  AlertCircle,
  Loader2,
  PanelRightClose,
} from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { LoadingSpinner } from '@/components/common/LoadingSpinner'
import { DiagramRenderer } from '@/components/diagram/DiagramRenderer'
import { DiagramChat, type DiagramChatMessage } from '@/components/diagram/DiagramChat'
import {
  useDiagram,
  useGenerateDiagram,
  useRefineDiagram,
  useAcceptDiagram,
} from '@/lib/hooks/use-diagram'
import { useTranslation } from '@/lib/hooks/use-translation'

/**
 * DiagramTab — the 4th tab on a source ("Content / Insights / Details / Diagram").
 *
 * Self-contained: it owns all diagram state via the `use-diagram` hooks and renders
 * every state the insights/details tabs establish — loading spinner, empty CTA,
 * error `Alert`, plus the diagram-specific generating and accepted states. The
 * chrome (Card / CardHeader / CardContent, the empty-state icon idiom, the Alert
 * error idiom) is lifted verbatim from `SourceDetailContent.tsx` so this tab is
 * visually indistinguishable from its siblings.
 *
 * Flow (design §5):
 *   • no diagram        → "Diagram this document" CTA → `generate`
 *   • draft             → live `DiagramRenderer` + Accept / Rebuild + a refine chat
 *   • accepted (frozen) → the static SVG snapshot + Rebuild (starts a new draft)
 *
 * Export (PNG / SVG, static) is handled by the renderer's own toolbar. There is
 * no runtime draw.io dependency on any path.
 */

interface DiagramTabProps {
  sourceId: string
}

export function DiagramTab({ sourceId }: DiagramTabProps): React.ReactElement {
  const { t } = useTranslation()
  // Diagrams default to a LIGHT canvas; the toolbar ☀/☾ toggle flips it to dark per-diagram,
  // independent of the app theme.
  const [diagramTheme, setDiagramTheme] = useState<'light' | 'dark'>('light')
  const toggleDiagramTheme = useCallback(
    () => setDiagramTheme((value) => (value === 'dark' ? 'light' : 'dark')),
    [],
  )

  const { data: diagram, isLoading, isError, refetch } = useDiagram(sourceId)
  const generate = useGenerateDiagram(sourceId)
  const refine = useRefineDiagram(sourceId)
  const accept = useAcceptDiagram(sourceId)

  // Local transcript for the refine chat (the backend regenerates per instruction;
  // there is no persisted chat history, so the log is session-scoped here).
  const [refineLog, setRefineLog] = useState<DiagramChatMessage[]>([])

  // Full-screen workspace: the ⤢ button opens a viewport-filling overlay with the canvas +
  // the refine chat (collapsible right sidebar). Esc exits. The diagram re-frames itself to
  // the larger area automatically (the renderer's ResizeObserver-driven fit).
  const [fullscreen, setFullscreen] = useState(false)
  const [chatOpen, setChatOpen] = useState(true)

  useEffect(() => {
    if (!fullscreen) return
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setFullscreen(false)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [fullscreen])

  const isAccepted = diagram?.status === 'accepted'
  const graph = diagram?.graph ?? null
  const snapshot = isAccepted ? diagram?.render_snapshot_svg : null

  // A pipeline run is in flight from any entry point (first build / rebuild / refine).
  const pipelineBusy = generate.isPending || refine.isPending

  /** Surface a pipeline failure consistently: 422 (no text) vs 502 (LLM) vs other. */
  const explainError = useCallback(
    (err: unknown): string => {
      if (isAxiosError(err)) {
        if (err.response?.status === 422) return t('diagram.noContent')
        if (err.response?.status === 502) return t('diagram.generateFailed')
      }
      return t('diagram.generateFailed')
    },
    [t],
  )

  const handleGenerate = useCallback(() => {
    generate.mutate(undefined, {
      onError: (err) => toast.error(explainError(err)),
    })
  }, [generate, explainError])

  const handleRefine = useCallback(
    (instruction: string) => {
      const stamp = Date.now()
      setRefineLog((prev) => [
        ...prev,
        { id: `h-${stamp}`, type: 'human', content: instruction },
      ])
      refine.mutate(
        { instruction },
        {
          onSuccess: (updated) => {
            setRefineLog((prev) => [
              ...prev,
              {
                id: `a-${stamp}`,
                type: 'ai',
                content: t('diagram.version').replace(
                  '{version}',
                  String(updated.version),
                ),
              },
            ])
          },
          onError: (err) => {
            const message = explainError(err)
            setRefineLog((prev) => [
              ...prev,
              { id: `a-${stamp}`, type: 'ai', content: message },
            ])
            toast.error(message)
          },
        },
      )
    },
    [refine, explainError, t],
  )

  const handleAccept = useCallback(() => {
    accept.mutate(undefined, {
      onSuccess: () => toast.success(t('diagram.acceptSuccess')),
      onError: () => toast.error(t('diagram.acceptFailed')),
    })
  }, [accept, t])

  const statusBadge = useMemo(() => {
    if (!diagram) return null
    return isAccepted ? (
      <Badge variant="default" className="gap-1">
        <Lock className="h-3 w-3" />
        {t('diagram.accepted')}
      </Badge>
    ) : (
      <Badge variant="secondary" className="gap-1">
        {t('diagram.draft')} · {t('diagram.version').replace('{version}', String(diagram.version))}
      </Badge>
    )
  }, [diagram, isAccepted, t])

  /* ------------------------------ loading ------------------------------- */

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Network className="h-5 w-5" />
            {t('diagram.title')}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <LoadingSpinner />
          </div>
        </CardContent>
      </Card>
    )
  }

  /* ------------------------------- error -------------------------------- */

  if (isError) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Network className="h-5 w-5" />
            {t('diagram.title')}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>{t('diagram.loadFailed')}</AlertTitle>
            <AlertDescription>
              <div className="mt-3">
                <Button size="sm" variant="outline" onClick={() => void refetch()}>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  {t('common.retry')}
                </Button>
              </div>
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    )
  }

  /* ------------------------------- header ------------------------------- */

  const header = (
    <CardHeader>
      <CardTitle className="flex items-center justify-between">
        <span className="flex items-center gap-2">
          <Network className="h-5 w-5" />
          {t('diagram.title')}
        </span>
        <div className="flex items-center gap-2">
          {statusBadge}
          {diagram && !isAccepted && (
            <Button size="sm" onClick={handleAccept} disabled={accept.isPending || pipelineBusy}>
              {accept.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {t('diagram.accepting')}
                </>
              ) : (
                <>
                  <CheckCircle2 className="mr-2 h-4 w-4" />
                  {t('diagram.accept')}
                </>
              )}
            </Button>
          )}
          {diagram && (
            <Button
              size="sm"
              variant="outline"
              onClick={handleGenerate}
              disabled={pipelineBusy || accept.isPending}
            >
              {generate.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {t('diagram.rebuilding')}
                </>
              ) : (
                <>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  {t('diagram.rebuild')}
                </>
              )}
            </Button>
          )}
        </div>
      </CardTitle>
      <CardDescription>
        {isAccepted ? t('diagram.acceptedHint') : t('diagram.description')}
      </CardDescription>
    </CardHeader>
  )

  /* ------------------------- empty / generating ------------------------- */

  if (!diagram) {
    return (
      <Card>
        {header}
        <CardContent>
          {generate.isPending ? (
            <div className="flex flex-col items-center justify-center gap-3 py-16 text-center text-muted-foreground">
              <LoadingSpinner size="lg" />
              <p className="text-sm font-medium text-foreground">{t('diagram.generating')}</p>
              <p className="max-w-sm text-xs">{t('diagram.generatingHint')}</p>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center text-muted-foreground">
              <Network className="mx-auto mb-3 h-12 w-12 opacity-50" />
              <p className="text-sm">{t('diagram.empty')}</p>
              <p className="mt-1 text-xs">{t('diagram.emptyHint')}</p>
              <Button className="mt-5" onClick={handleGenerate}>
                <Sparkles className="mr-2 h-4 w-4" />
                {t('diagram.diagramThis')}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    )
  }

  /* --------------------------- accepted (frozen) ------------------------ */

  if (isAccepted && snapshot) {
    return (
      <Card>
        {header}
        <CardContent>
          <div className="h-[520px] w-full">
            <DiagramRenderer
              graph={graph ?? { groups: [], nodes: [], edges: [] }}
              snapshot={snapshot}
              theme={diagramTheme}
              ariaLabel={t('diagram.title')}
            />
          </div>
        </CardContent>
      </Card>
    )
  }

  /* ------------------------------- draft -------------------------------- */

  return (
    <>
      <Card>
        {header}
        <CardContent>
          <div className="grid gap-4 lg:grid-cols-[1fr_360px]">
            <div className="relative h-[520px] w-full">
              {graph ? (
                <DiagramRenderer
                  graph={graph}
                  theme={diagramTheme}
                  animated={!pipelineBusy}
                  ariaLabel={t('diagram.title')}
                  onToggleFullscreen={() => setFullscreen(true)}
                  onToggleTheme={toggleDiagramTheme}
                  isFullscreen={false}
                />
              ) : (
                <div className="flex h-full items-center justify-center rounded-lg border bg-card text-sm text-muted-foreground">
                  {t('diagram.empty')}
                </div>
              )}
              {/* Dim + spinner overlay while a refine/rebuild regenerates in place. */}
              {pipelineBusy && (
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 rounded-lg bg-background/70 backdrop-blur-sm">
                  <LoadingSpinner size="lg" />
                  <p className="text-xs text-muted-foreground">{t('diagram.refining')}</p>
                </div>
              )}
            </div>

            <div className="h-[520px] overflow-hidden rounded-lg border bg-card">
              <DiagramChat
                messages={refineLog}
                busy={refine.isPending}
                disabled={pipelineBusy && !refine.isPending}
                onSend={handleRefine}
                className="h-full"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Full-screen workspace: canvas (left) + collapsible refine chat (right). */}
      {fullscreen && graph && (
        <div
          className="fixed inset-0 z-50 flex bg-background"
          role="dialog"
          aria-modal="true"
          aria-label={t('diagram.title')}
        >
          <div className="relative min-w-0 flex-1">
            <DiagramRenderer
              graph={graph}
              theme={diagramTheme}
              animated={!pipelineBusy}
              ariaLabel={t('diagram.title')}
              onToggleFullscreen={() => setFullscreen(false)}
              onToggleTheme={toggleDiagramTheme}
              isFullscreen
            />
            {pipelineBusy && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-background/70 backdrop-blur-sm">
                <LoadingSpinner size="lg" />
                <p className="text-xs text-muted-foreground">{t('diagram.refining')}</p>
              </div>
            )}
          </div>

          {chatOpen ? (
            <div className="relative flex w-[380px] shrink-0 flex-col border-l bg-card">
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-2 top-2 z-10 h-8 w-8"
                onClick={() => setChatOpen(false)}
                aria-label={t('diagram.hideChat')}
              >
                <PanelRightClose className="h-4 w-4" />
              </Button>
              <DiagramChat
                messages={refineLog}
                busy={refine.isPending}
                disabled={pipelineBusy && !refine.isPending}
                onSend={handleRefine}
                className="h-full"
              />
            </div>
          ) : (
            <Button
              className="absolute bottom-4 right-4 z-10 shadow-lg"
              onClick={() => setChatOpen(true)}
            >
              <Sparkles className="mr-2 h-4 w-4" />
              {t('diagram.refineTitle')}
            </Button>
          )}
        </div>
      )}
    </>
  )
}
