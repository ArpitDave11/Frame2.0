import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";
import { fileURLToPath, URL } from "node:url";
import type { UserConfig as VitestUserConfig } from "vitest/config";

// DocEX is a STANDALONE app (its own React). It is launched same-origin from FRAME's welcome
// screen via a full-screen iframe — NOT a module-federation remote. (Federation was dropped;
// see docs/2026-06-06-integration-same-origin-launch-design.md.)
// Dev/preview proxy /api/docx → the Docx backend; in prod the same-origin ingress does this.
const DOCX_API = process.env.VITE_DOCX_API_BASE || "http://localhost:8002";

const apiProxy = {
  "/api/docx": {
    target: DOCX_API,
    changeOrigin: true,
    rewrite: (p: string) => p.replace(/^\/api\/docx/, ""), // strip prefix → backend /sources, /ask
    secure: false,
  },
};

export default defineConfig({
  // Same-origin hosting: CI builds the prod image with VITE_BASE=/docex/ so asset URLs resolve
  // under the ingress path; local/dev default '/'. (FRAME launches DocEX as a same-origin iframe.)
  base: process.env.VITE_BASE || "/",
  plugins: [react(), tailwindcss()],
  resolve: {
    // Mirror tsconfig "@/*" → ./src so Open Notebook's "@/..." imports resolve in Vite.
    alias: { "@": fileURLToPath(new URL("./src", import.meta.url)) },
  },
  server: { port: 3003, proxy: apiProxy },
  preview: { port: 3003, proxy: apiProxy },
  build: { target: "esnext" },
  test: {
    environment: "jsdom",
    globals: true,
    setupFiles: ["./src/test/setup.ts"],
  },
} as VitestUserConfig);
