# Docx frontend — Module Federation remote

The Docx UI as a **Vite Module Federation remote**. It exposes `./DocxPanel` for FRAME to
mount at runtime (per the locked design: polyrepo + runtime composition), and also runs
standalone for development.

## What it does
`DocxPanel` talks to the Docx backend over **relative `/api/docx/*`** calls:
- **Ask** the collective company brain — `POST /api/docx/ask` (`{question, focus, limit}`)
- **Add** documents — `POST /api/docx/sources` (file or text, with `scope`)
- **List** sources — `GET /api/docx/sources`

Auth is **injected by the host**: `DocxPanel` accepts a `getAuthHeaders` prop so FRAME can
supply the MSAL/dev token. Standalone, it sends none (matching FRAME's current mock auth).

## Run standalone
```bash
npm install
cp .env.example .env        # point VITE_DOCX_API_BASE at the running Docx backend
npm run dev                 # http://localhost:3003 — proxies /api/docx → backend
```

## Build the remote (what FRAME consumes)
```bash
npm run build               # → dist/ including assets/remoteEntry.js
npm run preview             # serve dist/ on :3003 (FRAME points its remote at this)
```

## How FRAME consumes it
FRAME's `vite.config.ts` federation block adds this remote alongside its own `exposes`:
```ts
remotes: { docx: "http://localhost:3003/assets/remoteEntry.js" }  // dev; ingress URL in prod
shared: ["react", "react-dom", "zustand"]                          // React 19 singleton
```
FRAME then mounts it lazily in a Docx tab:
```tsx
const DocxPanel = lazy(() => import("docx/DocxPanel"));
// <Suspense><DocxPanel getAuthHeaders={...} /></Suspense>
```
Serve `remoteEntry.js` behind the **same ingress** as the SPA (same-origin, versioned URL,
long cache) so the one-time lazy load is fast and reliable.

## Routing
`/api/docx` is stripped to hit the backend's `/sources` and `/ask` (Docx is a RAG service,
not another `/api/v1/documents` extractor). Dev: the Vite proxy here. Prod: the FRAME
ingress (`charts/frame-ingress`), mirroring the `/api/docmining` route.
