# Design — DocEX × FRAME Integration: Same-Origin Standalone Launch

**Status:** APPROVED (user, 2026-06-06). Research-backed, verified.
**Supersedes:** the "native FRAME panel via **Vite Module Federation**" decision in `FINAL_DESIGN.md` (§2.2 / §9 reuse) and `CONVERSATION_CONTEXT.md` direction **B3**. Module Federation is **dropped** for this integration.
**Decision owner:** arpit

---

## 1. Decision

Integrate DocEX into FRAME **not** as a module-federated micro-frontend panel, but as an
**independent, standalone app launched full-screen from FRAME's welcome screen**, served
**same-origin** behind the platform ingress/gateway. DocEX keeps its **own React/runtime
(zero sharing)**. Launch mechanism = **full-screen `iframe` overlay** inside FRAME (variant A),
with a "← Back to FRAME" affordance.

## 2. Why (what changed + the research)

- We took the Module Federation path all the way to a live render — but only after fighting a
  **known, fragile class of bug**: the shared-React singleton resolving to `null`
  (`useSyncExternalStore` crash). Root cause confirmed: `@originjs/vite-plugin-federation`
  doesn't share React deep-imports and has broken singleton handling
  ([#534](https://github.com/originjs/vite-plugin-federation/issues/534) open,
  [#595](https://github.com/originjs/vite-plugin-federation/issues/595) "removal of singleton").
  Even after migrating to `@module-federation/vite`, MF's model is **runtime singleton
  negotiation** — *"every framework upgrade becomes a negotiation."* That's permanent coupling.
- The actual UX requirement is **not inline composition** — it's *"open DocEX as a **separate
  thing** from the welcome screen."* For a **whole separate app**, the proven pattern is an
  **independent app**, not federation.
- Research consensus: independent-app / iframe is *"good to power **whole pages**,"*
  **technology-agnostic** (ideal for a polyglot platform), and gives **hard isolation**
  (decision guides: *"need hard isolation → iframe"*). Martin Fowler's iframe cons
  (routing / deep-linking / responsive / toasts-beyond-boundary) are about **inline page
  composition** — they **do not apply** to a full-screen app that owns the viewport.
- The one real risk — **auth across the boundary** (browsers blocking third-party cookies in
  2026) — is solved by **same-origin serving** (reverse proxy / ingress ⇒ first-party) **plus
  the BFF/gateway (MSAL→JWT)** the platform already has.

## 3. Architecture

```
ONE origin (AKS ingress / gateway):
  /frame      → FRAME SPA              (welcome screen has a “DocEX” button)
  /docex      → DocEX standalone app   (its OWN React — zero sharing)
  /api/docx   → DocEX backend          (FastAPI + SurrealDB — UNCHANGED, verified green)
  gateway: MSAL → HS256 local JWT (BFF) → same-origin SSO session shared by both apps
```

- **DocEX** = the standalone app it already is (verified running on its own). No federation
  remote, no exposed module, no shared React.
- **Backend** (docx service) + tenancy (`owner`/`scope`) + `/api/docx` + `LocalJWTBearer` =
  **unchanged** — already verified end-to-end (248 tests, scoped `/notebooks` 200s).
- **FRAME welcome → "DocEX" button → full-screen iframe overlay** (`src = DOCEX_URL`) with a
  slim UBS top bar ("← Back to FRAME"). DocEX owns the viewport; its own routing/state.
- **Auth:** same-origin ⇒ DocEX shares the SSO session; its `/api/docx` calls carry the gateway
  JWT (the exact flow already verified). No tokens-in-URL, no third-party cookies, no singleton.

## 4. Launch UX (variant A — chosen)

1. Welcome screen shows a **"DocEX — Document Intelligence"** card alongside the existing CTAs.
2. Click → FRAME renders a **full-screen overlay**: a slim UBS bar ("← Back to FRAME") above an
   `<iframe src={DOCEX_URL}>` filling the rest.
3. DocEX runs fully inside; closing the overlay returns to FRAME.
4. **Dev:** `DOCEX_URL = http://localhost:3003` (DocEX standalone preview); DocEX calls its
   backend via its own `/api/docx` proxy → `:8002`. **Prod:** `DOCEX_URL = /docex` (same-origin).

## 5. Change delta

- **REMOVE** `@module-federation/vite` + all federation config from **both** repos. DocEX
  frontend becomes a normal standalone Vite app (`index.html → main.tsx → <App/>`). FRAME stops
  consuming a remote; the federated `DocxView`/workspace "Docx" tab is removed.
- **KEEP** (verified working): DocEX backend, tenancy, `/api/docx`, MSAL→JWT.
- **ADD**: welcome-screen "DocEX" button + a full-screen iframe-overlay component; `DOCEX_URL`
  env; (prod) ingress same-origin routing.

## 6. Trade-offs (honest)

- DocEX loads its **own React** (no sharing) — **irrelevant** for a separate full-screen app,
  and it **buys** hard isolation (DocEX's Tailwind can never clash with FRAME's UBS theme) and
  true polyglot freedom (any future sub-app, any stack, integrates the same way).
- **Cross-origin in dev** (`:3002` ↔ `:3003`) — fine; **same-origin in prod** via ingress.

## 7. Implementation phases

1. **DocEX standalone** — ensure the standalone entry renders the app; build + preview; verify
   in browser. (drop MF expose)
2. **FRAME** — remove federation; add the welcome "DocEX" button + full-screen iframe overlay
   (variant A); remove the old federated Docx tab.
3. **Verify full UX live** — welcome → DocEX opens full-screen → Back to FRAME; DocEX functions.
4. **Prod (deploy phase)** — same-origin ingress routing (`/frame`, `/docex`, `/api/docx`) +
   gateway SSO.

## 8. Independent of this change (unchanged backlog)

Azure end-to-end, the 2 un-screenshotted screens, the #13 backend deferrals, and panel polish
(logo) are all **DocEX-internal** and unaffected by the integration mechanism.

---

**Sources:** Martin Fowler — Micro Frontends; freeCodeCamp — iframes→Module Federation;
Leapcell — MF/iframe/Web Components; Modern Frontend Architecture — Federation vs iframes;
Microsoft Entra — third-party cookies for SPAs; Curity — OAuth & same-site cookies;
originjs/vite-plugin-federation #534, #595; module-federation/vite.
