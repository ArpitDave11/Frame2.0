# Design — DocEX Diagram Platform (Source diagrams · Notebook HLD · RepoGraph)

**Status:** proposed (awaiting approval)
**Date:** 2026-06-06
**Revised:** 2026-06-07 — folded in review fixes (entity resolution promoted to its own sub-design;
immutability = data + SVG snapshot; ELK-is-new-work; static exports; draw.io = string-emission;
defensive JSON parser; icon provenance/governance; **build order flipped to Source-tab first**).
**Supersedes:** `2026-06-06-source-diagram-tab-design.md` (the draw.io-only / single-surface draft).
**Companion:** `2026-06-07-entity-resolution-subdesign.md` (the load-bearing cross-source matching design).
**Principle:** one render-agnostic graph model, one custom renderer, three surfaces. Reuse the
three proven reference repos verbatim wherever possible; build new only the glue + the SVG draw
layer. **No feature is downplayed** — animated connectors and Azure icons are first-class, served
by *our* renderer (richer + more controllable than draw.io), with draw.io demoted to optional export.

---

## 0. Reference repos (the working code we copy/adapt — not from scratch)
- **gitdiagram** (`~/Downloads/gitdiagram-main`) — FastAPI + Mermaid + typed-JSON. We take: the
  **typed `DiagramGraph` model**, the **2-step LLM pipeline** (`prompts.py`), Pydantic
  **validation** (`graph_service.py`), the **repo→graph** flow + **drill-down** concept
  (`compile_diagram_graph` `click` directives), the **mermaid validator**, and the GitHub fetch
  (which we re-point at **GitLab**). *Note:* gitdiagram has **no** cross-source/entity logic and
  **no** direct elkjs use (it emits Mermaid and lets Mermaid's `elk` layout flag do the work) — so
  both entity-resolution and the custom renderer's layout are **new work**, flagged below.
- **next-ai-draw-io** (`~/Downloads/next-ai-draw-io-main`) — draw.io/mxGraph. We take: the
  **Azure shape catalog** (`docs/shape-libraries/azure2.md`, 648 icons), the **`get_shape_library`**
  tool, the **`flowAnimation=1`** edge style, and the **mxGraph emitter** — but only for the
  **optional draw.io string export** (never the live `react-drawio` canvas; see §4).
- **oh-my-mermaid** (`~/Downloads/oh-my-mermaid-main`) — hierarchy methodology. We take: the
  **recursive perspective/leveling** model, the **`@`-ref drill-down**, the **breadcrumb** UX,
  per-node **metadata** (description/constraint/concern/context), and **diff/refs/validation**.
  Its `@`-ref idea is the seed of our **shared-entity registry** (sub-design).
- **Microsoft Azure Architecture Icons** — the official SVG set. We embed the SVGs in our renderer
  — **with a pinned source-of-bytes + licensing nod** (see §12 governance note).

---

## 1. Architecture (one model, plugin renderers, three surfaces)
```
            ┌──────────── PIPELINE (gitdiagram 2-step LLM) ────────────┐
 input ───► explanation  ──►  TYPED JSON GRAPH (DiagramGraph, extended) │
 (source text │            + get_shape_library(azure) → real MS icons   │
  | notebook  │            + omm leveling/hierarchy + @-ref drill-down  │
  | gitlab repo)          CANONICAL · Pydantic-validated · composable · immutable-on-accept
                                          │  (stored as JSON — answers "XML or JSON?": JSON)
                          ELK layout (elkjs, driven by US) → coordinates
                                          │
                ★ ONE CUSTOM SVG RENDERER ★  (the presentation; reused by ALL surfaces)
                  • nodes: embedded MS Azure icons (+ generic shapes)
                  • edges: <animateMotion> particle on the path + animated gradient (richer than flowAnimation)
                  • drill-down: zoom into sub-diagram + breadcrumb  ·  optional file/dir link → new tab
                  • UBS-red themed, pan/zoom, export PNG/SVG (exports are STATIC — see §4)
                          │
        (optional) graph → draw.io mxGraph XML *string*  ·  graph → Mermaid
        for "hand-edit" / "pixel-exact MS reference" / quick text view — NOT required, no runtime dep
```
**Renderers are plugins** over `DiagramGraph`: `render_svg(graph)` (primary), `export_drawio(graph)`
(optional string emit), `to_mermaid(graph)` (optional). draw.io is never on the critical path.

**Three surfaces, one engine + one renderer:**
1. **Source-detail "Diagram" tab** — per-source detailed diagram (LLD) of a document. (Figma done.)
2. **Notebook HLD** — deterministically composes the accepted source graphs into one parent graph via the **shared-entity registry**; drill down into each source's LLD.
3. **RepoGraph** (new top-level panel) — the **GitDiagram experience for GitLab**: paste a GitLab repo URL → architecture diagram → drill down (sub-diagram) + optional click-to-open the GitLab file/dir.

---

## 2. The core model — `DiagramGraph` (extended from gitdiagram)
```python
class DiagramGraphGroup:  id; label; description?
class DiagramGraphNode:
    id; label; type; description?; groupId?
    shape?: box|database|queue|document|circle|hexagon
    icon?:   str        # NEW — e.g. "azure/compute/Virtual_Machine" or "azure/ai/Azure_OpenAI"
    link?:   str        # NEW — optional file/dir/url; click → open in new tab (gitdiagram-style)
    drill?:  str        # NEW — id of a deeper sub-graph to zoom into (omm-style)
    entity?: str        # NEW — canonical shared-entity key (notebook registry); the cross-source
                        #       link anchor. Born from controlled-vocab generation; see sub-design.
    meta?:   {description, constraint, concern, context}   # NEW — omm per-node metadata
class DiagramGraphEdge:
    from; to; label?; style?: solid|dashed
    animated?: bool    # NEW → renderer adds <animateMotion> particle/gradient (live canvas only)
    flow?: str         # NEW — optional flow color/semantics
class DiagramGraph: groups[]; nodes[]; edges[]    # + same validation limits as gitdiagram
```
- **Canonical artifact = this JSON.** Every renderer is a deterministic function of it.
- **Storage** (SurrealDB, owner-scoped): `diagram { id, owner, scope, surface:'source'|'notebook'|'repograph', ref (source_id|notebook_id|repo_url), parent_id?, status:'draft'|'accepted', graph_json, render_snapshot_svg?, version, created, updated }`.
- **Immutability — data *and* picture (decided).** Accepting **freezes `graph_json`** (the *data*).
  But the renderer can evolve (icon mapping, ELK version, layout), so the same JSON may render
  *differently* later — i.e. data-immutable is **not** pixel-immutable. The user's ask ("once
  accepted it must not change") is about the **picture**, so on accept we **also snapshot the
  rendered SVG** into `render_snapshot_svg`, and the accepted view shows that snapshot. **Freeze
  both:** JSON for re-derivation/diff/compose, SVG for the guaranteed-stable image. Edits create a
  new version (new JSON + new snapshot).
- **HLD composition** = *mostly* code, **not** a hand-wave: read children's accepted `graph_json` →
  build a parent `DiagramGraph` where each source is a **drillable node** and nodes resolving to the
  **same registry entity** become **cross-source bridges**. Resolution is deterministic for the
  common case (controlled-vocab `entity` ids + normalization) and falls back to embedding + LLM
  adjudication only for ambiguous matches. **This has its own sub-design** —
  `2026-06-07-entity-resolution-subdesign.md` — because it is the feature's load-bearing piece.

---

## 3. Pipeline (gitdiagram, provider-agnostic)
- **Step 1** `SYSTEM_FIRST_PROMPT` → `<explanation>` (architecture analysis). Copied.
- **Step 2** `SYSTEM_GRAPH_PROMPT` → the typed JSON (strict schema; no Mermaid/URLs from the model). Copied + extended for `icon`/`link`/`drill`/`entity`/`animated`.
- **Azure**: `get_shape_library('azure')` returns the MS icon catalog so the model sets `node.icon` to a real icon id (never guesses). Copied from next-ai-draw-io.
- **Controlled vocabulary**: when generating a *source within a notebook*, the current entity
  registry is injected so nodes are born with stable `entity` ids (sub-design, Path C).
- **LLM provider**: DocEX's existing client — **Azure OpenAI structured outputs** (prod) /
  **Anthropic tools** ; **`claude_cli` local path** uses JSON-in-fenced-block parsing (the model
  already returns JSON, so this is natural — tool-calling not even required for the graph step).
  **The fenced-block parser is the flakiest surface** (prose around the block, ```` ```json ```` vs
  ```` ``` ```` fences, trailing commas, multiple blocks) and is written **defensively**: strip
  prose → tolerate fence variants → `jsonrepair` → Pydantic-validate → retry with
  `<validation_feedback>`. Local-only parse flakiness must **not** be mistaken for a pipeline bug;
  prod's structured outputs avoid it entirely.
- **Validation**: Pydantic + gitdiagram's graph validator (node/edge limits, path existence, id rules) → auto-retry with `<validation_feedback>` (copied).

---

## 4. The custom SVG renderer (the heart — full control, one place)
- **Layout:** `elkjs` (Eclipse Layout Kernel) on the typed graph → node x/y + edge routes.
  **This is NEW work, not reused.** gitdiagram does *not* drive elkjs directly — it emits **Mermaid**
  and sets Mermaid's layout engine to `elk` (a one-line config flag). Driving `elkjs` ourselves to
  produce coordinates for the custom renderer is new, and the surfaces need **different ELK
  settings**: flat `layered` for a single source LLD vs **hierarchical/compound** (`INCLUDE_CHILDREN`,
  nested subgraphs) for the composed notebook HLD. Budget layout-tuning per surface.
- **Nodes:** render each as SVG; if `icon` set → embed the **official MS Azure SVG** (from a bundled
  `azure/` icon set; see §12 governance) + label; else a themed shape. Groups → subgraph containers.
- **Animated connectors (richer than draw.io):** for `edge.animated`, render the edge `<path id=...>`
  then attach **`<circle><animateMotion><mpath href="#path"/></animateMotion></circle>`** (a glowing
  particle riding the actual route) + an animated stroke gradient. Speed/color from `edge.flow`.
  **Live-canvas only:** a PNG export is static by definition, and a standalone exported SVG's SMIL
  usually won't run when embedded as an `<img>` elsewhere — so **exports (and the accepted SVG
  snapshot) use a static fallback** (directional gradient + arrowheads, no `<animateMotion>`). The
  flowing look is a canvas affordance, **not** an export guarantee. The motion mechanism lives behind
  a small internal seam (`renderFlow(edgePath)`) so SMIL can later be swapped for
  `requestAnimationFrame`/CSS `offset-path` without changing the renderer's contract (SMIL is
  well-supported today but the least React-native option and has been periodically rumored for
  deprecation).
- **Drill-down:** click a node → if it has `drill` → load that sub-graph (push a **breadcrumb**); if
  it has `link` → show an "open ↗" affordance that opens the **file/dir in a new tab**. Both, per spec.
- **UX:** pan/zoom, UBS-red theme, fit-to-view, export PNG/SVG (static), "▼ DRILL DOWN" hint on drillable nodes.
- **Optional exports:** `export_drawio(graph)` and `to_mermaid(graph)` (quick text/diff).
  **Critical — `export_drawio` is pure string emission:** `DiagramGraph` → mxGraph-XML *string* the
  user opens in their own draw.io (with `flowAnimation=1` + Azure stencils, for hand-edit / pixel-exact
  MS look). It does **NOT** render via `react-drawio`/`<DrawIoEmbed>`, which would phone home to
  `embed.diagrams.net` and be **dead inside UBS's air-gapped network**. There is **no runtime draw.io
  dependency on any path.** Built on the next-ai-draw-io + gitdiagram emitters, emit-only.

---

## 5. Surface 1 — Source-detail "Diagram" tab (LLD)
- 4th tab (Content/Insights/Details/**Diagram**), per the existing Figma.
- "Diagram this document" → pipeline over `source.full_text` → graph → custom renderer (animated + Azure). Chat to refine. **Accept & Save** freezes the JSON **+ SVG snapshot**.

## 6. Surface 2 — Notebook HLD
- "Build notebook diagram" → **statically compose** all accepted source graphs into a parent graph
  via the **shared-entity registry** (each source = drillable node; nodes that resolve to the same
  entity become cross-source bridges) → render. **▼ DRILL DOWN** a source node → its LLD (breadcrumb
  back). Cross-source matching is specified in the entity-resolution sub-design — review it before HLD work.

## 7. Surface 3 — RepoGraph (new top-level panel, GitDiagram-for-GitLab)
- New sidebar entry **RepoGraph** alongside Notebooks/Sources — the **exact GitDiagram UX**: a URL field ("paste a GitLab repo URL"), loading state, the diagram, export, copy.
- **GitLab**: target base URL + auth **provided by FRAME 2.0** (gateway/settings) — self-hosted UBS
  GitLab supported; RepoGraph consumes them (no BYO-key in DocEX). Fetch via GitLab API: project
  lookup, `repository/tree?recursive=true`, README raw. (Mirrors gitdiagram's GitHub service,
  re-pointed; the exact FRAME↔DocEX handshake is **to be finalized with the FRAME 2.0 team — an
  external dependency**, which is why RepoGraph is **not** built first; see build order.)
- After submit → **same pipeline + same custom renderer**. **Drill-down = both**: zoom into a subsystem sub-graph (breadcrumb) **and** each node optionally links to the GitLab file/dir → **opens in a new tab** on click.
- Per-owner persistence + immutability identical to the other surfaces.

---

## 8. Backend (`docx_app/diagram/`)
- `model.py` — the extended `DiagramGraph` Pydantic models + validator (gitdiagram).
- `prompts.py` — the 2-step prompts (gitdiagram) + Azure catalog hooks + controlled-vocab injection.
- `agent.py` — pipeline runner (explanation → JSON → validate/retry), provider-agnostic, defensive parse.
- `compose.py` — deterministic HLD composition + entity reconciliation (sub-design).
- `entities.py` — the **shared-entity registry** store + reconciler (sub-design).
- `render_svg.py` / FE renderer — ELK + custom SVG (primary). `export_drawio.py`, `to_mermaid.py` (optional, emit-only).
- `gitlab_service.py` — GitLab repo fetch (tree/README), config from FRAME/gateway.
- `shape_libraries/azure.*` — the MS Azure icon catalog + ids (pinned source-of-bytes).
- `domain.py` — `DiagramStore` (owner-scoped CRUD, draft/accepted, versions, SVG snapshot).
- `api/diagrams.py` — endpoints: source diagram chat/get/put/accept; notebook compose; **RepoGraph** generate (`POST /repograph {repo_url}` → stream/return graph) + get/list.

## 9. Frontend
- `DiagramRenderer` (the one custom SVG renderer component) — used by all three surfaces; props = `graph_json` + drill/link handlers + theme.
- Source: the Diagram tab (Figma). Notebook: HLD view. **RepoGraph**: new route/panel = GitDiagram-style URL→diagram screen.
- Breadcrumb + "open ↗" link handling; pan/zoom; export.

## 10. LLM + local testing
- Prod: Azure OpenAI structured outputs / Anthropic. Local: `claude_cli` returns the JSON in a fenced block → defensively parsed (no native tools needed for the graph step). Keeps the whole platform testable locally with Claude Sonnet. **Caveat:** the local hash embedder is lexical, so embedding-based synonym matching in entity reconciliation degrades to string + LLM locally (real embeddings in prod) — noted in the sub-design.

## 11. Testing
- Backend: pipeline with a fake LLM (scripted JSON) → assert validated graph; **HLD `compose` +
  entity-reconciler unit tests** (exact/plural/suffix/synonym/homonym/new — sub-design test matrix);
  `gitlab_service` with a fake API; `DiagramStore` tenancy/immutability/snapshot; renderer-emitter
  snapshot tests (svg/drawio/mermaid). ruff + mypy --strict stay green and the **existing** suite
  keeps passing — this feature **adds** tests, so the total rises; **don't gate on a literal count.**
- Live: RepoGraph on a real GitLab repo (Claude Sonnet) → graph renders with animated edges + Azure icons + drill-down (Playwright screenshot).

## 12. Reference-code reuse map (so nothing is rebuilt needlessly)
| Piece | From | Action |
|---|---|---|
| `DiagramGraph` model + validator | gitdiagram `graph_service.py` | copy + extend (icon/link/drill/entity/animated/meta) |
| 2-step prompts + retry | gitdiagram `prompts.py` | copy + tune (+ controlled-vocab) |
| ELK layout | (gitdiagram only via Mermaid flag) | **new work** — drive `elkjs` ourselves, per-surface options |
| repo fetch | gitdiagram `github_service` | adapt → `gitlab_service` |
| drill-down (`click`) + breadcrumb | gitdiagram + omm | reuse + extend (both modes) |
| Azure icon catalog + `get_shape_library` | next-ai-draw-io `azure2.md` | copy |
| `flowAnimation=1` + mxGraph emit | next-ai-draw-io | optional draw.io **string** export |
| hierarchy/leveling, `@`-refs, diff/refs, per-node meta | oh-my-mermaid | adopt methodology (seeds the entity registry) |
| cross-source entity resolution | **none — new** | own sub-design (`2026-06-07-entity-resolution-subdesign.md`) |
| Azure SVGs | Microsoft official set / draw.io shapes | bundle — **pin source-of-bytes + license** |

**Asset-governance note (Azure icons):** the SVG *bytes* and their license must be pinned before
bundling. draw.io's `azure2` shapes (under draw.io's license) are **not** the same artifacts as
Microsoft's official **Azure Architecture Icons** package (its own Terms of Use: no altering the
icons, no implying Microsoft endorsement). Decide the source-of-bytes and get a quick
third-party-asset/licensing nod before embedding 600+ into a UBS-internal product — separate from the
npm-dependency check.

## 13. Out of scope / later
- Live collaborative editing; the draw.io *import* path; multi-repo RepoGraph; vector-embedding diagrams for search (forward-compatible).

---

## Open items
1. **Entity resolution (cross-source edges) — the load-bearing piece** behind the notebook HLD.
   Now specified in its own sub-design: **`2026-06-07-entity-resolution-subdesign.md`** (shared-entity
   registry + controlled-vocab generation + normalization/embedding/LLM reconciliation + human
   override + HLD topology). **Review that before HLD work.**
2. **Build order — Source Diagram tab FIRST** (revised from RepoGraph-first). Rationale: it hardens
   the **custom renderer** — the one piece with *no* reference code — on the simplest single graph;
   the **Figma is ready**; and there is **no cross-team blocker**. Then **Notebook HLD** (adds compose
   + entity resolution on a *proven* renderer), then **RepoGraph** (mostly the re-pointed gitdiagram
   pipeline, and the only surface gated on the external **FRAME 2.0 GitLab handshake**). **Renderer →
   compose → repo.** To confirm before coding.
