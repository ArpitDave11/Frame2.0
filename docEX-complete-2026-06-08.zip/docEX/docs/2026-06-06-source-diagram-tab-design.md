# Design — Source "Diagram" tab ("diagram this document")

**Status:** proposed (awaiting approval)
**Date:** 2026-06-06
**Scope:** A per-source AI diagram tab on source-detail, ported from `next-ai-draw-io`
(approach **B — full tool-calling**), copying its code verbatim where it fits and tuning
for DocEX. **Notebook-level HLD + drill-down is explicitly out of scope** for this pass,
but the data model is left forward-compatible with it.

---

## 1. Goal
Add a **"Diagram"** tab next to Content / Insights / Details on a source. The user clicks
**"Diagram this document"** → the AI reads the source's extracted text and produces a
draw.io diagram (with **animated connectors** and **Azure/cloud shapes** where relevant),
rendered live. The user can **chat to refine** it, then **Accept/Save** to freeze it.

## 2. How the source repo works (recap, so the port is faithful)
- Canvas = `react-drawio` `<DrawIoEmbed>` (an `embed.diagrams.net` iframe); XML in / exports out via postMessage.
- AI loop = Vercel AI SDK `streamText` + a system prompt + **4 tools**: `display_diagram(xml)`,
  `edit_diagram(operations[])`, `append_diagram(xml)`, `get_shape_library(name)`.
- The model emits **only `<mxCell>` elements**; the `<mxfile><diagram><mxGraphModel><root>…`
  wrapper (+ root cells id 0/1) is added client-side.
- **Animated connectors = `flowAnimation=1`** in an edge's `style` (native draw.io). No code.
- **Azure/cloud = `get_shape_library('azure2')`** reads `docs/shape-libraries/azure2.md` so the
  model uses correct stencil syntax instead of guessing.

## 3. Architecture in DocEX
```
SourceDetail ▸ Diagram tab (React/Vite)
   ├─ DiagramCanvas  → react-drawio <DrawIoEmbed>     (renders mxGraph XML)
   ├─ DiagramChat    → prompt box + "Diagram this document"
   └─ diagram-context + tool-handlers (ported)        (apply display/edit/append)
        │  HTTP
        ▼
DocEX backend (FastAPI)
   ├─ POST /sources/{id}/diagram/chat   → DiagramAgent (tool-calling loop) → mxGraph XML
   ├─ GET/PUT /sources/{id}/diagram     → load / save (draft|accepted)
   └─ DiagramAgent: system prompt + 4 tools + shape-library .md files
        │
        ▼  tool-calling LLM (Azure OpenAI function-calling / Anthropic tools)
```

## 4. What is copied vs reimplemented vs new
**Copied ~verbatim (tuned lightly):**
- `lib/system-prompts.ts` → `docx_app/diagram/prompts.py` (the prompt, as a Python string).
  *Tune:* add an explicit line encouraging `flowAnimation=1` on connectors (user wants animated).
- `docs/shape-libraries/*.md` (azure2, aws4, gcp2, kubernetes, flowchart, …) → copied into the backend.
- Tool **schemas + descriptions** (display/edit/append/get_shape_library).
- Frontend XML helpers: `extractDiagramXML`, `isRealDiagram`, `validateAndFixXml`, the
  `<mxfile>…` wrapper logic (from `lib/utils.ts` + `diagram-context.tsx` + `use-diagram-tool-handlers.ts`).
- `react-drawio` usage; a trimmed `diagram-context` + `use-diagram-tool-handlers`.

**Reimplemented (Next.js route → FastAPI):**
- The AI chat route → `DiagramAgent` Python tool-calling loop (Vercel AI SDK has no Python
  equivalent; the prompt, tools, and XML contract are 100% portable — only the runtime changes).

**New (DocEX-specific):**
- `diagram` persistence in SurrealDB (per-owner, per-source, draft/accepted).
- The Diagram tab inside `SourceDetailContent.tsx`, UBS-themed.
- DocEX API endpoints + tenancy (owner-scoped, like every other store).

## 5. Data model (SurrealDB) — XML body + JSON envelope
```
diagram {
  id, owner, scope,                      // tenancy (PRIVATE, like notes)
  source_id,                             // the source it diagrams
  level: 'source',                       // 'notebook' reserved for the future HLD
  status: 'draft' | 'accepted',          // accepted = frozen (your immutability ask)
  mxgraph_xml: string,                   // canonical body (draw.io-native, lossless)
  title, version: int, created, updated
}
```
- **One accepted diagram per source** (drafts overwrite until accepted; accepting bumps version).
- "Save as XML or JSON?" → **XML is the body; the SurrealDB row is the JSON envelope.** No conversion.
- Immutability: once `accepted`, the chat endpoint won't overwrite it unless the user explicitly
  re-edits (which creates a new draft/version). (Optional later: a vector embedding of node labels
  so diagrams are searchable — noted, not in this pass.)

## 6. Backend — `docx_app/diagram/`
- `prompts.py` — the copied system prompt (+ flowAnimation tuning).
- `tools.py` — the 4 tool schemas; `get_shape_library(name)` reads `shape_libraries/{name}.md`
  (path-traversal-guarded, same as the repo).
- `agent.py` — `DiagramAgent.run(messages, current_xml) -> {xml, plan_text}`:
  tool-calling loop (≤ N steps) over the provider; applies `display/edit/append` server-side to
  build the final XML; `get_shape_library` returns docs mid-loop.
- `domain.py` — `DiagramStore` (owner-scoped CRUD), mirroring `NoteStore`/`SettingsStore`.
- `api/diagrams.py` — `POST /sources/{id}/diagram/chat`, `GET/PUT /sources/{id}/diagram`,
  `POST /sources/{id}/diagram/accept`.

**Tool-calling provider** (the one real consequence of choosing B):
- **Azure OpenAI** (prod) and **Anthropic API** support native tools → primary path.
- **`claude_cli` (local test) can't do native tools** → a small **JSON-protocol fallback**: the
  prompt tells the model to emit `<tool_call>{"name":…,"args":…}</tool_call>`; the agent parses,
  executes, and loops. Keeps the feature testable locally with Claude Sonnet.
- Selected by the existing `llm_provider` config; abstracted behind one `ToolLLM` interface.

## 7. Frontend — the Diagram tab
- New 4th tab in `SourceDetailContent.tsx` ("Diagram"), behind the existing segmented control.
- `DiagramCanvas.tsx` — wraps `<DrawIoEmbed baseUrl={config}>`; `baseUrl` is configurable
  (default public `embed.diagrams.net`; swappable to a **self-hosted** draw.io for UBS — decided
  behind one env var so feature code never changes).
- `DiagramChat.tsx` — prompt box + "Diagram this document" (seeds the first prompt with the
  source's `full_text`) + refine messages + **Accept/Save**.
- `diagram-context` + `use-diagram-tool-handlers` (ported, trimmed) apply the agent's tool output.
- States: empty (CTA) / generating (skeleton) / rendered / error (XML invalid → auto-fix or surface).

## 8. Animated connectors + Azure (the two headline features)
- **Animated:** the system prompt instructs `flowAnimation=1` on connectors; draw.io renders it.
- **Azure/cloud:** `get_shape_library('azure2'|'aws4'|…)` + the copied `.md` docs.
- Both are "free" once the prompt + shape docs are ported — no rendering code.

## 9. Error handling
- XML validation/repair on every tool result (`validateAndFixXml` + `jsonrepair` for tool args).
- Truncation → `append_diagram` continuation (ported).
- Tool/agent errors → typed → surfaced as a toast; the last good diagram is preserved.

## 10. Testing
- Backend: `DiagramAgent` unit tests with a **fake ToolLLM** (scripted tool calls) → assert the
  composed XML; `get_shape_library` path-guard tests; `DiagramStore` tenancy/immutability tests.
- Live: generate from a seeded source via Claude Sonnet (JSON-tool-call fallback) → verify
  `flowAnimation=1` edges + Azure shapes; load in the canvas (Playwright screenshot).
- ruff + mypy --strict + the existing 263-test suite stays green.

## 11. Dependencies
- Frontend: `react-drawio`, `jsonrepair` (XML helpers can use the browser DOMParser).
- Backend: existing `openai` SDK (Azure tools) + stdlib XML; copied shape-library `.md`s.

## 12. Out of scope (parked, forward-compatible)
- Notebook-level HLD that statically composes child diagrams + "▼ DRILL DOWN" navigation.
  The `level` + `source_id`/`notebook_id` fields and the accepted-snapshot model are designed so
  this drops in later without migration.
