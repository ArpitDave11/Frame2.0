# DocEX → UBS (Frame 2.0 polyrepo) — Onboarding & Deployment Guide

**Date:** 2026-06-08
**Audience:** whoever stands DocEX up inside the UBS GitLab + AKS / Frame 2.0 ecosystem.
**Status of this guide:** grounded in the ACTUAL repos on this machine
(`docx-platform`, `FRAME_DEPLOYED-brp`, and the `frame-docx-wiring` worktree on branch
`feature/docx-wiring`). Where a value is UBS-internal and not present in any local repo, it is
marked **`<FILL: …>`** — do **not** invent it; pull it from your existing Frame 2.0 repo /
platform team.

> **Read this first — honesty up front.** The Frame 2.0 polyrepo pattern is real and already
> drafted: per-service **Helm charts** centralized in the platform repo (`charts/frame-spa`,
> `charts/frame-docmining`, `charts/frame-docx`, `charts/frame-ingress`), images built per-repo,
> three namespaces (`frame` / `frame-dev` / `frame-engg`) mirroring AKS, an **ingress-nginx**
> path-router, and a **kind**-based local mirror (`infra/local/deploy-all.sh`). A **backend
> Helm chart for DocEX already exists** (`charts/frame-docx`). BUT several pieces required to
> actually run DocEX in-cluster **do not exist yet** and must be created (SurrealDB workload,
> the DocEX frontend chart, the `/docex` ingress route, secrets, the CI pipeline, the gateway
> JWT minter). The full gap list is §0.3. Nothing below is hand-waved.

---

## 0. Reality check — what exists vs what's missing

### 0.1 What DocEX ships today (`docx-platform`, the thing you'll ZIP)

| Area | State | Evidence |
|---|---|---|
| Backend service `services/docx` (FastAPI, py3.12) | ✅ complete, 251 tests, mypy --strict clean | `services/docx/` |
| Backend Dockerfile (image **`frame-docx`**, port **8002**) | ✅ present, non-root, healthcheck `/health/live` | `services/docx/Dockerfile` |
| Frontend `frontend/` (React 19 + Vite, port 3003 dev / nginx 80) | ✅ ported, builds green | `frontend/` |
| Frontend Dockerfile (image **`frame-docx-web`**, port **80**) | ✅ present (multi-stage node→nginx) | `frontend/Dockerfile:3` |
| DB migrations (11 `.surql`, auto-applied on boot) | ✅ present | `services/docx/migrations/` |
| Local full-stack compose (SurrealDB + docx + docx-web) | ✅ present | `docker-compose.yml` |
| uv workspace + lockfile, npm lockfile | ✅ committed | `uv.lock`, `frontend/package-lock.json` |
| `services/gateway` (MSAL→JWT BFF) | ⚠️ **stub** — not a working JWT minter | `services/gateway/` |
| Helm chart / k8s manifests / `.gitlab-ci.yml` inside this repo | ❌ **none** | — |

### 0.2 What Frame 2.0 already has (the polyrepo platform, `feature/docx-wiring`)

| Asset | Path (in `frame-docx-wiring` worktree) | Note |
|---|---|---|
| **DocEX backend chart** | `charts/frame-docx/` | image `frame-docx:dev`, svc port 8002, probes `/health/live` + `/health/ready`, `envFrom: docx-secrets` (commented) |
| Sibling backend chart (pattern to copy) | `charts/frame-docmining/` | shows the env + secret + resource shape |
| FRAME SPA chart | `charts/frame-spa/` | image `frame-spa`, nginx :80, replicas 2 |
| **Ingress chart** | `charts/frame-ingress/` | ingress-nginx, path routing (see §4.4) |
| Local kind mirror | `infra/kind/cluster.yaml`, `infra/local/deploy-all.sh`, `infra/local-proxy/nginx.conf` | 3 namespaces, ports 8080/8443 |
| FRAME→DocEX launcher (iframe) | `src/components/docx/DocxView.tsx`, `src/stores/uiStore.ts`, `src/App.tsx`, `WelcomeScreen.tsx` | `VITE_DOCEX_URL`, default `http://localhost:3003` |

### 0.3 The gaps you MUST close before DocEX runs in-cluster (no downplaying)

1. **No SurrealDB workload in k8s.** `charts/frame-docx/values.yaml` points at `SURREAL_URL:
   ws://surrealdb:8000/rpc`, but **there is no `surrealdb` chart / StatefulSet / Service / PVC**
   anywhere. SurrealDB is DocEX's *only* datastore (the "collective brain"); it needs persistence.
   → §4.2 provides a StatefulSet chart.
2. **No DocEX frontend chart.** The ingress references a service `docx-web:80`, but **no chart
   builds/deploys the `frame-docx-web` image.** → §4.3 provides it.
3. **Ingress serves the frontend at `/docx-remote`, not `/docex`.** That path is a leftover from
   the dropped Module-Federation design. The approved same-origin design (`docs/2026-06-06-
   integration-same-origin-launch-design.md`) says **`/docex`**. → §4.4 reconciles to `/docex`
   and requires the SPA be built with `base: '/docex/'`.
4. **Vite has no `base`, nginx has no SPA fallback.** `frontend/vite.config.ts` has no `base`
   (defaults `/`); `frontend/nginx.conf` uses `try_files … =404`. Same-origin at `/docex/` needs
   `base: '/docex/'` + `try_files … /docex/index.html`. → §4.3.
5. **The gateway (MSAL→HS256 JWT) is a stub.** Prod `AUTH_MODE=gateway` needs a real minter +
   `LOCAL_JWT_SECRET`. → §4.6 gives you a v1 decision (run `AUTH_MODE=dev` behind Istio
   mTLS/namespace isolation first — exactly DocMining's current posture — then finish the gateway).
6. **No `.gitlab-ci.yml` exists in any repo.** The pipeline is not on this machine; it lives in
   your UBS GitLab (or isn't written yet). → §3 gives a real template to align to your runners.
7. **`charts/frame-docx` is not wired into `deploy-all.sh`,** and the `docx-secrets` Secret it
   references is not created. → §4.5 + §4.7.
8. **DocEX backend has never run against real Azure OpenAI** (embeddings/chat/ask are mocked in
   tests). The first cluster deploy is also your first real-Azure test — expect to debug Entra /
   Workload Identity + deployment names. → §7 step 6.
9. **The FRAME-side launcher is on `feature/docx-wiring`, not merged to FRAME `main`,** and
   `VITE_DOCEX_URL` is not in FRAME's `.env.example` on main. → §5 + §6.

---

## 1. Create & structure the new `docEX` GitLab repository

**Recommendation:** the new repo = the `docx-platform` tree **as-is** (it's already a clean,
self-contained polyrepo app). Keep the **app** in `docEX`; keep the **deploy charts** centralized
in the FRAME platform repo (that is the established pattern — `frame-docmining`'s chart lives in
FRAME, not in the docmining backend repo). The `frame-docx` chart's own comment confirms this:
`image.repository: frame-docx # built from the docx-platform repo (polyrepo); referenced here`.

### 1.1 Make the ZIP (clean, no build cruft)

From `/Users/arpit/Documents/docx-platform`:

```bash
# Use git archive so .gitignore'd junk (.venv, node_modules, caches) is excluded automatically.
git archive --format=zip -o /tmp/docEX-$(git rev-parse --short HEAD).zip HEAD
# If you have uncommitted work you want included, commit it first (see note below).
```

> ⚠️ You are currently on branch `feat/diagram-platform` with **uncommitted changes** (the
> diagram theme/shape/animation batch). `git archive HEAD` captures only committed content.
> Commit (or stash) first, or use `git stash show -p`/a working-tree zip if you want the WIP in.

### 1.2 Repo layout that lands in `docEX`

```
docEX/                         # = docx-platform
├─ pyproject.toml  uv.lock     # uv workspace (members: services/shared, gateway, docx)
├─ docker-compose.yml          # local full stack (Surreal + docx + docx-web)
├─ services/
│  ├─ shared/                  # FastAPIFactory, BaseConfig, JWT utils
│  ├─ gateway/                 # MSAL→JWT BFF  (STUB — see §4.6)
│  └─ docx/                    # the backend  (Dockerfile → image frame-docx:8002)
│     └─ migrations/*.surql    # auto-applied on startup
├─ frontend/                   # React 19 SPA  (Dockerfile → image frame-docx-web:80)
├─ infra/                      # local Postgres/Neo4j compose (reference only — NOT used)
└─ docs/                       # designs incl. this guide
```

### 1.3 First push to UBS GitLab

```bash
git remote add origin https://devcloud.ubs.net/<FILL: group>/docEX.git   # UBS GitLab Enterprise
git push -u origin main
# Protect main; create dev + a feature branch to mirror the frame/frame-dev/frame-engg envs.
```

---

## 2. What to copy / reuse from Frame 2.0

You are **not** copying app code from Frame — you are reusing its **deploy machinery and
conventions**. Copy/extend these (they live in the platform repo, branch `feature/docx-wiring`):

| Reuse from Frame 2.0 | Why / what to do |
|---|---|
| `charts/frame-docx/` (already drafted) | The DocEX **backend** chart. Keep. Wire its secrets (§4.5) + add it to deploy (§4.7). |
| `charts/frame-docmining/` (as a template) | Copy its **`envFrom` + resources + probes** shape to author the SurrealDB and frontend charts. |
| `charts/frame-ingress/` | Add the `/docex` route + the `docx.serviceName` wiring (§4.4). |
| `infra/local/deploy-all.sh` | Add a `frame-docx` + `surrealdb` + `frame-docx-web` install block (§4.7) so the kind mirror runs DocEX. |
| `infra/kind/cluster.yaml`, `infra/local-proxy/nginx.conf` | Reuse unchanged for local validation. |
| Namespace + host convention (`frame`/`frame-dev`/`frame-engg`, `*.local` → AKS hosts) | Deploy DocEX **into the same namespaces** alongside FRAME (same-origin requires same ingress/host). |
| Image-naming + `<release>-<chart>` service convention | `helm install docx charts/frame-docx` ⇒ service `docx-frame-docx:8002` (matches the ingress default). Keep the names. |
| `.gitlab-ci.yml` from an existing Frame service repo | **The single best source** for your real registry path, runner tags, Kaniko image, and deploy job. Copy it and adapt (§3). |

---

## 3. CI/CD for DocEX

There is **no `.gitlab-ci.yml` in any local repo** — so the authoritative template is whatever
your existing Frame service repos use. Below is a correct, minimal pipeline grounded in DocEX's
real build commands; replace the `<FILL>` slots from your platform's existing CI.

### 3.1 Real build facts (use these verbatim)

- **Backend image** — context = **repo root** (uv workspace needs root manifest + `services/`):
  ```bash
  docker build -f services/docx/Dockerfile -t frame-docx:<tag> .
  ```
- **Frontend image** — context = `frontend/`:
  ```bash
  docker build -f frontend/Dockerfile -t frame-docx-web:<tag> \
    --build-arg/or env so the SPA is built with base=/docex/  (see §4.3) frontend
  ```
- **Lint/test gates that already pass locally** (mirror them in CI):
  ```bash
  uv run ruff check . && uv run ruff format --check . && uv run mypy --strict services/docx/src
  uv run pytest -q services/docx
  (cd frontend && npm ci && npx tsc --noEmit && npm run build && npm test -- --run)
  ```

### 3.2 `.gitlab-ci.yml` (drop in repo root; adapt `<FILL>`)

```yaml
stages: [lint, test, build, deploy]

variables:
  REGISTRY: <FILL: e.g. registry.devcloud.ubs.net/your-group/docex>
  # Kaniko is the usual in-cluster builder on UBS runners; confirm with platform team.

.python: &python
  image: python:3.12-slim
  before_script:
    - pip install --no-cache-dir uv==0.5.4

ruff-mypy:
  <<: *python
  stage: lint
  script:
    - uv sync --frozen
    - uv run ruff check . && uv run ruff format --check .
    - uv run mypy --strict services/docx/src

pytest:
  <<: *python
  stage: test
  script:
    - uv sync --frozen
    - uv run pytest -q services/docx          # 251 tests; mocks Azure (no secrets needed)

frontend:
  image: node:22-alpine
  stage: test
  script:
    - cd frontend && npm ci && npx tsc --noEmit && npm test -- --run && npm run build

build-backend:
  stage: build
  image: <FILL: kaniko executor image>
  script:
    - /kaniko/executor --context $CI_PROJECT_DIR --dockerfile services/docx/Dockerfile
      --destination $REGISTRY/frame-docx:$CI_COMMIT_SHORT_SHA
      --destination $REGISTRY/frame-docx:latest
  rules: [{ if: '$CI_COMMIT_BRANCH' }]

build-frontend:
  stage: build
  image: <FILL: kaniko executor image>
  script:
    - /kaniko/executor --context $CI_PROJECT_DIR/frontend --dockerfile frontend/Dockerfile
      --destination $REGISTRY/frame-docx-web:$CI_COMMIT_SHORT_SHA
      --destination $REGISTRY/frame-docx-web:latest
      --build-arg VITE_BASE=/docex/        # see §4.3
  rules: [{ if: '$CI_COMMIT_BRANCH' }]

deploy:
  stage: deploy
  image: <FILL: image with helm + kubectl + cluster creds>
  script:
    - helm upgrade --install docx <FILL: path to charts/frame-docx>
        -n $NAMESPACE
        --set image.repository=$REGISTRY/frame-docx --set image.tag=$CI_COMMIT_SHORT_SHA
    - helm upgrade --install docx-web <FILL: charts/frame-docx-web>
        -n $NAMESPACE --set image.tag=$CI_COMMIT_SHORT_SHA
  rules: [{ if: '$CI_COMMIT_BRANCH == "main"' }]   # map branch→namespace per your convention
```

> Whether the **deploy** job lives in the `docEX` repo or in the platform repo (which owns the
> charts) is a **convention choice** — see §6.3. UBS pipelines commonly **build in the app repo,
> deploy from the platform repo**; align to what Frame already does.

---

## 4. Kubernetes: configs, ingress, secrets, env, manifests

Target: DocEX runs in the **same namespace** as FRAME (e.g. `frame-engg` for the feature env) so
that `/frame`, `/docex`, `/api/docx` are **one origin**.

### 4.1 What's needed (4 workloads + 1 ingress + 1 secret)

| Workload | Image | Port | Chart | Status |
|---|---|---|---|---|
| DocEX backend | `frame-docx` | 8002 | `charts/frame-docx` | ✅ exists — wire secrets |
| **SurrealDB** | `surrealdb/surrealdb:v2.6.5` | 8000 | `charts/surrealdb` | ❌ **create (§4.2)** |
| **DocEX frontend** | `frame-docx-web` | 80 | `charts/frame-docx-web` | ❌ **create (§4.3)** |
| Ingress routes | — | — | `charts/frame-ingress` | ⚠️ add `/docex` (§4.4) |
| `docx-secrets` | — | — | k8s Secret | ❌ **create (§4.5)** |

### 4.2 SurrealDB StatefulSet (NEW — `charts/surrealdb/`)

SurrealDB holds the collective brain → **must persist**. Minimal StatefulSet:

```yaml
# templates/statefulset.yaml
apiVersion: apps/v1
kind: StatefulSet
metadata: { name: surrealdb }
spec:
  serviceName: surrealdb
  replicas: 1
  selector: { matchLabels: { app: surrealdb } }
  template:
    metadata: { labels: { app: surrealdb } }
    spec:
      containers:
        - name: surrealdb
          image: surrealdb/surrealdb:v2.6.5
          args: ["start","--user","$(SURREAL_USER)","--pass","$(SURREAL_PASSWORD)",
                 "rocksdb:/data/docx.db"]
          ports: [{ name: rpc, containerPort: 8000 }]
          env:
            - { name: SURREAL_USER, value: root }
            - { name: SURREAL_PASSWORD, valueFrom: { secretKeyRef: { name: docx-secrets, key: SURREAL_PASSWORD } } }
          readinessProbe: { exec: { command: ["/surreal","is-ready","--endpoint","http://localhost:8000"] }, initialDelaySeconds: 5 }
          volumeMounts: [{ name: data, mountPath: /data }]
  volumeClaimTemplates:
    - metadata: { name: data }
      spec:
        accessModes: ["ReadWriteOnce"]
        resources: { requests: { storage: <FILL: e.g. 20Gi> } }
        storageClassName: <FILL: UBS storage class>
---
# templates/service.yaml — name MUST be `surrealdb` (frame-docx points at ws://surrealdb:8000/rpc)
apiVersion: v1
kind: Service
metadata: { name: surrealdb }
spec:
  selector: { app: surrealdb }
  ports: [{ name: rpc, port: 8000, targetPort: rpc }]
```

> **Decisions:** storage size, storage class, and **backup/restore** of this PVC (Velero? volume
> snapshots?) are real and data-critical — confirm with the platform team. Single replica is
> correct for SurrealDB file mode.

### 4.3 DocEX frontend chart (NEW — `charts/frame-docx-web/`) + base path

Two required app-side changes so the SPA works same-origin at `/docex/`:

1. **`frontend/vite.config.ts`** — set base (parameterized for dev vs prod):
   ```ts
   export default defineConfig({ base: process.env.VITE_BASE || '/', /* …unchanged… */ })
   ```
   Build the prod image with `VITE_BASE=/docex/` (see CI §3.2).
2. **`frontend/nginx.conf`** — SPA fallback + serve under `/docex/`:
   ```nginx
   location /docex/ { try_files $uri $uri/ /docex/index.html; }
   ```
   (Drop the open `Access-Control-Allow-Origin *` — same-origin makes it unnecessary.)

Then a chart identical in shape to `frame-spa` (image `frame-docx-web`, port 80, probe `/`,
replicas 2). Service name must match the ingress (`docx-web`, or rename consistently — §4.4).

### 4.4 Ingress — add `/docex`, keep `/api/docx`

`charts/frame-ingress` already routes **`/api/docx/* → docx-frame-docx:8002`** (prefix stripped) —
that's correct and matches the SPA's fixed `API_BASE='/api/docx'`. The frontend route, however, is
currently **`/docx-remote` → `docx-web:80`** (federation-era). Replace it with `/docex`:

```yaml
# add to charts/frame-ingress/templates/ingress.yaml (new Ingress object)
metadata:
  name: frame-ingress-docex
  annotations:
    nginx.ingress.kubernetes.io/rewrite-target: /docex/$2     # keep the /docex/ prefix (matches base)
    nginx.ingress.kubernetes.io/use-regex: "true"
spec:
  ingressClassName: { { .Values.ingressClassName } }
  rules:
    - host: { { .Values.host } }
      http:
        paths:
          - path: /docex(/|$)(.*)
            pathType: ImplementationSpecific
            backend: { service: { name: { { .Values.docxWeb.serviceName } }, port: { number: 80 } } }
```

Final routes on the one host (`frame-engg.local` locally → `<FILL: AKS host>` in prod):

```
/frame          → spa-frame-spa:80          (FRAME SPA — welcome screen + DocEX button)
/docex          → frame-docx-web:80         (DocEX SPA, built base=/docex/)
/api/docx       → docx-frame-docx:8002      (DocEX backend; prefix stripped)
/api/docmining  → dm-frame-docmining:8000   (extraction; DocEX calls it server-side)
```

### 4.5 Secret `docx-secrets` (the only secrets DocEX needs)

```bash
kubectl -n <ns> create secret generic docx-secrets \
  --from-literal=AZURE_OPENAI_API_KEY='<FILL>' \
  --from-literal=AZURE_OPENAI_ENDPOINT='https://<FILL>.openai.azure.com' \
  --from-literal=AZURE_OPENAI_DEPLOYMENT='<FILL: chat deployment>' \
  --from-literal=AZURE_OPENAI_EMBEDDING_DEPLOYMENT='text-embedding-3-small' \
  --from-literal=SURREAL_PASSWORD='<FILL: strong>' \
  --from-literal=LOCAL_JWT_SECRET='<FILL: 32+ random bytes>' \
  --from-literal=GITLAB_TOKEN='<optional: RepoGraph on private GitLab>' \
  --from-literal=GITHUB_TOKEN='<optional: RepoGraph on GitHub>'
```

Then flip `charts/frame-docx/values.yaml` `envFrom` on:
```yaml
envFrom:
  - secretRef: { name: docx-secrets }
```

> In UBS this Secret is normally **projected from Azure Key Vault** (Workload Identity / CSI
> driver), not created by hand. Use whichever mechanism Frame already uses for its Azure key.

### 4.6 Env / config of record (non-secret, from the chart)

```
AUTH_MODE=gateway              # prod design (validates the gateway-minted JWT). See decision below.
SURREAL_URL=ws://surrealdb:8000/rpc
SURREAL_USER=root
SURREAL_NAMESPACE=docx
SURREAL_DATABASE=docx
DOCMINING_URL=http://dm-frame-docmining:8000
# secrets via envFrom: AZURE_OPENAI_*, SURREAL_PASSWORD, LOCAL_JWT_SECRET
```

> **AUTH decision for v1 (pick one, then move on):**
> **(a) Fastest — `AUTH_MODE=dev`:** backend derives the owner from the `X-Docx-User` header and
> stays **inside the cluster**, protected by **namespace isolation + Istio mTLS** (this is exactly
> DocMining's current posture: *"backend stays inside the cluster and relies on Istio mTLS +
> namespace isolation"*). Gets you running today. Identity is coarse until the gateway lands.
> **(b) Correct — `AUTH_MODE=gateway`:** finish the `services/gateway` MSAL→HS256-JWT minter,
> issue `LOCAL_JWT_SECRET`, and have it sit in front of `/api/docx`. Required before exposing
> DocEX to real multi-user traffic. The backend half (`decode_local_jwt`, tenancy) is already
> built and tested; only the minter is missing.

### 4.7 Wire DocEX into `infra/local/deploy-all.sh` (local kind mirror)

Add, inside the per-namespace loop (alongside the `dm` and `spa` installs):

```bash
helm upgrade --install surreal "$REPO_ROOT/charts/surrealdb" -n "$ns"
helm upgrade --install docx    "$REPO_ROOT/charts/frame-docx" -n "$ns" \
  --set image.repository=frame-docx --set image.tag=dev --set image.pullPolicy=IfNotPresent
helm upgrade --install docx-web "$REPO_ROOT/charts/frame-docx-web" -n "$ns" \
  --set image.repository=frame-docx-web --set image.tag=dev --set image.pullPolicy=IfNotPresent
# and add to the ingress install: --set docx.serviceName=docx-frame-docx --set docxWeb.serviceName=docx-web-frame-docx-web
```
…and add `frame-docx:dev` + `frame-docx-web:dev` to the `do_build` + `kind load docker-image` lines.

---

## 5. How DocEX integrates with Frame 2.0 (and stays independent)

**Mechanism (approved, `docs/2026-06-06-integration-same-origin-launch-design.md`): a
full-screen `<iframe>` overlay launched from FRAME's welcome screen, served same-origin.** Module
Federation was tried and **deliberately dropped** (the `@originjs/vite-plugin-federation`
shared-React-singleton bug → `useSyncExternalStore` null crash; permanent runtime coupling).

- **Independence:** DocEX runs its **own React** in the iframe — hard isolation (its Tailwind can
  never clash with FRAME's UBS theme), any stack, upgraded on its own cadence. This is the *point*
  of the iframe choice, not a compromise.
- **The launcher (already coded on `feature/docx-wiring`):** `src/components/docx/DocxView.tsx`
  renders a fixed full-screen overlay (`<iframe src={DOCEX_URL}>` + "← Back to FRAME"), gated on
  `uiStore.docexOpen`; the welcome card (`data-testid="welcome-docex"`) calls `openDocex()`.
- **`DOCEX_URL`:** `import.meta.env.VITE_DOCEX_URL || 'http://localhost:3003'`. **Dev** =
  `http://localhost:3003`; **prod** = **`/docex`** (same-origin). Add `VITE_DOCEX_URL=/docex` to
  FRAME's prod env.
- **Auth across the boundary:** solved by **same-origin** (first-party cookies) + the gateway JWT
  on DocEX's own `/api/docx` calls. **No token is passed into the iframe** (no postMessage, no
  query param) — confirmed in `DocxView.tsx`. DocEX authenticates its *own* API calls.

---

## 6. What changed in Frame 2.0 for the polyrepo — and what to replicate for DocEX

### 6.1 The polyrepo pattern Frame established

- **App code per repo; Helm charts centralized in the platform repo** (`charts/<service>`), each
  referencing an image built by that app's own CI. Confirmed by `frame-docmining` (chart in FRAME,
  backend elsewhere) and the `frame-docx` chart comment.
- **Three namespaces** `frame` / `frame-dev` / `frame-engg` (main / dev / feature) on one host
  each, mirrored locally by kind (`infra/local/deploy-all.sh`).
- **One ingress** path-routes every service on a shared host (same-origin) — `charts/frame-ingress`.
- **`<release>-<chart>` service naming** (e.g. `dm-frame-docmining`, `spa-frame-spa`,
  `docx-frame-docx`) — the ingress values depend on these exact names.

### 6.2 Frame-side changes already made FOR DocEX (on `feature/docx-wiring`)

- Added the welcome **DocEX launcher** (overlay + iframe + uiStore actions) — §5.
- **Removed** DocEX-as-a-federation-remote (`remotes.d.ts` cleared) while **keeping** FRAME's own
  `exposes: './App'` (FRAME is itself a remote for a company shell).
- Drafted `charts/frame-docx` + the `/api/docx` (and legacy `/docx-remote`) ingress routes.

### 6.3 What you must replicate / finish for DocEX

| Must do | Where | Ref |
|---|---|---|
| Author **SurrealDB** + **frame-docx-web** charts | platform repo `charts/` | §4.2, §4.3 |
| Reconcile ingress to **`/docex`** + create `docx-secrets` | `charts/frame-ingress`, k8s | §4.4, §4.5 |
| Add DocEX installs to **`deploy-all.sh`** + image build/load | `infra/local/` | §4.7 |
| Add **`VITE_DOCEX_URL=/docex`** to FRAME prod env; **merge `feature/docx-wiring`** | FRAME repo | §5 |
| Author **`.gitlab-ci.yml`** in `docEX` (build+push both images) | `docEX` repo root | §3 |
| Decide **AUTH_MODE v1** (dev-behind-Istio vs finish gateway) | — | §4.6 |
| (prod) Add **Istio VirtualService/DestinationRule** if Frame uses Istio rather than raw ingress-nginx in AKS | platform repo | §0.2 note; DocMining plan §C2 host pattern `*.dmeshdev.azpriv-cloud.ubs.net` |

---

## 7. End-to-end validation in UBS (do it locally first — same shape as AKS)

The kind mirror is byte-for-byte the AKS shape ("the RDP switch is just registry push + cluster
credentials"). Validate locally, then repeat against AKS.

1. **Build images:** `docker build -f services/docx/Dockerfile -t frame-docx:dev .` and
   `docker build -t frame-docx-web:dev frontend` (with `VITE_BASE=/docex/`), plus pull
   `surrealdb/surrealdb:v2.6.5`.
2. **Bring up the mirror:** `bash infra/local/deploy-all.sh up` (after the §4.7 edits). Confirms
   cluster + ingress-nginx + all charts across the 3 namespaces.
3. **Pods healthy:** `kubectl -n frame-engg get pods` → `surrealdb`, `docx-frame-docx`,
   `docx-web-…`, `spa-frame-spa`, `dm-frame-docmining` all `Running`/`Ready`.
4. **Backend health (through ingress):**
   `curl -fs http://frame-engg.local:8080/api/docx/health/ready` → 200.
5. **Migrations ran:** check `kubectl logs deploy/docx-frame-docx` for the migration runner
   applying `0001…0011` with no error (fail-fast means a bad migration crashes the pod).
6. **Real Azure smoke (first-ever):** create a source, confirm it embeds + you can chat/ask. This
   is the first real-Azure exercise — if it fails, it's Entra/Workload-Identity or a wrong
   `AZURE_OPENAI_DEPLOYMENT`, not app logic.
7. **The launch UX:** open `http://frame-engg.local:8080/frame/` → click **DocEX** → the
   full-screen overlay loads `/docex` → DocEX renders, lists notebooks/sources, "← Back to FRAME"
   returns. (Set `VITE_DOCEX_URL=/docex` in the FRAME image for this env.)
8. **Promote to AKS:** push images to `<FILL: registry>`, `helm upgrade --install` the same charts
   with cluster creds into the AKS namespace, repeat 3–7 against the AKS host.

---

## 8. Post-deploy testing checklist

**Platform / cluster**
- [ ] All 5 workloads `Ready`; no `CrashLoopBackOff`.
- [ ] SurrealDB PVC `Bound`; data survives a pod restart (`kubectl delete pod surrealdb-0` → data intact).
- [ ] `docx-secrets` mounted (`kubectl exec … env | grep AZURE_OPENAI_ENDPOINT`).

**Backend (through `/api/docx`)**
- [ ] `/api/docx/health/live` + `/health/ready` → 200.
- [ ] `GET /api/docx/sources` → 200 (with identity per AUTH_MODE).
- [ ] Migrations `0001–0011` applied (logs); `/openapi.json` lists the full route set.
- [ ] Tenancy: two identities don't see each other's `private`-scope data; `org-common` is shared.
- [ ] Body-size: a ~40 MB upload succeeds (ingress `proxy-body-size: 50m`).

**Azure (first real run)**
- [ ] A source **embeds** (no Azure 401/404 on the embedding deployment).
- [ ] **Chat** and **Ask** return grounded answers (chat deployment reachable).
- [ ] RepoGraph (optional) reaches GitHub/GitLab if `*_TOKEN` set.

**Frontend (`/docex`)**
- [ ] `/docex/` serves `index.html`; **assets resolve under `/docex/`** (no 404s → base is right).
- [ ] SPA deep-render works (no white screen); `/api/docx` calls succeed same-origin (no CORS error).

**FRAME integration**
- [ ] Welcome **DocEX** card visible; click → full-screen overlay; iframe `src` = `/docex`.
- [ ] DocEX functions inside the iframe; **"← Back to FRAME"** restores FRAME.
- [ ] FRAME's own screens unaffected (UBS theme intact — isolation holds).

**Auth posture**
- [ ] If `AUTH_MODE=gateway`: a request without a valid JWT → 401; with the gateway JWT → 200.
- [ ] If `AUTH_MODE=dev`: backend is **not** reachable from outside the cluster (Istio mTLS /
      NetworkPolicy), since dev mode trusts a header.

---

## Appendix — quick reference (real values found on this machine)

| Thing | Value |
|---|---|
| Backend image / port / health | `frame-docx` / 8002 / `/health/live`,`/health/ready` |
| Frontend image / port | `frame-docx-web` / 80 |
| Backend build | `docker build -f services/docx/Dockerfile -t frame-docx .` (context = repo root) |
| Frontend build | `docker build -t frame-docx-web frontend` (set `VITE_BASE=/docex/`) |
| Service names (release `docx`/`spa`/`dm`) | `docx-frame-docx:8002`, `spa-frame-spa:80`, `dm-frame-docmining:8000`, `surrealdb:8000` |
| Namespaces / local hosts | `frame`,`frame-dev`,`frame-engg` / `*.local:8080` (kind) |
| Ingress class | `nginx` (ingress-nginx) |
| UBS GitLab | `https://devcloud.ubs.net` |
| Prod Istio host pattern (sibling) | `frame-docmining.dmeshdev.azpriv-cloud.ubs.net` |
| DocEX env (non-secret) | `AUTH_MODE`, `SURREAL_URL=ws://surrealdb:8000/rpc`, `SURREAL_{USER,NAMESPACE,DATABASE}`, `DOCMINING_URL=http://dm-frame-docmining:8000` |
| DocEX secrets | `AZURE_OPENAI_API_KEY/ENDPOINT/DEPLOYMENT`, `SURREAL_PASSWORD`, `LOCAL_JWT_SECRET`, opt `GIT{LAB,HUB}_TOKEN` |
| Launch | FRAME welcome → iframe overlay, `VITE_DOCEX_URL` (`/docex` prod, `:3003` dev) |
```
