# MASTER CONTEXT — DocEX × FRAME Integration

> **Purpose:** Single source of truth so context is never lost across sessions/discussions.
> **Last updated:** 2026-05-31. **Status:** IMPLEMENTED — backend service + full UI port built & verified standalone.
> **Owner:** arpit (arpitdav007@gmail.com). Company environment (UBS-context, per FRAME docs).
> ⚠️ §0–§7 below are the original PLANNING context (2026-05-29). The live build state is in **§R (RESUME HERE)** immediately below — read that first.

---

## §R. ⭐ RESUME HERE — live build state (2026-05-31)

> **🔖 Session bookmark:** Claude Code session ID `b53dea5c-701a-4197-ae78-9ea41f2dfe08`.
> Resume the exact conversation: `claude --resume b53dea5c-701a-4197-ae78-9ea41f2dfe08` (run from `~/Documents/open-notebook`).
> Or start fresh anywhere and say: *"continue Docx — read docs/CONVERSATION_CONTEXT.md §R"*.

Since the planning phase we BUILT it. Two things now exist and are verified:
1. **A new docx backend service** — `docx-platform/services/docx/` (package `docx_app`, FastAPI, port **8002**, 73 routes). NOT the original ON `api/`. Reuses ON's domain logic, adds row-level multi-tenancy (`owner`/`scope`/`notebook`), hybrid retrieval (vector+BM25+RRF+rerank), dev-auth header (`X-Docx-User`) → gateway-JWT in prod, migration runner. **251 tests pass · mypy --strict clean · ruff clean.**
2. **The FULL Open Notebook UI ported** into the Vite federation panel — `docx-platform/frontend/` (port **3003**). ON's shadcn/Tailwind UI **untouched**, only de-Next-ified (Path B(a)). **`tsc --noEmit` clean (168 files) · `vite build` green (remoteEntry + shared react).** 7 screens visually verified standalone vs live ON, 1:1, on real tenant data.

### How to restart everything (services are session-scoped — they stop when the terminal closes)
```bash
# 0. SurrealDB (data store) — verify :8000 is up; if not, start it (root/root, ns/db = docx):
#    surreal start --user root --pass root <storage>   # data persists in ns/db 'docx'
curl -s localhost:8000/health && echo " surreal up"

# 1. Backend (port 8002) — dev-auth, SurrealDB ns/db 'docx'. Runs migrations on boot.
AUTH_MODE=dev SURREAL_URL=ws://localhost:8000/rpc SURREAL_USER=root SURREAL_PASSWORD=root \
  SURREAL_NAMESPACE=docx SURREAL_DATABASE=docx \
  uv run --directory /Users/arpit/Documents/docx-platform/services/docx \
  uvicorn docx_app.main:app --host 127.0.0.1 --port 8002 --log-level warning
#  verify: curl localhost:8002/health/ready ; curl localhost:8002/config ; expect 73 routes in /openapi.json

# 2. Frontend standalone panel (port 3003) — Vite proxies /api/docx → :8002
cd /Users/arpit/Documents/docx-platform/frontend && npx vite --port 3003
#  open http://localhost:3003  → full DocEX UI on the docx backend

# 3. (optional) Live ON reference for visual diffing — open-notebook app at :3000 (+ its api :5055)
```

### Verify the build still green after reopening
```bash
cd /Users/arpit/Documents/docx-platform/frontend && npx tsc --noEmit && npx vite build   # FE
cd /Users/arpit/Documents/docx-platform/services/docx && uv run pytest -q                  # BE (251 tests)
```

### Frontend file map (what was done — see memory `docx-fe-port-status.md`)
- `src/DocxPanel.tsx` — the shell: ErrorBoundary→Theme→Query→I18n→ConnectionGuard→CreateDialogs + internal **MemoryRouter** + route tree. Each ON page renders its OWN `<AppShell>` (source-detail is full-screen) so DocxPanel does NOT wrap routes.
- `src/lib/config.ts` — one fixed `API_BASE='/api/docx'` (no runtime discovery). `src/lib/host-auth.ts` — FRAME passes `getAuthHeaders` → axios interceptor + SSE fetches.
- `vite.config.ts` — `@tailwindcss/vite` + `@`→`./src` alias + federation (`exposes ./DocxPanel`, shared react/react-dom) + `/api/docx`→:8002 proxy. `tsconfig.json` — `@/*` paths, tests excluded from build.
- De-Next-ified via codemod (`/tmp/denext.mjs` — recreate if needed): next/navigation→react-router, next/link/image→Link/`<img>`, next/dynamic→React.lazy, process.env→import.meta.env, NodeJS.Timeout→`ReturnType<typeof setTimeout>`. **Codemod gotcha (fixed):** broad `\brouter\b`→navigate also mangled `react-router-dom`→`react-navigate-dom`.

### What's DONE & verified vs what's NOT (do not downplay)
- ✅ Backend service (251 tests, mypy strict, ruff) — but **NEVER run against real Azure** (embeddings/chat/ask mocked; UI correctly shows "no model" guards).
- ✅ FE port: tsc+build green; 7 screens (notebooks list, **3-col notebook detail**, sources table, ask/search, models, transformations, advanced) render 1:1 vs ON with real tenant data; ON's real states show (SetupBanner "no ENCRYPTION_KEY", model guards).
- ❌ **NOT yet consumed inside FRAME** (the v1 target). FRAME wiring exists in worktree `/Users/arpit/Documents/frame-docx-wiring` (branch `feature/docx-wiring`): `DocxView.tsx` lazy-imports `docx/DocxPanel` + passes `X-Docx-User`. Unverified live.
- ❌ `/settings` main page + source-detail not screenshotted (compile OK).
- ❌ #13 backend deferrals open: `POST /credentials/{id}/register-models`, `GET /sources/{id}/download`, per-request vector-only search override, source-chat SSE streaming.
- 🔸 Polish: logo asset, "AdvancedTools" i18n spacing, bundle code-split (1.2MB expose chunk).

### NEXT STEP (where we paused)
Launch the running **FRAME** app and verify the panel loads as a **federated remote** there (with `X-Docx-User` flowing through) — closing the actual v1 "make it part of FRAME" loop. Then: Azure end-to-end, the 2 unshot screens, #13 deferrals.

### Git state
`docx-platform` is a git repo with **NO commits yet — everything untracked** (work lives on disk). Nothing has been committed; commit only when the user asks.

---

## 0. THE GOAL (in one paragraph)

We are integrating two apps. **FRAME** (the deployed company app) stays the **host**. Inside FRAME's existing **Doc Intelligence** tab, a user uploads a document → it is extracted by **Docling** (already in FRAME, the "docline model") → then we surface **Open Notebook / DocEX** capabilities (chat-with-documents, semantic search, notes) on that extracted content. We are NOT making DocEX the host. The agreed mechanism is **native FRAME UI panel + DocEX backend-as-a-service** (NOT embedding DocEX's Next.js UI). See §5 for the decision and §6 for confirmed answers.

---

## 1. THE TWO PROJECTS

### 1A. DocEX (this repo) — `/Users/arpit/Documents/open-notebook`
- **What it is:** "Open Notebook" — an open-source, privacy-focused Notebook-LM alternative. AI research assistant: upload sources → semantic search → notes → chat-with-sources → (podcasts, removed). **Now rebranded to "DocEX" / "Document Intelligence".**
- **Stack:** Next.js 16 frontend (port 3000) · FastAPI backend `api/` (port 5055) · SurrealDB (port 8000) · `surreal-commands` worker · LangGraph workflows · embeddings/vector search in SurrealDB · multi-provider AI via Esperanto (now restricted to **OpenAI + Azure**).
- **Value lives in the BACKEND:** LangGraph `chat`/`ask` graphs, vector search/embeddings, content ingestion, transformations, notebooks/notes. The Next.js UI is a thin client (≈40+ REST endpoints, OpenAPI at `/docs`).
- **Auth:** simple shared **password** Bearer middleware (default `open-notebook-change-me`). Single-user. **NOT MSAL-compatible** (this is a key integration gap).
- **Git:** on branch **`internal-reuse`** (NOT committed). Main branch is `main`.

### 1B. FRAME — `/Users/arpit/Documents/FRAME_DEPLOYED`
- **What it is:** "FRAME 2.0" (npm `epic-generator` v5; product context "BRP"/UBS requirement engine). An **Epic-generation SPA** that turns docs/notes → structured epics via a 6-stage Azure OpenAI pipeline, with GitLab publish + a **Doc Intelligence** feature.
- **Stack:** React 19 + Vite 6 + TypeScript + Zustand v5 · **module federation** (`@originjs/vite-plugin-federation`, exposes `./App` as `remoteEntry.js`, port 3002) — it is a **REMOTE consumed by a company shell**. Custom Zustand tab router (NO react-router). **MSAL/Entra** auth. Mantine UI + BlockNote editor + Mermaid. UBS theme (red `#E60000`).
- **Backend:** almost none of its own — only the **DocMining (Docling) FastAPI** service (:8000), an **Export** service (:8001, Pandoc/WeasyPrint), a GitLab proxy, and **Azure OpenAI called directly from the browser**. **No database. No user store.**

---

## 2. WORK ALREADY DONE ON DocEX (branch `internal-reuse`)

This was the first phase of the conversation — turning Open Notebook into a clean internal "DocEX". **All verified: backend imports, 139 backend tests pass, frontend tsc clean, 30 frontend tests pass.** Done in 4 phases:

1. **Stopped outbound network calls** — removed the GitHub version-check phone-home (`api/routers/config.py`, deleted `frontend/.../use-version-check.ts`, removed `useVersionCheck()` from dashboard layout). `/api/config` still returns `dbStatus`; no GitHub call.
2. **Restricted AI providers to OpenAI + Azure only** — trimmed provider lists in `open_notebook/ai/connection_tester.py` (TEST_MODELS), `open_notebook/ai/model_discovery.py` (PROVIDER_DISCOVERY_FUNCTIONS), `api/credentials_service.py` (PROVIDER_ENV_CONFIG + PROVIDER_MODALITIES), `frontend/.../settings/api-keys/page.tsx` (4 maps), `.env.example`. Provider is a free-form string in DB; no enum break.
3. **Removed the podcast feature entirely** — deleted ~18 files (backend `open_notebook/podcasts/`, `api/podcast_service.py`, podcast routers, `commands/podcast_commands.py`, frontend `podcasts/` dirs/hooks/types), removed `podcast-creator` dep, fixed `commands/__init__.py` + `api/command_service.py` (repointed `import commands.podcast_commands` → `import commands` so other jobs still register), cleaned podcast i18n keys across 11 locales, removed podcast tests. Orphaned DB tables left inert.
4. **Removed dead external links** (GitHub/Discord/website) from UI + cleaned orphaned i18n keys.

**Rebrand → "DocEX":** name = **DocEX**, tagline = **"Document Intelligence"**. Replaced "Open Notebook" → "DocEX" in all 11 locale files (values only), `layout.tsx` (browser tab `DocEX — Document Intelligence`), `api/main.py` (title/root msg), AppSidebar alt, code docstrings (14 files), added `auth.loginSubtitle` key. The Python package `open_notebook`, class `OpenNotebookError`, and `OPEN_NOTEBOOK_*` env vars were intentionally NOT renamed (identifiers, no spaces). Logo image unchanged (can't generate). 60 markdown docs still say "Open Notebook" (internal only, not swept).

**License note:** MIT obligations only trigger on redistribution; local/internal use needs nothing. LICENSE left in place.

**Ran locally and verified live** (see §7).

---

## 3. FRAME — KEY ASSETS ANALYZED

### 3A. DocMining (Docling) service = the "docline model" — `FRAME_DEPLOYED/backend/docmining/`
- **Production-ready, fully implemented, OFFLINE/airgap-safe** FastAPI + **Docling 2.90**.
- **Endpoints:** `GET /healthz`, `GET /readyz`, `POST /api/v1/documents/convert` (→ markdown), `POST /api/v1/documents/analyze` (→ markdown + outline + tables(HTML/CSV) + metadata).
- **Inputs:** pdf, docx, pptx, xlsx, html/htm, png/jpg/jpeg/tiff/tif, md, txt. **Limits:** 50 MB (413), 180s (504), 300 pages — env-configurable (`DOCMINING_*`).
- **Models bundled (~1.2 GB):** docling-layout-heron, TableFormer (ACCURATE), DocumentFigureClassifier-v2.5, CodeFormulaV2, **RapidOCR** (PP-OCRv4). At `backend/docmining/plugins/`.
- **Offline guarantees:** `enable_remote_services=False` guardrail + `HF_HUB_OFFLINE=1`/`TRANSFORMERS_OFFLINE=1`. Temp files deleted per request.
- **HARD CONSTRAINT:** Docling PDF backends are **NOT thread-safe** → hardcoded `workers=1` + single-thread executor; scale by **processes/pods**, not threads. Image ~4-5 GB; ~2 GB RAM; cold start 30-60s.
- **Key files:** `app/main.py`, `app/services/docling_service.py`, `app/api/v1/documents.py`, `app/core/config.py`, `Dockerfile`.

### 3B. FRAME's Doc Intelligence feature (already built, production-grade)
- **Flow:** upload → `/api/docmining/analyze` (Docling) → **nano lens auto-classifier** (gpt-5-nano) → **3 parallel Azure calls (Summary / Insights / Visuals)** with strict JSON schemas → structured cards + Mermaid diagrams → export **MD / DOCX / PDF / GitLab**.
- **It is single-shot per document** — NO persistent memory, NO cross-document query, NO chat. (This is the gap DocEX fills.)
- **Structure:** `src/components/docIntel/DocIntelView.tsx` (single full-screen view, phase machine empty→uploaded→analyzing→ready), `src/stores/docIntelStore.ts`, `src/services/docIntel/*` (analyzeAction, lensPrompts, schemas, validators). Reached via `uiStore.TabId 'docIntel'` → `ViewRouter` (`src/components/layout/ViewRouter.tsx`) → sidebar (`WorkspaceSidebar.tsx` NAV_ITEMS). BlockNote editing designed but partly read-only today.
- **To append a sibling panel:** add a sub-tab inside `DocIntelView` (recommended), OR a new top-level `TabId` + ViewRouter case + nav item.

### 3C. FRAME's 6-stage AI pipeline (`src/pipeline/`) — context only, NOT the target
- Comprehension → Classification → Structural → Refinement → Mandatory → Validation (two-phase: linear 1-3, iterative 4→5→6 with validation feedback loop). Produces **epics + user stories + Mermaid** (FRAME-specific domain). ~70-80% portable *logic* but output is requirements-artifacts, not research notes. Reusable infra: `src/services/ai/aiClient.ts` (Azure client), `throttler.ts`, externalized prompts. **Not the integration target** unless scope changes.

### 3D. FRAME's own design docs (highest-signal references)
- `docs/plans/2026-04-23-docmining-integration-design.md` + `-ultraplan.md` (22 atomic tasks) + `docs/runbooks/docmining-execution-runbook.md` — the Docling service design/contract.
- `docs/plans/2026-05-08-doc-intelligence-design.md` (+ implementation-plan) — the Doc Intelligence feature.
- `docs/research/docling research.md` — Docling vs Azure DI/Unstructured/LlamaParse evaluation (authoritative).
- `FRAME3 Backend Blueprint_FastAPI_Azure OpenAI_Docling*.md` — production FastAPI + Azure + Docling + Entra reference code.
- `docs/plans/2026-04-26-remote-ready-deployment-design.md` — Helm/Istio/proxy deployment.

---

## 4. INTEGRATION DIRECTION — THE DECISION

**Two directions were compared:**
- **Dir A — DocEX as host** (bring Docling/FRAME into DocEX). ✗ Weaker: DocEX is laptop-side, password-auth, would duplicate FRAME's Doc Intelligence/export/GitLab/Entra.
- **Dir B — FRAME as host** (append Open Notebook into FRAME's Doc Intelligence). ✓ **CHOSEN.** FRAME is the deployed company app, owns MSAL/Entra, already has Docling + Azure + UBS theme + Doc Intelligence.

**Within Dir B, the mechanism (critical):**
- ❌ **B1 — module-federate DocEX's Next.js UI into FRAME:** INFEASIBLE (Vite federation vs Next.js/Webpack incompatible).
- ⚠️ **B2 — iframe DocEX's Next.js UI:** FRAGILE (double login password↔MSAL, CORS, no shared state, theme clash). PoC only, not seamless.
- ✅ **B3 — native FRAME panel + DocEX BACKEND-as-a-service:** **RECOMMENDED & AGREED.** New native FRAME React panel (Mantine/UBS) in Doc Intelligence calls DocEX's FastAPI over HTTP (same pattern FRAME uses for DocMining/Export). **DocEX's Next.js UI is NOT used.**

**Why:** DocEX's value is its BACKEND (chat/search/notebooks/embeddings); its UI is Next.js-locked and easier to rebuild than embed. FRAME's Doc Intelligence is single-shot analysis; **DocEX adds the persistent chat + semantic-search + notebooks layer it lacks.** Keep **Docling as the single extractor** — feed its markdown into DocEX backend as a text source (`POST /sources`), no double-extraction.

**Target architecture:**
```
FRAME (host, Vite/React, MSAL/Entra, UBS theme)
  Doc Intelligence tab
    ├─ [existing] Analysis panel: upload → Docling → 3 lenses → export   (unchanged)
    └─ [NEW] "Explore/Chat" panel (native FRAME React)
          • push Docling markdown → DocEX backend as a Source/Notebook
          • chat-with-document (DocEX /chat/execute)
          • semantic search / ask (/search, /search/ask)
          • notes & transformations (/notes, /sources/{id}/insights)
              │ HTTP (/api/docex/* proxy, MSAL bearer)
              ▼
  DocEX BACKEND as a service (headless, NO Next.js):
  FastAPI :5055 + SurrealDB + surreal-commands worker
  LangGraph chat/ask · embeddings/vector search · notebooks · transformations · Azure
```

---

## 5. CONFIRMED DECISIONS (from user, 2026-05-29)
1. **Scope of DocEX capability to expose:** **FULL** — chat + semantic search + notes (the whole backend, not just "chat with this document").
2. **Running DocEX backend as a service:** **YES, OK** — SurrealDB + DocEX FastAPI + worker as a company service is acceptable.
3. **FRAME's MSAL/Entra:** **LIVE** (real, not MockAuth). → we WILL bridge real Entra tokens; DocEX backend must validate JWT/Entra (replace password middleware).
4. **Knowledge base model (single vs per-user/per-team):** **TO BE DISCUSSED** (user wants a longer conversation on this).
5. **Deployment target (RDP box vs AKS/Istio):** not yet finalized (FRAME's sidecars run in the company env; DocEX would join that pattern). Discuss alongside #4.

---

## 6. KEY TECHNICAL FACTS / CONSTRAINTS (don't forget)
- **Docling = "docline model".** Single extractor. workers=1, not thread-safe, scale by pods. Offline-capable.
- **DocEX auth = password Bearer, single-user, MSAL-incompatible.** Biggest backend change = **swap to Entra/JWT validation** + per-user data isolation. This is the critical path.
- **Don't double-extract:** Docling markdown → DocEX `POST /sources` (type=text/markdown); DocEX's content-core extraction becomes fallback only.
- **DocEX backend is the asset; its Next.js UI is throwaway** for this integration.
- **FRAME integrates backends via Vite proxy + (prod) Istio/ingress** — `/api/docmining`, `/api/export`. Add `/api/docex` the same way.
- **Both use Azure OpenAI** — aligned. DocEX calls Azure via Esperanto/LangChain (Python); FRAME calls Azure from the browser (TS aiClient).
- **DocEX key backend endpoints** to drive the FRAME panel: `POST /sources` (ingest text/markdown), `POST /chat/sessions` + `POST /chat/execute` + `POST /chat/context` (chat), `POST /search` + `POST /search/ask` (search/RAG), `GET/POST /notes` (notes), `GET /sources/{id}/insights` + `POST /sources/{id}/insights` (transformations), `GET/POST /notebooks`.
- **DocEX integration seams (if ever hosting Docling there instead):** extraction at `open_notebook/graphs/source.py:78`; pipeline via transformations (`graphs/transformation.py`) or a new graph. (Not the chosen direction, but recorded.)

---

## 7. LOCAL RUN STATE (DocEX, as last left)
Ran the full DocEX stack locally and verified the rebrand + cleanups live:
- SurrealDB via `docker compose up -d surrealdb` (:8000). API `uv run run_api.py` (:5055). Worker `uv run --env-file .env surreal-commands-worker --import-modules commands`. Frontend `cd frontend && npm run dev` (:3000).
- Created a host-tuned `.env` (`SURREAL_URL=ws://localhost:8000/rpc`, dev encryption key, Azure/OpenAI key slots commented).
- Verified: `/api/config` no GitHub call; migrations ran clean (v14); `/api/credentials/status` shows only openai+azure; podcast routes 404; browser tab "DocEX — Document Intelligence"; login shows DocEX; default auth password `open-notebook-change-me`.
- (These services may not still be running in a later session — restart as above if needed.)

---

## 8. COMPANION DOCUMENTS (already written, in this repo)
- `REUSE_PLAN.md` — the DocEX internal-reuse/cleanup plan (phases 1-4).
- `DOCLING_INTEGRATION_ANALYSIS.md` — first-direction analysis (bringing Docling into DocEX) + FRAME asset deep-dive.
- `INTEGRATION_DIRECTION_ANALYSIS.md` — the honest A-vs-B comparison + recommended B3 architecture (the decision doc).
- `CONVERSATION_CONTEXT.md` — **this file (master context).**

---

## 9. OPEN DISCUSSION TOPICS (next conversation)
1. **Knowledge base design** (the big one): single shared KB vs per-user vs per-team; how uploaded docs map to DocEX **notebooks/sources**; retention; does each FRAME upload create a notebook, or append to one? Cross-document search scope.
2. **Auth bridge specifics:** how FRAME's Entra token is validated by DocEX (validate JWT signature vs introspection); mapping Entra identity → DocEX per-user data; whether to run per-team DocEX instances initially.
3. **Deployment:** AKS/Istio (join FRAME's sidecar pattern) vs simpler; SurrealDB persistence/backups; resource sizing (Docling RAM, SurrealDB storage).
4. **UX in FRAME's Doc Intelligence:** sub-tab vs new top-level tab; what the "Explore/Chat" panel shows; relationship between FRAME's 3 lenses and DocEX chat/notes (avoid overlap/confusion).
5. **Data flow & dedup:** confirm Docling markdown → DocEX source ingestion path; embeddings provider (Azure embeddings in DocEX); model/deployment names shared with FRAME.
6. **Scope/phasing:** MVP first (e.g., chat-with-this-document) then full search+notes+multi-doc KB?

---

## 9B. DESIGN REFERENCES STUDIED (2026-05-29) — see `DESIGN_REFERENCE_VERDICT.md`
Two reference projects were analyzed to choose the best design to model on:
- **`/Users/arpit/Documents/FRAME3_reference`** — production-grade **Python microservices** platform (apparent FRAME 3 backend): FastAPI + `shared/` lib + Celery/Redis + **Neo4j knowledge graph (GraphRAG/DRIFT)** + PostgreSQL + Azure OpenAI + **Bicep + Kustomize k8s** + Workload Identity/Key Vault. Has `ui_service` **API gateway with Entra→LOCAL-JWT token exchange**, `document_processing_service` (Docling+Tika, Celery), `neo4j_ingestion_service` (GraphRAG), `neo4j_retrival_service` (DRIFT: HyDE→primer→followups→aggregate), `neo4j_retrival_mcp_server` (FastMCP for Copilot). **VERDICT: the ARCHITECTURAL north star — model the integration on this.** (Rating ~7.5/10; gaps: no OTel tracing, no service mesh.)
- **`/Users/arpit/Documents/code-reviewer/code-refiner-fix-cleanup`** — enterprise **TypeScript CI tool** (GitLab MR-reviewer + Playwright tester via MCP/Codex). **VERDICT: the ENGINEERING-HYGIENE reference** — copy practices (Zod→Pydantic validation at boundaries, strict typing, semantic-release, hadolint, devcontainer, reusable GitLab CI component templates, cert pinning, fail-fast/fail-open), not its architecture.

### Key updates this produced:
1. **AUTH BRIDGE = SOLVED pattern.** Use FRAME3's gateway + **Entra→short-lived LOCAL JWT exchange**; DocEX/backend validates the **LOCAL JWT** (not MSAL directly). Supersedes the earlier vague "add Entra to DocEX."
2. **KB question is now a 3-way architecture choice (the big open decision):**
   - **K1 — DocEX-as-KB (current plan):** DocEX SurrealDB vector RAG + notebooks/notes/chat behind FRAME. Ready UX, fast/cheap; but introduces **SurrealDB** (not in company stack) and **duplicates** FRAME3's Neo4j knowledge graph.
   - **K2 — FRAME3-aligned KB:** use/extend FRAME3's Neo4j (or LightRAG+pgvector) ingestion+retrieval; keep only DocEX's notebooks/notes/chat UX on top. Company-aligned, one stack; more build.
   - **K3 — Hybrid (FRAME3's own research recommendation):** vector RAG for 80% simple Q&A + graph for cross-doc reasoning; align store to **pgvector/LightRAG**, NOT SurrealDB. (Their research explicitly says drop Microsoft GraphRAG → LightRAG: incremental-update pain + ~6000× token cost.)
   - **Honest lean:** if FRAME3 is the real company trajectory, **K2/K3 (align with FRAME3) is cleaner** than bolting DocEX's SurrealDB onto FRAME — but K1 ships DocEX's working UX fastest. DECIDE IN KB DISCUSSION.
3. **Tenant scoping:** FRAME3 models `IN_PROJECT` on every node → adopt per-project/per-user scoping from day 1 (answers our per-user/per-team question structurally).
4. **Deployment/service conventions to adopt from FRAME3:** `shared/` lib, uniform FastAPI skeleton + `/health`+`/ready`, structlog JSON, pydantic-settings, Celery+Redis→SSE progress, Bicep+Kustomize, Workload Identity, Key Vault CSI.
5. **Optional high-value:** expose the knowledge backend as an **MCP server** (Copilot/agent access) — FRAME3 already does this.

### New open questions for the KB discussion (sharper):
- Is **FRAME3_reference the live company trajectory** or a POC? (Decides K1 vs K2/K3.)
- Do we **accept SurrealDB** in the stack, or must we align with Neo4j/pgvector?
- Do we want DocEX's **backend RAG**, or mainly its **notebooks/notes/chat UX** on a FRAME3-aligned retrieval backend?
- Is **GraphRAG/cross-document reasoning** a real need, or is fast vector Q&A enough?
- Is there a **shared gateway/auth service** (FRAME3 ui_service/authentication_service) we plug into?

---

## 9C. FRAME_4 ANALYZED (2026-05-29) — DEFINITIVE ARCHITECTURE + DIRECTION PIVOT — see `FRAME4_VERDICT_AND_DIRECTION.md`
A 4th project was analyzed: **`/Users/arpit/Desktop/Frame_4`** — and it is **the current, authoritative company architecture** (its foundation doc explicitly synthesizes "FRAME3 reference + code-refiner patterns"). It supersedes FRAME3_reference ("sunset").

**Frame_4 = 3 services + shared lib (uv workspace):**
- `gateway/` — MSAL → **HS256 local JWT** (1h) + **S2S JWT** (5m) → **SSE** fan-out; only service the SPA talks to.
- `core/` — AI orchestrator + Docling doc-processor + retrieval-KG + **in-process FastMCP** + Procrastinate workers; one image, `FRAME_ROLE=api|worker`.
- `delivery/` — GitLab + export (Pandoc DOCX, WeasyPrint PDF).
- `shared/` — FastAPIFactory, BaseConfig (pydantic-settings), structlog, `LocalJWTBearer`, Procrastinate app.

**Hard stack (explicit anti-patterns):** **Procrastinate (Postgres) — NO Redis/Celery EVER**; **Neo4j Community single DB**; **Azure OpenAI only** (Entra+Workload Identity); MSAL only at gateway; tools mechanical, reasoning in LangGraph nodes.

**Knowledge layer (decisive for our KB question):** **Cognee 1.0.9** (document KG: Docling→entities→Neo4j, tenancy `node_set`/`belongs_to_set`, filter `WHERE $pid IN n.belongs_to_set`) + **Graphiti** (temporal **chat memory**, `group_id="project:{pid}:session:{sid}"`, *planned stages 5-6, not yet a dep*); shared embedding **text-embedding-3-large 3072**. Orchestration: Procrastinate dispatches ONE job; **LangGraph 6-stage DAG** (4 & 6 = agent loop + evaluator, max 3 iters → END_DEGRADED).

**8 top-notch patterns to follow:** tool allowlist at bind time · 2-layer idempotency · Neo4j property-filter tenancy · FastAPIFactory · dual-role entrypoint · typed PipelineState · evaluator-as-contract · SKILL.md-injected agents.

**Maturity:** EARLY — Stage-1 slice works (Docling→Cognee→Neo4j tenant-safe query, ~50 tests). Stages 2-6 stubbed; **Graphiti, semantic doc search, conversational chat, notebooks/notes — NOT built yet** (these are exactly DocEX's strengths).

### ⚠️ DIRECTION PIVOT (supersedes earlier K1/B3 lean):
The company's real stack is **Cognee+Graphiti+Neo4j — NOT SurrealDB**. Bolting DocEX's SurrealDB onto FRAME now reads as a **divergent island** that violates Frame_4's own rules. Revised options:
- **D1 — Align with Frame_4 (RECOMMENDED destination):** build chat/notebooks/notes **on Frame_4's stack** (Cognee+Graphiti+Neo4j+LangGraph), exposed via `core` FastMCP + a **native FRAME panel**. **DocEX becomes a UX + logic reference, NOT a deployed service; drop SurrealDB.** Port DocEX's LangGraph chat/ask logic + notebook/notes UX onto Frame_4.
- **D2 — DocEX backend-as-a-service (fast but divergent island):** run DocEX behind FRAME now; throwaway later. Avoid as permanent.
- **D3 — Pragmatic bridge (if chat needed before Frame_4 matures):** use DocEX as a *prototype* to validate UX + harvest chat/ask logic, but commit to building production on Frame_4.

**DocEX's residual value given Frame_4 exists:** (a) a working conversational-RAG product TODAY (Frame_4 has none yet), (b) reusable **LangGraph chat/ask graph logic** as the blueprint for Frame_4's missing conversational layer, (c) notebook/notes/chat **UX** to rebuild natively. **NOT its SurrealDB/infra (now redundant/divergent).**

**Auth question = SETTLED:** adopt Frame_4's gateway pattern (MSAL→HS256 local JWT + S2S JWT; `LocalJWTBearer` downstream).

### New decisive open questions:
- Urgency: need chat-with-docs SOON (→ D3) or can it land with Frame_4 (→ D1)?
- Is Frame_4 funded/staffed as the deploy platform?
- Can we contribute the conversational layer INTO Frame_4 `core/`, or build adjacent?
- Are notebooks/notes first-class (need data model), or is per-document chat enough first?
- Cross-document graph reasoning (Cognee) vs fast vector Q&A — which matters?

---

## 9D. BEST-IN-CLASS ARCHITECTURE (2026 research, 2026-05-29) — see `BEST_ARCHITECTURE_DESIGN.md`
User lifted the "must align with Frame_4 stack" constraint: **"company has no limitation on stack — find the best."** Ran 4 parallel web-research streams (retrieval architecture, GraphRAG libs, stores/embeddings/extraction, memory/orchestration). Verdict:

**The 2026 consensus retrieval core = Hybrid (dense + BM25) + RRF + reranking + contextual chunking + ADAPTIVE/AGENTIC routing.** Add a knowledge graph only SELECTIVELY for multi-hop/cross-doc/global queries. Pure vector RAG = weak baseline; full Microsoft GraphRAG = usually over-engineering.

**Honest challenge to Frame_4:** its skeleton is right, but it makes a **graph-first retrieval bet** (Cognee+Graphiti+Neo4j) and appears to **skip the higher-ROI hybrid+rerank+contextual baseline** — inverting the recommended build order. *(Caveat: FRAME's requirements-traceability domain is a stronger-than-average case for an eventual graph.)*

**Recommended best architecture = keep Frame_4 skeleton, replace retrieval core:**
- KEEP: 3-service shape, gateway MSAL→HS256 JWT, Docling, LangGraph, Procrastinate, in-process FastMCP (per-tenant scoped), AKS/Kustomize. ✅
- CHANGE/ADD: **contextual chunking** (Anthropic, ~49-67% fewer retrieval misses) → embed (text-embedding-3-large or Cohere v4 @768-1024d, Matryoshka) → **hybrid + reranking** (Cohere Rerank 4 on Azure Foundry, or BGE-reranker-v2-m3 offline) → **adaptive/agentic LangGraph router** (simple→hybrid, complex→multi-step verify).
- STORE: **Azure AI Search** (managed hybrid + semantic ranker + multi-tenant high-density; may remove separate reranker; NOT offline) | **pgvector** (already need Postgres; modest scale) | **Qdrant on AKS** (open/offline/scale). NOT Neo4j-for-everything.
- GRAPH: **deferred & selective** — LightRAG or LazyGraphRAG (or Cognee) only when eval shows multi-hop failures. Avoid classic MS GraphRAG.
- MEMORY: **simple first** (Postgres session summary + project facts); Graphiti only if temporal reasoning is a real need; Letta = over-engineering.
- EVAL/OBS: add **Langfuse** (self-host AKS, OTel) + **Ragas in CI** (faithfulness, context recall).
- MCP: thin per-tenant external retrieval server for Copilot.

**Build order (the point):** skeleton → hybrid+rerank+contextual baseline → adaptive/agentic → eval/obs → memory → graph (only if needed) → MCP edge. Frame_4 roughly started at the graph step.

**Implication for Frame_4 vs DocEX:** NEITHER's retrieval core is ideal as-is (Frame_4 graph-first; DocEX vector-only). Both need the hybrid+rerank+contextual middle (new but small work). DocEX reuse = chat/ask LangGraph logic + notebook/notes UX (NOT SurrealDB). Frame_4 reuse = the skeleton.

**New open questions:** offline/air-gapped tenants? query mix (per-doc Q&A vs cross-doc/global)? scale (#docs/tenants/vectors)? build INTO Frame_4 core or fresh core on same skeleton? managed (Azure AI Search/Cohere) vs all-open-on-AKS? temporal memory a real need?

---

## 9E. SYSTEM SHAPE CLARIFIED + DOCX DESIGN (2026-05-29) — see `DOCX_SERVICE_DESIGN.md`
User clarified the platform = **two bounded domains**:
1. **Epic/Issue generation** — ALREADY built in Frame modeling; keep as own service + own Epic-optimized KB. Tenancy = GitLab Groups→Subgroups→Projects→Epics/Issues. Recommend **keep on Neo4j** (existing + traceability traversal + Cognee/GDS ecosystem).
2. **Docx (NEW)** — standalone document-intelligence service, OWN isolated KB, lightweight/scalable/performant, graph-based understanding + node-graph contextual linking/traversal + embeddings. Session uploads → promotable to persistent org KB.

**Separation recommendation:** Docx = standalone microservice + **physically separate data store** from Epic KB; share ONLY gateway(MSAL→JWT)/shared-lib/observability/AKS. Three isolated KBs: Epic, Docx-persistent, Docx-session.

**Graph store verdict — REVISED after proper full-field research (2026-05-29), see `GRAPH_DB_DEEP_DIVE.md` (supersedes earlier SurrealDB lean):**
- **Docx → FalkorDB (lead candidate).** Purpose-built for GraphRAG; GraphBLAS engine; native HNSW vectors (1-4096d); **native multigraph = one isolated graph per tenant OR per session → maps perfectly to the session-KB + promotion design** (session = own graph, promotion = copy nodes/edges to tenant graph); lightest footprint/fastest cold start; **Graphiti backend** (+ Cognee community, GraphRAG-SDK, MCP). Caveats: **SSPL** (fine internal, not for reselling DB); **a single graph must fit one node + no cross-graph queries** (fine for per-tenant; verify largest tenant size); no built-in RRF fusion (DIY in retrieval layer — building agentic layer anyway); young vendor + mostly vendor benchmarks → **run a spike on real data**.
- **Docx → Neo4j (safe fallback / de-risk baseline).** Most mature, **first-class in EVERY GraphRAG framework**, Azure AuraDB managed, **consolidates with existing Epic KB**. Cost: clustering/multi-tenancy = Enterprise; GPLv3 Community single-instance; heavy JVM.
- **Docx → Postgres+AGE+pgvector (lowest-ops alt).** Azure-managed, one backend; good only if graphs modest + traversal shallow (AGE weak on deep multi-hop).
- **SurrealDB DOWNGRADED for Docx:** documented TiKV/3.0 write-load maturity issues (RocksDB compaction stalls) threaten *continuous ingestion*; **no GraphRAG-library support** (full DIY). Only if you want one multi-model engine + accept the risk.
- **Kùzu = OUT** (project ARCHIVED Oct 2025; note Cognee defaults to it → liability).
- **ArcadeDB = niche** (Apache-2.0, built-in RRF hybrid fusion, dense+sparse vectors, HA in core — best features-per-license — BUT tiny community/1 maintainer/no managed cloud/no GraphRAG-lib adoption). Memgraph = multi-tenancy+HA paywalled, no sharding. NebulaGraph/TigerGraph = heavy/enterprise-vector; Dgraph = vendor-tied.
- **Epic/Issue KB → Neo4j (keep, unchanged).**
- **Recommended path:** prototype Docx on **Graphiti + FalkorDB**, keep **Neo4j** as fallback (also Graphiti-compatible), measure per-tenant memory + continuous-ingestion throughput + traversal before committing. **Org-tech-consistency alternative:** all-Neo4j (separate DB per domain).

**Session memory design (refines user's "30 min temp store"):** session = scoped namespace (`session:{id}`), **LIGHTWEIGHT indexing only** (Docling→contextual chunk→embed→vector+BM25+chunk/doc links; NO heavy entity-graph extraction — keeps sessions fast/cheap). Lifecycle = **sliding idle TTL (~30 min) + hard cap + explicit End/Discard** + background sweeper (not flat 30 min). 

**Promotion workflow (session→persistent org KB):** explicit (whole-session or per-doc) → async worker: **re-scope** `session:{id}`→`org:{org_id}` (NO re-embed) + run **HEAVY graph enrichment now** (LLM entity/relationship extraction → node-graph + contextual links) + dedup by doc hash + provenance (Entra identity, timestamp, source session). Key principle: **ephemeral=light, persistent-on-promotion=heavy** → cost/latency stay low; expensive graph built once for kept knowledge.

**Retrieval (both KBs, same pattern):** hybrid (vector+BM25) + rerank + contextual chunking + adaptive/agentic LangGraph routing + citations/faithfulness; graph traversal for multi-hop. Embeddings text-embedding-3-large/Cohere v4 @768-1024d (BGE-M3 offline); reranker Cohere Rerank 4 (Azure) / BGE-v2-m3 (offline). Eval Ragas in CI; obs Langfuse.

**Optional later bridge:** a promoted Docx doc could be linked into Epic KB as a project grounding source — deliberate cross-link, NOT shared storage.

**Open questions to finalize:** Docx scale target; offline/air-gapped tenants?; one-graph-tech-org-wide vs best-fit-per-domain?; session semantics (single-user vs collaborative, size)?; does promoted Docx feed Epic KB?; build Docx fresh on Frame_4 skeleton vs fork DocEX chat/ask logic?

### Epic/Issue stack recommendation (existing Neo4j+Cognee+Graphiti) — see `EPIC_ISSUE_STACK_RECOMMENDATION.md`
- **Neo4j → KEEP** (right tool for epic→issue→requirement→component traceability; deep traversal + GDS; mature; Azure AuraDB; already deployed).
- **Cognee → SCRUTINIZE/SHRINK.** Cognee = unstructured-doc→KG, which is now **Docx's domain** → running doc-KG in BOTH = duplication. Recommend: **Docx owns document intelligence; Epic KB becomes a STRUCTURED Neo4j traceability graph** grounding in past epics/standards + pulling doc context from Docx (bridge). Keep Cognee in Epic only for genuine unstructured-doc ingestion Docx won't cover. **Hygiene: confirm Cognee on Neo4j backend NOT its Kùzu default (Kùzu archived Oct 2025).**
- **Graphiti → KEEP ONLY IF earning its keep** (real temporal/conversational memory need, e.g. epic-authoring agent). Premature for batch epic gen (not even built in Frame_4). Can be the shared memory lib across both domains (runs on Neo4j AND FalkorDB).
- **Don't unify graph engines: best-fit-per-domain = Neo4j (Epic) + FalkorDB (Docx).** All-Neo4j loses Docx's session-multigraph fit; all-FalkorDB churns Epic + loses deep-traversal/GDS.
- **Cross-domain:** one doc-intelligence system (Docx), one structured epic/traceability system (Epic/Neo4j), deliberate Docx→Epic grounding bridge. 
- **To finalize:** what is Cognee actually ingesting (unstructured docs vs structured epic data)? real conversational agent using Graphiti or dormant? doc grounding from Docx or Epic self-contained? Cognee backend Neo4j vs Kùzu? — offered to verify against live Epic/Issue code.

---

## 9F. 🔒 LOCKED DESIGN DECISIONS (Docx / document-intelligence) — 2026-05-30
These are FINAL per the user. Do not re-litigate.
1. **Store for Docx = SurrealDB** (keep Open Notebook's store; NOT FalkorDB). Rationale: user wants Open Notebook's functionality + per-user document KB (Path A = vector-RAG, not heavy GraphRAG). FalkorDB only revisited if deep graph reasoning becomes a real need later.
2. **Reuse Open Notebook** as the basis for Docx (its chat/ask logic + notebook/source/note model on SurrealDB). Build the net-new layers on top (below). NOT its Next.js UI (native FRAME panel) — TBD when we get to UI.
3. **Multi-tenancy = shared DB, row-level scoping** (one SurrealDB, every record tagged `owner`, filter every query; enforce via SurrealDB record permissions). NOT a database-per-user. `owner` comes from Entra/MSAL `sub`/oid via the gateway JWT. (Open Notebook today has NONE of this — it's single shared password, no owner field; this is the core net-new work.)
4. **"Workspace" = Open Notebook's Notebook** (already the container: sources/notes/chat attach via reference/artifact/refers_to edges; chat/search scoped to it). A user can have multiple workspaces (notebooks), all under their `owner`.
5. **🔒 COLLECTIVE COMPANY BRAIN (final, HR-cleared — no confidentiality gating):**
   - **Default: every uploaded document AUTO-ENRICHES the shared/common org KB** (the whole point — collective knowledge grows with every upload).
   - **Default retrieval = the common KB** (users get the big shared picture).
   - **Private/Focus = the opt-in EXCEPTION** for a narrow, non-diluted answer from the user's own/specific docs only.
   - Write default scope = `org-common`; read default scope = `org-common`; Private/Focus narrows to `owner=me`/selected docs.
   - This INVERTS the usual private-by-default; it is intentional and final.
6. **Toggle (read scope):** off = common KB (default, big picture); a Focus/Private mode narrows. (Read scope and write contribution are conceptually two axes, but per the locked model both default to common.)
7. **Retrieval upgrade regardless of store:** hybrid (vector+BM25) + reranking + contextual chunking + adaptive/agentic LangGraph (Open Notebook today is vector-OR-keyword only). Docling extraction (vs content-core). Entra/MSAL→JWT auth at gateway (vs password).
8. **Recommended-but-not-yet-locked hygiene for the common KB** (user leaning yes): dedup by content hash, provenance/citations (who uploaded/when), easy removal/unshare, versioning/recency. "How wide is common" (whole-company vs department-scoped) — still open.

**Sizing note (settled framing):** SurrealDB is disk-based → workspace size bounded by cheap disk, NOT RAM (the FalkorDB RAM ceiling does NOT apply). ~0.5–1 MB/document; 10 workspaces×100 docs ≈ ~1GB/user. Real limits are about retrieval quality + cost + abuse, not a hard wall → guardrails: per-file cap (~50MB), per-user quota, soft per-workspace "getting big, split" nudge. Numbers TBD on scale/usage.

---

## 10. GROUND RULES (user directives)
- **Do NOT implement anything yet.** Analysis & discussion only until explicitly approved.
- Keep this file updated as decisions are made — it is the anti-context-loss anchor.
- Be honest about tradeoffs; prefer the genuinely seamless architecture over the fastest hack.
