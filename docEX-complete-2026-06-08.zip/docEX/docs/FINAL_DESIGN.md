# FINAL DESIGN — FRAME Platform: Epic/Issue + Docx (Collective Company Brain)

**Status:** Consolidated final design. 🔒 = locked by user; ⚠️ = recommended, pending confirmation.

> **⚠️ UI INTEGRATION SUPERSEDED (2026-06-06):** the "native FRAME panel via **Vite Module Federation**" approach below is **dropped**. After taking federation to a live render and hitting the known shared-React-singleton fragility, DocEX now integrates as an **independent same-origin app launched full-screen from FRAME's welcome screen** (iframe overlay + BFF/gateway SSO). See **`2026-06-06-integration-same-origin-launch-design.md`**. Backend, tenancy, and auth (MSAL→JWT) are unchanged.
**Date:** 2026-05-30
**Supersedes / consolidates:** CONVERSATION_CONTEXT.md, DOCX_SERVICE_DESIGN.md, OPEN_NOTEBOOK_AS_DOCX_AUDIT.md, BEST_ARCHITECTURE_DESIGN.md, EPIC_ISSUE_STACK_RECOMMENDATION.md, GRAPH_DB_DEEP_DIVE.md.

---

## 1. What we're building
One platform, two bounded domains + a shared platform layer:
- **Epic/Issue** (exists) — generates structured epics/issues, GitLab-integrated, traceability KB.
- **Docx** (new) — a **collective company-brain** document-intelligence service: upload → understand → chat/search across the org's documents.
- **Shared platform** — gateway/auth, shared lib, orchestration, queue, deploy, observability.

---

## 2. 🔒 Locked decisions
1. **Docx store = SurrealDB** (reuse Open Notebook's store; not FalkorDB). FalkorDB only revisited if deep graph reasoning becomes a real need.
2. **Docx is built on Open Notebook** — reuse its Notebook/Source/Note model + chat/ask LangGraph logic; build the new layers (multi-tenancy, collective brain, hybrid retrieval, sessions, Entra) on top. Not its Next.js UI as-is.
3. **Multi-tenancy = one shared database, row-level scoping** — every record tagged `owner`; every query filtered; enforced in the **application layer** (mandatory scoped queries + a cross-owner leak test). NOT a DB-per-user. `owner` = Entra `sub`/oid from the gateway JWT.
4. **"Workspace" = Open Notebook's Notebook** — the container for sources/notes/chat; a user can have many, all under their `owner`.
5. **🔒 COLLECTIVE COMPANY BRAIN (HR-cleared, no confidentiality gating):**
   - **Default: every uploaded document AUTO-ENRICHES the shared/common org KB.**
   - **Default retrieval = the common KB** (the big shared picture).
   - **Private/Focus = the opt-in exception** → narrow answer over the user's own/specific docs only.
   - Write default scope = `org-common`; read default scope = `org-common`; Private/Focus narrows to `owner=me`/selected.
6. **Epic/Issue store = Neo4j** (keep — traceability traversal + GDS + ecosystem).

## ⚠️ Recommended, pending your confirmation
- **Epic/Issue: shrink/remove Cognee** (Docx owns document intelligence; Epic KB = structured Neo4j graph; keep Cognee only for genuine unstructured-doc ingestion, and on the Neo4j backend not the dead Kùzu default). **Graphiti only if a real conversational/temporal-memory need exists.**
- **Common-KB hygiene:** dedup by content hash, provenance/citations, easy removal/unshare, versioning/recency. (Strongly recommended.)
- **"How wide is common"** — whole-company vs department-scoped. (HR-cleared → whole-company is acceptable; department-scoping optional for relevance.)
- **Retrieval upgrade** (both domains): hybrid (vector+BM25) + reranking + contextual chunking + adaptive/agentic LangGraph (Open Notebook today is vector-OR-keyword only).
- **Docling** extraction (vs content-core). **Entra/MSAL→JWT** auth (vs password). **Native FRAME panel** (vs Next.js UI).

---

## 3. Architecture (target)
```
FRAME React SPA (MSAL)  ──talks only to──▶  GATEWAY
                                              • MSAL → HS256 local JWT (+ S2S JWT, user claims incl. owner/sub)
                                              • SSE fan-out; routes to services
            ┌───────────────────────────────────┴───────────────────────────────────┐
            ▼                                                                         ▼
   EPIC/ISSUE service (exists)                                          DOCX service (new, on Open Notebook)
   • LangGraph epic-gen pipeline                                        • FastAPI (FRAME_ROLE=api|worker)
   • GitLab integration (delivery)                                      • Upload → Docling extract
   • Neo4j (epic→issue→requirement→component traceability)             • Contextual chunk → embed
   • (Cognee → shrink; Graphiti iff needed)                            • Index into SurrealDB (owner + scope tagged)
                                                                       • Retrieval: hybrid(vector+BM25)+rerank
                                                                         + adaptive/agentic LangGraph; citations
                                                                       • Sessions (ephemeral) + promotion
                                                                       • FastMCP (per-tenant) for Copilot
   Shared: shared lib (FastAPIFactory, BaseConfig, structlog, JWT) · LangGraph · Procrastinate(Postgres) ·
           Azure OpenAI · Langfuse + Ragas · AKS + Kustomize + GitLab CI
   Stores: Neo4j (Epic) · SurrealDB (Docx) · Postgres (state + Procrastinate queue)
   Bridge: a promoted Docx doc can be linked into a project's Epic context (deliberate, not shared storage)
```

---

## 3.5 🔒 Hybrid Extraction Routing (LOCKED 2026-05-30)
Two engines behind ONE normalized `extract() → ExtractedDoc{markdown, tables, outline, metadata, engine_used}`.
- **content-core** = in-process (light path). **Docling** = HTTP call to FRAME_DEPLOYED's existing **DocMining** service (quality path — we build nothing).
- **Posture = Docling-first for real document files; content-core for what Docling can't do + as the universal fallback.**

| Input | **Primary** | Fallback |
|---|---|---|
| **.docx / .pptx / .html (file)** | **Docling** | content-core (degraded) |
| **.xlsx / table-heavy Office** | **Docling** | content-core (degraded) |
| **Image (png/jpg/tiff)** | **Docling (OCR)** | clean error |
| **PDF** | **probe** (text layer? table density?): scanned/table-heavy → **Docling**; clean digital → content-core | bidirectional |
| URL / web page | content-core | retry → clean error |
| Audio / video | content-core (transcribe) | clean error |
| .txt / .md | content-core (trivial) | clean error |

**Bidirectional fallback:** content-core → **Docling** on QUALITY failure (low text/empty/error); Docling → **content-core** on AVAILABILITY failure (DocMining down → degraded, flagged, alerted). **Both fail → clean user error; NEVER ingest garbage into the KB.**
**PDF decision = Option B locked** (probe retained: clean digital PDFs use fast content-core; scanned/table-heavy → Docling).

## 3.6 🔒 v1 target & deployment model (LOCKED 2026-05-30)
- **v1 integrates with FRAME_DEPLOYED** (the already-working app: SPA + Doc Intelligence tab + DocMining/Docling + MSAL). **Merge with Frame_4 LATER** (once Frame_4 is finished). Frame_4's gateway/shared skeleton = deferred future-merge scaffolding, **not** used in v1.
- **Epic/Issue** = separate, EXISTING, **IN-PROGRESS** (Neo4j + Cognee + Graphiti) — not in this repo, not finished, **we don't touch it**.
- **Deployment = polyrepo + runtime composition:** Docx is its **own repo, standalone-runnable**, and **wired into FRAME at deploy** via **micro-frontend (Vite Module Federation** panel in the Doc Intelligence tab**) + microservice** (reverse-proxy/ingress route `/api/docx → Docx backend`). Composition at runtime, not build-time coupling.
- **v1 Docx backend** = **adapted Open Notebook** (SurrealDB) + multi-tenancy (`owner` from MSAL) + collective-KB + hybrid extraction; **consumes DocMining markdown** (no re-extract). Defer Frame_4's gateway/Procrastinate to the merge.

---

## 4. Final tech stack
### Shared platform
| Concern | Choice |
|---|---|
| Frontend | FRAME React 19 + Vite + Zustand SPA; native panels; **MSAL/Entra** |
| Gateway | FastAPI; **MSAL → HS256 local JWT + S2S JWT** (carries `owner`/sub); SSE |
| Shared lib | FastAPIFactory · BaseConfig (pydantic-settings) · structlog · JWT utils (LocalJWTBearer) |
| Orchestration | **LangGraph** |
| Async queue | **Procrastinate (Postgres)** — no Redis/Celery |
| LLM | **Azure OpenAI** (Entra + Workload Identity) |
| Embeddings | text-embedding-3-large **or** Cohere Embed v4 @768–1024d (BGE-M3 offline) |
| Reranker | Cohere Rerank 4 (Azure Foundry) / BGE-v2-m3 (offline) |
| Deploy | **AKS + Kustomize + GitLab CI** |
| Obs / eval | **Langfuse** (self-host, OTel) + **Ragas** in CI |
| Relational/state | **Postgres** (app state + Procrastinate) |

### Epic/Issue (existing)
| Concern | Choice |
|---|---|
| Graph store | **Neo4j** (traceability) |
| Doc-KG | Cognee → ⚠️ shrink/remove (Neo4j backend if kept) |
| Memory | Graphiti — ⚠️ only if real temporal need |
| Pipeline | LangGraph epic-gen + GitLab (delivery) |

### Docx (new — built on Open Notebook)
| Concern | Choice |
|---|---|
| Store | **SurrealDB** (vector + records + graph relations; multi-tenant via namespaces + owner tag) |
| Extraction | **Docling** (+ Azure AI Document Intelligence for scans) |
| Retrieval | **hybrid (vector+BM25) + rerank + contextual chunking + adaptive/agentic LangGraph + citations** |
| Tenancy | shared DB, `owner` on every record, app-layer scoped queries + leak test |
| KB model | **collective brain**: default enrich+read common; Private/Focus opt-in |
| Sessions | ephemeral scope, lightweight indexing, sliding TTL + explicit promote/discard |
| Promotion | session→persistent (no re-embed) + (private→)common; dedup + provenance |
| Tools | **FastMCP** (per-tenant scoped) for Copilot/agents |
| Reused | Open Notebook chat/ask logic + notebook/source/note model (not Next.js UI, not password auth, not content-core, not vector-only) |

---

## 5. Multi-tenancy & the collective-brain KB
- **Identity:** user logs in via Entra/MSAL at the gateway → JWT with `sub`/oid → that becomes `owner` on writes and the filter on reads.
- **Scoping fields on every Docx record:** `owner` (the user) + `scope` (`org-common` | `private`) [+ optional `dept`].
- **Write (upload):** default `scope=org-common` → enriches the shared brain. `Private` → `scope=private, owner=me`.
- **Read (ask):** default search `scope=org-common` (big picture). **Focus/Private** → narrow to `owner=me`/selected docs.
- **Enforcement:** APP-LAYER. Every read goes through a mandatory owner/scope predicate (`select_scoped` / `build_scoped_select`), proven by a cross-owner leak test (`tests/test_tenancy_isolation.py`). The service connects to SurrealDB as a SINGLE principal (auth terminates at the gateway), so we do NOT use SurrealDB record permissions — those key on a per-user DB session we don't have. (DB-layer permissions remain a possible future hardening if we ever move to per-user SurrealDB sessions.)
- **Common-KB quality (⚠️ recommended):** content-hash **dedup**, **provenance** (who/when/source doc) surfaced as **citations**, **versioning/recency**, **remove/unshare**.

## 6. Document lifecycle
```
Upload ─▶ Docling extract ─▶ contextual chunk ─▶ embed
       ─▶ index in SurrealDB (owner=me, scope=org-common by default)   ──▶ enriches COMMON KB
       (or scope=private if user chose Private)
Session (optional ephemeral): light index for the live working set; sliding TTL;
       explicit "promote" → persist (and/or move private→common); dedup; provenance.
Ask ─▶ default retrieve over COMMON KB (hybrid+rerank) ─▶ cited answer
    └▶ Focus/Private ─▶ retrieve over own/selected docs only
```

## 7. Workspace sizing (guardrails, not hard walls)
SurrealDB is disk-based → size bounded by cheap disk, not RAM. ~0.5–1 MB/doc; 10 workspaces×100 docs ≈ ~1 GB/user. Real concerns = retrieval quality + cost + abuse. Guardrails: per-file ~50 MB cap; per-user quota; soft per-workspace "getting big — split" nudge; display usage. (Numbers TBD on scale.)

## 8. Auth flow (end-to-end)
`FRAME SPA → (Entra token) → Gateway validates via MSAL → mints HS256 local JWT (+ S2S JWT with owner/sub) → Docx/Epic services validate local JWT (LocalJWTBearer) → owner used for scoping. Azure tokens never on the inter-service wire.`

## 9. What we reuse from each existing project
- **Open Notebook** → Docx base: chat/ask LangGraph logic + Notebook/Source/Note model on SurrealDB.
- **Frame_4** → the platform skeleton: gateway MSAL→JWT, shared lib, Procrastinate, in-process FastMCP, AKS/Kustomize, dual-role container, SKILL.md-injected agents, tool-allowlist discipline.
- **FRAME (deployed)** → host SPA + Docling DocMining service + Epic/Issue domain.
- **code-refiner** → engineering practices (see §11).

---

## 10. Build order (phased; each ends usable)
1. **Skeleton:** gateway (MSAL→JWT) + Docx service (FastAPI/LangGraph/FastMCP) + Procrastinate worker + Postgres + SurrealDB; native FRAME panel calls Docx.
2. **Multi-tenancy:** `owner`/`scope` on models + SurrealDB permissions + JWT wiring.
3. **Retrieval baseline:** Docling → contextual chunk → embed → **hybrid + rerank**; ship chat/search over the common KB.
4. **Collective-brain rules:** default enrich+read common; Private/Focus; dedup + provenance + remove.
5. **Adaptive/agentic + eval/obs:** LangGraph router; Ragas in CI; Langfuse.
6. **Sessions + promotion;** MCP edge for Copilot.
7. **Epic/Issue refinements** (Cognee shrink, optional Docx→Epic bridge).

---

## 11. 🔧 INBUILT ENGINEERING STANDARDS (enforced by construction — not optional)
**Principle:** hygiene is the *path of least resistance* — you get it free by using the shared primitives, and **you cannot merge without passing the gates.** Enforced at four layers:

### Layer A — Shared library (every service inherits automatically)
A service is created via `shared.FastAPIFactory` + `shared.BaseConfig`, which **auto-wire**:
- **structlog JSON logging + correlation-id** on every request (no per-service setup).
- **`/health/live` + `/health/ready`** probes.
- **Fail-fast config validation at boot** — required env/settings validated by pydantic-settings; missing → process won't start.
- **Corporate-CA HTTP client** — `shared.http.client()` returns an httpx client with the **corporate CA mounted**; all outbound calls (Azure OpenAI, GitLab, internal, Docling) MUST go through it. (No raw `httpx`/`requests`.)
- **`LocalJWTBearer`** auth dependency (validates the gateway-minted JWT, exposes `owner`/claims).
- **Result-envelope helpers** (`Ok(data)` / `Err(error)`) + typed exception → HTTP mapping.
- **External-response validation** — shared Pydantic models for Azure OpenAI / Docling / GitLab responses; every external response is parsed through them (schema drift fails loudly).
- **`@fail_open` decorator** for non-critical deps (e.g., reranker down → degrade, don't 500) and `@fail_fast` for critical ones.
- **OTel tracing** auto-instrumented → Langfuse.
- **`@audited` decorator** for sensitive actions (upload/promote/remove) → provenance audit log.

### Layer B — CI/CD (one reusable template; every service `include:`s it — no copy-paste)
A shared `ci/templates/service.yml` runs on every MR and **blocks merge** on failure:
- `ruff check` + `ruff format --check` (lint/format) · `mypy --strict` (types)
- `pytest -x` + **coverage threshold gate**
- **hadolint** (Dockerfile lint) · **secret scan** · **dependency/vuln scan** (pip-audit/trivy)
- **conventional-commit lint** · **Ragas eval gate** (for retrieval-affecting changes)
- on merge → **semantic-release** (version + changelog) → build → push (registry w/ corporate CA) → **Kustomize deploy**

### Layer C — Repo / dev environment
- **pre-commit hooks** (ruff, format, mypy, secret-scan, commit-lint) — same checks as CI, locally.
- **devcontainer** — pinned tools + corporate certs + env; identical for every dev.
- **path-scoped rule files** (`.claude/rules/*` — Frame_4 style) so even AI coding tools follow the conventions.
- **PR template** with a Definition-of-Done checklist; `REVIEWERS.md` / standards doc.

### Layer D — Architectural guardrails (the "anti-patterns", enforced by tests)
- **Every Docx data query MUST be `owner`/`scope`-filtered** — enforced in-app via mandatory `select_scoped()` / `build_scoped_select()` + a cross-owner leak test that fails on an unscoped query (`tests/test_tenancy_isolation.py`).
- **Tools are mechanical adapters; reasoning lives in LangGraph nodes** (no LLM calls inside MCP tools).
- **No secrets in code; no Azure tokens on the inter-service wire; CA via mount only.**
- **Dedup by content hash on ingest;** **provenance + citations** on every common-KB answer.
- **No Redis/Celery** (Procrastinate only); **no DB-per-user** (shared DB + owner scoping).

### Definition of Done (a change isn't "done" until)
lint+types+tests+coverage pass · hadolint+secret+vuln scan pass · external responses validated · owner-scoping test passes · traces/audit present · docs/rules updated · conventional commit · (retrieval changes) Ragas gate passes.

*Net: the six code-refiner gaps (corporate-CA, reusable CI templates, external-response validation, prose/SKILL.md orchestration, result-envelope + fail-fast/open, hadolint/devcontainer/semantic-release) are now **structurally enforced**, plus the architectural guardrails — so they can't silently regress.*

---

## 12. Open items (to finalize)
- Confirm Epic/Issue Cognee/Graphiti fate (verify against live code).
- "How wide is common" — whole-company vs department-scoped.
- Sizing numbers (scale: #users, docs/user, cost ceiling).
- UI: native FRAME panel scope (reuse which Open Notebook screens as reference).
- Confirm common-KB hygiene set (dedup/provenance/remove/versioning).

*No implementation until you approve.*
