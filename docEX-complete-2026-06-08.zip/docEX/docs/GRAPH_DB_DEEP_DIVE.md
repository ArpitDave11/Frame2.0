# Graph + Vector DB — Proper Deep Dive (revises the earlier Neo4j-vs-SurrealDB call)

**Status:** Research-backed. NO code changes. **Supersedes the DB section of `DOCX_SERVICE_DESIGN.md`.**
**Date:** 2026-05-29
**Why this doc exists:** The earlier analysis only weighed Neo4j vs SurrealDB — too narrow. This covers the full field (FalkorDB, ArcadeDB, Memgraph, Kùzu, NebulaGraph, TigerGraph, Dgraph, Postgres+AGE) for the **Docx** standalone GraphRAG service. Caveat up front: most vendor latency/throughput numbers are self-published; the few near-independent benchmarks are flagged.

---

## 0. Revised verdict (the honest correction)

- **FalkorDB is the strongest *technical fit* for Docx** — and its native **multigraph** model (one isolated graph per tenant *or per session*) maps almost perfectly onto your session-KB + promotion design. Lightweight, GraphRAG-native, native HNSW vectors, a Graphiti backend.
- **Neo4j is the safest *default*** — most mature, **first-class in every GraphRAG framework**, managed on Azure (AuraDB Enterprise), and it **consolidates with your existing Epic/Issue KB**.
- **My earlier SurrealDB-for-Docx lean is downgraded.** Two new facts weaken it for *this* use case: (1) documented **distributed/TiKV + 3.0 write-load maturity issues (RocksDB compaction stalls)** — bad for your *continuous session ingestion*; (2) **no GraphRAG-library support** (fully DIY). Still fine as a single-node multi-model store, but not the best pick here.
- **Kùzu is OUT** — the project was **archived in October 2025** (creator team gone; a fork "bighorn" exists but is barely active). Do **not** start new production on it. (Worth knowing because Cognee *defaults* to Kùzu — that default is now a liability.)
- **ArcadeDB** — genuinely the best *features-per-license* (Apache 2.0, built-in RRF hybrid fusion, dense+sparse vectors, HA in core) but **tiny community / one maintainer / no GraphRAG-library adoption / no managed cloud** → niche; don't pick over Neo4j/FalkorDB unless an OSI license is a hard requirement.
- **Memgraph** — fast in-memory, cleanest single-query hybrid, but **multi-tenancy + HA are Enterprise-paywalled**, **no sharding (RAM-bound)**, BSL. Poor fit for cost-sensitive multi-tenant.
- **Postgres + Apache AGE + pgvector** — the "do you even need a graph DB?" option; **managed on Azure**, lowest ops, one backend. Good if graphs are modest and traversal shallow (AGE is weak on deep multi-hop).

**One-line answer to "FalkorDB or ArcadeDB?":** FalkorDB — yes, it should be a top contender (arguably the best fit for Docx). ArcadeDB — interesting but too thin an ecosystem to lead with.

---

## 1. Comparison matrix (Docx lens: lightweight · standalone · multi-tenant · GraphRAG · Azure/AKS)

| DB | Native vector | Hybrid (built-in fusion) | Traversal | Scale / HA | Multi-tenancy | License | Maturity | GraphRAG ecosystem | Footprint |
|---|---|---|---|---|---|---|---|---|---|
| **FalkorDB** | HNSW 1–4096d | DIY (no RRF op) | Strong (GraphBLAS) | shard *by graph*; 1 graph must fit a node; no cross-graph query | **Native multigraph (per-tenant/session)** | **SSPL** | Young ("Assess"); BofA Erica | **Graphiti ✓, Cognee ✓(community), GraphRAG-SDK, MCP** | **Lightest** (~500MB, ~1ms cold) |
| **Neo4j** | Mature HNSW + VECTOR type | Documented | **Best** + GDS algos | clustering/HA = **Enterprise** | multi-DB+RBAC = **Enterprise** | GPLv3 / commercial | **Highest**; Azure AuraDB managed | **Best by far** (Graphiti/Cognee/LightRAG/LlamaIndex/MS-GraphRAG) | Heavy (JVM, ~2.6GB) |
| **SurrealDB** | HNSW/MTREE | DIY in SurrealQL | Moderate (< Neo4j deep) | **TiKV immature; 3.0 write regressions** | **Strong (NS/DB/RBAC)** | BSL 1.1 | Emerging (3.0 GA Feb 2026) | **None** (DIY) | Light (Rust) |
| **ArcadeDB** | dense+sparse, INT8 | **Yes (RRF/DBSF/LINEAR)** | Good (untested at scale) | Raft HA in core | Per-DB (not first-class) | **Apache 2.0** | **Low** (~900★, 1 maintainer) | **None** | Light (embeddable+server) |
| **Memgraph** | Yes (3.2+) | **Yes (Atomic GraphRAG)** | Fast (in-mem) | **no sharding**; HA = Enterprise | **Enterprise-only** | BSL 1.1 | High | LightRAG ✓; LlamaIndex | RAM-bound (~2× data) |
| **Kùzu** | (had it) | (had it) | columnar/analytical | embedded single-node | n/a | MIT | **ARCHIVED Oct 2025** ❌ | Graphiti/Cognee (now risky) | Embedded |
| **NebulaGraph** | **Enterprise-only** | Enterprise | **Excellent (scale)** | native distributed | Enterprise RBAC | Apache(CE)/Ent for vector | High engine, new AI | Vendor-only | Heavy (multi-service) |
| **TigerGraph** | v4.2 HNSW | hnsw_overlap | Excellent (MPP) | distributed | Enterprise | Commercial (free tier) | High | Vendor (CoPilot) | Heavy |
| **Dgraph** | Yes | Partial | Good | distributed | **v25 namespaces** | Apache 2.0 | Medium, vendor-tied (Hypermode) | Low | Medium |
| **Postgres+AGE+pgvector** | pgvector | via extensions | shallow ok; **weak deep** | **Azure-managed HA** | SQL `WHERE tenant_id` | Apache/PostgreSQL | High (Postgres) | LightRAG ✓ (Postgres) | Light (reuses PG) |

---

## 2. Why FalkorDB fits Docx so well (the new insight)
Your Docx design has **ephemeral session graphs + a promoted persistent graph, multi-tenant, lightweight**. FalkorDB's **multigraph topology** models this *directly*:
- Each **session = its own graph key** (cheap to create, cheap to drop on expiry).
- Each **tenant's persistent KB = its own graph key** (hard isolation, no cross-tenant leak).
- **Promotion = copy nodes/edges from `session:{id}` graph → `tenant:{id}` graph** — a clean graph-to-graph operation, not a re-ingest.
- Native **HNSW vectors** on nodes + GraphBLAS traversal in one engine; it's literally marketed as a GraphRAG store, ships a **GraphRAG-SDK + MCP server**, and is a **Graphiti backend** (so you get the temporal-KG library for free if you want it).
- Lightest footprint + fastest cold start of the field → serves "lightweight, standalone, performant."

**The constraints to accept (verify before committing):**
- **SSPL license** — fine for an internal company service; only a problem if you'd resell the DB itself.
- **A single graph must fit in one node's memory; no cross-graph queries.** Perfect for per-tenant/per-session isolation; a problem only if one tenant's graph grows beyond a node (unlikely for doc-intelligence per tenant). Verify your largest-tenant graph size.
- **No built-in RRF hybrid fusion** — you combine vector + full-text in your retrieval layer (you're building the agentic retrieval layer anyway).
- **Young vendor + vendor-sourced benchmarks** — the one semi-independent test had Neo4j ~27% faster/cheaper on *end-to-end* GraphRAG (LLM calls dominate), while FalkorDB was lighter/faster on raw traversal. So **don't believe "500×"; do a spike on your data.**

---

## 3. Recommended decision for Docx
**Lead candidate: FalkorDB. Safe fallback / de-risking baseline: Neo4j. Lowest-ops alternative: Postgres+AGE+pgvector.**

Concretely:
1. **Prototype Docx on Graphiti + FalkorDB** — you get the session/tenant multigraph model + temporal KG library + native vectors with minimal build. Measure: per-tenant memory, **continuous-ingestion throughput**, p50/p99 traversal, recall.
2. **In parallel, keep Neo4j as the fallback** (Graphiti also supports it) — if FalkorDB's single-graph-per-node ceiling or young-vendor risk bites, Neo4j is the proven landing spot, and it's *already your Epic-KB tech* (skills/ops consolidation).
3. **If, after a spike, Docx's graphs turn out shallow/modest** and you'd rather not run another store → **Postgres + AGE + pgvector (Azure-managed)** collapses everything to one managed backend.
4. **Epic/Issue KB stays Neo4j** (unchanged — mature, ecosystem, traceability/GDS).

**Net change from before:** earlier I said "SurrealDB for Docx." Corrected: **FalkorDB (primary) or Neo4j (safe)**; SurrealDB is now a third option only if you specifically want a single multi-model engine and accept its write-load maturity risk + DIY ecosystem.

---

## 4. Honest notes on research quality / sources
- Most performance claims are **vendor-published**; flagged throughout. The most-independent comparison (AIMultiple, single-node) favors FalkorDB on footprint/latency/ingestion; a near-independent FalkorDB-affiliated GraphRAG test favored Neo4j on end-to-end latency/cost. **Therefore: a workload spike on your own documents/tenancy is part of the recommendation, not optional.**
- Ecosystem facts (which DBs are first-class backends for Graphiti/Cognee/LightRAG/LlamaIndex) are the most decision-relevant and are well-corroborated: **Neo4j everywhere; FalkorDB in Graphiti + LlamaIndex (+Cognee community); SurrealDB/ArcadeDB/AGE = DIY.**
- **Kùzu archived Oct 2025** — corroborated by multiple sources; treat as unavailable.

**On tooling for research:** WebSearch + WebFetch were sufficient; Context7 MCP is available for pulling exact DB/library docs when we implement. No additional MCP needed — but if you have an internal benchmarking/data MCP you trust, point me at it and I'll fold it in.

Key sources: FalkorDB docs (multigraph, vector index, KubeBlocks, SSPL); Graphiti backends (Neo4j/FalkorDB/Kùzu/Neptune); AIMultiple graph-DB benchmark; dev.to FalkorDB-vs-Neo4j GraphRAG benchmark; ArcadeDB 26.5.1 + license posts; SurrealDB 3.0 benchmarks + issues #6800/#4697/#4710; Memgraph multi-tenancy/HA licensing; Kùzu archival (theregister/9to5mac); Azure AGE+pgvector posts; Neo4j AuraDB-on-Azure. (Full URLs captured in research logs.)

---

## 5. Open questions that decide it
1. **Largest expected per-tenant graph size?** (FalkorDB's single-graph-per-node ceiling hinges on this.)
2. **Is SSPL acceptable** (internal use → yes; reselling the DB → no)?
3. **Do you want the Graphiti temporal-KG library** (then FalkorDB/Neo4j) or a fully custom graph layer (then SurrealDB/ArcadeDB/AGE are on the table)?
4. **One graph tech org-wide (all-Neo4j) or best-fit-per-domain (FalkorDB Docx + Neo4j Epic)?**
5. **Are Docx graphs deep-multi-hop** (favor FalkorDB/Neo4j) **or shallow** (Postgres+AGE+pgvector may suffice)?

*Recorded in CONVERSATION_CONTEXT.md. No implementation until approved.*
