# Sub-design — Cross-source entity resolution (the Notebook-HLD backbone)

**Status:** proposed (awaiting approval)
**Date:** 2026-06-07
**Parent:** `2026-06-06-diagram-platform-design.md` (§2, §6 — Notebook HLD composition).
**Why this exists:** the parent doc carried "cross-source edges via shared entities" in four words.
A review correctly flagged it as the one piece that is **load-bearing *and* unspecified** — the whole
notebook-HLD value proposition rests on it, and there is **no reference code to copy** (gitdiagram
produces one graph from one repo; it has no cross-graph/entity logic at all). This sub-design closes
that gap before any HLD code is written.

---

## 1. The problem, precisely
Each source's LLD `DiagramGraph` is generated **independently** by the LLM. To draw the notebook HLD's
cross-source edges, `compose.py` must decide, for nodes coming from *different* source graphs, **which
ones denote the same real-world entity.** Two failure modes, both real:

- **Same entity, different labels** (false split): `Customer` vs `Customer Record` vs `CustomerService`
  vs `Client`. Label string-equality misses these → HLD shows *no* cross-source edge where one exists →
  the HLD degrades to a disconnected menu of sources.
- **Different entities, same label** (false merge): two unrelated `Manager` / `Handler` / `Service`
  nodes. Naive normalization merges them → HLD shows a *wrong* edge.

This is classic **entity resolution / record linkage / coreference**. It cannot be solved by string
match alone. The HLD is still *useful* without it (a navigable drill-down **index** of source
diagrams), but cross-source edges are the **differentiator** the user explicitly asked for ("a parent
… statically analyzes all the child diagrams and produces the **complete graph**").

---

## 2. Approaches considered

**A — String/fuzzy normalization only.** Lowercase, singularize, strip common suffixes
(`Service`/`Record`/`Manager`/`Controller`), then match by normalized string + token overlap /
Levenshtein.
- ➕ Zero extra cost, fully deterministic, trivial.
- ➖ Exactly the fragility the review named: misses synonyms (`Customer`↔`Client`), false-merges
  homonyms (two `Manager`s). **Insufficient alone.**

**B — Compose-time reconciliation against a registry (embeddings + LLM adjudication).** Keep a
per-notebook **entity registry**. At compose time, each source node is matched against the registry by
normalization → embedding similarity → and, for ambiguous cases only, an **LLM "same entity?"**
adjudication. Confirmed matches link to the canonical entity; new ones are registered.
- ➕ Handles synonyms (embeddings) **and** homonyms (LLM disambiguation with context); LLM cost only
  on the ambiguous tail.
- ➖ More moving parts; the registry must be stored; LLM in the compose path for hard cases.

**C — Controlled vocabulary at write time (registry-first).** The notebook holds a canonical
vocabulary. When a source LLD is generated, the **existing vocabulary is injected into the prompt**,
and the model is told to **reuse the canonical `entity` id** when it draws the same entity, or coin a
new one (which gets registered). Resolution happens at **write** time → nodes are **born with stable
`entity` ids** → compose becomes a trivial group-by.
- ➕ Cleanest linkage (ids match by construction); compose is pure code; mirrors oh-my-mermaid `@`-refs.
- ➖ Needs the vocabulary to exist as sources are diagrammed (ordering: the first source seeds it);
  re-diagramming must reconcile; relies on the model honoring the instruction; older/frozen diagrams
  pre-date the registry.

### Recommendation — **hybrid C + B + A (layered), C primary.**
- **C is the primary mechanism**: generation reads + writes the registry, so most nodes arrive with a
  correct `entity` id and compose is deterministic.
- **B is the reconciliation fallback** for nodes that arrive **without** a matched `entity` (frozen
  diagrams made before the registry, or the model coining a fresh label for an existing entity):
  normalize (A) → embed → LLM-adjudicate the ambiguous tail.
- **A is the cheap first pass inside B.**
This is precisely "a shared-entity registry **and** a normalization pass," as the review asked — and
it keeps the LLM out of the loop for the common case while still catching synonyms and homonyms.

---

## 3. Data model — the shared-entity registry
```python
notebook_entity {                 # owner-scoped, per notebook
  id, owner, scope,               # tenancy (PRIVATE, like notes/settings)
  notebook_id,
  entity_key:      str,           # stable slug used in DiagramGraphNode.entity, e.g. "customer"
  canonical_label: str,           # "Customer"
  kind:            str | None,    # actor|service|datastore|external|component|... — disambiguates homonyms
  aliases:         list[str],     # ["Client", "Customer Record", "CustomerService"]
  description:     str | None,    # short gloss used for embedding + LLM context
  embedding:       list[float] | None,   # vector of (canonical_label + description); prod only
  source_refs:     list[str],     # source_ids whose accepted graphs reference this entity
  created, updated
}
```
- `DiagramGraphNode.entity` (added in the parent §2) holds an `entity_key`. That is the only change to
  the graph model; everything else hangs off the registry.
- **One registry per notebook.** Entities are **not** shared across notebooks (a notebook is the unit
  of "one brain"); cross-notebook resolution is explicitly out of scope.

---

## 4. Path C — controlled-vocabulary generation (write time)
When generating/refining a **source LLD that belongs to a notebook**, inject the current registry:

> *Known entities in this notebook (reuse the `entity` key + canonical label when your diagram shows
> the same real-world thing; coin a new lowercase-slug key for a genuinely new shared entity):*
> `customer → "Customer" (actor)`, `order-service → "Order Service" (service)`, `orders-db → "Orders DB" (datastore)` …

- The model sets `node.entity = "customer"` for a node it recognizes as the Customer; new shared
  entities get a new slug the model proposes.
- After a source is **accepted**, a cheap post-step **upserts the registry**: new `entity` keys →
  new `notebook_entity` rows; reused keys → append the node's label to `aliases` (dedup) and add the
  `source_id` to `source_refs`. (Embeddings computed here in prod.)
- **Ordering:** the first source in an empty notebook seeds the registry; subsequent sources see it.
  Re-diagramming a source replaces its contribution (old aliases/source_refs for that source are
  recomputed). No global rebuild needed.

This makes the common path **deterministic and LLM-free at compose time** — the model already did the
linking, once, at write time.

---

## 5. Path B — compose-time reconciliation (the fallback)
For any node reaching `compose.py` **without** a registry-matched `entity` (legacy/frozen graphs, or a
fresh label the model didn't link), run the cascade — cheapest first, stop at first confident hit:

1. **Normalize (A):** lowercase; singularize; strip suffixes (`service|record|manager|controller|
   handler|component|module`); collapse whitespace/punctuation. Exact match of the normalized form
   against registry `canonical_label`/`aliases` (also normalized) → **assign** (method=`exact|alias`).
2. **Embedding candidates (B):** cosine of the node's `(label + description)` embedding vs registry
   embeddings → top-K above `τ_high` (auto-accept) / between `τ_low..τ_high` (→ step 3). (Prod only;
   the local hash embedder is lexical, so locally this mostly collapses into step 1 + step 3.)
3. **LLM adjudication (B), ambiguous tail only — batched:** for each uncertain pair,
   > *In this notebook, is "{label}" ({desc}, kind={kind}, from source {A}) the **same architectural
   > entity** as "{canonical}" ({desc}, kind={kind})? Answer `same` / `different` / `uncertain`.*
   `same` → assign + add alias; `different`/`uncertain` → not merged. **Homonyms with a different
   `kind` are never auto-merged** (a `Manager` actor ≠ a `Manager` service) — kind mismatch short-circuits to `different` without spending an LLM call.
4. **No candidate →** it's a **new entity** → create a `notebook_entity` row.

Every assignment records **`{method, confidence}`** (`exact|alias|embedding|llm|new`) so merges are
auditable and reviewable.

---

## 6. Human override (because auto-resolution will be wrong sometimes)
Entity resolution is heuristic; it *will* mis-merge/mis-split occasionally. The registry is therefore
**user-editable**, and this is part of the design, not an afterthought:
- **Merge** two registry entities (pick survivor; aliases + source_refs union).
- **Split** an entity (move selected aliases/source_refs to a new entity).
- **Rename** canonical label / **edit** kind / aliases.
- Manual edits are **sticky** — a later reconciliation pass must not silently undo a human merge/split
  (track a `locked`/`origin:user` flag on those decisions).
This keeps the HLD trustworthy: low-confidence machine guesses are visible and one click to fix.

---

## 7. HLD topology — what the composed graph actually looks like
Two reasonable shapes; **recommend entity-bridged** (it *is* "the complete graph"):

- **(i) Source-centric (simpler):** nodes = sources; an edge between two sources for each shared
  entity (edge label = entity). Drill = into the source LLD. Gets cluttered when many entities are
  shared (parallel edges between the same two sources).
- **(ii) Entity-bridged (recommended):** nodes = **sources** *and* **shared entities** (entities that
  appear in ≥2 sources). Each source connects to the entities it contains; a shared entity thus
  **bridges** the sources that use it. Drill: a **source** node → its LLD (breadcrumb); a **shared
  entity** node → a small "used in: A, B, C" view. This makes cross-source structure a first-class,
  visible thing and reads as one connected graph.
- Singleton entities (in only one source) are **not** promoted to HLD nodes — they live inside the
  source's LLD. Only entities with `len(source_refs) ≥ 2` become bridges, keeping the HLD high-level.

`compose.py` is then: collect accepted child graphs → resolve every node to an `entity_key` (C, else
B) → registry group-by → emit a parent `DiagramGraph` (source nodes with `drill` = child diagram id;
shared-entity bridge nodes with `meta.source_refs`) → hand to the **same custom renderer.** No LLM in
composition except the §5 ambiguous-tail adjudication.

---

## 8. Determinism & immutability interaction
- Reconciliation affects the **HLD only**; it never mutates the **frozen source LLDs** (their `entity`
  fields are part of the frozen JSON).
- The HLD is a **derived view** — it legitimately changes as sources are added/re-diagrammed or the
  registry is edited. That is expected and correct (it's the "live composition").
- If the user **accepts an HLD**, freeze it like any other surface: snapshot `graph_json` **+
  `render_snapshot_svg`** (parent doc §2 immutability decision). A frozen HLD is a point-in-time
  picture; "rebuild" produces a new version rather than mutating the accepted one.

---

## 9. Local testing (honest about the hash embedder)
The local test embedder is a 256-dim **lexical hash** — it will **not** capture `Customer`↔`Client`
semantic similarity. So **locally**, Path B step 2 (embeddings) is weak and resolution leans on
step 1 (normalization) + step 3 (Claude-Sonnet adjudication). This is acceptable for local E2E and is
called out so a missed synonym locally isn't mistaken for a logic bug. Prod uses real embeddings.

### Test matrix (fake embedder + fake/`claude_cli` LLM, deterministic)
| Case | Inputs | Expected |
|---|---|---|
| exact | `Customer` / `Customer` | merge (method=exact) |
| plural | `Order` / `Orders` | merge (singularize) |
| suffix | `Customer` / `CustomerService` (same kind) | merge (suffix strip / alias) |
| synonym | `Customer` / `Client` | merge **only** when embeddings or LLM say `same` |
| homonym | `Manager` (actor) / `Manager` (service) | **split** (kind mismatch → never merge) |
| new | label with no candidate | new `notebook_entity` row |
| controlled-vocab | node born with `entity="customer"` | used directly, **no** reconciliation |
| human merge sticky | user merges A,B; re-run compose | stays merged (locked) |

Plus: `compose.py` topology test (entity-bridged; singletons excluded; source nodes drillable);
registry tenancy (owner-scoped, no cross-owner/cross-notebook leakage); upsert idempotency on
re-accept.

---

## 10. What we explicitly accept (non-goals / risks owned)
- **Not perfect recall/precision.** Auto-resolution is heuristic; the human override (§6) is the
  safety net, and low-confidence merges are surfaced, not hidden.
- **Cross-notebook resolution: out of scope.** Registry is per-notebook.
- **No silent caps.** If reconciliation truncates (top-K candidates, batch limits), it is logged, not
  swallowed — a partially-resolved HLD must not look fully resolved.

## 11. Open questions (to confirm before HLD coding)
1. **HLD topology:** confirm **entity-bridged** (recommended) vs source-centric.
2. **Thresholds `τ_low`/`τ_high`** and the per-notebook LLM-adjudication budget cap (tunable; defaults
   proposed at implementation time).
3. **Singleton promotion rule:** confirm "entity must appear in ≥2 sources to become an HLD bridge."
4. **Where override lives:** a small registry editor in the Notebook HLD view (recommended) vs a
   settings sub-page.

---

## Implementation status (2026-06-07)

Surface 2 (Notebook HLD) ships on **Path B** (compose-time reconciliation): `entities.py`
(registry store), `reconciler.py` (the normalize → embedding → LLM cascade with the
kind-mismatch guard — now fed `node.kind` from `meta.kind` *or* the node's `type`, with a
controlled-`kind` enum added to the graph prompt), and `compose.py` (entity-bridged topology).
The homonym false-bridge (a step-4 slug collision) is fixed and the guard test is no longer xfail.

**Path C (controlled-vocabulary generation) is specified above but NOT yet wired** — it is the
design's *primary, deterministic* mechanism. `entity_registry_rules()` exists, but no
source-generation caller injects a populated `<entity_registry>`, so today every node resolves
through Path B. Wiring Path C means a notebook-scoped source-generation wrapper that threads the
notebook's registry into the graph step (mirroring `repo_pipeline.py`'s thin wrapper over the
frozen `agent.py`). Tracked here as a known follow-up so it is not mistaken for done — Path B
alone yields a correct HLD; Path C will make the common case deterministic + LLM-free.
