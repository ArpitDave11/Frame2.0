/**
 * Issue Refinery — story-point marker parsing + sizing helpers.
 *
 * The refinement stage is instructed to append a machine-readable marker as
 * the final line of `refinedBody`:
 *
 *     <!-- frame:points=5 -->
 *
 * An HTML comment is invisible in rendered GitLab markdown, so even an
 * un-stripped marker is harmless — but we strip it anyway so the published
 * body is clean. This mirrors how the main epic pipeline carries story points
 * inside generated story bodies (`parseUserStories`), keeping one convention.
 *
 * The estimate is snapped to the Fibonacci scale the picker offers. When the
 * model omits the marker, `estimatePointsFallback` derives a deterministic
 * suggestion from the refined body so the user always sees a starting value.
 */

/** Fibonacci point scale offered in the UI and accepted as GitLab weight. */
export const POINT_SCALE = [1, 2, 3, 5, 8, 13, 21] as const;

const MARKER_RE = /<!--\s*frame:points\s*=\s*(\d+)\s*-->/i;

/** Snap an arbitrary positive number to the nearest value on POINT_SCALE. */
export function snapToScale(n: number): number {
  let best = POINT_SCALE[0] as number;
  let bestDist = Math.abs(n - best);
  for (const v of POINT_SCALE) {
    const d = Math.abs(n - v);
    // Ties resolve downward (prefer the smaller estimate).
    if (d < bestDist) {
      best = v;
      bestDist = d;
    }
  }
  return best;
}

/**
 * Extract the story-point marker from a refined body. Returns the snapped
 * point value (or null when absent / unparseable) and the body with the
 * marker line removed and trailing whitespace trimmed.
 */
export function extractPoints(body: string): { points: number | null; body: string } {
  const match = MARKER_RE.exec(body);
  const points = match ? snapToScale(parseInt(match[1]!, 10)) : null;
  const cleaned = body.replace(MARKER_RE, '').replace(/\s+$/, '');
  return { points, body: cleaned };
}

/**
 * Deterministic fallback used when the model omitted the marker. Sizes off
 * two cheap, complexity-correlated signals in the refined body: the number of
 * acceptance-criteria bullets and the overall word count. Intentionally
 * coarse — it only needs to seed an editable suggestion.
 */
export function estimatePointsFallback(refinedBody: string): number {
  const acSection = /##\s*Acceptance Criteria([\s\S]*?)(\n##\s|\s*$)/i.exec(refinedBody);
  const acBullets = acSection
    ? (acSection[1]!.match(/^\s*[-*]\s+/gm) ?? []).length
    : 0;
  const words = refinedBody.trim().split(/\s+/).filter(Boolean).length;

  // Blend: acceptance criteria dominate, word count nudges.
  const raw = acBullets * 1.6 + words / 120;
  return snapToScale(raw < 1 ? 1 : raw);
}
