/**
 * Issue Refinery — Refinement stage runner (R-6).
 *
 * Thin wrapper around `runStageWithRetry`. Stage-specific config:
 *   - schema: RefinementSchema
 *   - temperature: 0.4 (moderate creativity for rewriting)
 *   - no reasoningEffort (default generation)
 */

import type { AIClientConfig } from '@/services/ai/types';
import { buildPrompts } from '../promptAssembly';
import { RefinementSchema } from '../schemas';
import { runStageWithRetry } from '../stageRunner';
import { extractPoints } from '../pointsMarker';
import type { ComprehensionResult, RefinementResult } from '../types';

export async function runRefinement(
  aiConfig: AIClientConfig,
  epicBody: string,
  issueBody: string,
  comprehension: ComprehensionResult,
  /** Pre-formatted sibling digest for relative story-point sizing (optional). */
  siblingsDigest = '',
): Promise<RefinementResult> {
  const { systemPrompt, userPrompt } = buildPrompts('refinement', epicBody, issueBody, {
    comprehension,
    siblings: siblingsDigest,
  });

  const result = await runStageWithRetry({
    stageName: 'issue-refinery:refinement',
    schema: RefinementSchema,
    schemaName: 'RefinementResult',
    aiConfig,
    systemPrompt,
    userPrompt,
    temperature: 0.4,
  });

  // Pull the story-point marker out of the body and clean it up. `points` is
  // null when the model omitted the marker; the action layer applies a
  // deterministic fallback in that case.
  const { points, body } = extractPoints(result.refinedBody);
  return { refinedBody: body, storyPoints: points };
}
