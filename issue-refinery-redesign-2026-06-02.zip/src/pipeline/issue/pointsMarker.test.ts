import { describe, it, expect } from 'vitest';
import {
  POINT_SCALE,
  snapToScale,
  extractPoints,
  estimatePointsFallback,
} from './pointsMarker';

describe('snapToScale', () => {
  it('returns exact scale values unchanged', () => {
    for (const v of POINT_SCALE) expect(snapToScale(v)).toBe(v);
  });

  it('snaps to the nearest Fibonacci value', () => {
    expect(snapToScale(6)).toBe(5);
    expect(snapToScale(7)).toBe(8);
    expect(snapToScale(100)).toBe(21);
    expect(snapToScale(0)).toBe(1);
  });

  it('resolves ties downward (prefers the smaller estimate)', () => {
    // 4 is equidistant from 3 and 5 → smaller wins.
    expect(snapToScale(4)).toBe(3);
  });
});

describe('extractPoints', () => {
  it('parses and strips a trailing marker, snapping the value', () => {
    const body = '## Summary\nDo the thing.\n\n<!-- frame:points=8 -->';
    const { points, body: cleaned } = extractPoints(body);
    expect(points).toBe(8);
    expect(cleaned).toBe('## Summary\nDo the thing.');
    expect(cleaned).not.toContain('frame:points');
  });

  it('snaps an off-scale marker value', () => {
    const { points } = extractPoints('x <!-- frame:points=9 -->');
    expect(points).toBe(8);
  });

  it('tolerates whitespace variations in the marker', () => {
    expect(extractPoints('y <!--frame:points = 13-->').points).toBe(13);
  });

  it('returns null + the unchanged body when no marker is present', () => {
    const body = '## Summary\nNo marker here.';
    const { points, body: cleaned } = extractPoints(body);
    expect(points).toBeNull();
    expect(cleaned).toBe(body);
  });
});

describe('estimatePointsFallback', () => {
  it('returns a small point for a tiny body with few criteria', () => {
    const body = '## Summary\nTiny.\n\n## Acceptance Criteria\n- one thing';
    expect(estimatePointsFallback(body)).toBeLessThanOrEqual(3);
  });

  it('scales up with more acceptance criteria', () => {
    const many = Array.from({ length: 8 }, (_, i) => `- criterion ${i}`).join('\n');
    const body = `## Summary\nBig.\n\n## Acceptance Criteria\n${many}`;
    expect(estimatePointsFallback(body)).toBeGreaterThanOrEqual(8);
  });

  it('always returns a value on the scale', () => {
    expect(POINT_SCALE).toContain(estimatePointsFallback('## Summary\nx'));
  });
});
