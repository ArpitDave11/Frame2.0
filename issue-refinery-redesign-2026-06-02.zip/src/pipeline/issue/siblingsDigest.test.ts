import { describe, it, expect } from 'vitest';
import { buildSiblingsDigest, MAX_SIBLINGS } from './promptAssembly';

describe('buildSiblingsDigest', () => {
  it('formats one line per sibling with iid, title, weight anchor and size hint', () => {
    const out = buildSiblingsDigest([
      { iid: 12, title: 'Tokenize card', weight: 3, description: 'a b c' },
      { iid: 13, title: 'Refund webhook', weight: null, description: '' },
    ]);
    expect(out).toContain('- #12 "Tokenize card" · weight: 3 · ~3w');
    expect(out).toContain('- #13 "Refund webhook" · weight: — · empty');
    expect(out.split('\n')).toHaveLength(2);
  });

  it('truncates long titles', () => {
    const long = 'x'.repeat(120);
    const out = buildSiblingsDigest([{ iid: 1, title: long, weight: 1 }]);
    expect(out).toContain('…');
    expect(out.length).toBeLessThan(long.length + 40);
  });

  it('caps the number of siblings at MAX_SIBLINGS', () => {
    const many = Array.from({ length: MAX_SIBLINGS + 10 }, (_, i) => ({
      iid: i,
      title: `t${i}`,
      weight: null,
    }));
    expect(buildSiblingsDigest(many).split('\n')).toHaveLength(MAX_SIBLINGS);
  });

  it('returns empty string for no siblings', () => {
    expect(buildSiblingsDigest([])).toBe('');
  });
});
