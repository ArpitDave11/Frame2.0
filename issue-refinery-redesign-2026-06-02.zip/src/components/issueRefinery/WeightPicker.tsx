/**
 * Issue Refinery — story-point weight picker (Phase 2).
 *
 * Shows the effective story-point weight as a chip and, on click, an
 * accessible popover of Fibonacci options. FRAME suggests the weight from the
 * refinement stage (sized relative to sibling issues, anchored on their
 * existing GitLab weights); the user can override it before publishing. The
 * chosen value maps to the GitLab issue `weight` on publish.
 *
 * Reads `issueRefineryStore` directly — consistent with the other Issue
 * Refinery components (this feature has no separate action seam to compose).
 */

import React, { useEffect, useId, useRef, useState } from 'react';
import { useIssueRefineryStore } from '@/stores/issueRefineryStore';
import { POINT_SCALE } from '@/pipeline/issue/pointsMarker';
import { ui, chip, bandColors } from './styles';
import { radius, fontSize, fontWeight, font, color, shadow } from '@/theme/tokens';

export const WeightPicker: React.FC = () => {
  const weight = useIssueRefineryStore((s) => s.weight);
  const suggestedWeight = useIssueRefineryStore((s) => s.suggestedWeight);
  const setWeight = useIssueRefineryStore((s) => s.setWeight);

  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);
  const popoverId = useId();

  // Close on outside click + Escape.
  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const accent = bandColors('purple'); // story points share the "estimate" accent
  const hasValue = weight != null;

  return (
    <div ref={rootRef} style={{ position: 'relative' }}>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-controls={open ? popoverId : undefined}
        data-testid="ir-weight-chip"
        aria-label={hasValue ? `Story points: ${weight}. Edit weight.` : 'Set story-point weight'}
        style={{
          ...chip({
            bg: hasValue ? accent.bg : color.white,
            fg: hasValue ? accent.fg : ui.textSubtle,
            border: hasValue ? accent.border : ui.border,
          }),
          cursor: 'pointer',
          gap: 5,
        }}
      >
        <span aria-hidden="true">✦</span>
        {hasValue ? `${weight} SP` : 'Set weight'}
        <span aria-hidden="true" style={{ fontSize: '0.625rem', opacity: 0.7 }}>
          ▾
        </span>
      </button>

      {open && (
        <div
          id={popoverId}
          role="dialog"
          aria-label="Choose story-point weight"
          data-testid="ir-weight-popover"
          style={{
            position: 'absolute',
            top: 'calc(100% + 6px)',
            right: 0,
            zIndex: 20,
            width: 232,
            padding: 14,
            background: color.white,
            border: `1px solid ${ui.border}`,
            borderRadius: radius.lg,
            boxShadow: shadow.lg,
            fontFamily: font.sans,
          }}
        >
          <div
            style={{
              display: 'flex',
              alignItems: 'baseline',
              justifyContent: 'space-between',
              marginBottom: 10,
            }}
          >
            <span
              style={{
                fontSize: '0.6875rem',
                fontWeight: fontWeight.semibold,
                letterSpacing: '0.06em',
                textTransform: 'uppercase',
                color: ui.textFaint,
              }}
            >
              Story points
            </span>
            {suggestedWeight != null && (
              <span style={{ fontSize: fontSize.xs, color: ui.textSubtle }}>
                FRAME suggests <strong style={{ color: accent.fg }}>{suggestedWeight}</strong>
              </span>
            )}
          </div>

          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
            {POINT_SCALE.map((p) => {
              const selected = p === weight;
              const isSuggested = p === suggestedWeight;
              return (
                <button
                  key={p}
                  type="button"
                  onClick={() => {
                    setWeight(p);
                    setOpen(false);
                  }}
                  aria-pressed={selected}
                  data-testid={`ir-weight-option-${p}`}
                  title={isSuggested ? 'FRAME suggestion' : undefined}
                  style={{
                    position: 'relative',
                    minWidth: 40,
                    padding: '8px 0',
                    flex: '1 0 40px',
                    textAlign: 'center',
                    cursor: 'pointer',
                    borderRadius: radius.md,
                    fontFamily: font.sans,
                    fontSize: fontSize.sm,
                    fontWeight: selected ? fontWeight.semibold : fontWeight.normal,
                    background: selected ? accent.fg : color.white,
                    color: selected ? color.white : ui.textPrimary,
                    border: `1px solid ${selected ? accent.fg : isSuggested ? accent.border : ui.border}`,
                  }}
                >
                  {p}
                </button>
              );
            })}
          </div>

          <p
            style={{
              margin: '10px 0 0',
              fontSize: '0.6875rem',
              color: ui.textFaint,
            }}
          >
            Maps to the GitLab issue weight on publish.
          </p>
        </div>
      )}
    </div>
  );
};
