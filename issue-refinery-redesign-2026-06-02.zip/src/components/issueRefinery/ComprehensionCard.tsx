/**
 * Issue Refinery — Comprehension display card (R-11).
 *
 * Renders the output of the Comprehension stage: epicIntent, issueIntent,
 * and three lists (gaps, ambiguities, alignmentNotes). Reads directly from
 * `issueRefineryStore.comprehension`; returns null when the field is null
 * so the parent view doesn't have to gate.
 */

import React from 'react';
import { useIssueRefineryStore } from '@/stores/issueRefineryStore';
import { ui, card, cardHeader, eyebrow, bandColors, type Band } from './styles';
import { radius, fontSize, fontWeight } from '@/theme/tokens';

export const ComprehensionCard: React.FC = () => {
  const comprehension = useIssueRefineryStore((s) => s.comprehension);
  if (comprehension === null) return null;

  const { epicIntent, issueIntent, gaps, ambiguities, alignmentNotes } = comprehension;

  return (
    <section className="ir-card ir-comprehension-card" data-testid="comprehension-card" style={card}>
      <header className="ir-card__header" style={cardHeader}>
        <h3 className="ir-card__title" style={eyebrow}>
          Comprehension
        </h3>
      </header>

      <dl
        className="ir-comprehension-card__intents"
        style={{
          margin: '0 0 16px',
          display: 'grid',
          gridTemplateColumns: 'auto 1fr',
          columnGap: 14,
          rowGap: 8,
          fontSize: fontSize.sm,
        }}
      >
        <dt style={intentTermStyle}>Epic intent</dt>
        <dd style={intentDefStyle}>{epicIntent}</dd>
        <dt style={intentTermStyle}>Issue intent</dt>
        <dd style={intentDefStyle}>{issueIntent}</dd>
      </dl>

      <div style={{ display: 'grid', gap: 12 }}>
        <FindingList
          label="Gaps"
          band="amber"
          items={gaps}
          testIdSuffix="gaps"
          emptyMessage="No gaps identified."
        />
        <FindingList
          label="Ambiguities"
          band="purple"
          items={ambiguities}
          testIdSuffix="ambiguities"
          emptyMessage="No ambiguities identified."
        />
        <FindingList
          label="Alignment notes"
          band="green"
          items={alignmentNotes}
          testIdSuffix="alignment"
          emptyMessage="No alignment notes."
        />
      </div>
    </section>
  );
};

const intentTermStyle: React.CSSProperties = {
  fontWeight: fontWeight.semibold,
  color: ui.textFaint,
  whiteSpace: 'nowrap',
};
const intentDefStyle: React.CSSProperties = {
  margin: 0,
  color: ui.textPrimary,
  lineHeight: 1.5,
};

interface FindingListProps {
  label: string;
  band: Band;
  items: string[];
  testIdSuffix: string;
  emptyMessage: string;
}

const FindingList: React.FC<FindingListProps> = ({
  label,
  band,
  items,
  testIdSuffix,
  emptyMessage,
}) => {
  const c = bandColors(band);
  const empty = items.length === 0;
  return (
    <div className="ir-comprehension-card__group" data-testid={`comprehension-${testIdSuffix}`}>
      <h4
        className="ir-comprehension-card__group-title"
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          margin: '0 0 6px',
          fontSize: fontSize.xs,
          fontWeight: fontWeight.semibold,
          color: ui.textPrimary,
        }}
      >
        <span
          aria-hidden="true"
          style={{
            width: 8,
            height: 8,
            borderRadius: radius.full,
            background: c.fg,
            flexShrink: 0,
          }}
        />
        {label}
        <span
          style={{
            fontSize: '0.625rem',
            fontWeight: fontWeight.medium,
            color: ui.textFaint,
          }}
        >
          {empty ? '0' : items.length}
        </span>
      </h4>
      {empty ? (
        <p
          className="ir-comprehension-card__empty"
          style={{ margin: 0, fontSize: fontSize.xs, color: ui.textFaint, fontStyle: 'italic' }}
        >
          {emptyMessage}
        </p>
      ) : (
        <ul
          className="ir-comprehension-card__items"
          style={{
            listStyle: 'none',
            margin: 0,
            padding: 0,
            display: 'grid',
            gap: 6,
          }}
        >
          {items.map((text, i) => (
            <li
              key={i}
              style={{
                padding: '7px 11px',
                borderRadius: radius.md,
                background: c.bg,
                border: `1px solid ${c.border}`,
                borderLeft: `3px solid ${c.fg}`,
                fontSize: fontSize.sm,
                lineHeight: 1.5,
                color: ui.textPrimary,
              }}
            >
              {text}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};
