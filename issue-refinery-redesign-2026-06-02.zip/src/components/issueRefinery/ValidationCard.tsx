/**
 * Issue Refinery — Validation display card (R-11).
 *
 * Color-coded score badge + findings list, advisory only (per locked
 * decision D6 the UI never gates Publish on the score). Reads directly
 * from `issueRefineryStore.validation`.
 */

import React from 'react';
import { useIssueRefineryStore } from '@/stores/issueRefineryStore';
import {
  ui,
  card,
  cardHeader,
  eyebrow,
  cardSubtitle,
  bandColors,
  type Band,
} from './styles';
import { radius, fontSize, fontWeight, font } from '@/theme/tokens';

type Severity = 'critical' | 'important' | 'nit' | 'unknown';

function parseFindingSeverity(s: string): Severity {
  if (/^\s*\[critical\]/i.test(s)) return 'critical';
  if (/^\s*\[important\]/i.test(s)) return 'important';
  if (/^\s*\[nit\]/i.test(s)) return 'nit';
  return 'unknown';
}

function scoreTier(score: number): 'good' | 'warn' | 'poor' {
  if (score >= 80) return 'good';
  if (score >= 60) return 'warn';
  return 'poor';
}

const TIER_BAND: Record<'good' | 'warn' | 'poor', Band> = {
  good: 'green',
  warn: 'amber',
  poor: 'red',
};

const SEVERITY_BAND: Record<Severity, Band> = {
  critical: 'red',
  important: 'amber',
  nit: 'neutral',
  unknown: 'neutral',
};

const SEVERITY_LABEL: Record<Severity, string> = {
  critical: 'Critical',
  important: 'Important',
  nit: 'Nit',
  unknown: 'Note',
};

export const ValidationCard: React.FC = () => {
  const validation = useIssueRefineryStore((s) => s.validation);
  if (validation === null) return null;

  const tier = scoreTier(validation.score);
  const tierLabel = tier === 'good' ? 'Good' : tier === 'warn' ? 'Fair' : 'Poor';
  const tierColors = bandColors(TIER_BAND[tier]);

  return (
    <section className="ir-card ir-validation-card" data-testid="validation-card" style={card}>
      <header className="ir-card__header" style={cardHeader}>
        <h3 className="ir-card__title" style={eyebrow}>
          Validation
        </h3>
        <span className="ir-card__subtitle" style={cardSubtitle}>
          advisory only
        </span>
      </header>

      <div
        className="ir-validation-card__row"
        style={{ display: 'flex', gap: 18, alignItems: 'flex-start' }}
      >
        <div
          className={`ir-validation-card__score ir-validation-card__score--${tier}`}
          data-testid="validation-score"
          data-tier={tier}
          aria-label={`${tierLabel} quality, score ${validation.score} out of 100`}
          style={{
            flexShrink: 0,
            width: 104,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 2,
            padding: '14px 12px',
            borderRadius: radius.lg,
            background: tierColors.bg,
            color: tierColors.fg,
            border: `1px solid ${tierColors.border}`,
          }}
        >
          <span
            className="ir-validation-card__score-num"
            style={{ fontSize: fontSize['3xl'], fontWeight: fontWeight.semibold, lineHeight: 1 }}
          >
            {validation.score}
          </span>
          <span
            className="ir-validation-card__score-suffix"
            style={{ fontSize: fontSize.xs, opacity: 0.8 }}
          >
            / 100
          </span>
          <span
            className="ir-validation-card__score-tier"
            style={{
              marginTop: 4,
              fontSize: fontSize.xs,
              fontWeight: fontWeight.semibold,
              textTransform: 'uppercase',
              letterSpacing: '0.06em',
            }}
          >
            {tierLabel}
          </span>
        </div>

        <div className="ir-validation-card__findings" style={{ flex: 1, minWidth: 0 }}>
          {validation.findings.length === 0 ? (
            <p
              className="ir-validation-card__empty"
              style={{ margin: 0, fontSize: fontSize.sm, color: ui.textSubtle }}
            >
              No findings — looks clean.
            </p>
          ) : (
            <ul
              className="ir-validation-card__findings-list"
              style={{ listStyle: 'none', margin: 0, padding: 0, display: 'grid', gap: 8 }}
            >
              {validation.findings.map((f, i) => {
                const sev = parseFindingSeverity(f);
                const c = bandColors(SEVERITY_BAND[sev]);
                // Strip the leading [severity] token from the display text since
                // it's now represented by the colored severity tag.
                const text = f.replace(/^\s*\[(critical|important|nit)\]\s*/i, '');
                return (
                  <li
                    key={i}
                    className={`ir-validation-card__finding ir-validation-card__finding--${sev}`}
                    data-severity={sev}
                    data-testid={`validation-finding-${i}`}
                    style={{
                      display: 'flex',
                      gap: 10,
                      alignItems: 'baseline',
                      padding: '8px 12px',
                      borderRadius: radius.md,
                      background: c.bg,
                      border: `1px solid ${c.border}`,
                      fontSize: fontSize.sm,
                      color: ui.textPrimary,
                      lineHeight: 1.5,
                    }}
                  >
                    <span
                      style={{
                        flexShrink: 0,
                        fontFamily: font.sans,
                        fontSize: '0.625rem',
                        fontWeight: fontWeight.semibold,
                        textTransform: 'uppercase',
                        letterSpacing: '0.06em',
                        color: c.fg,
                      }}
                    >
                      {SEVERITY_LABEL[sev]}
                    </span>
                    <span style={{ minWidth: 0 }}>{text}</span>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </div>
    </section>
  );
};
