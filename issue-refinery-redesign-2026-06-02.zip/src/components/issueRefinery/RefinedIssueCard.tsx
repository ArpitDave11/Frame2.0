/**
 * Issue Refinery — Refined-issue side-by-side card (R-12).
 *
 * Two columns: the original GitLab issue body (read-only) on the left, the
 * refined draft (editable textarea) on the right. Editing the right pane
 * calls setRefinedDraft(text, true) — the `userEdited` flag — so the
 * PublishButton can prompt "publish your edited version?".
 *
 * v1 keeps the diff visual minimal: side-by-side panes only, no inline
 * +/- highlighting. A future task can introduce a proper diff library
 * if dogfood shows users want it. The card surfaces a "Reset" affordance
 * so users can revert their inline edits to the model output.
 */

import React from 'react';
import { useIssueRefineryStore } from '@/stores/issueRefineryStore';
import { ui, card, cardHeader, eyebrow, bandColors } from './styles';
import { radius, fontSize, fontWeight, font, color } from '@/theme/tokens';

export const RefinedIssueCard: React.FC = () => {
  const originalBody = useIssueRefineryStore((s) => s.originalBody);
  const refinedDraft = useIssueRefineryStore((s) => s.refinedDraft);
  const userEditedDraft = useIssueRefineryStore((s) => s.userEditedDraft);
  const phase = useIssueRefineryStore((s) => s.phase);
  const setRefinedDraft = useIssueRefineryStore((s) => s.setRefinedDraft);

  if (refinedDraft === null) return null;

  // B-C2: lock the textarea while a re-run pipeline is mid-flight or a
  // publish is in progress. Otherwise an in-flight `setRefinedDraft` (from
  // the orchestrator) could clobber the user's keystrokes silently.
  const editable = phase === 'ready' || phase === 'idle' || phase === 'error';

  const handleEdit = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setRefinedDraft(e.target.value, /* userEdited */ true);
  };

  const editedColors = bandColors('amber');

  return (
    <section className="ir-card ir-refined-card" data-testid="refined-card" style={card}>
      <header className="ir-card__header" style={cardHeader}>
        <h3 className="ir-card__title" style={eyebrow}>
          Refined draft
        </h3>
        {userEditedDraft && (
          <span
            className="ir-card__subtitle ir-card__subtitle--edited"
            data-testid="refined-edited-badge"
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 4,
              padding: '2px 8px',
              borderRadius: radius.full,
              background: editedColors.bg,
              color: editedColors.fg,
              border: `1px solid ${editedColors.border}`,
              fontSize: '0.625rem',
              fontWeight: fontWeight.semibold,
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
            }}
          >
            ● edited
          </span>
        )}
      </header>

      <div
        className="ir-refined-card__panes"
        style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: 14,
          alignItems: 'stretch',
        }}
      >
        <div className="ir-refined-card__pane" data-testid="refined-original" style={paneStyle}>
          <h4 style={paneTitleStyle('original')}>Original</h4>
          <pre
            className="ir-refined-card__pre"
            style={{
              flex: 1,
              margin: 0,
              padding: 12,
              borderRadius: radius.md,
              background: color.neutral50,
              border: `1px solid ${ui.border}`,
              fontFamily: font.mono,
              fontSize: '0.8125rem',
              lineHeight: 1.55,
              color: ui.textSubtle,
              whiteSpace: 'pre-wrap',
              wordBreak: 'break-word',
              overflow: 'auto',
              minHeight: 220,
              maxHeight: 420,
            }}
          >
            {originalBody ?? ''}
          </pre>
        </div>

        <div className="ir-refined-card__pane" data-testid="refined-draft-pane" style={paneStyle}>
          <h4 style={paneTitleStyle('refined')}>Refined</h4>
          <textarea
            className="ir-refined-card__textarea"
            value={refinedDraft}
            onChange={handleEdit}
            readOnly={!editable}
            spellCheck={false}
            data-testid="refined-textarea"
            aria-label={
              editable
                ? 'Refined issue body (editable)'
                : 'Refined issue body (read-only while pipeline is running)'
            }
            style={{
              flex: 1,
              margin: 0,
              padding: 12,
              borderRadius: radius.md,
              background: editable ? color.white : color.neutral50,
              border: `1px solid ${editable ? ui.borderSoft : ui.border}`,
              fontFamily: font.mono,
              fontSize: '0.8125rem',
              lineHeight: 1.55,
              color: ui.textPrimary,
              resize: 'vertical',
              minHeight: 220,
              maxHeight: 420,
              outline: 'none',
            }}
          />
        </div>
      </div>
    </section>
  );
};

const paneStyle: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 6,
  minWidth: 0,
};

function paneTitleStyle(kind: 'original' | 'refined'): React.CSSProperties {
  return {
    display: 'flex',
    alignItems: 'center',
    gap: 6,
    margin: 0,
    fontSize: fontSize.xs,
    fontWeight: fontWeight.semibold,
    textTransform: 'uppercase',
    letterSpacing: '0.05em',
    color: kind === 'refined' ? ui.brand : ui.textFaint,
  };
}
