/**
 * Issue Refinery — top-level tab view (R-14, with deep-review #2 fixes).
 *
 * Composes the Issue Refinery components into a two-pane layout. The
 * gitlab → store bridge is delegated to `bridgeLoadedEpicAction()` in the
 * action layer (Phase B review B-I4) so the view stays presentational.
 *
 * The `bridgedIidRef` is only updated AFTER a successful bridge — addresses
 * B-C1 (retry not blocked on fetch failure).
 */

import React, { useEffect, useRef, useState } from 'react';
import { useGitlabStore } from '@/stores/gitlabStore';
import { useUiStore } from '@/stores/uiStore';
import { useIssueRefineryStore } from '@/stores/issueRefineryStore';
import { refineSelectedIssue, bridgeLoadedEpicAction } from '@/actions/refineIssueAction';
import { ChildIssueList } from './ChildIssueList';
import { ComprehensionCard } from './ComprehensionCard';
import { RefinedIssueCard } from './RefinedIssueCard';
import { ValidationCard } from './ValidationCard';
import { PublishButton } from './PublishButton';
import { WeightPicker } from './WeightPicker';
import { AssigneePicker, IterationPicker } from './AssignmentControls';
import { ui, eyebrow, chip, bandColors, secondaryButton, primaryButton, type Band } from './styles';
import { radius, fontSize, fontWeight, font, color, band } from '@/theme/tokens';

type Phase = ReturnType<typeof useIssueRefineryStore.getState>['phase'];

function phaseStatus(phase: Phase): { label: string; band: Band } {
  switch (phase) {
    case 'comprehending':
    case 'refining':
    case 'validating':
      return { label: 'Refining…', band: 'amber' };
    case 'ready':
      return { label: 'Refined', band: 'green' };
    case 'publishing':
      return { label: 'Publishing…', band: 'amber' };
    case 'error':
      return { label: 'Error', band: 'red' };
    default:
      return { label: 'Not refined', band: 'neutral' };
  }
}

// Pseudo-class states (hover / focus-visible) can't be expressed inline, so
// inject a single token-derived stylesheet for the interactive surfaces.
const INTERACTIVE_CSS = `
.ir-view :focus-visible {
  outline: 2px solid ${ui.brand};
  outline-offset: 2px;
  border-radius: ${radius.sm};
}
.ir-childlist__item-btn:hover { background: ${band.neutralBg} !important; }
.ir-childlist__item-btn--selected:hover { background: ${band.brandTint} !important; }
.ir-refine-btn:hover:not(:disabled),
.ir-childlist__loadbtn:hover:not(:disabled) { background: ${color.neutral50}; }
.ir-publish-btn:hover:not(:disabled) { filter: brightness(0.93); }
.ir-refined-card__textarea:focus { border-color: ${ui.brand} !important; }
`;

export const IssueRefineryView: React.FC = () => {
  const loadedEpicIid = useGitlabStore((s) => s.loadedEpicIid);
  const loadedGroupId = useGitlabStore((s) => s.loadedGroupId);
  const gitlabSelectedEpic = useGitlabStore((s) => s.selectedEpic);

  const irSelectedEpic = useIssueRefineryStore((s) => s.selectedEpic);
  const phase = useIssueRefineryStore((s) => s.phase);
  const selectedChildIid = useIssueRefineryStore((s) => s.selectedChildIid);
  const children = useIssueRefineryStore((s) => s.children);
  const error = useIssueRefineryStore((s) => s.error);
  const publishedUrl = useIssueRefineryStore((s) => s.publishedUrl);

  const openModal = useUiStore((s) => s.openModal);

  const [childrenLoading, setChildrenLoading] = useState(false);

  // Only-bridge-once-per-epic guard. Reset on failure so the user can retry
  // the same epic without first loading a different one (B-C1).
  const bridgedIidRef = useRef<number | null>(null);
  useEffect(() => {
    if (
      loadedEpicIid === null ||
      loadedGroupId === null ||
      gitlabSelectedEpic === null ||
      gitlabSelectedEpic.iid !== loadedEpicIid
    ) {
      return;
    }
    if (bridgedIidRef.current === loadedEpicIid) return;

    let cancelled = false;
    setChildrenLoading(true);
    bridgeLoadedEpicAction(loadedGroupId, loadedEpicIid, gitlabSelectedEpic)
      .then((ok) => {
        if (cancelled) return;
        setChildrenLoading(false);
        // B-C1: only mark this epic as "bridged" if the fetch actually succeeded.
        if (ok) bridgedIidRef.current = loadedEpicIid;
      })
      .catch(() => {
        if (cancelled) return;
        setChildrenLoading(false);
        // Leave bridgedIidRef untouched so the user can retry.
      });

    return () => {
      cancelled = true;
    };
  }, [loadedEpicIid, loadedGroupId, gitlabSelectedEpic]);

  const handleLoadEpic = () => openModal('loadEpic');
  const refining =
    phase === 'comprehending' || phase === 'refining' || phase === 'validating';
  const refineDisabled = selectedChildIid === null || refining || phase === 'publishing';

  const selectedChild =
    selectedChildIid === null ? null : children.find((c) => c.iid === selectedChildIid) ?? null;
  const status = phaseStatus(phase);
  const statusColors = bandColors(status.band);

  return (
    <div
      className="ir-view"
      data-testid="issue-refinery-view"
      style={{
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        minHeight: 0,
        background: ui.pageBg,
        fontFamily: font.sans,
        color: ui.textPrimary,
      }}
    >
      <style>{INTERACTIVE_CSS}</style>

      {/* View header */}
      <div
        style={{
          display: 'flex',
          alignItems: 'baseline',
          gap: 12,
          padding: '16px 24px',
          borderBottom: `1px solid ${ui.border}`,
          background: color.white,
          flexShrink: 0,
        }}
      >
        <h2
          style={{
            margin: 0,
            fontSize: fontSize.lg,
            fontWeight: fontWeight.semibold,
            color: ui.textPrimary,
          }}
        >
          Issue Refinery
        </h2>
        <span style={{ fontSize: fontSize.sm, color: ui.textSubtle }}>
          Refine GitLab issues with FRAME
        </span>
      </div>

      {/* Two-pane body */}
      <div
        className="ir-view__panes"
        style={{ display: 'flex', flex: 1, minHeight: 0, gap: 0 }}
      >
        <aside
          className="ir-view__left"
          style={{
            width: 312,
            flexShrink: 0,
            background: ui.railBg,
            borderRight: `1px solid ${ui.border}`,
            display: 'flex',
            flexDirection: 'column',
            minHeight: 0,
            overflow: 'hidden',
          }}
        >
          {childrenLoading ? (
            <p
              className="ir-view__loading"
              data-testid="ir-children-loading"
              style={{ margin: 0, padding: 20, fontSize: fontSize.sm, color: ui.textSubtle }}
            >
              Loading child issues…
            </p>
          ) : (
            <ChildIssueList onRequestLoadEpic={handleLoadEpic} />
          )}
        </aside>

        <main
          className="ir-view__right"
          style={{ flex: 1, minWidth: 0, overflowY: 'auto', padding: 24 }}
        >
          {irSelectedEpic === null || selectedChildIid === null ? (
            <div
              data-testid="ir-empty-hint"
              className="ir-view__hint"
              style={{
                height: '100%',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 8,
                textAlign: 'center',
                color: ui.textFaint,
              }}
            >
              <span aria-hidden="true" style={{ fontSize: 32, opacity: 0.4 }}>
                ⌖
              </span>
              <p style={{ margin: 0, fontSize: fontSize.base, color: ui.textSubtle }}>
                Select a child issue from the left pane to begin.
              </p>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16, maxWidth: 1080 }}>
              {/* Child workspace header */}
              <header
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 12,
                  flexWrap: 'wrap',
                  paddingBottom: 12,
                  borderBottom: `1px solid ${ui.border}`,
                }}
              >
                <div style={{ minWidth: 0, flex: 1 }}>
                  <div style={{ ...eyebrow, marginBottom: 2 }}>
                    <span style={{ fontFamily: font.mono, color: ui.brand }}>
                      #{selectedChild?.iid ?? selectedChildIid}
                    </span>
                  </div>
                  <h3
                    title={selectedChild?.title}
                    style={{
                      margin: 0,
                      fontSize: fontSize.xl,
                      fontWeight: fontWeight.semibold,
                      lineHeight: 1.3,
                      color: ui.textPrimary,
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                    }}
                  >
                    {selectedChild?.title ?? `Issue #${selectedChildIid}`}
                  </h3>
                </div>

                <span
                  data-testid="ir-status"
                  style={chip({ bg: statusColors.bg, fg: statusColors.fg, border: statusColors.border })}
                >
                  {status.label}
                </span>

                <WeightPicker />
                <AssigneePicker />
                <IterationPicker />

                <div style={{ display: 'flex', gap: 8 }}>
                  <button
                    type="button"
                    onClick={() => void refineSelectedIssue()}
                    disabled={refineDisabled}
                    className="ir-refine-btn"
                    data-testid="refine-btn"
                    data-phase={phase}
                    style={{
                      ...secondaryButton(refineDisabled),
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: 6,
                    }}
                  >
                    <span aria-hidden="true">{refining ? '↻' : '✦'}</span>
                    {refining ? 'Refining…' : phase === 'ready' ? 'Refine again' : 'Refine'}
                  </button>
                  <PublishButton />
                </div>
              </header>

              {publishedUrl && (
                <div
                  data-testid="ir-published-banner"
                  role="status"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 12,
                    padding: '12px 16px',
                    borderRadius: radius.md,
                    background: bandColors('green').bg,
                    border: `1px solid ${bandColors('green').border}`,
                    color: bandColors('green').fg,
                    fontSize: fontSize.sm,
                  }}
                >
                  <span aria-hidden="true" style={{ fontSize: fontSize.base }}>
                    ✓
                  </span>
                  <span style={{ flex: 1, minWidth: 0 }}>
                    Published to GitLab.
                  </span>
                  <a
                    href={publishedUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    data-testid="ir-open-in-gitlab"
                    style={{
                      ...primaryButton(false),
                      textDecoration: 'none',
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: 6,
                    }}
                  >
                    Open #{selectedChild?.iid ?? selectedChildIid} in GitLab
                    <span aria-hidden="true">↗</span>
                  </a>
                </div>
              )}

              <ComprehensionCard />
              <RefinedIssueCard />
              <ValidationCard />

              {error && (
                <p
                  className="ir-view__error"
                  data-testid="ir-error"
                  role="alert"
                  style={{
                    margin: 0,
                    padding: '12px 14px',
                    borderRadius: radius.md,
                    background: bandColors('red').bg,
                    border: `1px solid ${bandColors('red').border}`,
                    color: bandColors('red').fg,
                    fontSize: fontSize.sm,
                  }}
                >
                  {error}
                </p>
              )}
            </div>
          )}
        </main>
      </div>
    </div>
  );
};
