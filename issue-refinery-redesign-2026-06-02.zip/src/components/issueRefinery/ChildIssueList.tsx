/**
 * Issue Refinery — left-pane child issue list (R-10).
 *
 * Displays the currently loaded epic, its direct child issues, and lets the
 * user select one for refinement. Reads from `issueRefineryStore`; does NOT
 * fetch anything itself — the parent view drives epic loading via the
 * existing GitLab patterns and calls `setSelectedEpic` to populate state.
 *
 * Empty states:
 *   - No epic loaded → "Load an epic to begin"
 *   - Epic loaded but no children → "This epic has no child issues"
 */

import React from 'react';
import { useIssueRefineryStore } from '@/stores/issueRefineryStore';
import { ui, eyebrow, secondaryButton, primaryButton } from './styles';
import { radius, fontSize, fontWeight, font, transition, band } from '@/theme/tokens';

export interface ChildIssueListProps {
  /** Optional callback fired when the user clicks "Load epic". */
  onRequestLoadEpic?: () => void;
}

export const ChildIssueList: React.FC<ChildIssueListProps> = ({ onRequestLoadEpic }) => {
  const selectedEpic = useIssueRefineryStore((s) => s.selectedEpic);
  const children = useIssueRefineryStore((s) => s.children);
  const selectedChildIid = useIssueRefineryStore((s) => s.selectedChildIid);
  const setSelectedChild = useIssueRefineryStore((s) => s.setSelectedChild);

  if (selectedEpic === null) {
    return (
      <div
        className="ir-childlist ir-childlist--empty"
        data-testid="childlist-empty"
        style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'flex-start',
          gap: 10,
          padding: 20,
        }}
      >
        <p style={eyebrow}>Issue Refinery</p>
        <p
          className="ir-childlist__hint"
          style={{ margin: 0, fontSize: fontSize.sm, color: ui.textSubtle, lineHeight: 1.5 }}
        >
          Load an epic to refine its child issues.
        </p>
        {onRequestLoadEpic && (
          <button
            type="button"
            onClick={onRequestLoadEpic}
            className="ir-childlist__loadbtn"
            style={{ ...primaryButton(false), marginTop: 4 }}
          >
            Load epic
          </button>
        )}
      </div>
    );
  }

  return (
    <div
      className="ir-childlist"
      data-testid="childlist"
      style={{ display: 'flex', flexDirection: 'column', height: '100%', minHeight: 0 }}
    >
      <header
        className="ir-childlist__header"
        style={{
          padding: '16px 16px 14px',
          borderBottom: `1px solid ${ui.border}`,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
          <span
            className="ir-childlist__epic-iid"
            style={{
              fontFamily: font.mono,
              fontSize: fontSize.xs,
              fontWeight: fontWeight.medium,
              color: ui.brand,
            }}
          >
            &amp;{selectedEpic.epicIid}
          </span>
          {onRequestLoadEpic && (
            <button
              type="button"
              onClick={onRequestLoadEpic}
              className="ir-childlist__loadbtn"
              style={{ ...secondaryButton(false), marginLeft: 'auto', padding: '5px 12px' }}
            >
              Change
            </button>
          )}
        </div>
        <h3
          className="ir-childlist__epic-title"
          title={selectedEpic.title}
          style={{
            margin: 0,
            fontSize: fontSize.base,
            fontWeight: fontWeight.semibold,
            color: ui.textPrimary,
            lineHeight: 1.35,
          }}
        >
          {selectedEpic.title}
        </h3>
      </header>

      {children.length === 0 ? (
        <p
          className="ir-childlist__hint"
          data-testid="childlist-no-children"
          style={{ margin: 0, padding: 20, fontSize: fontSize.sm, color: ui.textSubtle }}
        >
          This epic has no child issues.
        </p>
      ) : (
        <>
          <div
            style={{
              padding: '10px 16px 4px',
              ...eyebrow,
              fontSize: '0.625rem',
            }}
          >
            {children.length} child {children.length === 1 ? 'issue' : 'issues'}
          </div>
          <ul
            className="ir-childlist__items"
            role="radiogroup"
            aria-label="Child issues"
            style={{
              listStyle: 'none',
              margin: 0,
              padding: '4px 10px 12px',
              display: 'grid',
              gap: 4,
              overflowY: 'auto',
              minHeight: 0,
            }}
            onKeyDown={(e) => {
              // B-I1: WAI-ARIA radio pattern — Up/Down/Home/End move selection.
              if (children.length === 0) return;
              const currentIdx = children.findIndex((c) => c.iid === selectedChildIid);
              let nextIdx = currentIdx;
              switch (e.key) {
                case 'ArrowDown':
                case 'ArrowRight':
                  nextIdx = currentIdx < 0 ? 0 : (currentIdx + 1) % children.length;
                  e.preventDefault();
                  break;
                case 'ArrowUp':
                case 'ArrowLeft':
                  nextIdx =
                    currentIdx < 0
                      ? children.length - 1
                      : (currentIdx - 1 + children.length) % children.length;
                  e.preventDefault();
                  break;
                case 'Home':
                  nextIdx = 0;
                  e.preventDefault();
                  break;
                case 'End':
                  nextIdx = children.length - 1;
                  e.preventDefault();
                  break;
                default:
                  return;
              }
              const next = children[nextIdx];
              if (next) setSelectedChild(next.iid);
            }}
          >
            {children.map((c) => {
              const selected = c.iid === selectedChildIid;
              // Only the selected radio (or first, when nothing selected) gets
              // tabindex=0 per ARIA radiogroup pattern.
              const focusable =
                selected || (selectedChildIid === null && c.iid === children[0]?.iid);
              return (
                <li key={c.id} className="ir-childlist__item" style={{ listStyle: 'none' }}>
                  <button
                    type="button"
                    role="radio"
                    aria-checked={selected}
                    tabIndex={focusable ? 0 : -1}
                    onClick={() => setSelectedChild(c.iid)}
                    className={`ir-childlist__item-btn${selected ? ' ir-childlist__item-btn--selected' : ''}`}
                    data-testid={`childlist-item-${c.iid}`}
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      gap: 3,
                      width: '100%',
                      textAlign: 'left',
                      padding: '9px 11px',
                      borderRadius: radius.md,
                      cursor: 'pointer',
                      background: selected ? band.brandTint : 'transparent',
                      border: `1px solid ${selected ? ui.brand : 'transparent'}`,
                      borderLeft: `3px solid ${selected ? ui.brand : 'transparent'}`,
                      transition: transition.colors,
                      fontFamily: font.sans,
                    }}
                  >
                    <span
                      className="ir-childlist__item-iid"
                      style={{
                        fontFamily: font.mono,
                        fontSize: '0.6875rem',
                        fontWeight: fontWeight.medium,
                        color: selected ? ui.brand : ui.textFaint,
                      }}
                    >
                      #{c.iid}
                    </span>
                    <span
                      className="ir-childlist__item-title"
                      style={{
                        fontSize: fontSize.sm,
                        fontWeight: selected ? fontWeight.medium : fontWeight.normal,
                        color: ui.textPrimary,
                        lineHeight: 1.4,
                      }}
                    >
                      {c.title}
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        </>
      )}
    </div>
  );
};
