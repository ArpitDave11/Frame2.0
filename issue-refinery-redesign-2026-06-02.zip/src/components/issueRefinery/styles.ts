/**
 * Issue Refinery — shared inline-style fragments (FRAME design tokens).
 *
 * The Issue Refinery components were originally shipped with `ir-*` class
 * names that had no CSS defined anywhere, so they rendered as raw unstyled
 * HTML. This module replaces that with token-driven inline styles so the
 * surface matches the FRAME / UBS design language (Frutiger, UBS gray ramp,
 * red brand accent) and the approved Figma redesign.
 *
 * Everything here is derived from `@/theme/tokens` — no ad-hoc hex. Severity
 * / finding accents come from the `band` palette.
 */

import type { CSSProperties } from 'react';
import {
  color,
  cssVar,
  radius,
  shadow,
  font,
  fontSize,
  fontWeight,
  transition,
  band,
} from '@/theme/tokens';

export const ui = {
  pageBg: color.neutral50,
  cardBg: color.white,
  railBg: color.white,
  border: color.neutral200,
  borderSoft: cssVar.colBorderIllustrative,
  textPrimary: cssVar.colTextPrimary,
  textSubtle: cssVar.colTextSubtle,
  textFaint: color.grayIII,
  brand: color.red,
  mono: font.mono,
  sans: font.sans,
} as const;

/** Uppercase tracked eyebrow used for section / card titles. */
export const eyebrow: CSSProperties = {
  margin: 0,
  fontFamily: font.sans,
  fontSize: '0.6875rem', // 11px
  fontWeight: fontWeight.semibold,
  letterSpacing: '0.08em',
  textTransform: 'uppercase',
  color: ui.textFaint,
};

export const card: CSSProperties = {
  background: ui.cardBg,
  border: `1px solid ${ui.border}`,
  borderRadius: radius.lg,
  boxShadow: shadow.sm,
  padding: '18px 20px',
  fontFamily: font.sans,
  color: ui.textPrimary,
};

export const cardHeader: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 10,
  marginBottom: 14,
};

export const cardSubtitle: CSSProperties = {
  fontFamily: font.sans,
  fontSize: fontSize.xs,
  fontWeight: fontWeight.normal,
  color: ui.textFaint,
};

/** Generic pill / chip. */
export function chip(opts: {
  bg: string;
  fg: string;
  border?: string;
}): CSSProperties {
  return {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 6,
    padding: '3px 10px',
    borderRadius: radius.full,
    background: opts.bg,
    color: opts.fg,
    border: `1px solid ${opts.border ?? 'transparent'}`,
    fontFamily: font.sans,
    fontSize: fontSize.xs,
    fontWeight: fontWeight.medium,
    lineHeight: 1.4,
    whiteSpace: 'nowrap',
  };
}

export type Band = 'green' | 'amber' | 'red' | 'purple' | 'neutral';

/** bg / text / border triple for a semantic band. */
export function bandColors(b: Band): { bg: string; fg: string; border: string } {
  switch (b) {
    case 'green':
      return { bg: band.greenBg, fg: band.greenText, border: band.greenBorder };
    case 'amber':
      return { bg: band.amberBg, fg: band.amberText, border: band.amberBorder };
    case 'red':
      return { bg: band.redBg, fg: band.redText, border: band.redBorder };
    case 'purple':
      return { bg: band.purpleBg, fg: band.purpleText, border: band.purpleBorder };
    default:
      return { bg: band.neutralBg, fg: band.neutralText, border: band.neutralBorder };
  }
}

/** Primary (filled red) button. */
export function primaryButton(disabled: boolean): CSSProperties {
  return {
    appearance: 'none',
    border: 'none',
    borderRadius: radius.button,
    padding: '9px 18px',
    fontFamily: font.sans,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.medium,
    cursor: disabled ? 'not-allowed' : 'pointer',
    background: disabled ? color.grayI : ui.brand,
    color: disabled ? ui.textFaint : color.white,
    opacity: disabled ? 0.85 : 1,
    transition: transition.colors,
  };
}

/** Secondary (outline) button. */
export function secondaryButton(disabled: boolean): CSSProperties {
  return {
    appearance: 'none',
    borderRadius: radius.button,
    padding: '9px 16px',
    fontFamily: font.sans,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.medium,
    cursor: disabled ? 'not-allowed' : 'pointer',
    background: color.white,
    color: disabled ? ui.textFaint : ui.textPrimary,
    border: `1px solid ${ui.border}`,
    opacity: disabled ? 0.6 : 1,
    transition: transition.colors,
  };
}
