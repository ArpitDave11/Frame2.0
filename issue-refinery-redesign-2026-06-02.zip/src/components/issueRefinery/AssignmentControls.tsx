/**
 * Issue Refinery — assignee + iteration pickers (Phase 2).
 *
 * Two chip-and-popover controls in the child workspace header. Candidates are
 * loaded lazily the first time each control opens (so they never perturb the
 * refine/publish request sequence). Selection is stored on
 * `issueRefineryStore`; the publish action sends the assignee via
 * `assignee_ids` and the iteration via the `/iteration` quick-action note.
 *
 * Read the store directly — consistent with the other Issue Refinery
 * components.
 */

import React, { useEffect, useId, useRef, useState } from 'react';
import { useIssueRefineryStore } from '@/stores/issueRefineryStore';
import { loadAssigneeCandidates, loadIterationCandidates } from '@/actions/refineIssueAction';
import type { GitLabUser, GitLabIteration } from '@/services/gitlab/types';
import { ui, chip, bandColors } from './styles';
import { radius, fontSize, fontWeight, font, color, shadow } from '@/theme/tokens';

// ─── Shared popover primitive ───────────────────────────────────────

interface PopoverProps {
  ariaLabel: string;
  testid: string;
  /** Trigger chip rendered content + style. */
  trigger: React.ReactNode;
  triggerStyle: React.CSSProperties;
  triggerLabel: string;
  /** Called the first time the popover opens (lazy candidate load). */
  onOpen?: () => void;
  children: (close: () => void) => React.ReactNode;
}

const Popover: React.FC<PopoverProps> = ({
  ariaLabel,
  testid,
  trigger,
  triggerStyle,
  triggerLabel,
  onOpen,
  children,
}) => {
  const [open, setOpen] = useState(false);
  const openedOnce = useRef(false);
  const rootRef = useRef<HTMLDivElement>(null);
  const panelId = useId();

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const toggle = () => {
    setOpen((o) => {
      const next = !o;
      if (next && !openedOnce.current) {
        openedOnce.current = true;
        onOpen?.();
      }
      return next;
    });
  };

  return (
    <div ref={rootRef} style={{ position: 'relative' }}>
      <button
        type="button"
        onClick={toggle}
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-controls={open ? panelId : undefined}
        aria-label={triggerLabel}
        data-testid={testid}
        style={{ ...triggerStyle, cursor: 'pointer', gap: 5 }}
      >
        {trigger}
        <span aria-hidden="true" style={{ fontSize: '0.625rem', opacity: 0.7 }}>
          ▾
        </span>
      </button>
      {open && (
        <div
          id={panelId}
          role="dialog"
          aria-label={ariaLabel}
          data-testid={`${testid}-popover`}
          style={{
            position: 'absolute',
            top: 'calc(100% + 6px)',
            right: 0,
            zIndex: 20,
            width: 248,
            maxHeight: 320,
            overflowY: 'auto',
            padding: 8,
            background: color.white,
            border: `1px solid ${ui.border}`,
            borderRadius: radius.lg,
            boxShadow: shadow.lg,
            fontFamily: font.sans,
          }}
        >
          {children(() => setOpen(false))}
        </div>
      )}
    </div>
  );
};

const optionStyle = (selected: boolean): React.CSSProperties => ({
  display: 'flex',
  alignItems: 'center',
  gap: 8,
  width: '100%',
  textAlign: 'left',
  padding: '8px 10px',
  borderRadius: radius.md,
  cursor: 'pointer',
  background: selected ? bandColors('neutral').bg : color.white,
  border: `1px solid ${selected ? ui.border : 'transparent'}`,
  fontFamily: font.sans,
  fontSize: fontSize.sm,
  color: ui.textPrimary,
});

// ─── Assignee ───────────────────────────────────────────────────────

function initials(name: string): string {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]!.toUpperCase())
    .join('');
}

const Avatar: React.FC<{ name: string }> = ({ name }) => (
  <span
    aria-hidden="true"
    style={{
      flexShrink: 0,
      width: 20,
      height: 20,
      borderRadius: radius.full,
      background: ui.brand,
      color: color.white,
      fontSize: '0.625rem',
      fontWeight: fontWeight.semibold,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
    }}
  >
    {initials(name)}
  </span>
);

export const AssigneePicker: React.FC = () => {
  const assignee = useIssueRefineryStore((s) => s.assignee);
  const candidates = useIssueRefineryStore((s) => s.memberCandidates);
  const setAssignee = useIssueRefineryStore((s) => s.setAssignee);

  const has = assignee != null;

  return (
    <Popover
      ariaLabel="Choose assignee"
      testid="ir-assignee-chip"
      onOpen={() => void loadAssigneeCandidates()}
      triggerLabel={has ? `Assignee: ${assignee!.name}. Change assignee.` : 'Assign issue'}
      triggerStyle={chip({
        bg: has ? color.white : color.white,
        fg: has ? ui.textPrimary : ui.textSubtle,
        border: ui.border,
      })}
      trigger={
        has ? (
          <>
            <Avatar name={assignee!.name} />
            {assignee!.name}
          </>
        ) : (
          <>
            <span aria-hidden="true">＋</span> Assign
          </>
        )
      }
    >
      {(close) => (
        <>
          <button
            type="button"
            data-testid="ir-assignee-option-none"
            onClick={() => {
              setAssignee(null);
              close();
            }}
            style={optionStyle(!has)}
          >
            <span aria-hidden="true" style={{ color: ui.textFaint }}>
              ⊘
            </span>
            Unassigned
          </button>
          {candidates.length === 0 ? (
            <p style={{ margin: 0, padding: '8px 10px', fontSize: fontSize.xs, color: ui.textFaint }}>
              No members found.
            </p>
          ) : (
            candidates.map((u: GitLabUser) => {
              const selected = assignee?.id === u.id;
              return (
                <button
                  key={u.id}
                  type="button"
                  data-testid={`ir-assignee-option-${u.id}`}
                  onClick={() => {
                    setAssignee(u);
                    close();
                  }}
                  style={optionStyle(selected)}
                >
                  <Avatar name={u.name} />
                  <span style={{ minWidth: 0 }}>
                    <span style={{ display: 'block', fontWeight: selected ? fontWeight.medium : fontWeight.normal }}>
                      {u.name}
                    </span>
                    <span style={{ display: 'block', fontSize: '0.6875rem', color: ui.textFaint }}>
                      @{u.username}
                    </span>
                  </span>
                </button>
              );
            })
          )}
        </>
      )}
    </Popover>
  );
};

// ─── Iteration ──────────────────────────────────────────────────────

function iterationLabel(it: GitLabIteration): string {
  if (it.title && it.title.trim().length > 0) return it.title;
  // Iterations frequently have null titles — fall back to the date range.
  const fmt = (d: string) => {
    const parts = d.split('-'); // YYYY-MM-DD
    return parts.length === 3 ? `${parts[1]}/${parts[2]}` : d;
  };
  return `${fmt(it.start_date)} → ${fmt(it.due_date)}`;
}

export const IterationPicker: React.FC = () => {
  const iteration = useIssueRefineryStore((s) => s.iteration);
  const candidates = useIssueRefineryStore((s) => s.iterationCandidates);
  const setIteration = useIssueRefineryStore((s) => s.setIteration);

  const has = iteration != null;

  return (
    <Popover
      ariaLabel="Choose iteration"
      testid="ir-iteration-chip"
      onOpen={() => void loadIterationCandidates()}
      triggerLabel={has ? `Iteration: ${iterationLabel(iteration!)}. Change iteration.` : 'Set iteration'}
      triggerStyle={chip({
        bg: color.white,
        fg: has ? ui.textPrimary : ui.textSubtle,
        border: ui.border,
      })}
      trigger={
        <>
          <span aria-hidden="true">◷</span>
          {has ? iterationLabel(iteration!) : 'Iteration'}
        </>
      }
    >
      {(close) => (
        <>
          <button
            type="button"
            data-testid="ir-iteration-option-none"
            onClick={() => {
              setIteration(null);
              close();
            }}
            style={optionStyle(!has)}
          >
            <span aria-hidden="true" style={{ color: ui.textFaint }}>
              ⊘
            </span>
            No iteration
          </button>
          {candidates.length === 0 ? (
            <p style={{ margin: 0, padding: '8px 10px', fontSize: fontSize.xs, color: ui.textFaint }}>
              No iterations found.
            </p>
          ) : (
            candidates.map((it: GitLabIteration) => {
              const selected = iteration?.id === it.id;
              return (
                <button
                  key={it.id}
                  type="button"
                  data-testid={`ir-iteration-option-${it.id}`}
                  onClick={() => {
                    setIteration(it);
                    close();
                  }}
                  style={optionStyle(selected)}
                >
                  <span aria-hidden="true">◷</span>
                  {iterationLabel(it)}
                </button>
              );
            })
          )}
        </>
      )}
    </Popover>
  );
};
