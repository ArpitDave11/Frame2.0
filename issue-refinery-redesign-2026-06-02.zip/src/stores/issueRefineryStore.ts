/**
 * Issue Refinery — Zustand store (R-2).
 *
 * Drives the Issue Refinery tab. All state is in-memory; no persistence.
 * The store holds:
 *   - the selected parent epic + child-issue list (fetched via gitlabStore /
 *     gitlabClient — this store does not fetch anything itself)
 *   - the currently selected child issue
 *   - per-stage pipeline results (comprehension, refinedDraft, validation)
 *   - the FRAME-suggested + effective story-point weight (Phase 2)
 *   - publish-target metadata: assignee, iteration, and the candidate lists
 *   - the published issue URL (drives the "Open in GitLab" affordance)
 *   - phase machine for UI rendering
 *   - dev-only `lastCachedTokens` for prompt-cache verification
 *
 * Phase machine (see `Phase` type):
 *   idle → comprehending → refining → validating → ready → publishing → idle | error
 *
 * Selecting a different child issue clears all per-issue derived state.
 *
 * State lifetimes:
 *   - per-issue (cleared on child switch + epic switch + refine kickoff):
 *     pipeline outputs, suggestedWeight, weight, publishedUrl
 *   - per-issue selection (cleared on child switch + epic switch, NOT on
 *     re-refine): assignee, iteration
 *   - per-epic (cleared on epic switch only): memberCandidates,
 *     iterationCandidates
 */

import { create } from 'zustand';
import type {
  GitLabIssue,
  GitLabUser,
  GitLabIteration,
} from '@/services/gitlab/types';
import type {
  ComprehensionResult,
  Phase,
  ValidationResult,
} from '@/pipeline/issue/types';

export interface SelectedEpic {
  groupId: string;
  epicIid: number;
  title: string;
  body: string;
}

export interface IssueRefineryState {
  // Selection
  selectedEpic: SelectedEpic | null;
  children: GitLabIssue[];
  selectedChildIid: number | null;
  originalBody: string | null;
  originalProjectId: number | null;

  // Pipeline outputs
  comprehension: ComprehensionResult | null;
  refinedDraft: string | null;
  userEditedDraft: boolean;
  validation: ValidationResult | null;

  // Story-point weight (Phase 2)
  /** FRAME's suggested weight (AI estimate or deterministic fallback). */
  suggestedWeight: number | null;
  /** Effective weight published to GitLab — starts at the suggestion, user-editable. */
  weight: number | null;

  // Publish-target metadata (Phase 2)
  assignee: GitLabUser | null;
  iteration: GitLabIteration | null;
  memberCandidates: GitLabUser[];
  iterationCandidates: GitLabIteration[];

  /** web_url of the just-published issue; drives the "Open in GitLab" button. */
  publishedUrl: string | null;

  // Status
  phase: Phase;
  error: string | null;

  // Observability (dev only — populated by the action layer)
  lastCachedTokens: number[];

  // Actions
  setSelectedEpic: (epic: SelectedEpic, children: GitLabIssue[]) => void;
  setSelectedChild: (iid: number) => void;
  setComprehension: (c: ComprehensionResult) => void;
  setRefinedDraft: (draft: string, userEdited: boolean) => void;
  setValidation: (v: ValidationResult) => void;
  setPhase: (p: Phase, error?: string | null) => void;
  recordCachedTokens: (n: number) => void;

  /** Apply a fresh weight suggestion: sets both suggestedWeight and the effective weight. */
  setWeightSuggestion: (points: number) => void;
  /** User override of the effective weight (suggestion is preserved for reference). */
  setWeight: (points: number | null) => void;
  setAssignee: (user: GitLabUser | null) => void;
  setIteration: (iteration: GitLabIteration | null) => void;
  setMemberCandidates: (users: GitLabUser[]) => void;
  setIterationCandidates: (iterations: GitLabIteration[]) => void;
  setPublishedUrl: (url: string | null) => void;

  /**
   * Clear per-issue derived state (comprehension, refinedDraft, validation,
   * weight, publishedUrl, lastCachedTokens, error) without dropping the
   * selected epic / child or the assignee / iteration selection. Used by the
   * action layer at the start of every refine kickoff so that a mid-pipeline
   * failure doesn't leave the UI showing mixed fresh + stale stage outputs.
   */
  clearResults: () => void;
  reset: () => void;
}

const INITIAL_STATE = {
  selectedEpic: null,
  children: [],
  selectedChildIid: null,
  originalBody: null,
  originalProjectId: null,
  comprehension: null,
  refinedDraft: null,
  userEditedDraft: false,
  validation: null,
  suggestedWeight: null,
  weight: null,
  assignee: null,
  iteration: null,
  memberCandidates: [] as GitLabUser[],
  iterationCandidates: [] as GitLabIteration[],
  publishedUrl: null,
  phase: 'idle' as Phase,
  error: null,
  lastCachedTokens: [] as number[],
};

export const useIssueRefineryStore = create<IssueRefineryState>((set, get) => ({
  ...INITIAL_STATE,

  setSelectedEpic: (epic, children) =>
    set({
      selectedEpic: epic,
      children,
      // Selecting a new epic clears the previously selected child, cached
      // pipeline results, weight, publish metadata, and candidate lists —
      // they all belong to the old context.
      selectedChildIid: null,
      originalBody: null,
      originalProjectId: null,
      comprehension: null,
      refinedDraft: null,
      userEditedDraft: false,
      validation: null,
      suggestedWeight: null,
      weight: null,
      assignee: null,
      iteration: null,
      memberCandidates: [],
      iterationCandidates: [],
      publishedUrl: null,
      phase: 'idle',
      error: null,
      lastCachedTokens: [],
    }),

  setSelectedChild: (iid) => {
    const child = get().children.find((c) => c.iid === iid);
    if (!child) {
      // Unknown iid — no-op. Tests assert this.
      return;
    }
    set({
      selectedChildIid: iid,
      originalBody: child.description ?? '',
      originalProjectId: child.project_id ?? null,
      // Clear derived + per-issue state from any prior child. Candidate lists
      // (epic-scoped) are intentionally preserved.
      comprehension: null,
      refinedDraft: null,
      userEditedDraft: false,
      validation: null,
      suggestedWeight: null,
      weight: null,
      assignee: null,
      iteration: null,
      publishedUrl: null,
      phase: 'idle',
      error: null,
      lastCachedTokens: [],
    });
  },

  setComprehension: (c) => set({ comprehension: c }),

  setRefinedDraft: (draft, userEdited) =>
    set({ refinedDraft: draft, userEditedDraft: userEdited }),

  setValidation: (v) => set({ validation: v }),

  setPhase: (p, error = null) => set({ phase: p, error }),

  recordCachedTokens: (n) =>
    set((s) => ({ lastCachedTokens: [...s.lastCachedTokens, n] })),

  setWeightSuggestion: (points) => set({ suggestedWeight: points, weight: points }),

  setWeight: (points) => set({ weight: points }),

  setAssignee: (user) => set({ assignee: user }),

  setIteration: (iteration) => set({ iteration }),

  setMemberCandidates: (users) => set({ memberCandidates: users }),

  setIterationCandidates: (iterations) => set({ iterationCandidates: iterations }),

  setPublishedUrl: (url) => set({ publishedUrl: url }),

  clearResults: () =>
    set({
      comprehension: null,
      refinedDraft: null,
      userEditedDraft: false,
      validation: null,
      suggestedWeight: null,
      weight: null,
      publishedUrl: null,
      error: null,
      lastCachedTokens: [],
    }),

  reset: () => set({ ...INITIAL_STATE, lastCachedTokens: [] }),
}));
