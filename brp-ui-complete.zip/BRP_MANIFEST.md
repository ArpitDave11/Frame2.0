# BRP branch changes — feature/brp ahead of main
# Generated 2026-05-27
# Commits: 44
# Files: 86

## All files (sorted)
.powerstack4/task_plan.md
.taskmaster/config.json
.taskmaster/docs/brp-headless-prd.txt
.taskmaster/docs/brp-ui-complete-prd.txt
.taskmaster/tasks/tasks.json
CLAUDE.md
docs/adr/0003-brp-no-derived-state.md
docs/adr/0004-brp-audit-log.md
docs/adr/0005-brp-llm-swap.md
docs/devlog/2026-05-26-brp-headless.md
docs/devlog/2026-05-27-brp-ui-complete.md
docs/knowledge/domain/brp.md
docs/knowledge/services/brp/README.md
docs/knowledge/services/brp/auditLog.md
docs/knowledge/services/brp/azureEstimator.md
docs/knowledge/services/brp/brpActions.md
docs/knowledge/services/brp/brpGitlabService.md
docs/knowledge/services/brp/simulatedEstimator.md
docs/knowledge/stores/brpStore.md
docs/reviews/2026-05-25-brp-headless-deep-review.md
docs/reviews/acknowledged.md
docs/runbooks/brp-acceptance.md
package-lock.json
package.json
src/components/brp/AnalysisProgress.test.tsx
src/components/brp/AnalysisProgress.tsx
src/components/brp/BrpView.aiAssist.test.tsx
src/components/brp/BrpView.cancel.test.tsx
src/components/brp/BrpView.test.tsx
src/components/brp/BrpView.tsx
src/components/brp/CapacityDialog.suggest.test.tsx
src/components/brp/CapacityDialog.test.tsx
src/components/brp/CapacityDialog.tsx
src/components/brp/CrewSelector.test.tsx
src/components/brp/CrewSelector.tsx
src/components/brp/DetailPanel.test.tsx
src/components/brp/DetailPanel.tsx
src/components/brp/EpicPicker.states.test.tsx
src/components/brp/EpicPicker.test.tsx
src/components/brp/EpicPicker.tsx
src/components/brp/EpicRow.test.tsx
src/components/brp/EpicRow.tsx
src/components/brp/MetricsModal.test.tsx
src/components/brp/MetricsModal.tsx
src/components/brp/PodLoader.test.tsx
src/components/brp/PodLoader.tsx
src/components/brp/PodView.test.tsx
src/components/brp/PodView.tsx
src/components/brp/PortfolioView.test.tsx
src/components/brp/PortfolioView.tsx
src/components/brp/VarianceBadge.test.tsx
src/components/brp/VarianceBadge.tsx
src/components/brp/a11y.contract.test.tsx
src/components/layout/ViewRouter.tsx
src/components/layout/WorkspaceSidebar.tsx
src/domain/brp.constants.ts
src/domain/brp.test.ts
src/domain/brp.ts
src/services/brp/ai/azureEstimator.test.ts
src/services/brp/ai/azureEstimator.ts
src/services/brp/ai/capacityAssistant.test.ts
src/services/brp/ai/capacityAssistant.ts
src/services/brp/ai/duplicateDetector.test.ts
src/services/brp/ai/duplicateDetector.ts
src/services/brp/ai/estimatorProvider.test.ts
src/services/brp/ai/estimatorProvider.ts
src/services/brp/ai/schemas.test.ts
src/services/brp/ai/schemas.ts
src/services/brp/ai/simulatedEstimator.test.ts
src/services/brp/ai/simulatedEstimator.ts
src/services/brp/ai/types.ts
src/services/brp/ai/varianceInterpreter.test.ts
src/services/brp/ai/varianceInterpreter.ts
src/services/brp/auditLog.test.ts
src/services/brp/auditLog.ts
src/services/brp/brpActions.analysis.test.ts
src/services/brp/brpActions.test.ts
src/services/brp/brpActions.ts
src/services/brp/brpGitlabService.live.test.ts
src/services/brp/brpGitlabService.test.ts
src/services/brp/brpGitlabService.ts
src/stores/brpStore.progress.test.ts
src/stores/brpStore.test.ts
src/stores/brpStore.ts
src/stores/uiStore.ts
src/test/integration/brpFiveFlows.test.tsx

## Group: production code (src/)
src/components/brp/AnalysisProgress.tsx
src/components/brp/BrpView.tsx
src/components/brp/CapacityDialog.tsx
src/components/brp/CrewSelector.tsx
src/components/brp/DetailPanel.tsx
src/components/brp/EpicPicker.tsx
src/components/brp/EpicRow.tsx
src/components/brp/MetricsModal.tsx
src/components/brp/PodLoader.tsx
src/components/brp/PodView.tsx
src/components/brp/PortfolioView.tsx
src/components/brp/VarianceBadge.tsx
src/components/layout/ViewRouter.tsx
src/components/layout/WorkspaceSidebar.tsx
src/domain/brp.constants.ts
src/domain/brp.ts
src/services/brp/ai/azureEstimator.ts
src/services/brp/ai/capacityAssistant.ts
src/services/brp/ai/duplicateDetector.ts
src/services/brp/ai/estimatorProvider.ts
src/services/brp/ai/schemas.ts
src/services/brp/ai/simulatedEstimator.ts
src/services/brp/ai/types.ts
src/services/brp/ai/varianceInterpreter.ts
src/services/brp/auditLog.ts
src/services/brp/brpActions.ts
src/services/brp/brpGitlabService.ts
src/stores/brpStore.ts
src/stores/uiStore.ts

## Group: tests
src/components/brp/AnalysisProgress.test.tsx
src/components/brp/BrpView.aiAssist.test.tsx
src/components/brp/BrpView.cancel.test.tsx
src/components/brp/BrpView.test.tsx
src/components/brp/CapacityDialog.suggest.test.tsx
src/components/brp/CapacityDialog.test.tsx
src/components/brp/CrewSelector.test.tsx
src/components/brp/DetailPanel.test.tsx
src/components/brp/EpicPicker.states.test.tsx
src/components/brp/EpicPicker.test.tsx
src/components/brp/EpicRow.test.tsx
src/components/brp/MetricsModal.test.tsx
src/components/brp/PodLoader.test.tsx
src/components/brp/PodView.test.tsx
src/components/brp/PortfolioView.test.tsx
src/components/brp/VarianceBadge.test.tsx
src/components/brp/a11y.contract.test.tsx
src/domain/brp.test.ts
src/services/brp/ai/azureEstimator.test.ts
src/services/brp/ai/capacityAssistant.test.ts
src/services/brp/ai/duplicateDetector.test.ts
src/services/brp/ai/estimatorProvider.test.ts
src/services/brp/ai/schemas.test.ts
src/services/brp/ai/simulatedEstimator.test.ts
src/services/brp/ai/varianceInterpreter.test.ts
src/services/brp/auditLog.test.ts
src/services/brp/brpActions.analysis.test.ts
src/services/brp/brpActions.test.ts
src/services/brp/brpGitlabService.live.test.ts
src/services/brp/brpGitlabService.test.ts
src/stores/brpStore.progress.test.ts
src/stores/brpStore.test.ts
src/test/integration/brpFiveFlows.test.tsx

## Group: docs
docs/adr/0003-brp-no-derived-state.md
docs/adr/0004-brp-audit-log.md
docs/adr/0005-brp-llm-swap.md
docs/devlog/2026-05-26-brp-headless.md
docs/devlog/2026-05-27-brp-ui-complete.md
docs/knowledge/domain/brp.md
docs/knowledge/services/brp/README.md
docs/knowledge/services/brp/auditLog.md
docs/knowledge/services/brp/azureEstimator.md
docs/knowledge/services/brp/brpActions.md
docs/knowledge/services/brp/brpGitlabService.md
docs/knowledge/services/brp/simulatedEstimator.md
docs/knowledge/stores/brpStore.md
docs/reviews/2026-05-25-brp-headless-deep-review.md
docs/reviews/acknowledged.md
docs/runbooks/brp-acceptance.md

## Group: tooling (.taskmaster, .powerstack4, hooks)
.powerstack4/task_plan.md
.taskmaster/config.json
.taskmaster/docs/brp-headless-prd.txt
.taskmaster/docs/brp-ui-complete-prd.txt
.taskmaster/tasks/tasks.json

## Commits
93081df docs(brp): acceptance checklist — P1-P7 complete (B-42)
7770bf6 docs(brp): knowledge base + devlog + CLAUDE.md update (B-40, B-41)
2fd3452 test(brp): a11y contract suite for all BRP components (B-38)
44d238c feat(brp): empty/loading/error states for EpicPicker (B-39)
297bed2 feat(brp): Azure OpenAI estimator + provider swap (B-36, B-37)
1c42402 feat(brp): audit log for significant planner actions (B-35)
0a57ea8 feat(brp): AI-assist variance interpreter + duplicate detection (B-34)
eb681c8 feat(brp): AI-assist capacity prefill (B-33)
70d32e1 fix(brp): deep-review checkpoint #3 — C1/C2/C3/C4/I1/I4 (B-32)
93e81c8 test(brp): integration test for the 5 canonical BRP flows (B-31)
9defec1 feat(brp): brpActions Analysis flow + BrpView handoff (B-30)
5f357af feat(brp): brpActions Load/Capacity flows + BrpView wiring (B-29)
aebeab3 feat(brp): real BrpView routing between Portfolio and Pod (B-27/B-28)
f3cdd24 feat(brp): PodView single-pod inspector (B-26)
648e9a5 feat(brp): PortfolioView dashboard (B-25)
d643980 feat(brp): AnalysisProgress banner (B-24)
fca1c5e feat(brp): CrewSelector + PodLoader + EpicPicker (B-23)
79a8f8b feat(brp): DetailPanel right-rail inspector (B-22)
430d630 feat(brp): EpicRow component (B-21)
7b0005e feat(brp): MetricsModal with recharts (B-20)
b2c38b8 feat(brp): CapacityDialog component (B-19)
6f500ac feat(brp): VarianceBadge component (B-18)
8fcf07e feat(brp): register BRP tab — uiStore + ViewRouter + WorkspaceSidebar (B-17)
65ecae5 feat(brp): widen Result<T> error with code discriminant (B-16, deep-review I8)
8b6b6a5 feat(brp): BrpProgress + onError in runAnalysis (B-15)
25c49e3 chore(brp): install recharts dep + parse P5-P7 PRD (B-14)
80473c1 docs(brp): ADR-0003 + devlog — branch ready for PR (B-13)
cd46ab8 docs(brp): knowledge base for the BRP headless layer (B-12)
557d3b9 fix(brp): coerce numeric GitLab subgroup ids at boundary (live-smoke L1)
5f4569f fix(brp): defensive clone + stale-FrameResult filter + comment cleanup (deep-review I3/I4/I9)
ed4de92 test(brp): deep-review test corrections + additions (C3/I11/I12/I13/I14/I15)
f33ae0c fix(brp): AIEstimator AbortSignal + runAnalysis cancellation (deep-review C1/I1/I2/I7/I10)
e0b5bd6 feat(brp): brpGitlabService live smoke (gated) — P4 complete (B-11)
f16ece4 feat(brp): brpGitlabService skeleton + 20 mocked tests (B-10)
68fded4 feat(brp): deterministic simulatedEstimator + provider — P3 complete (B-9)
20be397 feat(brp): Zod runtime schemas for FrameResult + AnalysisEvent (B-8)
3d7e39d feat(brp): brpStore Navigation/UI/Modal actions — P2 complete (B-7)
1f675bc feat(brp): brpStore Capacity + Estimates + Analysis actions (B-6)
1317156 feat(brp): brpStore state + Loading actions (B-5)
9118464 feat(brp): computePodMetrics + tests — P1 complete (B-4)
737c9e5 feat(brp): computeDelta + computeVariance + 21 tests (B-3)
2624974 feat(brp): computeCapacity + 7 unit tests (B-2)
0158912 feat(brp): pure type model + constants (B-1)
b8801d1 chore(brp): preflight + PRD + task plan (B-0)
