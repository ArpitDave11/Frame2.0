# BRP delta — changes since /Users/arpit/Documents/brp-ui-complete.zip (2026-05-27 09:47)
# Generated 2026-05-27_11:48:32

## Commits since the previous zip
93b5979 fix(brp): wire Load crews + Load pods buttons in PortfolioView

## Files
src/components/brp/BrpView.tsx
src/components/brp/PortfolioView.tsx

## Diff stat
 src/components/brp/BrpView.tsx       |  53 ++++++++++
 src/components/brp/PortfolioView.tsx | 186 +++++++++++++++++++++++++++++++++--
 2 files changed, 230 insertions(+), 9 deletions(-)
