# Config Patch for backend/docmining/app/core/config.py

Add this field to the `AISettings` class:

```python
class AISettings(BaseSettings):
    """Azure OpenAI proxy configuration."""

    model_config = SettingsConfigDict(
        env_prefix="AZURE_OPENAI_",
        extra="ignore",
    )

    api_key: str = ""
    endpoint: str = ""
    deployment: str = ""
    deployment_docex: str = ""   # ← ADD THIS LINE
```

## How it works:

- Key Vault secret: `AZURE-OPENAI-DEPLOYMENT-DOCEX`
- K8s injects as env var: `AZURE_OPENAI_DEPLOYMENT_DOCEX`
- `env_prefix="AZURE_OPENAI_"` strips prefix → field name: `deployment_docex`
- `ai.py` reads: `settings.deployment_docex`
- When `isDocIntel=true` and `deployment_docex` is set → routes to that deployment
- When empty → falls back to default `deployment` (same as pipeline)
