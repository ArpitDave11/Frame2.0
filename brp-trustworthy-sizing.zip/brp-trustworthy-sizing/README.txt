BRP Trustworthy Sizing — changed files (branch feature/brp-trustworthy-sizing)

Apply options at remote:
  A) git apply brp-trustworthy-sizing.patch   (from repo root)
  B) copy the files under src/, docs/, .taskmaster/ over your tree

      51 files. Generated 2026-06-25
