# FRAME 2.0 — DocEX launcher (apply to your FRAME repo)

The FRAME-side change that adds the welcome-screen **"Open DocEX"** button + the full-screen
iframe launcher. It is INDEPENDENT of the DocEX app (the `docEX` zip) — apply this to your **FRAME
2.0** repo. It is intentionally minimal. **Do NOT merge the big `feature/docx-wiring` branch** — that
carries ~220 unrelated files (docIntel, docmining, initiative, gitlab services). Only the pieces
below are the launcher.

## What it does
```
Welcome "Open DocEX" button → openDocex() → uiStore.docexOpen = true
   → <DocExLauncher> renders a fixed full-screen overlay (zIndex 1000):
        slim "← Back to FRAME" bar  +  <iframe src={DOCEX_URL}>
   → DOCEX_URL = import.meta.env.VITE_DOCEX_URL || 'http://localhost:3003'
"← Back to FRAME" → closeDocex() → overlay unmounts
```

## Files touched
| File | Change |
|---|---|
| `src/components/docx/DocxView.tsx` | **NEW** — the launcher (in this zip + in the patch) |
| `src/App.tsx` | import + mount `<DocExLauncher />` |
| `src/components/views/WelcomeScreen.tsx` | the "DocEX — Document Intelligence" banner + "Open DocEX" button |
| `src/stores/uiStore.ts` | `docexOpen` state + `openDocex` / `closeDocex` actions (apply MANUALLY — see step 4) |

## Option 1 — git apply (if your FRAME tree is close to ours)
From the FRAME repo root:
```bash
git apply --stat  frame-docex-launcher.patch    # preview
git apply --check frame-docex-launcher.patch     # dry-run (fails loudly if your tree drifted)
git apply         frame-docex-launcher.patch     # applies DocxView.tsx + App.tsx + WelcomeScreen.tsx
```
Then do the uiStore edit (step 4). If `--check` fails (your `main` drifted from our base), use Option 2.

## Option 2 — manual (always works)
1. **Add the new file:** copy `src/components/docx/DocxView.tsx` from this zip into your FRAME repo at the same path.
2. **`src/App.tsx`** — import at top, mount near the other shell children:
   ```tsx
   import DocExLauncher from '@/components/docx/DocxView';
   // …inside the AuthGuard shell, after <ToastContainer />:
   <DocExLauncher />
   ```
3. **`src/components/views/WelcomeScreen.tsx`** — add the selector + the banner block. The exact
   63-line additive block is the `WelcomeScreen.tsx` hunk in `frame-docex-launcher.patch`
   (`const openDocex = useUiStore((s) => s.openDocex);` + the `{/* DocEX Launcher Banner */}` card
   with `data-testid="welcome-docex"` and `onClick={openDocex}`).
4. **`src/stores/uiStore.ts`** — add ONLY these (the branch also added unrelated tabs/modals — skip those):
   ```ts
   // interface UiState:
   docexOpen: boolean;
   // interface UiActions:
   openDocex: () => void;
   closeDocex: () => void;
   // INITIAL_STATE:
   docexOpen: false,
   // store body (alongside the other actions):
   openDocex: () => { set({ docexOpen: true }); },
   closeDocex: () => { set({ docexOpen: false }); },
   ```

## Production
Set **`VITE_DOCEX_URL=/docex`** in the FRAME build so the iframe loads DocEX **same-origin** behind
the platform ingress. Dev default is `http://localhost:3003` (DocEX's standalone dev server).

## Notes / prerequisites
- `DocxView.tsx` imports `ArrowLeft` from **`@phosphor-icons/react`** (FRAME's icon lib — already
  present) and uses FRAME CSS vars (`--col-border-illustrative`, `--col-text-primary`, …) + Frutiger.
  **No new dependencies.**
- The branch also added a `src/types/remotes.d.ts` stub that removes the old module-federation
  "DocEX remote" types. Only relevant if your FRAME still declares DocEX as an MF remote — otherwise
  ignore it (it isn't needed for the iframe launcher).
- This pairs with the DocEX side already serving at `/docex` (the `docEX` zip: `charts/docx` ingress
  + the SPA built with `VITE_BASE=/docex/`).
