/**
 * DocExLauncher — full-screen overlay that launches the DocEX app as an INDEPENDENT,
 * same-origin app in an iframe (NOT a module-federation remote). Opened from the welcome
 * screen's "DocEX" button (uiStore.docexOpen), closed via "← Back to FRAME".
 *
 * See docx-platform/docs/2026-06-06-integration-same-origin-launch-design.md.
 * Dev:  VITE_DOCEX_URL || http://localhost:3003 (DocEX standalone dev server).
 * Prod: a same-origin path (e.g. /docex) served by the platform ingress.
 */

import { ArrowLeft } from '@phosphor-icons/react';
import { useUiStore } from '@/stores/uiStore';

const DOCEX_URL = import.meta.env.VITE_DOCEX_URL || 'http://localhost:3003';
const FONT = "Frutiger, 'Helvetica Neue', Helvetica, Arial, sans-serif";

export default function DocExLauncher() {
  const docexOpen = useUiStore((s) => s.docexOpen);
  const closeDocex = useUiStore((s) => s.closeDocex);

  if (!docexOpen) return null;

  return (
    <div
      data-testid="docex-launcher"
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 1000,
        display: 'flex',
        flexDirection: 'column',
        background: '#ffffff',
      }}
    >
      {/* Top bar — stays in the FRAME shell with a way back */}
      <div
        style={{
          height: 48,
          flexShrink: 0,
          display: 'flex',
          alignItems: 'center',
          gap: 12,
          padding: '0 16px',
          borderBottom: '1px solid var(--col-border-illustrative, #e0e0e0)',
          background: '#ffffff',
          fontFamily: FONT,
        }}
      >
        <button
          onClick={closeDocex}
          data-testid="docex-back"
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 6,
            padding: '6px 12px',
            border: '1px solid var(--col-border-illustrative, #e0e0e0)',
            borderRadius: 6,
            background: '#ffffff',
            color: 'var(--col-text-primary, #000)',
            cursor: 'pointer',
            fontFamily: FONT,
            fontSize: 13,
            fontWeight: 400,
          }}
          onMouseEnter={(e) => { e.currentTarget.style.background = 'var(--col-background-ui-10, #f5f5f5)'; }}
          onMouseLeave={(e) => { e.currentTarget.style.background = '#ffffff'; }}
        >
          <ArrowLeft size={16} weight="bold" />
          Back to FRAME
        </button>
        <span style={{ fontSize: 13, fontWeight: 500, color: 'var(--col-text-primary, #000)' }}>
          DocEX — Document Intelligence
        </span>
      </div>

      {/* The DocEX app itself (its own React, isolated) */}
      <iframe
        src={DOCEX_URL}
        title="DocEX — Document Intelligence"
        style={{ flex: 1, width: '100%', border: 'none' }}
      />
    </div>
  );
}
