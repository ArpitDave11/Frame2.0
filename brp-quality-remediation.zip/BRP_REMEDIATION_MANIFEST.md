# BRP quality remediation — files changed since brp-ui-complete.zip
# Generated 2026-05-27_23:42:39
# Base: 93b5979 (Load crews/pods buttons fix)
# Head: a9de675
# Branch: feature/brp-quality-remediation

## Commits since base
a9de675 fix(brp): quality remediation — Phase 0-5 (21 atomic tasks)

## Files
src/components/brp/BrpView.test.tsx
src/components/brp/BrpView.tsx
src/components/brp/CrewSelector.tsx
src/components/brp/DetailPanel.tsx
src/components/brp/EpicRow.tsx
src/components/brp/PodView.capacityBreakdown.test.tsx
src/components/brp/PodView.tsx
src/components/brp/PortfolioView.test.tsx
src/components/brp/PortfolioView.tsx
src/components/brp/SummaryStrip.test.tsx
src/components/brp/SummaryStrip.tsx
src/components/brp/VarianceBadge.colors.test.tsx
src/components/brp/VarianceBadge.tsx
src/domain/brp.crewMetrics.test.ts
src/domain/brp.ts
src/styles/global.css
src/test/integration/brpFiveFlows.test.tsx
src/theme/tokens.ts

## Diff stat
 src/components/brp/BrpView.test.tsx                |  19 +-
 src/components/brp/BrpView.tsx                     |  35 +
 src/components/brp/CrewSelector.tsx                |  79 +-
 src/components/brp/DetailPanel.tsx                 |  14 +-
 src/components/brp/EpicRow.tsx                     |  15 +-
 .../brp/PodView.capacityBreakdown.test.tsx         | 146 ++++
 src/components/brp/PodView.tsx                     | 316 ++++++-
 src/components/brp/PortfolioView.test.tsx          | 237 +++++-
 src/components/brp/PortfolioView.tsx               | 911 +++++++++++++++------
 src/components/brp/SummaryStrip.test.tsx           | 109 +++
 src/components/brp/SummaryStrip.tsx                | 140 ++++
 src/components/brp/VarianceBadge.colors.test.tsx   |  72 ++
 src/components/brp/VarianceBadge.tsx               |  34 +-
 src/domain/brp.crewMetrics.test.ts                 | 151 ++++
 src/domain/brp.ts                                  |  71 ++
 src/styles/global.css                              |   2 +-
 src/test/integration/brpFiveFlows.test.tsx         |  43 +-
 src/theme/tokens.ts                                |  26 +-
 18 files changed, 1992 insertions(+), 428 deletions(-)

## Uncommitted hand-edits (working tree vs HEAD)
 M src/components/brp/BrpView.tsx
 M src/components/brp/CrewSelector.tsx
 M src/components/brp/DetailPanel.tsx
 M src/components/brp/EpicRow.tsx
 M src/components/brp/PodView.tsx
 M src/components/brp/PortfolioView.tsx
 M src/styles/global.css
 M src/theme/tokens.ts
