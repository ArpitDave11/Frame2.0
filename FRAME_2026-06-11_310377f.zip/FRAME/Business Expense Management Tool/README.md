
  # Business Expense Management Tool

  This is a code bundle for Business Expense Management Tool. The original project is available at https://www.figma.com/design/UQlh2Cg15FUwYjrBAH9yiA/Business-Expense-Management-Tool.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  